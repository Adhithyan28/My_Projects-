
package com.csvcomparison.tool.service;

import com.csvcomparison.tool.model.RepeatedRecord;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class ResultFileWriter implements AutoCloseable {

    public static final int INDEX_INTERVAL = 1000;

    private final Path file;
    private final BufferedOutputStream outputStream;
    private final List<Long> pageOffsets = new ArrayList<>();

    private long recordCount;
    private long currentOffset;
    private boolean closed;

    public ResultFileWriter(Path file) throws IOException {
        this.file = file;
        this.outputStream = new BufferedOutputStream(
                Files.newOutputStream(file),
                64 * 1024
        );
    }

    public void writeRecord(String[] record) throws IOException {
        ensureOpen();

        if (recordCount % INDEX_INTERVAL == 0) {
            pageOffsets.add(currentOffset);
        }

        byte[] bytes = toCsvLine(record)
                .getBytes(StandardCharsets.UTF_8);

        outputStream.write(bytes);
        currentOffset += bytes.length;
        recordCount++;
    }

    /**
     * Writes a repeated record as:
     * source, key, original CSV row fields...
     */
    public void writeRepeatedRecord(
            RepeatedRecord repeatedRecord
    ) throws IOException {

        ensureOpen();

        if (repeatedRecord == null) {
            throw new IllegalArgumentException(
                    "Repeated record cannot be null."
            );
        }

        String[] originalRecord = repeatedRecord.record();

        if (originalRecord == null) {
            originalRecord = new String[0];
        }

        String[] outputRecord =
                new String[originalRecord.length + 2];

        outputRecord[0] = repeatedRecord.source();
        outputRecord[1] = repeatedRecord.id();

        System.arraycopy(
                originalRecord,
                0,
                outputRecord,
                2,
                originalRecord.length
        );

        writeRecord(outputRecord);
    }

    public long getRecordCount() {
        return recordCount;
    }

    public List<Long> getPageOffsets() {
        return List.copyOf(pageOffsets);
    }

    public Path getFile() {
        return file;
    }

    private void ensureOpen() {
        if (closed) {
            throw new IllegalStateException(
                    "Result file writer is already closed."
            );
        }
    }

    private String toCsvLine(String[] record) {
        StringBuilder builder = new StringBuilder();

        for (int i = 0; i < record.length; i++) {
            if (i > 0) {
                builder.append(',');
            }

            builder.append(escapeCsvValue(record[i]));
        }

        builder.append('\n');
        return builder.toString();
    }

    private String escapeCsvValue(String value) {
        if (value == null) {
            return "";
        }

        boolean requiresQuotes =
                value.contains(",")
                        || value.contains("\"")
                        || value.contains("\n")
                        || value.contains("\r");

        if (!requiresQuotes) {
            return value;
        }

        return "\""
                + value.replace("\"", "\"\"")
                + "\"";
    }

    @Override
    public void close() throws IOException {
        if (closed) {
            return;
        }

        closed = true;
        outputStream.close();
    }
}
