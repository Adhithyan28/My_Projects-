
package com.csvcomparison.tool.model;

import java.util.List;

public record ComparisonResult(
        String comparisonId,
        List<String> headers,
        long addedRecordCount,
        long updatedRecordCount,
        long missingRecordCount,
        long repeatedRecordCount
) {
    /**
     * Backward-compatible constructor for existing callers.
     */
    public ComparisonResult(
            String comparisonId,
            List<String> headers,
            long addedRecordCount,
            long updatedRecordCount
    ) {
        this(
                comparisonId,
                headers,
                addedRecordCount,
                updatedRecordCount,
                0L,
                0L
        );
    }
}
