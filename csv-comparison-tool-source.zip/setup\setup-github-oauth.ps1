$ErrorActionPreference = "Stop"

$scriptDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$projectRoot = Split-Path -Parent $scriptDirectory
$backendDirectory = Join-Path $projectRoot "backend"
$configPath = Join-Path $backendDirectory "oauth.env"

$clientId = Read-Host "GitHub OAuth client ID"
$secretSecure = Read-Host "GitHub OAuth client secret (input hidden)" -AsSecureString
$secretPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secretSecure)
try {
    $clientSecret = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($secretPointer)
}
finally {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($secretPointer)
}

if ([string]::IsNullOrWhiteSpace($clientId) `
        -and [string]::IsNullOrWhiteSpace($clientSecret)) {
    $utf8WithoutBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllLines(
        $configPath,
        @("GITHUB_OAUTH_SETUP_SKIPPED=true"),
        $utf8WithoutBom
    )
    Write-Host "No OAuth credentials entered. Continuing without GitHub integration."
    exit 0
}

if ([string]::IsNullOrWhiteSpace($clientId) `
        -or [string]::IsNullOrWhiteSpace($clientSecret)) {
    Write-Error "Enter both OAuth values, or leave both empty for CSV-only use."
}

$redirectUri = Read-Host "GitHub callback URI [http://localhost:8080/api/connections/github/callback]"
if ([string]::IsNullOrWhiteSpace($redirectUri)) {
    $redirectUri = "http://localhost:8080/api/connections/github/callback"
}

function ConvertTo-PropertyValue([string]$value) {
    if ($value.Contains("`n") -or $value.Contains("`r")) {
        throw "OAuth values cannot contain line breaks."
    }
    return $value
}

$settings = @(
    "GITHUB_OAUTH_CLIENT_ID=$(ConvertTo-PropertyValue $clientId)"
    "GITHUB_OAUTH_CLIENT_SECRET=$(ConvertTo-PropertyValue $clientSecret)"
    "GITHUB_OAUTH_REDIRECT_URI=$(ConvertTo-PropertyValue $redirectUri)"
)
$utf8WithoutBom = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllLines($configPath, $settings, $utf8WithoutBom)

Write-Host "OAuth settings saved to backend\oauth.env."
Write-Host "This file is git-ignored. Restart the backend to load the new settings."
