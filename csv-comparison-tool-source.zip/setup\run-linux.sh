#!/usr/bin/env sh
set -eu

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

if ! command -v bash >/dev/null 2>&1; then
    echo "Bash is required to run the Linux setup script." >&2
    exit 1
fi

exec bash "$SCRIPT_DIR/run-macos.sh"
