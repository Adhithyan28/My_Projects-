$ErrorActionPreference = "Stop"

$scriptDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$jarPath = Join-Path $scriptDirectory "csv-comparison-tool.jar"
$oauthConfigPath = Join-Path $scriptDirectory "oauth.env"

if (-not (Test-Path $jarPath -PathType Leaf)) {
    Write-Error "csv-comparison-tool.jar was not found beside this script."
}

. (Join-Path $scriptDirectory "java-runtime-windows.ps1")
Ensure-JavaRuntime
Import-LocalOAuthEnvironment $oauthConfigPath
Set-LocalOAuthEnvironment $oauthConfigPath

$preferredPort = if ($env:PORT) { [int]$env:PORT } else { 8080 }
$port = Find-FreePort $preferredPort
if ($port -ne $preferredPort) {
    Write-Host "Port $preferredPort is busy; using port $port instead." -ForegroundColor Yellow
}
Set-LocalApplicationUrls $port

Set-Location $scriptDirectory
Write-Host "Starting the embedded frontend and backend at http://localhost:$port"
$server = Start-Process `
    -FilePath "java" `
    -ArgumentList @("-jar", "`"$jarPath`"", "--server.port=$port") `
    -WorkingDirectory $scriptDirectory `
    -PassThru `
    -NoNewWindow

try {
    $ready = $false
    for ($attempt = 0; $attempt -lt 60; $attempt++) {
        if ($server.HasExited) {
            throw "The application stopped before it was ready."
        }

        try {
            $response = Invoke-WebRequest `
                -Uri "http://localhost:$port/" `
                -UseBasicParsing `
                -TimeoutSec 2
            if ($response.StatusCode -eq 200) {
                $ready = $true
                break
            }
        }
        catch {
            Start-Sleep -Seconds 1
        }
    }

    if (-not $ready) {
        throw "The application did not become ready. Check the Java output above."
    }

    Start-Process "http://localhost:$port"
    Write-Host "Application is ready. Press Ctrl+C in this window to stop it."
    $server.WaitForExit()
    exit $server.ExitCode
}
finally {
    if (-not $server.HasExited) {
        Stop-Process -Id $server.Id -Force
    }
}
