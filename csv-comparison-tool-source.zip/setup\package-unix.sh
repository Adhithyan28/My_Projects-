#!/usr/bin/env sh
set -eu

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
PROJECT_ROOT=$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd)
FRONTEND_DIR="$PROJECT_ROOT/frontend"
BACKEND_DIR="$PROJECT_ROOT/backend"
RELEASE_DIR="$PROJECT_ROOT/release"
ARCHIVE_PATH="$RELEASE_DIR/csv-comparison-tool.zip"
STAGE_DIR=$(mktemp -d "${TMPDIR:-/tmp}/csv-comparison-tool.XXXXXX")

cleanup() {
    rm -rf -- "$STAGE_DIR"
}
trap cleanup EXIT HUP INT TERM

mkdir -p "$RELEASE_DIR"

cd "$FRONTEND_DIR"
npm install --no-package-lock --no-audit --no-fund
npm run build

cd "$BACKEND_DIR"
./mvnw -q clean package -Pdistribution -DskipTests

cp "$BACKEND_DIR/target/backend-0.0.1-SNAPSHOT.jar" \
    "$STAGE_DIR/csv-comparison-tool.jar"
cp "$SCRIPT_DIR/run-package-windows.ps1" "$STAGE_DIR/"
cp "$SCRIPT_DIR/start-package-windows.bat" \
    "$STAGE_DIR/Start-CSV-Comparison-Tool.bat"
cp "$SCRIPT_DIR/Start-CSV-Comparison-Tool.command" "$STAGE_DIR/"
cp "$SCRIPT_DIR/Start-CSV-Comparison-Tool-linux.sh" "$STAGE_DIR/"
chmod +x "$STAGE_DIR/Start-CSV-Comparison-Tool.command" \
    "$STAGE_DIR/Start-CSV-Comparison-Tool-linux.sh"
cp "$SCRIPT_DIR/run-package-unix.sh" "$STAGE_DIR/"
cp "$SCRIPT_DIR/java-runtime-windows.ps1" "$STAGE_DIR/"
cp "$SCRIPT_DIR/java-runtime-unix.sh" "$STAGE_DIR/"
cp "$PROJECT_ROOT/DEPLOYMENT.md" "$STAGE_DIR/README.md"
cp "$PROJECT_ROOT/User-guide.html" "$STAGE_DIR/"
cp "$PROJECT_ROOT/csv-comparison-developer-guide.html" "$STAGE_DIR/"

SOURCE_DIR="$STAGE_DIR/source-code"
mkdir -p "$SOURCE_DIR/backend" "$SOURCE_DIR/frontend"
cp -R "$BACKEND_DIR/src" "$SOURCE_DIR/backend/"
cp -R "$BACKEND_DIR/.mvn" "$SOURCE_DIR/backend/"
cp "$BACKEND_DIR/pom.xml" "$BACKEND_DIR/mvnw" "$BACKEND_DIR/mvnw.cmd" \
    "$BACKEND_DIR/.gitignore" "$BACKEND_DIR/REPOSITORY_PROVIDERS.md" \
    "$SOURCE_DIR/backend/"

cp -R "$FRONTEND_DIR/src" "$FRONTEND_DIR/public" "$SOURCE_DIR/frontend/"
cp "$FRONTEND_DIR/package.json" "$FRONTEND_DIR/package-lock.json" \
    "$FRONTEND_DIR/index.html" "$FRONTEND_DIR/vite.config.ts" \
    "$FRONTEND_DIR/tsconfig.json" "$FRONTEND_DIR/tsconfig.app.json" \
    "$FRONTEND_DIR/tsconfig.node.json" "$FRONTEND_DIR/eslint.config.js" \
    "$FRONTEND_DIR/.gitignore" "$SOURCE_DIR/frontend/"
cp -R "$SCRIPT_DIR" "$SOURCE_DIR/setup"
cp "$PROJECT_ROOT/DEPLOYMENT.md" "$PROJECT_ROOT/User-guide.html" \
    "$PROJECT_ROOT/csv-comparison-developer-guide.html" "$SOURCE_DIR/"

cat > "$SOURCE_DIR/SOURCE-README.md" <<'EOF'
# Source code package

This archive contains the editable backend and frontend source for CSV Comparison Tool.

Requirements: Java 21+, Node.js/npm, and network access to download Maven/npm dependencies.

Backend:
  cd backend
  chmod +x mvnw
  ./mvnw test

Frontend:
  cd frontend
  npm ci
  npm run build

For local development startup scripts, OAuth setup, architecture, and adding a
repository platform, see DEPLOYMENT.md, backend/REPOSITORY_PROVIDERS.md, and
csv-comparison-developer-guide.html.

Build output, installed dependencies, IDE settings, runtime logs, and local
OAuth credentials are intentionally excluded. Create backend/oauth.env locally
for GitHub OAuth; never commit or share it.
EOF

(
    cd "$SOURCE_DIR"
    zip -q -r "$STAGE_DIR/source-code.zip" .
)
rm -rf -- "$SOURCE_DIR"

mkdir -p "$RELEASE_DIR"
rm -f -- "$ARCHIVE_PATH"
cd "$STAGE_DIR"
zip -q -r "$ARCHIVE_PATH" .

echo "Created: $ARCHIVE_PATH"
