package com.csvcomparison.tool.engine;

import com.csvcomparison.tool.exception.CsvValidationException;
import com.univocity.parsers.csv.CsvParser;
import com.univocity.parsers.csv.CsvParserSettings;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

@Component
public class CsvHeaderValidator {

    public String[] validateAndGetHeader(
            Path oldCsv,
            Path newCsv
    ) throws IOException {

        String[] oldHeader =
                readHeader(oldCsv);

        String[] newHeader =
                readHeader(newCsv);

        validateHeaders(
                oldHeader,
                newHeader
        );

        return newHeader;
    }

    private String[] readHeader(
            Path csvFile
    ) throws IOException {

        CsvParserSettings settings =
                new CsvParserSettings();

        settings.setHeaderExtractionEnabled(false);
        settings.setLineSeparatorDetectionEnabled(true);

        CsvParser parser =
                new CsvParser(settings);

        parser.beginParsing(
                csvFile.toFile()
        );

        try {

            String[] header =
                    parser.parseNext();

            if (header == null
                    || header.length == 0) {

                throw new CsvValidationException(
                        "CSV file is empty: "
                                + csvFile.getFileName()
                );
            }

            validateHeaderNames(
                    header
            );

            return header;

        } finally {

            parser.stopParsing();
        }
    }

    private void validateHeaders(
            String[] oldHeader,
            String[] newHeader
    ) {

        if (oldHeader.length != newHeader.length) {

            throw new CsvValidationException(
                    "CSV files have different column counts."
            );
        }

        if (!Arrays.equals(
                oldHeader,
                newHeader
        )) {

            throw new CsvValidationException(
                    "CSV files have different headers."
            );
        }
    }

        private void validateHeaderNames(
                String[] header
        ) {

            Set<String> columnNames =
                    new HashSet<>();

            for (String column : header) {

                if (column == null
                        || column.isBlank()) {

                    throw new CsvValidationException(
                            "CSV contains an empty column name."
                    );
                }

                if (!columnNames.add(column)) {

                    throw new CsvValidationException(
                            "CSV contains duplicate column name '"
                                    + column
                                    + "'."
                    );
            }
        }
    }
}