package com.csvcomparison.tool.engine;

import com.csvcomparison.tool.config.CsvComparisonProperties;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Set;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ExternalSorterTest {

    @TempDir
    Path tempDirectory;

    @Test
    void sortedChunkSetDeletesAllChunkFilesWhenClosed() throws Exception {
        Path chunksDirectory = Files.createDirectory(
                tempDirectory.resolve("chunks")
        );
        Path nestedDirectory = Files.createDirectory(
                chunksDirectory.resolve("nested")
        );
        Files.writeString(nestedDirectory.resolve("chunk.csv"), "id\n1\n");

        ExternalSorter.SortedChunks chunks =
                new ExternalSorter.SortedChunks(
                        chunksDirectory,
                        java.util.List.of(
                                nestedDirectory.resolve("chunk.csv")
                        )
                );
        chunks.close();

        assertFalse(Files.exists(chunksDirectory));
    }

    @Test
    void sorterRemovesTemporaryChunksAfterSuccess() throws Exception {
        CsvComparisonProperties properties = new CsvComparisonProperties();
        properties.setChunkSize("1B");
        ExternalSorter sorter = new ExternalSorter(properties);
        Path input = Files.writeString(
                tempDirectory.resolve("input.csv"),
                "id,value\n2,b\n1,a\n"
        );

        ExternalSorter.SortedChunks chunks =
                sorter.sortWithOriginalPosition(input);
        Path chunkDirectory = chunks.directory();
        assertTrue(Files.exists(chunkDirectory));

        chunks.close();

        assertFalse(Files.exists(chunkDirectory));
    }

    @Test
    void sorterRemovesChunksWhenInputValidationFails() throws Exception {
        CsvComparisonProperties properties = new CsvComparisonProperties();
        properties.setChunkSize("1B");
        ExternalSorter sorter = new ExternalSorter(properties);
        Path input = Files.writeString(
                tempDirectory.resolve("invalid.csv"),
                "id,value\n1,ok\n,invalid\n"
        );
        Path systemTemporaryDirectory = Path.of(
                System.getProperty("java.io.tmpdir")
        );
        Set<String> before = temporaryChunkDirectories(
                systemTemporaryDirectory
        );

        assertThrows(
                RuntimeException.class,
                () -> sorter.sortWithOriginalPosition(input)
        );

        assertEquals(
                before,
                temporaryChunkDirectories(systemTemporaryDirectory)
        );
    }

    private Set<String> temporaryChunkDirectories(Path parent)
            throws Exception {
        try (var entries = Files.list(parent)) {
            return entries
                    .filter(Files::isDirectory)
                    .map(path -> path.getFileName().toString())
                    .filter(name -> name.startsWith("csv-comparison-"))
                    .collect(Collectors.toSet());
        }
    }
}
