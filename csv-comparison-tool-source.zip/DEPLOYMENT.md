# Cross-platform deployment package

Create a distributable ZIP from the project root:

- Windows: `.\setup\package-windows.ps1`
- macOS/Linux: `bash setup/package-unix.sh`

The ZIP is written to `release/csv-comparison-tool.zip`. It contains a
platform-independent Spring Boot executable JAR with the built frontend
embedded, platform launchers and runtime-install helpers, plus
`User-guide.html`, `csv-comparison-developer-guide.html`, and a
`source-code.zip` containing the editable backend/frontend source and
development scripts. The source archive excludes build outputs, installed
dependencies, IDE files, logs, and OAuth credentials. The launcher
checks for Java 21+ and offers to install it using winget (Windows), Homebrew
(macOS), or apt/dnf (Linux). No separate Node.js, Maven, or frontend server is
needed on the target computer.

Extract the ZIP, configure GitHub OAuth if repository features are needed,
then start the application:

- Windows: double-click `Start-CSV-Comparison-Tool.bat`, or use
  `powershell -ExecutionPolicy Bypass -File .\run-package-windows.ps1`
- macOS: `bash ./Start-CSV-Comparison-Tool.command`
- Linux: `bash ./Start-CSV-Comparison-Tool-linux.sh`

The OS buttons in `User-guide.html` download the matching launcher when the
guide is opened from the extracted package. Browsers intentionally do not
execute local programs; save the launcher beside the JAR and start it using
the OS-specific instructions in the guide.

The launcher tries port 8080 and selects the next available port if it is
already occupied. It starts the backend, serves the embedded frontend, waits
for the application to become ready, and opens the browser at the selected
`http://localhost:<port>` URL.

Before using external sort for a comparison, the app checks free space on the
system temporary-storage volume. It requires an estimate of three times the
combined CSV input size plus a 64 MB safety reserve. Sorted chunk folders are
deleted after merging and also when sorting or comparison fails. If temporary
file deletion fails, the cleanup error is reported rather than silently
ignored.
On first launch, it asks whether to configure GitHub OAuth and offers to save
the credentials locally; leave both values blank to use CSV-only mode. The
saved `oauth.env` file is beside the launcher and is not included in the ZIP.
If OAuth was skipped, stop the application and run the launcher again to be
prompted; after credentials are saved, later starts reuse them.
OAuth values are exported as environment variables to the application process
each time it starts; they are not written to the operating system's global
environment.

When repository comparison results are published, the new branch contains
`added.csv`, `updated.csv`, and `updated-changes.xlsx` in the selected output
directory. The workbook's `Updated` sheet highlights changed latest values in
yellow; the matching `Previous` sheet shows the prior values in the same row
order. The CSV remains unchanged and machine-readable.

The source-project run scripts (`setup/run-windows.ps1` on Windows,
`bash setup/run-macos.sh` on macOS, and `bash setup/run-linux.sh` on Linux)
offer to configure OAuth on first launch. They save settings to the git-ignored
`backend/oauth.env`, export them to the backend process, and reuse that file on
later launches. You can also run
`.\setup\setup-github-oauth.ps1` or `bash setup/setup-github-oauth.sh`
directly to configure or replace credentials. Restart the app after changing
OAuth settings.

Register an OAuth app with callback URI
`http://localhost:8080/api/connections/github/callback` when running locally.
If port 8080 is occupied, the launcher automatically adjusts the callback
environment variable to the selected port. Update the callback URL in your
GitHub OAuth app to that selected port before connecting; GitHub requires an
exact callback URL match. Alternatively, stop the other service or set `PORT`
to a free port already registered in your OAuth app. Set `APP_FRONTEND_URL` if
the OAuth callback should return to a different UI URL. Credentials are stored
as a local plaintext file; restrict access to the file and never include it
when sharing the project or ZIP.

Build requirements for creating the ZIP are Java 21+, Node.js/npm, `zip` on
macOS/Linux, and network access for dependencies. Run
`setup/setup-windows.ps1` or `bash setup/setup-macos.sh` first if the build
tools need to be installed.

The repository does not contain OAuth credentials. If a credential was
previously committed or shared, revoke/rotate it in the GitHub OAuth app
settings before using this package.
