#!/bin/bash

set -e

echo ""
echo "========================================"
echo "       CSV Comparison Tool - Setup"
echo "========================================"
echo ""

# --------------------------------------------------
# Helper functions
# --------------------------------------------------

command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# --------------------------------------------------
# Homebrew
# --------------------------------------------------

echo "Checking Homebrew..."

if command_exists brew; then
    echo "Homebrew detected: $(brew --version | head -n 1)"
else
    echo ""
    echo "Homebrew is not installed."
    echo "Homebrew is required to install Java and Node.js automatically."
    echo ""

    read -r -p "Install Homebrew now? [Y/n] " answer

    if [[ -z "$answer" || "$answer" =~ ^[Yy]$ ]]; then
        echo ""
        echo "Installing Homebrew..."

        /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

        echo ""
        echo "Homebrew installation completed."
        echo "Please restart this Terminal and run this setup script again."
        exit 0
    else
        echo "Homebrew installation skipped."
        echo "Please install Java 21 and Node.js manually."
        exit 1
    fi
fi

# --------------------------------------------------
# Java
# --------------------------------------------------

echo ""
echo "Checking Java..."

java_major=""

if command_exists java; then
    java_version_output=$(java -version 2>&1 | head -n 1)

    if [[ "$java_version_output" =~ \"([0-9]+) ]]; then
        java_major="${BASH_REMATCH[1]}"
    fi
fi

if [[ -n "$java_major" && "$java_major" -ge 21 ]]; then
    echo "Java $java_major detected."
else
    if [[ -z "$java_major" ]]; then
        echo "Java 21 or newer was not found."
    else
        echo "Java $java_major detected, but Java 21 or newer is required."
    fi

    read -r -p "Install Java 21 now? [Y/n] " answer

    if [[ -z "$answer" || "$answer" =~ ^[Yy]$ ]]; then
        echo ""
        echo "Installing Java 21..."

        brew install --cask temurin@21

        echo ""
        echo "Java 21 installation completed."
        echo "Please restart this Terminal and run this setup script again."
        exit 0
    else
        echo "Java installation skipped."
        exit 1
    fi
fi

# --------------------------------------------------
# Node.js / npm
# --------------------------------------------------

echo ""
echo "Checking Node.js..."

if command_exists node && command_exists npm; then
    node_version=$(node --version)
    npm_version=$(npm --version)

    echo "Node.js $node_version detected."
    echo "npm $npm_version detected."
else
    echo "Node.js and/or npm were not found."

    read -r -p "Install Node.js now? [Y/n] " answer

    if [[ -z "$answer" || "$answer" =~ ^[Yy]$ ]]; then
        echo ""
        echo "Installing Node.js..."

        brew install node@24
        brew link --overwrite --force node@24

        echo ""
        echo "Node.js installation completed."
        echo "Please restart this Terminal and run this setup script again."
        exit 0
    else
        echo "Node.js installation skipped."
        exit 1
    fi
fi

# --------------------------------------------------
# Frontend dependencies
# --------------------------------------------------

echo ""
echo "Installing frontend dependencies..."

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
FRONTEND_DIR="$PROJECT_ROOT/frontend"

if [[ ! -d "$FRONTEND_DIR" ]]; then
    echo "Frontend directory was not found:"
    echo "$FRONTEND_DIR"
    exit 1
fi

cd "$FRONTEND_DIR"

npm install

# --------------------------------------------------
# Complete
# --------------------------------------------------

echo ""
echo "========================================"
echo "          Setup completed!"
echo "========================================"
echo ""
echo "To start the application:"
echo ""
echo "Backend:"
echo "  cd backend"
echo "  chmod +x mvnw"
echo "  ./mvnw spring-boot:run"
echo ""
echo "Frontend (open another terminal):"
echo "  cd frontend"
echo "  npm run dev"
echo ""
echo "Then open the URL shown by Vite, normally:"
echo "  http://localhost:5173"
echo ""