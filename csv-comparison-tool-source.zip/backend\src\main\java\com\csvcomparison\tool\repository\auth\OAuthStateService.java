
package com.csvcomparison.tool.repository.auth;

import java.security.SecureRandom;
import java.util.Base64;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Service;

/**
 * Creates and validates OAuth state values using the HTTP session.
 */
@Service
public class OAuthStateService {

    private static final String SESSION_STATE_KEY =
            "github_oauth_state";

    private static final SecureRandom SECURE_RANDOM =
            new SecureRandom();

    /**
     * Creates a new state value and stores it in the user's session.
     */
    public String createState(HttpSession session) {
        return createState(session, "github");
    }

    public String createState(HttpSession session, String provider) {
        byte[] randomBytes = new byte[32];
        SECURE_RANDOM.nextBytes(randomBytes);

        String state = Base64.getUrlEncoder()
                .withoutPadding()
                .encodeToString(randomBytes);

        session.setAttribute(stateKey(provider), state);

        return state;
    }

    /**
     * Validates the returned state and consumes the stored value.
     * A state value can be successfully validated only once.
     */
    public boolean validateAndConsumeState(
            HttpSession session,
            String returnedState) {
        return validateAndConsumeState(session, returnedState, "github");
    }

    public boolean validateAndConsumeState(
            HttpSession session,
            String returnedState,
            String provider) {

        if (session == null
                || returnedState == null
                || returnedState.isBlank()) {
            return false;
        }

        Object storedValue =
                session.getAttribute(stateKey(provider));

        // Remove before returning, preventing reuse.
        session.removeAttribute(stateKey(provider));

        if (!(storedValue instanceof String expectedState)) {
            return false;
        }

        return java.security.MessageDigest.isEqual(
                expectedState.getBytes(
                        java.nio.charset.StandardCharsets.UTF_8),
                returnedState.getBytes(
                        java.nio.charset.StandardCharsets.UTF_8));
    }

    private String stateKey(String provider) {
        return SESSION_STATE_KEY.replace("github", provider.toLowerCase());
    }
}