
import { useEffect, useState } from 'react'
import './RepositoryWorkspace.css'

const API_BASE =
    import.meta.env.VITE_API_BASE_URL ?? ''

type Provider = 'github' | 'gitlab' | 'bitbucket'
type ResultType = 'ADDED' | 'UPDATED' | 'MISSING' | 'REPEATED'

type Repository = {
    id: string
    fullName: string
    defaultBranch: string
    description?: string
}

type ComparisonSummary = {
    comparisonId: string
    headers: string[]
    addedRecordCount: number
    updatedRecordCount: number
    missingRecordCount: number
    repeatedRecordCount: number
}

type RepeatedRecord = {
    source: 'PREVIOUS' | 'LATEST'
    id: string
    record: string[]
}

type RepositoryResultPage = {
    records?: string[][]
    repeatedRecords?: RepeatedRecord[]
    page: number
    size: number
    totalRecords: number
    totalPages: number
}

type PublishedFile = {
    destinationPath: string
    fileUrl?: string
}

type PublishResult = {
    repository: string
    branchName: string
    destinationPath?: string
    updatedDestinationPath?: string
    highlightedReportDestinationPath?: string
    commitSha: string
    commitUrl: string
    fileUrl?: string
    updatedFileUrl?: string
    highlightedReportUrl?: string
    message: string
    files?: PublishedFile[]
}

type RepositoryWorkspaceProps = {
    onUseLocalFiles: () => void
}

const PAGE_SIZE = 100

export default function RepositoryWorkspace({
                                                onUseLocalFiles,
                                            }: RepositoryWorkspaceProps) {
    const [provider, setProvider] = useState<Provider>('github')

    const [connected, setConnected] = useState(
        () =>
            new URLSearchParams(window.location.search).get('connected') ===
            'github',
    )

    const [repositories, setRepositories] = useState<Repository[]>([])
    const [repositoryId, setRepositoryId] = useState('')

    const [branches, setBranches] = useState<string[]>([])
    const [oldBranch, setOldBranch] = useState('')
    const [newBranch, setNewBranch] = useState('')

    const [oldFiles, setOldFiles] = useState<string[]>([])
    const [newFiles, setNewFiles] = useState<string[]>([])
    const [oldPath, setOldPath] = useState('')
    const [newPath, setNewPath] = useState('')

    const [loading, setLoading] = useState(false)
    const [resultsLoading, setResultsLoading] = useState(false)
    const [publishLoading, setPublishLoading] = useState(false)
    const [error, setError] = useState('')

    const [comparisonResult, setComparisonResult] =
        useState<ComparisonSummary | null>(null)

    const [publishResult, setPublishResult] =
        useState<PublishResult | null>(null)

    const [selectedResult, setSelectedResult] =
        useState<ResultType>('ADDED')

    const [records, setRecords] = useState<string[][]>([])
    const [repeatedRecords, setRepeatedRecords] =
        useState<RepeatedRecord[]>([])

    const [currentPage, setCurrentPage] = useState(0)
    const [totalRecords, setTotalRecords] = useState(0)
    const [totalPages, setTotalPages] = useState(0)

    async function requestJson<T>(
        path: string,
        options?: RequestInit,
    ): Promise<T> {
        const response = await fetch(`${API_BASE}${path}`, {
            ...options,
            credentials: 'include',
            headers: {
                ...(options?.body
                    ? { 'Content-Type': 'application/json' }
                    : {}),
                ...options?.headers,
            },
        })

        if (!response.ok) {
            let message =
                `Request failed (${response.status}). Please try again.`

            try {
                const body = await response.json()
                message = body?.message || body?.error || message
            } catch {
                // The response may not contain JSON.
            }

            if (response.status === 401) {
                throw new Error(
                    'Your GitHub connection is missing or expired. Please connect again.',
                )
            }

            throw new Error(message)
        }

        return response.json() as Promise<T>
    }

    function resetComparison(): void {
        setComparisonResult(null)
        setPublishResult(null)
        setRecords([])
        setRepeatedRecords([])
        setSelectedResult('ADDED')
        setCurrentPage(0)
        setTotalRecords(0)
        setTotalPages(0)
    }

    // Handle the OAuth callback after GitHub redirects back to the app.
    useEffect(() => {
        const params = new URLSearchParams(window.location.search)
        const callbackError = params.get('githubError')
        const callbackConnected = params.get('connected') === 'github'

        if (callbackError) {
            const messages: Record<string, string> = {
                access_denied: 'GitHub authorization was denied.',
                missing_code:
                    'GitHub did not return an authorization code.',
                invalid_state:
                    'OAuth state validation failed. Please start the connection again.',
                token_exchange_failed:
                    'GitHub token exchange failed. Check the OAuth application configuration.',
            }

            setError(
                messages[callbackError] ??
                'GitHub authorization failed. Please try again.',
            )
            setConnected(false)
            window.history.replaceState({}, '', window.location.pathname)
            return
        }

        if (callbackConnected) {
            setConnected(true)
            window.history.replaceState({}, '', window.location.pathname)
        }
    }, [])

    // Load repositories after GitHub is connected.
    useEffect(() => {
        if (!connected) {
            setRepositories([])
            setLoading(false)
            return
        }

        let cancelled = false

        async function fetchRepositories(): Promise<void> {
            setLoading(true)
            setError('')

            try {
                const data = await requestJson<Repository[]>(
                    '/api/repositories?provider=github',
                )

                if (!Array.isArray(data)) {
                    throw new Error(
                        'The backend returned an invalid repository list.',
                    )
                }

                if (!cancelled) {
                    setRepositories(data)
                }
            } catch (err) {
                if (!cancelled) {
                    setRepositories([])
                    setError(
                        err instanceof Error
                            ? err.message
                            : 'Could not load repositories.',
                    )

                    if (
                        err instanceof Error &&
                        err.message.includes(
                            'connection is missing or expired',
                        )
                    ) {
                        setConnected(false)
                    }
                }
            } finally {
                if (!cancelled) {
                    setLoading(false)
                }
            }
        }

        void fetchRepositories()

        return () => {
            cancelled = true
        }
    }, [connected])

    async function connectGitHub(): Promise<void> {
        setLoading(true)
        setError('')

        try {
            const response = await fetch(
                `${API_BASE}/api/connections/github/authorize`,
                {
                    method: 'GET',
                    credentials: 'include',
                },
            )

            if (!response.ok) {
                const errorBody = await response.json().catch(() => null)
                throw new Error(
                    errorBody?.error ||
                    `Authorization endpoint returned HTTP ${response.status}.`,
                )
            }

            const data: { authorizationUrl: string } =
                await response.json()

            if (!data.authorizationUrl) {
                throw new Error(
                    'The backend did not return an authorization URL.',
                )
            }

            const authorizationUrl = new URL(data.authorizationUrl)

            if (
                authorizationUrl.protocol !== 'https:' ||
                !['github.com', 'www.github.com'].includes(
                    authorizationUrl.hostname,
                ) ||
                authorizationUrl.pathname !== '/login/oauth/authorize'
            ) {
                throw new Error(
                    'The backend returned an invalid GitHub authorization URL.',
                )
            }

            window.location.href = authorizationUrl.toString()
        } catch (err) {
            setError(
                err instanceof Error
                    ? err.message
                    : 'Could not start GitHub authorization.',
            )
            setLoading(false)
        }
    }

    // Fetch CSV files from one repository branch.
    async function fetchCsvFiles(
        id: string,
        branch: string,
    ): Promise<string[]> {
        const data = await requestJson<string[]>(
            `/api/repositories/${encodeURIComponent(id)}/files?provider=${encodeURIComponent(provider)}&branch=${encodeURIComponent(branch)}`,
        )

        if (!Array.isArray(data)) {
            throw new Error(
                'The backend returned an invalid file list.',
            )
        }

        return data.filter(
            (path) =>
                typeof path === 'string' &&
                path.toLowerCase().endsWith('.csv'),
        )
    }

    // Selecting a repository automatically loads its branches and CSV files.
    async function selectRepository(id: string): Promise<void> {
        setRepositoryId(id)
        setBranches([])
        setOldBranch('')
        setNewBranch('')
        setOldFiles([])
        setNewFiles([])
        setOldPath('')
        setNewPath('')
        setError('')
        resetComparison()

        if (!id) {
            return
        }

        setLoading(true)

        try {
            const branchData = await requestJson<string[]>(
                `/api/repositories/${encodeURIComponent(id)}/branches?provider=${encodeURIComponent(provider)}`,
            )

            if (!Array.isArray(branchData)) {
                throw new Error(
                    'The backend returned an invalid branch list.',
                )
            }

            setBranches(branchData)

            const repository = repositories.find(
                (item) => item.id === id,
            )

            const defaultBranch =
                repository?.defaultBranch ?? branchData[0] ?? ''

            if (!defaultBranch) {
                setError(
                    'No branches were found for this repository.',
                )
                return
            }

            setOldBranch(defaultBranch)
            setNewBranch(defaultBranch)

            // Fetch the selected branch's CSV list once and populate both
            // dropdowns because both initially use the same branch.
            const csvFiles = await fetchCsvFiles(id, defaultBranch)

            setOldFiles(csvFiles)
            setNewFiles(csvFiles)

            if (csvFiles.length === 0) {
                setError(
                    `No CSV files were found on branch "${defaultBranch}".`,
                )
            }
        } catch (err) {
            setError(
                err instanceof Error
                    ? err.message
                    : 'Could not load repository branches or CSV files.',
            )
        } finally {
            setLoading(false)
        }
    }

    // Refresh the appropriate CSV dropdown when its branch changes.
    async function loadFiles(
        branch: string,
        version: 'old' | 'new',
    ): Promise<void> {
        if (!repositoryId || !branch) {
            if (version === 'old') {
                setOldFiles([])
                setOldPath('')
            } else {
                setNewFiles([])
                setNewPath('')
            }
            return
        }

        setError('')
        setLoading(true)

        try {
            const csvFiles = await fetchCsvFiles(repositoryId, branch)

            if (version === 'old') {
                setOldFiles(csvFiles)
                setOldPath('')
            } else {
                setNewFiles(csvFiles)
                setNewPath('')
            }

            if (csvFiles.length === 0) {
                setError(
                    `No CSV files were found on branch "${branch}".`,
                )
            }
        } catch (err) {
            if (version === 'old') {
                setOldFiles([])
                setOldPath('')
            } else {
                setNewFiles([])
                setNewPath('')
            }

            setError(
                err instanceof Error
                    ? err.message
                    : 'Could not load CSV files.',
            )
        } finally {
            setLoading(false)
        }
    }

    async function loadRepositoryResults(
        comparisonId: string,
        type: ResultType,
        page = 0,
    ): Promise<void> {
        setResultsLoading(true)
        setError('')

        try {
            const data = await requestJson<RepositoryResultPage>(
                `/api/comparisons/${encodeURIComponent(comparisonId)}/results/${type}?page=${page}&size=${PAGE_SIZE}`,
            )

            if (
                !data ||
                (!Array.isArray(data.records) &&
                    !Array.isArray(data.repeatedRecords))
            ) {
                throw new Error(
                    'The backend returned an invalid results page. Check the ResultPage response structure.',
                )
            }

            setRecords(data.records ?? [])
            setRepeatedRecords(data.repeatedRecords ?? [])
            setCurrentPage(data.page)
            setTotalRecords(data.totalRecords)
            setTotalPages(data.totalPages)
            setSelectedResult(type)
        } catch (err) {
            setRecords([])
            setRepeatedRecords([])
            setError(
                err instanceof Error
                    ? err.message
                    : 'Could not load comparison results.',
            )
        } finally {
            setResultsLoading(false)
        }
    }

    async function handleCompare(): Promise<void> {
        if (
            !repositoryId ||
            !oldBranch ||
            !newBranch ||
            !oldPath ||
            !newPath
        ) {
            setError(
                'Choose a repository, both branches, and both CSV files.',
            )
            return
        }

        setLoading(true)
        setError('')
        resetComparison()

        try {
            const result = await requestJson<ComparisonSummary>(
                '/api/repository-comparisons',
                {
                    method: 'POST',
                    body: JSON.stringify({
                        repositoryId,
                        oldBranch,
                        newBranch,
                        oldPath,
                        newPath,
                    }),
                },
            )

            if (!result?.comparisonId) {
                throw new Error(
                    'The backend did not return a comparison ID.',
                )
            }

            setComparisonResult(result)

            await loadRepositoryResults(
                result.comparisonId,
                'ADDED',
                0,
            )
        } catch (err) {
            setError(
                err instanceof Error
                    ? err.message
                    : 'Repository comparison failed.',
            )
        } finally {
            setLoading(false)
        }
    }

    async function handlePublish(): Promise<void> {
        if (!comparisonResult || !repositoryId || !newBranch) {
            setError(
                'The comparison is incomplete. Run the comparison again.',
            )
            return
        }

        const resultTypes: ResultType[] = []

        if (comparisonResult.addedRecordCount > 0) {
            resultTypes.push('ADDED')
        }

        if (comparisonResult.updatedRecordCount > 0) {
            resultTypes.push('UPDATED')
        }

        if (resultTypes.length === 0) {
            setError(
                'There are no added or updated records to publish.',
            )
            return
        }

        setPublishLoading(true)
        setPublishResult(null)
        setError('')

        try {
            const result = await requestJson<PublishResult>(
                `/api/repository-comparisons/${encodeURIComponent(comparisonResult.comparisonId)}/publish`,
                {
                    method: 'POST',
                    body: JSON.stringify({
                        repositoryId,
                        sourceBranch: newBranch,
                        resultTypes,
                        commitMessage: 'Publish CSV comparison results',
                    }),
                },
            )

            if (!result?.branchName || !result?.repository) {
                throw new Error(
                    'The backend did not return the published branch details.',
                )
            }

            setPublishResult(result)
        } catch (err) {
            setError(
                err instanceof Error
                    ? err.message
                    : 'Could not publish the comparison results.',
            )
        } finally {
            setPublishLoading(false)
        }
    }

    function handleResultTypeChange(type: ResultType): void {
        if (!comparisonResult) return

        void loadRepositoryResults(
            comparisonResult.comparisonId,
            type,
            0,
        )
    }

    const hasPublishableRecords =
        (comparisonResult?.addedRecordCount ?? 0) > 0 ||
        (comparisonResult?.updatedRecordCount ?? 0) > 0

    const publishedFiles: PublishedFile[] = publishResult
        ? publishResult.files ??
        [
            ...(publishResult.destinationPath
                ? [{
                    destinationPath: publishResult.destinationPath,
                    fileUrl: publishResult.fileUrl,
                }]
                : []),
            ...(publishResult.updatedDestinationPath
                ? [{
                    destinationPath: publishResult.updatedDestinationPath,
                    fileUrl: publishResult.updatedFileUrl,
                }]
                : []),
            ...(publishResult.highlightedReportDestinationPath
                ? [{
                    destinationPath:
                        publishResult.highlightedReportDestinationPath,
                    fileUrl: publishResult.highlightedReportUrl,
                }]
                : []),
        ]
        : []

    return (
        <div className="repo-page">
            <main className="repo-main">
                <div className="repo-eyebrow">
                    <span className="repo-eyebrow-dot" />
                    CSV COMPARISON WORKSPACE
                </div>

                <h1>
                    Compare CSV files
                    <br />
                    <span>directly from your repository.</span>
                </h1>

                <p className="repo-intro">
                    Connect your source-control account, select two CSV
                    versions, and review the differences without manually
                    downloading the files.
                </p>

                {!connected ? (
                    <section className="repo-card">
                        <div className="repo-card-heading">
                            <div className="repo-icon" aria-hidden="true">
                                ⌘
                            </div>
                            <div>
                                <h2>Connect a provider</h2>
                                <p>
                                    Choose where your CSV files are stored.
                                </p>
                            </div>
                        </div>

                        <div className="provider-list">
                            <button
                                type="button"
                                className={`provider-option ${
                                    provider === 'github'
                                        ? 'provider-active'
                                        : ''
                                }`}
                                onClick={() => setProvider('github')}
                            >
                                <span className="provider-symbol">GH</span>
                                <span className="provider-copy">
                                    <strong>GitHub</strong>
                                    <small>
                                        Repositories and branches
                                    </small>
                                </span>
                                <span
                                    className="provider-radio"
                                    aria-hidden="true"
                                >
                                    {provider === 'github' ? '●' : '○'}
                                </span>
                            </button>

                            <button
                                type="button"
                                className="provider-option provider-disabled"
                                disabled
                            >
                                <span className="provider-symbol">GL</span>
                                <span className="provider-copy">
                                    <strong>GitLab</strong>
                                    <small>Planned provider</small>
                                </span>
                                <span className="provider-soon">
                                    Coming later
                                </span>
                            </button>

                            <button
                                type="button"
                                className="provider-option provider-disabled"
                                disabled
                            >
                                <span className="provider-symbol">BB</span>
                                <span className="provider-copy">
                                    <strong>Bitbucket</strong>
                                    <small>Planned provider</small>
                                </span>
                                <span className="provider-soon">
                                    Coming later
                                </span>
                            </button>
                        </div>

                        <button
                            type="button"
                            className="repo-primary-button"
                            disabled={loading || provider !== 'github'}
                            onClick={() => void connectGitHub()}
                        >
                            {loading ? 'Connecting...' : 'Connect GitHub'}
                            {!loading && (
                                <span aria-hidden="true">→</span>
                            )}
                        </button>

                        <p className="repo-privacy">
                            Authorization is handled by GitHub. Keep access
                            tokens on the backend.
                        </p>

                        {loading && (
                            <p className="repo-status" role="status">
                                Connecting to GitHub...
                            </p>
                        )}

                        {error && (
                            <div className="repo-error" role="alert">
                                {error}
                            </div>
                        )}
                    </section>
                ) : (
                    <section className="repo-card">
                        <div className="repo-card-heading">
                            <div
                                className="repo-connected-icon"
                                aria-hidden="true"
                            >
                                ✓
                            </div>
                            <div>
                                <h2>Choose your CSV versions</h2>
                                <p>
                                    Connected to GitHub. Select the
                                    repository and files to compare.
                                </p>
                            </div>
                            <span className="repo-connection-badge">
                                <span />
                                Connected
                            </span>
                        </div>

                        <label
                            className="repo-field"
                            htmlFor="repository"
                        >
                            <span>Repository</span>
                            <select
                                id="repository"
                                name="repository"
                                value={repositoryId}
                                disabled={loading}
                                onChange={(event) =>
                                    void selectRepository(
                                        event.target.value,
                                    )
                                }
                            >
                                <option value="">
                                    {loading
                                        ? 'Loading repositories...'
                                        : 'Select a repository'}
                                </option>
                                {repositories.map((repo) => (
                                    <option
                                        key={repo.id}
                                        value={repo.id}
                                    >
                                        {repo.fullName}
                                    </option>
                                ))}
                            </select>
                        </label>

                        {repositories.length === 0 &&
                            !loading &&
                            !error && (
                                <p className="repo-status">
                                    No repositories were returned by GitHub.
                                </p>
                            )}

                        {repositoryId && (
                            <div className="repo-version-grid">
                                <div className="repo-version repo-version-old">
                                    <div className="repo-version-label">
                                        <span>01</span>
                                        <div>
                                            <strong>
                                                Previous version
                                            </strong>
                                            <small>Baseline CSV</small>
                                        </div>
                                    </div>

                                    <label
                                        className="repo-field"
                                        htmlFor="old-branch"
                                    >
                                        <span>Branch</span>
                                        <select
                                            id="old-branch"
                                            name="oldBranch"
                                            value={oldBranch}
                                            disabled={loading}
                                            onChange={(event) => {
                                                const branch =
                                                    event.target.value

                                                setOldBranch(branch)
                                                setOldFiles([])
                                                setOldPath('')
                                                resetComparison()

                                                void loadFiles(
                                                    branch,
                                                    'old',
                                                )
                                            }}
                                        >
                                            <option value="">
                                                Select branch
                                            </option>
                                            {branches.map((branch) => (
                                                <option
                                                    key={branch}
                                                    value={branch}
                                                >
                                                    {branch}
                                                </option>
                                            ))}
                                        </select>
                                    </label>

                                    <label
                                        className="repo-field"
                                        htmlFor="old-csv"
                                    >
                                        <span>CSV file</span>
                                        <select
                                            id="old-csv"
                                            name="oldCsvPath"
                                            value={oldPath}
                                            disabled={
                                                loading ||
                                                oldFiles.length === 0
                                            }
                                            onChange={(event) => {
                                                setOldPath(
                                                    event.target.value,
                                                )
                                                resetComparison()
                                            }}
                                        >
                                            <option value="">
                                                {loading
                                                    ? 'Loading CSV files...'
                                                    : oldFiles.length === 0
                                                        ? 'No CSV files available'
                                                        : 'Select previous CSV'}
                                            </option>
                                            {oldFiles.map((path) => (
                                                <option
                                                    key={path}
                                                    value={path}
                                                >
                                                    {path}
                                                </option>
                                            ))}
                                        </select>
                                    </label>
                                </div>

                                <div className="repo-version repo-version-new">
                                    <div className="repo-version-label">
                                        <span>02</span>
                                        <div>
                                            <strong>Latest version</strong>
                                            <small>Updated CSV</small>
                                        </div>
                                    </div>

                                    <label
                                        className="repo-field"
                                        htmlFor="new-branch"
                                    >
                                        <span>Branch</span>
                                        <select
                                            id="new-branch"
                                            name="newBranch"
                                            value={newBranch}
                                            disabled={loading}
                                            onChange={(event) => {
                                                const branch =
                                                    event.target.value

                                                setNewBranch(branch)
                                                setNewFiles([])
                                                setNewPath('')
                                                resetComparison()

                                                void loadFiles(
                                                    branch,
                                                    'new',
                                                )
                                            }}
                                        >
                                            <option value="">
                                                Select branch
                                            </option>
                                            {branches.map((branch) => (
                                                <option
                                                    key={branch}
                                                    value={branch}
                                                >
                                                    {branch}
                                                </option>
                                            ))}
                                        </select>
                                    </label>

                                    <label
                                        className="repo-field"
                                        htmlFor="new-csv"
                                    >
                                        <span>CSV file</span>
                                        <select
                                            id="new-csv"
                                            name="newCsvPath"
                                            value={newPath}
                                            disabled={
                                                loading ||
                                                newFiles.length === 0
                                            }
                                            onChange={(event) => {
                                                setNewPath(
                                                    event.target.value,
                                                )
                                                resetComparison()
                                            }}
                                        >
                                            <option value="">
                                                {loading
                                                    ? 'Loading CSV files...'
                                                    : newFiles.length === 0
                                                        ? 'No CSV files available'
                                                        : 'Select latest CSV'}
                                            </option>
                                            {newFiles.map((path) => (
                                                <option
                                                    key={path}
                                                    value={path}
                                                >
                                                    {path}
                                                </option>
                                            ))}
                                        </select>
                                    </label>
                                </div>
                            </div>
                        )}

                        <button
                            type="button"
                            className="repo-primary-button"
                            disabled={
                                loading ||
                                resultsLoading ||
                                publishLoading ||
                                !repositoryId ||
                                !oldBranch ||
                                !newBranch ||
                                !oldPath ||
                                !newPath
                            }
                            onClick={() => void handleCompare()}
                        >
                            {loading
                                ? 'Loading or comparing CSV files...'
                                : 'Compare selected CSV files'}
                            {!loading && (
                                <span aria-hidden="true">→</span>
                            )}
                        </button>

                        {loading && (
                            <p className="repo-status" role="status">
                                Loading repository data or comparing CSV
                                files...
                            </p>
                        )}

                        {error && (
                            <div className="repo-error" role="alert">
                                {error}
                            </div>
                        )}

                        {comparisonResult && (
                            <section
                                className="repo-results"
                                aria-labelledby="repo-results-title"
                            >
                                <div className="repo-results-top">
                                    <div>
                                        <div className="repo-section-kicker">
                                            COMPARISON COMPLETE
                                        </div>
                                        <h2 id="repo-results-title">
                                            Your results
                                        </h2>
                                        <p>
                                            Review added, updated, missing,
                                            and repeated records.
                                        </p>
                                    </div>
                                    <span className="repo-results-check">
                                        ✓
                                    </span>
                                </div>

                                <div className="repo-comparison-id">
                                    <span>Comparison ID</span>
                                    <code>
                                        {comparisonResult.comparisonId}
                                    </code>
                                </div>

                                <div className="repo-summary-grid">
                                    {(
                                        [
                                            {
                                                type: 'ADDED',
                                                label: 'Added records',
                                                count:
                                                comparisonResult.addedRecordCount,
                                                hint: 'Present in latest CSV',
                                                icon: '+',
                                                className:
                                                    'repo-summary-added',
                                            },
                                            {
                                                type: 'MISSING',
                                                label: 'Missing records',
                                                count:
                                                comparisonResult.missingRecordCount,
                                                hint: 'Not found in latest CSV',
                                                icon: '−',
                                                className:
                                                    'repo-summary-missing',
                                            },
                                            {
                                                type: 'UPDATED',
                                                label: 'Updated records',
                                                count:
                                                comparisonResult.updatedRecordCount,
                                                hint: 'Existing keys with changed values',
                                                icon: '↻',
                                                className: '',
                                            },
                                            {
                                                type: 'REPEATED',
                                                label: 'Repeated records',
                                                count:
                                                comparisonResult.repeatedRecordCount,
                                                hint: 'Duplicate-key rows in either CSV',
                                                icon: '≡',
                                                className: '',
                                            },
                                        ] as const
                                    ).map((item) => (
                                        <button
                                            key={item.type}
                                            type="button"
                                            className={`repo-summary-card ${item.className} ${
                                                selectedResult === item.type
                                                    ? 'repo-result-active'
                                                    : ''
                                            }`}
                                            disabled={resultsLoading}
                                            aria-pressed={
                                                selectedResult === item.type
                                            }
                                            onClick={() =>
                                                handleResultTypeChange(
                                                    item.type,
                                                )
                                            }
                                        >
                                            <span className="repo-summary-icon">
                                                {item.icon}
                                            </span>
                                            <span className="repo-summary-label">
                                                {item.label}
                                            </span>
                                            <strong>
                                                {item.count.toLocaleString()}
                                            </strong>
                                            <span className="repo-summary-hint">
                                                {item.hint}
                                            </span>
                                        </button>
                                    ))}
                                </div>

                                {hasPublishableRecords && (
                                    <div className="repo-publish-section">
                                        <div>
                                            <h3>
                                                Publish comparison results
                                            </h3>
                                            <p>
                                                Create a new branch from{' '}
                                                <strong>{newBranch}</strong>{' '}
                                                and commit the available
                                                generated CSV files and a
                                                highlighted Excel report
                                                for changed values. Your
                                                source branch will not be
                                                changed.
                                            </p>

                                            <ul>
                                                {comparisonResult.addedRecordCount >
                                                    0 && (
                                                        <li>
                                                            <code>
                                                                comparison-results/added.csv
                                                            </code>{' '}
                                                            —{' '}
                                                            {comparisonResult.addedRecordCount.toLocaleString()}{' '}
                                                            records
                                                        </li>
                                                    )}
                                                {comparisonResult.updatedRecordCount >
                                                    0 && (
                                                        <li>
                                                            <code>
                                                                comparison-results/updated.csv
                                                            </code>{' '}
                                                            —{' '}
                                                            {comparisonResult.updatedRecordCount.toLocaleString()}{' '}
                                                            records
                                                        </li>
                                                    )}
                                                {comparisonResult.updatedRecordCount >
                                                    0 && (
                                                        <li>
                                                            <code>
                                                                comparison-results/updated-changes.xlsx
                                                            </code>{' '}
                                                            — changed latest
                                                            values highlighted
                                                            in yellow
                                                        </li>
                                                    )}
                                            </ul>
                                        </div>

                                        <button
                                            type="button"
                                            className="repo-primary-button"
                                            disabled={
                                                publishLoading ||
                                                loading ||
                                                resultsLoading ||
                                                !repositoryId ||
                                                !newBranch
                                            }
                                            onClick={() =>
                                                void handlePublish()
                                            }
                                        >
                                            {publishLoading
                                                ? 'Creating branch and committing...'
                                                : 'Push & Commit Results'}
                                            {!publishLoading && (
                                                <span aria-hidden="true">
                                                    →
                                                </span>
                                            )}
                                        </button>

                                        {publishLoading && (
                                            <p
                                                className="repo-status"
                                                role="status"
                                            >
                                                Creating a new GitHub branch
                                                and committing the CSV files
                                                and highlighted Excel report...
                                            </p>
                                        )}

                                        {publishResult && (
                                            <div
                                                className="repo-publish-success"
                                                role="status"
                                            >
                                                <h3>
                                                    Published successfully
                                                </h3>
                                                <p>
                                                    {publishResult.message}
                                                </p>

                                                <p>
                                                    <strong>
                                                        Repository:
                                                    </strong>{' '}
                                                    {publishResult.repository}
                                                </p>

                                                <p>
                                                    <strong>Branch:</strong>{' '}
                                                    <a
                                                        href={`https://github.com/${publishResult.repository}/tree/${publishResult.branchName
                                                            .split('/')
                                                            .map(encodeURIComponent)
                                                            .join('/')}`}
                                                        target="_blank"
                                                        rel="noreferrer"
                                                    >
                                                        {publishResult.branchName}
                                                    </a>
                                                </p>

                                                {publishedFiles.length > 0 ? (
                                                    <div>
                                                        <strong>
                                                            Published files:
                                                        </strong>
                                                        <ul>
                                                            {publishedFiles.map(
                                                                (file) => (
                                                                    <li
                                                                        key={
                                                                            file.destinationPath
                                                                        }
                                                                    >
                                                                        {file.fileUrl ? (
                                                                            <a
                                                                                href={
                                                                                    file.fileUrl
                                                                                }
                                                                                target="_blank"
                                                                                rel="noreferrer"
                                                                            >
                                                                                {
                                                                                    file.destinationPath
                                                                                }
                                                                            </a>
                                                                        ) : (
                                                                            file.destinationPath
                                                                        )}
                                                                    </li>
                                                                ),
                                                            )}
                                                        </ul>
                                                    </div>
                                                ) : (
                                                    publishResult.destinationPath && (
                                                        <p>
                                                            <strong>
                                                                File:
                                                            </strong>{' '}
                                                            {publishResult.fileUrl ? (
                                                                <a
                                                                    href={
                                                                        publishResult.fileUrl
                                                                    }
                                                                    target="_blank"
                                                                    rel="noreferrer"
                                                                >
                                                                    {
                                                                        publishResult.destinationPath
                                                                    }
                                                                </a>
                                                            ) : (
                                                                publishResult.destinationPath
                                                            )}
                                                        </p>
                                                    )
                                                )}

                                                {publishResult.commitUrl && (
                                                    <p>
                                                        <strong>
                                                            Commit:
                                                        </strong>{' '}
                                                        <a
                                                            href={
                                                                publishResult.commitUrl
                                                            }
                                                            target="_blank"
                                                            rel="noreferrer"
                                                        >
                                                            View commit
                                                        </a>
                                                    </p>
                                                )}

                                                {publishResult.commitSha && (
                                                    <p>
                                                        <strong>
                                                            Commit SHA:
                                                        </strong>{' '}
                                                        <code>
                                                            {
                                                                publishResult.commitSha
                                                            }
                                                        </code>
                                                    </p>
                                                )}
                                            </div>
                                        )}
                                    </div>
                                )}

                                <div className="repo-results-heading">
                                    <div>
                                        <h3>
                                            {{
                                                ADDED: 'Added records',
                                                UPDATED: 'Updated records',
                                                MISSING: 'Missing records',
                                                REPEATED: 'Repeated records',
                                            }[selectedResult]}
                                        </h3>
                                        <p>
                                            {{
                                                ADDED: 'Records found in the latest CSV but not in the previous CSV.',
                                                UPDATED: 'Records whose values changed between the two CSV files.',
                                                MISSING: 'Records from the previous CSV that are absent from the latest CSV.',
                                                REPEATED: 'Duplicate-key rows detected in either CSV.',
                                            }[selectedResult]}
                                        </p>
                                    </div>
                                    <span className="repo-record-count">
                                        {totalRecords.toLocaleString()} records
                                    </span>
                                </div>

                                {resultsLoading ? (
                                    <div
                                        className="repo-results-loading"
                                        role="status"
                                    >
                                        <span className="repo-spinner" />
                                        Loading records...
                                    </div>
                                ) : selectedResult === 'REPEATED' ? (
                                    repeatedRecords.length > 0 ? (
                                        <div className="repo-table-wrapper">
                                            <table className="repo-results-table">
                                                <thead>
                                                <tr>
                                                    <th>Source</th>
                                                    {comparisonResult.headers.map(
                                                        (header, index) => (
                                                            <th
                                                                key={`${header}-${index}`}
                                                            >
                                                                {header}
                                                            </th>
                                                        ),
                                                    )}
                                                </tr>
                                                </thead>
                                                <tbody>
                                                {repeatedRecords.map(
                                                    (item, rowIndex) => (
                                                        <tr
                                                            key={`${item.id}-${rowIndex}`}
                                                        >
                                                            <td>
                                                                {item.source}
                                                            </td>
                                                            {comparisonResult.headers.map(
                                                                (
                                                                    _header,
                                                                    columnIndex,
                                                                ) => (
                                                                    <td
                                                                        key={`${rowIndex}-${columnIndex}`}
                                                                        title={
                                                                            item.record[
                                                                                columnIndex
                                                                                ] ?? ''
                                                                        }
                                                                    >
                                                                        {item.record[
                                                                            columnIndex
                                                                            ] ?? ''}
                                                                    </td>
                                                                ),
                                                            )}
                                                        </tr>
                                                    ),
                                                )}
                                                </tbody>
                                            </table>
                                        </div>
                                    ) : (
                                        <div className="repo-empty-results">
                                            <span aria-hidden="true">✓</span>
                                            <strong>
                                                No repeated records
                                            </strong>
                                            <p>
                                                There are no repeated rows on
                                                this page.
                                            </p>
                                        </div>
                                    )
                                ) : records.length > 0 ? (
                                    <div className="repo-table-wrapper">
                                        <table className="repo-results-table">
                                            <thead>
                                            <tr>
                                                {comparisonResult.headers.map(
                                                    (header, index) => (
                                                        <th
                                                            key={`${header}-${index}`}
                                                        >
                                                            {header}
                                                        </th>
                                                    ),
                                                )}
                                            </tr>
                                            </thead>
                                            <tbody>
                                            {records.map(
                                                (record, rowIndex) => (
                                                    <tr key={rowIndex}>
                                                        {comparisonResult.headers.map(
                                                            (
                                                                _header,
                                                                columnIndex,
                                                            ) => (
                                                                <td
                                                                    key={`${rowIndex}-${columnIndex}`}
                                                                    title={
                                                                        record[
                                                                            columnIndex
                                                                            ] ?? ''
                                                                    }
                                                                >
                                                                    {record[
                                                                        columnIndex
                                                                        ] ?? ''}
                                                                </td>
                                                            ),
                                                        )}
                                                    </tr>
                                                ),
                                            )}
                                            </tbody>
                                        </table>
                                    </div>
                                ) : (
                                    <div className="repo-empty-results">
                                        <span aria-hidden="true">✓</span>
                                        <strong>
                                            No {selectedResult.toLowerCase()}{' '}
                                            records
                                        </strong>
                                        <p>
                                            There are no records to display in
                                            this category.
                                        </p>
                                    </div>
                                )}

                                <div className="repo-pagination">
                                    <span className="repo-page-info">
                                        Page {currentPage + 1} of{' '}
                                        {Math.max(totalPages, 1)}
                                    </span>

                                    <div className="repo-page-controls">
                                        <button
                                            type="button"
                                            disabled={
                                                resultsLoading ||
                                                currentPage <= 0
                                            }
                                            onClick={() => {
                                                void loadRepositoryResults(
                                                    comparisonResult.comparisonId,
                                                    selectedResult,
                                                    currentPage - 1,
                                                )
                                            }}
                                        >
                                            ← Previous
                                        </button>

                                        {currentPage + 1 < totalPages && (
                                            <button
                                                type="button"
                                                disabled={resultsLoading}
                                                onClick={() => {
                                                    void loadRepositoryResults(
                                                        comparisonResult.comparisonId,
                                                        selectedResult,
                                                        currentPage + 1,
                                                    )
                                                }}
                                            >
                                                Next →
                                            </button>
                                        )}
                                    </div>
                                </div>
                            </section>
                        )}
                    </section>
                )}

                <button
                    type="button"
                    className="repo-local-link"
                    onClick={onUseLocalFiles}
                >
                    <span aria-hidden="true">←</span>
                    Or compare files from this computer
                </button>

                <p className="repo-footer">
                    CSV Comparison Tool · Repository workspace
                </p>
            </main>
        </div>
    )
}
