
package com.csvcomparison.tool.model;

public enum ResultType {
    ADDED,
    UPDATED,
    MISSING,
    REPEATED
}
