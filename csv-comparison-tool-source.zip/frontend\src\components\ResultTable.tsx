import type {
    RepeatedRecord,
    ResultCategory,
} from '../types/comparison'

interface ResultTableProps {
    headers: string[]
    records: string[][]
    repeatedRecords?: RepeatedRecord[]
    type: ResultCategory
}

function ResultTable({
                         headers,
                         records,
                         repeatedRecords = [],
                         type,
                     }: ResultTableProps) {
    const isRepeated = type === 'repeated'

    if (
        (isRepeated && repeatedRecords.length === 0) ||
        (!isRepeated && records.length === 0)
    ) {
        const messages: Record<
            ResultCategory,
            { title: string; description: string }
        > = {
            added: {
                title: 'No added records found',
                description:
                    'The latest CSV does not contain any new records.',
            },
            updated: {
                title: 'No updated records found',
                description:
                    'No existing records have changed between the two CSV files.',
            },
            missing: {
                title: 'No missing records found',
                description:
                    'All IDs from the previous CSV are present in the latest CSV.',
            },
            repeated: {
                title: 'No repeated records found',
                description:
                    'There are no duplicate IDs in either CSV file.',
            },
        }

        return (
            <div className="empty-result">
                <div className="empty-result-icon">✓</div>

                <h3>{messages[type].title}</h3>

                <p>{messages[type].description}</p>
            </div>
        )
    }

    return (
        <div className="result-table-container">
            <table className="result-table">
                <thead>
                <tr>
                    {isRepeated && <th>Source</th>}

                    {headers.map((header, index) => (
                        <th key={`${header}-${index}`}>
                            {header}
                        </th>
                    ))}
                </tr>
                </thead>

                <tbody>
                {isRepeated
                    ? repeatedRecords.map((item, index) => (
                        <tr key={`${item.id}-${index}`}>
                            <td>
                                      <span
                                          className={`record-source ${item.source.toLowerCase()}`}
                                      >
                                          {item.source}
                                      </span>
                            </td>

                            {item.record.map((value, columnIndex) => (
                                <td key={`${index}-${columnIndex}`}>
                                    {value}
                                </td>
                            ))}
                        </tr>
                    ))
                    : records.map((record, rowIndex) => (
                        <tr key={rowIndex}>
                            {record.map((value, columnIndex) => (
                                <td key={`${rowIndex}-${columnIndex}`}>
                                    {value}
                                </td>
                            ))}
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    )
}

export default ResultTable