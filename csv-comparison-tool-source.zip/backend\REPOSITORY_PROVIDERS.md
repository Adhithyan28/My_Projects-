# Adding a repository provider

Repository-hosting integrations are adapters behind
`RepositoryProvider`. The connection, repository browsing, comparison, and
publishing controllers select an adapter through `RepositoryProviderRegistry`;
the CSV comparison engine does not depend on a hosting platform.

## Add an adapter

1. Add a Spring `@Component` that implements `RepositoryProvider`.
2. Return a stable, lowercase provider identifier from `getProviderName()`.
   That identifier is used in routes, requests, and session token keys.
3. Implement OAuth URL creation and code exchange, repository/branch/file
   listing, file download, and comparison-result publishing.
4. Use `RepositorySummary` for repository listings. Its `id` is an opaque
   provider-owned identifier; pass it unchanged back to the provider methods.
5. Keep provider API calls and provider-specific validation in the adapter.
   Store access tokens in the session only; never return or log them.
6. Add the platform's OAuth configuration and register its callback URI as
   `/api/connections/{provider}/callback`.

The generic API routes accept an optional `provider` parameter/body property.
When it is omitted, the existing GitHub behavior remains the default:

- `GET /api/repositories?provider={provider}`
- `GET /api/repositories/{id}/branches?provider={provider}`
- `GET /api/repositories/{id}/files?provider={provider}&branch={branch}`
- `POST /api/repository-comparisons` with `provider` in the request body
- `POST /api/repository-comparisons/{comparisonId}/publish` with `provider`
  in the request body
- `GET /api/connections/{provider}/authorize`

The comparison endpoint downloads both selected files via the provider
adapter, then passes the local temporary CSV files to the shared comparison
service. A new platform should not implement or modify the CSV comparison
engines.
