
package com.csvcomparison.tool.repository.auth;

import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClient;

/**
 * Handles GitHub OAuth authorization and token exchange.
 *
 * OAuth state generation and validation are handled separately.
 * Access tokens must never be logged or exposed to the frontend.
 */
@Service
public class GitHubOAuthService {

    private static final String AUTHORIZE_URL =
            "https://github.com/login/oauth/authorize";

    private static final String TOKEN_URL =
            "https://github.com/login/oauth/access_token";

    private final String clientId;
    private final String clientSecret;
    private final String redirectUri;
    private final RestClient restClient;

    public GitHubOAuthService(
            @Value("${github.oauth.client-id}") String clientId,
            @Value("${github.oauth.client-secret}") String clientSecret,
            @Value("${github.oauth.redirect-uri}") String redirectUri) {

        this.clientId = clientId;
        this.clientSecret = clientSecret;
        this.redirectUri = redirectUri;
        this.restClient = RestClient.create();
    }

    /**
     * Builds the GitHub authorization URL.
     *
     * The caller must supply a cryptographically random state value
     * and validate it when GitHub redirects back.
     */
    public String buildAuthorizationUrl(String state) {
        if (state == null || state.isBlank()) {
            throw new IllegalArgumentException(
                    "OAuth state must not be empty");
        }
        validateConfiguration();

        return AUTHORIZE_URL
                + "?client_id=" + encode(clientId)
                + "&redirect_uri=" + encode(redirectUri)
                + "&scope=" + encode("public_repo")
                + "&state=" + encode(state);
    }

    /**
     * Exchanges the temporary authorization code for an access token.
     *
     * The returned token must be stored securely by the caller.
     * Do not send it to the browser or write it to application logs.
     */
    public String exchangeCodeForAccessToken(String code) {
        if (code == null || code.isBlank()) {
            throw new IllegalArgumentException(
                    "GitHub authorization code must not be empty");
        }
        validateConfiguration();

        MultiValueMap<String, String> form = new LinkedMultiValueMap<>();
        form.add("client_id", clientId);
        form.add("client_secret", clientSecret);
        form.add("code", code);
        form.add("redirect_uri", redirectUri);

        Map<String, Object> response = restClient.post()
                .uri(TOKEN_URL)
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .accept(MediaType.APPLICATION_JSON)
                .body(form)
                .retrieve()
                .body(Map.class);

        if (response == null) {
            throw new IllegalStateException(
                    "GitHub returned an empty token response");
        }

        Object error = response.get("error");
        if (error != null) {
            throw new IllegalStateException(
                    "GitHub OAuth token exchange failed: "
                            + error);
        }

        Object token = response.get("access_token");

        if (!(token instanceof String accessToken)
                || accessToken.isBlank()) {
            throw new IllegalStateException(
                    "GitHub response did not contain an access token");
        }

        return accessToken;
    }

    private String encode(String value) {
        return java.net.URLEncoder.encode(
                value,
                java.nio.charset.StandardCharsets.UTF_8);
    }

    private void validateConfiguration() {
        if (clientId == null || clientId.isBlank()
                || clientSecret == null || clientSecret.isBlank()
                || redirectUri == null || redirectUri.isBlank()) {
            throw new IllegalStateException(
                    "GitHub OAuth is not configured. Set "
                            + "GITHUB_OAUTH_CLIENT_ID, "
                            + "GITHUB_OAUTH_CLIENT_SECRET, and "
                            + "GITHUB_OAUTH_REDIRECT_URI."
            );
        }
    }
}