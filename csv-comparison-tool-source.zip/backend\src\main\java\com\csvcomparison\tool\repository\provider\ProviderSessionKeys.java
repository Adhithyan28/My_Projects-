package com.csvcomparison.tool.repository.provider;

import jakarta.servlet.http.HttpSession;

import java.util.Locale;

public final class ProviderSessionKeys {

    private ProviderSessionKeys() {
    }

    public static String tokenKey(String provider) {
        return provider.trim().toLowerCase(Locale.ROOT)
                + "_access_token";
    }

    public static String getToken(HttpSession session, String provider) {
        Object value = session.getAttribute(tokenKey(provider));
        return value instanceof String token && !token.isBlank()
                ? token
                : null;
    }
}
