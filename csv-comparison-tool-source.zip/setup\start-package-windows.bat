@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0run-package-windows.ps1"
if errorlevel 1 (
    echo.
    echo The application launcher exited with an error.
    pause
)
