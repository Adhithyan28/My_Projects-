
package com.csvcomparison.tool.engine;

import com.csvcomparison.tool.config.CsvComparisonProperties;
import com.csvcomparison.tool.exception.CsvValidationException;
import com.univocity.parsers.csv.CsvParser;
import com.univocity.parsers.csv.CsvParserSettings;
import com.univocity.parsers.csv.CsvWriter;
import com.univocity.parsers.csv.CsvWriterSettings;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

@Component
public class ExternalSorter {

    private static final String POSITION_HEADER =
            "__CSV_COMPARISON_ORIGINAL_POSITION__";

    private final CsvComparisonProperties properties;

    public ExternalSorter(CsvComparisonProperties properties) {
        this.properties = properties;
    }

    public SortedChunks sort(Path inputFile) throws IOException {
        return sortInternal(inputFile, false);
    }

    /**
     * Sorts by key and preserves each row's original position.
     * The position is temporary metadata and must be removed by KWayMerger.
     */
    public SortedChunks sortWithOriginalPosition(Path inputFile)
            throws IOException {
        return sortInternal(inputFile, true);
    }

    private SortedChunks sortInternal(
            Path inputFile,
            boolean preserveOriginalPosition
    ) throws IOException {

        long chunkSizeBytes = parseChunkSize(properties.getChunkSize());
        Path tempDirectory = Files.createTempDirectory("csv-comparison-");
        List<Path> sortedChunks = new ArrayList<>();

        try {
            createSortedChunks(
                    inputFile,
                    tempDirectory,
                    chunkSizeBytes,
                    sortedChunks,
                    preserveOriginalPosition
            );

            if (sortedChunks.isEmpty()) {
                deleteTemporaryFiles(tempDirectory);
                return new SortedChunks(tempDirectory, List.of());
            }

            return new SortedChunks(tempDirectory, sortedChunks);

        } catch (IOException | RuntimeException exception) {
            try {
                deleteTemporaryFiles(tempDirectory);
            } catch (IOException cleanupException) {
                exception.addSuppressed(cleanupException);
            }
            throw exception;
        }
    }

    private void createSortedChunks(
            Path inputFile,
            Path tempDirectory,
            long chunkSizeBytes,
            List<Path> sortedChunks,
            boolean preserveOriginalPosition
    ) throws IOException {

        CsvParserSettings settings = new CsvParserSettings();
        settings.setHeaderExtractionEnabled(false);
        settings.setLineSeparatorDetectionEnabled(true);
        settings.setNullValue("");
        settings.setEmptyValue("");

        CsvParser parser = new CsvParser(settings);
        parser.beginParsing(inputFile.toFile());

        try {
            String[] header = parser.parseNext();

            if (header == null || header.length == 0) {
                throw new CsvValidationException("CSV file is empty.");
            }

            List<String[]> currentChunk = new ArrayList<>();
            long currentChunkSize = 0;
            long originalPosition = 0;
            int chunkNumber = 0;

            String[] row;

            while ((row = parser.parseNext()) != null) {
                validateRow(row, header.length);

                String[] storedRow = row;

                if (preserveOriginalPosition) {
                    storedRow = new String[row.length + 1];
                    System.arraycopy(row, 0, storedRow, 0, row.length);
                    storedRow[row.length] =
                            Long.toString(originalPosition);
                }

                originalPosition++;

                currentChunk.add(storedRow);
                currentChunkSize += estimateRowSize(storedRow);

                if (currentChunkSize >= chunkSizeBytes) {
                    sortedChunks.add(
                            writeSortedChunk(
                                    header,
                                    currentChunk,
                                    tempDirectory,
                                    chunkNumber++,
                                    preserveOriginalPosition
                            )
                    );

                    currentChunk.clear();
                    currentChunkSize = 0;
                }
            }

            if (!currentChunk.isEmpty()) {
                sortedChunks.add(
                        writeSortedChunk(
                                header,
                                currentChunk,
                                tempDirectory,
                                chunkNumber,
                                preserveOriginalPosition
                        )
                );
            }

        } finally {
            parser.stopParsing();
        }
    }

    private Path writeSortedChunk(
            String[] originalHeader,
            List<String[]> rows,
            Path tempDirectory,
            int chunkNumber,
            boolean positioned
    ) throws IOException {

        Comparator<String[]> comparator =
                Comparator.comparing(
                        (String[] row) -> row[0],
                        Comparator.nullsFirst(String::compareTo)
                );

        if (positioned) {
            comparator = comparator.thenComparingLong(
                    row -> Long.parseLong(row[row.length - 1])
            );
        }

        rows.sort(comparator);

        Path chunkFile = tempDirectory.resolve(
                String.format("chunk-%05d.csv", chunkNumber)
        );

        String[] chunkHeader = originalHeader;

        if (positioned) {
            chunkHeader = new String[originalHeader.length + 1];
            System.arraycopy(
                    originalHeader, 0,
                    chunkHeader, 0,
                    originalHeader.length
            );
            chunkHeader[originalHeader.length] = POSITION_HEADER;
        }

        CsvWriter writer = new CsvWriter(
                chunkFile.toFile(),
                StandardCharsets.UTF_8,
                new CsvWriterSettings()
        );

        try {
            writer.writeRow(chunkHeader);

            for (String[] row : rows) {
                writer.writeRow(row);
            }
        } finally {
            writer.close();
        }

        return chunkFile;
    }

    private void validateRow(String[] row, int expectedColumnCount) {
        if (row.length != expectedColumnCount) {
            throw new CsvValidationException(
                    "Invalid CSV row. Expected "
                            + expectedColumnCount
                            + " columns but found "
                            + row.length
                            + "."
            );
        }

        if (row[0] == null || row[0].isBlank()) {
            throw new CsvValidationException(
                    "CSV contains a row with an empty key."
            );
        }
    }

    private long estimateRowSize(String[] row) {
        long size = 0;

        for (String value : row) {
            if (value != null) {
                size += value.getBytes(StandardCharsets.UTF_8).length;
            }
            size++;
        }

        return size;
    }

    private long parseChunkSize(String value) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException(
                    "CSV comparison chunk size cannot be empty."
            );
        }

        String normalized = value.trim().toUpperCase();

        if (normalized.endsWith("GB")) {
            return multiplySize(parseNumber(normalized, 2),
                    1024L * 1024L * 1024L);
        }

        if (normalized.endsWith("MB")) {
            return multiplySize(parseNumber(normalized, 2),
                    1024L * 1024L);
        }

        if (normalized.endsWith("KB")) {
            return multiplySize(parseNumber(normalized, 2), 1024L);
        }

        if (normalized.endsWith("B")) {
            return parseNumber(normalized, 1);
        }

        throw new IllegalArgumentException(
                "Unsupported chunk size: " + value
                        + ". Use B, KB, MB, or GB."
        );
    }

    private long parseNumber(String value, int suffixLength) {
        String number = value.substring(
                0, value.length() - suffixLength
        ).trim();

        return Long.parseLong(number);
    }

    private long multiplySize(long value, long multiplier) {
        return Math.multiplyExact(value, multiplier);
    }

    private static void deleteTemporaryFiles(Path directory) throws IOException {
        if (!Files.exists(directory)) {
            return;
        }

        AtomicReference<IOException> cleanupFailure =
                new AtomicReference<>();
        SimpleFileVisitor<Path> visitor = new SimpleFileVisitor<>() {

            @Override
            public FileVisitResult visitFile(
                    Path file,
                    BasicFileAttributes attributes
            ) {
                try {
                    Files.deleteIfExists(file);
                } catch (IOException exception) {
                    recordFailure(exception);
                }
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult postVisitDirectory(
                    Path visitedDirectory,
                    IOException exception
            ) throws IOException {
                if (exception != null) {
                    recordFailure(exception);
                }
                try {
                    Files.deleteIfExists(visitedDirectory);
                } catch (IOException deleteException) {
                    recordFailure(deleteException);
                }
                return FileVisitResult.CONTINUE;
            }

            private void recordFailure(IOException exception) {
                IOException firstFailure = cleanupFailure.get();
                if (firstFailure == null) {
                    cleanupFailure.set(exception);
                } else {
                    firstFailure.addSuppressed(exception);
                }
            }
        };

        Files.walkFileTree(directory, visitor);
        if (cleanupFailure.get() != null) {
            throw cleanupFailure.get();
        }
    }

    public record SortedChunks(
            Path directory,
            List<Path> paths
    ) implements AutoCloseable {
        public SortedChunks {
            paths = List.copyOf(paths);
        }

        @Override
        public void close() throws IOException {
            deleteTemporaryFiles(directory);
        }
    }
}
