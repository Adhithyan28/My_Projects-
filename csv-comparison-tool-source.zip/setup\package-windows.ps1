$ErrorActionPreference = "Stop"

$scriptDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$projectRoot = Split-Path -Parent $scriptDirectory
$backendDirectory = Join-Path $projectRoot "backend"
$frontendDirectory = Join-Path $projectRoot "frontend"
$releaseDirectory = Join-Path $projectRoot "release"
$archivePath = Join-Path $releaseDirectory "csv-comparison-tool.zip"
$stageDirectory = Join-Path ([System.IO.Path]::GetTempPath()) (
    "csv-comparison-tool-" + [guid]::NewGuid().ToString("N")
)

New-Item -ItemType Directory -Path $releaseDirectory -Force | Out-Null
New-Item -ItemType Directory -Path $stageDirectory -Force | Out-Null

try {
    Push-Location $frontendDirectory
    try {
        npm install --no-package-lock --no-audit --no-fund
        if ($LASTEXITCODE -ne 0) {
            throw "Frontend dependency installation failed."
        }
        npm run build
        if ($LASTEXITCODE -ne 0) {
            throw "Frontend build failed."
        }
    }
    finally {
        Pop-Location
    }

    Push-Location $backendDirectory
    try {
        & .\mvnw.cmd -q clean package -Pdistribution -DskipTests
        if ($LASTEXITCODE -ne 0) {
            throw "Backend package build failed."
        }
    }
    finally {
        Pop-Location
    }

    Copy-Item (Join-Path $backendDirectory "target\backend-0.0.1-SNAPSHOT.jar") `
        (Join-Path $stageDirectory "csv-comparison-tool.jar")
    Copy-Item (Join-Path $scriptDirectory "run-package-windows.ps1") $stageDirectory
    Copy-Item (Join-Path $scriptDirectory "start-package-windows.bat") `
        (Join-Path $stageDirectory "Start-CSV-Comparison-Tool.bat")
    Copy-Item (Join-Path $scriptDirectory "Start-CSV-Comparison-Tool.command") $stageDirectory
    Copy-Item (Join-Path $scriptDirectory "Start-CSV-Comparison-Tool-linux.sh") $stageDirectory
    Copy-Item (Join-Path $scriptDirectory "run-package-unix.sh") $stageDirectory
    Copy-Item (Join-Path $scriptDirectory "java-runtime-windows.ps1") $stageDirectory
    Copy-Item (Join-Path $scriptDirectory "java-runtime-unix.sh") $stageDirectory
    Copy-Item (Join-Path $projectRoot "DEPLOYMENT.md") `
        (Join-Path $stageDirectory "README.md")
    Copy-Item (Join-Path $projectRoot "User-guide.html") $stageDirectory
    Copy-Item (Join-Path $projectRoot "csv-comparison-developer-guide.html") $stageDirectory

    $sourceDirectory = Join-Path $stageDirectory "source-code"
    $sourceBackend = Join-Path $sourceDirectory "backend"
    $sourceFrontend = Join-Path $sourceDirectory "frontend"
    New-Item -ItemType Directory -Path $sourceBackend,$sourceFrontend | Out-Null

    Copy-Item (Join-Path $backendDirectory "src") $sourceBackend -Recurse
    Copy-Item (Join-Path $backendDirectory ".mvn") $sourceBackend -Recurse
    Copy-Item (Join-Path $backendDirectory "pom.xml") $sourceBackend
    Copy-Item (Join-Path $backendDirectory "mvnw") $sourceBackend
    Copy-Item (Join-Path $backendDirectory "mvnw.cmd") $sourceBackend
    Copy-Item (Join-Path $backendDirectory ".gitignore") $sourceBackend
    Copy-Item (Join-Path $backendDirectory "REPOSITORY_PROVIDERS.md") $sourceBackend

    foreach ($item in @("src", "public")) {
        Copy-Item (Join-Path $frontendDirectory $item) $sourceFrontend -Recurse
    }
    foreach ($item in @(
            "package.json", "package-lock.json", "index.html",
            "vite.config.ts", "tsconfig.json", "tsconfig.app.json",
            "tsconfig.node.json", "eslint.config.js", ".gitignore"
        )) {
        Copy-Item (Join-Path $frontendDirectory $item) $sourceFrontend
    }
    Copy-Item $scriptDirectory $sourceDirectory -Recurse
    Copy-Item (Join-Path $projectRoot "DEPLOYMENT.md") $sourceDirectory
    Copy-Item (Join-Path $projectRoot "User-guide.html") $sourceDirectory
    Copy-Item (Join-Path $projectRoot "csv-comparison-developer-guide.html") $sourceDirectory

    @"
# Source code package

This archive contains the editable backend and frontend source for CSV Comparison Tool.

Requirements: Java 21+, Node.js/npm, and network access to download Maven/npm dependencies.

Backend:
  cd backend
  Windows: .\mvnw.cmd test
  macOS/Linux: chmod +x mvnw, then ./mvnw test

Frontend:
  cd frontend
  npm ci
  npm run build

For local development startup scripts, OAuth setup, architecture, and adding a
repository platform, see DEPLOYMENT.md, backend/REPOSITORY_PROVIDERS.md, and
csv-comparison-developer-guide.html.

Build output, installed dependencies, IDE settings, runtime logs, and local
OAuth credentials are intentionally excluded. Create backend/oauth.env locally
for GitHub OAuth; never commit or share it.
"@ | Set-Content -LiteralPath (Join-Path $sourceDirectory "SOURCE-README.md") -Encoding UTF8

    $sourceArchivePath = Join-Path $stageDirectory "source-code.zip"
    Compress-Archive -Path (Join-Path $sourceDirectory "*") `
        -DestinationPath $sourceArchivePath -CompressionLevel Optimal
    Remove-Item -LiteralPath $sourceDirectory -Recurse -Force

    if (Test-Path $archivePath) {
        Remove-Item -LiteralPath $archivePath -Force
    }
    Compress-Archive -Path (Join-Path $stageDirectory "*") `
        -DestinationPath $archivePath -CompressionLevel Optimal

    Write-Host "Created: $archivePath"
}
finally {
    if (Test-Path $stageDirectory) {
        Remove-Item -LiteralPath $stageDirectory -Recurse -Force
    }
}
