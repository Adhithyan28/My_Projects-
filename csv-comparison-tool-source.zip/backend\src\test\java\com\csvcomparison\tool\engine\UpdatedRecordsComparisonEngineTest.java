package com.csvcomparison.tool.engine;

import com.csvcomparison.tool.config.CsvComparisonProperties;
import com.csvcomparison.tool.model.ComparisonResult;
import com.csvcomparison.tool.service.ComparisonResultStore;
import com.csvcomparison.tool.service.UpdatedRecordsExcelExporter;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.assertEquals;

class UpdatedRecordsComparisonEngineTest {

    @TempDir
    Path tempDirectory;

    @Test
    void hashmapEngineKeepsPreviousValuesForExcelReport() throws Exception {
        ComparisonResultStore resultStore = new ComparisonResultStore();
        HashMapComparisonEngine engine = new HashMapComparisonEngine(
                new CsvHeaderValidator(),
                resultStore
        );

        assertPreviousValuesInReport(
                resultStore,
                engine.compare(previousCsv(), latestCsv())
        );
    }

    @Test
    void externalSortEngineKeepsPreviousValuesForExcelReport()
            throws Exception {
        ComparisonResultStore resultStore = new ComparisonResultStore();
        CsvComparisonProperties properties = new CsvComparisonProperties();
        ExternalSortMergeComparisonEngine engine =
                new ExternalSortMergeComparisonEngine(
                        new CsvHeaderValidator(),
                        new ExternalSorter(properties),
                        new KWayMerger(),
                        resultStore
                );

        assertPreviousValuesInReport(
                resultStore,
                engine.compare(previousCsv(), latestCsv())
        );
    }

    private Path previousCsv() throws Exception {
        return Files.writeString(
                tempDirectory.resolve("previous.csv"),
                "id,amount,description\n1,10,old\n"
        );
    }

    private Path latestCsv() throws Exception {
        return Files.writeString(
                tempDirectory.resolve("latest.csv"),
                "id,amount,description\n1,12,new\n"
        );
    }

    private void assertPreviousValuesInReport(
            ComparisonResultStore resultStore,
            ComparisonResult result
    ) throws Exception {
        assertEquals(1, result.updatedRecordCount());
        Path report = resultStore.exportUpdatedExcel(
                result.comparisonId(),
                new UpdatedRecordsExcelExporter()
        );

        try (InputStream input = Files.newInputStream(report);
             XSSFWorkbook workbook = new XSSFWorkbook(input)) {
            assertEquals(
                    "10",
                    workbook.getSheet("Previous 1")
                            .getRow(1)
                            .getCell(1)
                            .getStringCellValue()
            );
            assertEquals(
                    "12",
                    workbook.getSheet("Updated 1")
                            .getRow(1)
                            .getCell(1)
                            .getStringCellValue()
            );
        } finally {
            Files.deleteIfExists(report);
            resultStore.clear();
        }
    }
}
