﻿# Source code package

This archive contains the editable backend and frontend source for CSV Comparison Tool.

Requirements: Java 21+, Node.js/npm, and network access to download Maven/npm dependencies.

Backend:
  cd backend
  Windows: .\mvnw.cmd test
  macOS/Linux: chmod +x mvnw, then ./mvnw test

Frontend:
  cd frontend
  npm ci
  npm run build

For local development startup scripts, OAuth setup, architecture, and adding a
repository platform, see DEPLOYMENT.md, backend/REPOSITORY_PROVIDERS.md, and
csv-comparison-developer-guide.html.

Build output, installed dependencies, IDE settings, runtime logs, and local
OAuth credentials are intentionally excluded. Create backend/oauth.env locally
for GitHub OAuth; never commit or share it.
