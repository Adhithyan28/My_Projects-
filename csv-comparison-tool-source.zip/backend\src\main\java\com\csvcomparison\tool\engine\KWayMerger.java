
package com.csvcomparison.tool.engine;

import com.csvcomparison.tool.model.RepeatedRecord;
import com.univocity.parsers.csv.CsvParser;
import com.univocity.parsers.csv.CsvParserSettings;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.PriorityQueue;

@Component
public class KWayMerger {

    public RowIterator stream(
            List<Path> sortedChunks,
            String source,
            RepeatedRecordSink repeatedRecordSink
    ) {
        return new RowIterator(
                sortedChunks, source, repeatedRecordSink, false, false
        );
    }

    public RowIterator stream(List<Path> sortedChunks, String source) {
        return stream(sortedChunks, source, repeatedRecord -> {});
    }

    public RowIterator stream(List<Path> sortedChunks) {
        return stream(sortedChunks, "PREVIOUS");
    }

    /**
     * Merges chunks sorted by key and original position.
     * Returns only the first original occurrence of each key.
     * Subsequent occurrences are written to the repeated-record sink.
     */
    public RowIterator streamUniqueByKey(
            List<Path> sortedChunks,
            String source,
            RepeatedRecordSink repeatedRecordSink
    ) {
        return new RowIterator(
                sortedChunks, source, repeatedRecordSink, true, true
        );
    }

    public static class RowIterator
            implements Iterator<String[]>, AutoCloseable {

        private final List<ChunkReader> readers = new ArrayList<>();
        private final PriorityQueue<ChunkEntry> queue;
        private final String source;
        private final RepeatedRecordSink repeatedRecordSink;
        private final boolean positioned;
        private final boolean skipDuplicates;

        private String previousKey;
        private boolean closed;

        public RowIterator(
                List<Path> sortedChunks,
                String source,
                RepeatedRecordSink repeatedRecordSink
        ) {
            this(sortedChunks, source, repeatedRecordSink, false, false);
        }

        private RowIterator(
                List<Path> sortedChunks,
                String source,
                RepeatedRecordSink repeatedRecordSink,
                boolean positioned,
                boolean skipDuplicates
        ) {
            this.source = source;
            this.repeatedRecordSink = repeatedRecordSink;
            this.positioned = positioned;
            this.skipDuplicates = skipDuplicates;

            Comparator<ChunkEntry> comparator =
                    Comparator.comparing(ChunkEntry::key);

            if (positioned) {
                comparator = comparator.thenComparingLong(
                        ChunkEntry::originalPosition
                );
            }

            this.queue = new PriorityQueue<>(comparator);

            if (sortedChunks == null || sortedChunks.isEmpty()) {
                return;
            }

            try {
                for (Path chunk : sortedChunks) {
                    ChunkReader reader = new ChunkReader(chunk);
                    readers.add(reader);

                    String[] firstRow = reader.nextRow();

                    if (firstRow != null) {
                        queue.add(new ChunkEntry(firstRow, reader));
                    }
                }
            } catch (RuntimeException exception) {
                close();
                throw exception;
            }
        }

        @Override
        public boolean hasNext() {
            return !queue.isEmpty();
        }

        @Override
        public String[] next() {
            while (hasNext()) {
                ChunkEntry entry = queue.poll();
                String[] currentRow = entry.row();
                String currentKey = entry.key();

                String[] nextRow = entry.reader().nextRow();

                if (nextRow != null) {
                    queue.add(new ChunkEntry(nextRow, entry.reader()));
                }

                boolean duplicate = currentKey.equals(previousKey);
                previousKey = currentKey;

                if (duplicate) {
                    if (skipDuplicates) {
                        writeRepeated(currentKey, currentRow);
                        continue;
                    }

                    try {
                        repeatedRecordSink.accept(
                                new RepeatedRecord(
                                        source,
                                        currentKey,
                                        currentRow
                                )
                        );
                    } catch (IOException exception) {
                        throw new RuntimeException(
                                "Failed to write repeated record.",
                                exception
                        );
                    }
                }

                if (positioned) {
                    return removePosition(currentRow);
                }

                return currentRow;
            }

            throw new NoSuchElementException();
        }

        private void writeRepeated(String key, String[] positionedRow) {
            try {
                repeatedRecordSink.accept(
                        new RepeatedRecord(
                                source,
                                key,
                                removePosition(positionedRow)
                        )
                );
            } catch (IOException exception) {
                throw new RuntimeException(
                        "Failed to write repeated record.",
                        exception
                );
            }
        }

        private String[] removePosition(String[] row) {
            String[] originalRow = new String[row.length - 1];
            System.arraycopy(row, 0, originalRow, 0, originalRow.length);
            return originalRow;
        }

        @Override
        public void close() {
            if (closed) {
                return;
            }

            closed = true;

            for (ChunkReader reader : readers) {
                reader.close();
            }

            readers.clear();
            queue.clear();
            previousKey = null;
        }
    }

    @FunctionalInterface
    public interface RepeatedRecordSink {
        void accept(RepeatedRecord repeatedRecord) throws IOException;
    }

    private record ChunkEntry(String[] row, ChunkReader reader) {

        String key() {
            return row[0];
        }

        long originalPosition() {
            return Long.parseLong(row[row.length - 1]);
        }
    }

    private static class ChunkReader {

        private final CsvParser parser;
        private boolean closed;

        ChunkReader(Path file) {
            CsvParserSettings settings = new CsvParserSettings();
            settings.setHeaderExtractionEnabled(false);
            settings.setLineSeparatorDetectionEnabled(true);

            parser = new CsvParser(settings);
            parser.beginParsing(file.toFile());

            String[] header = parser.parseNext();

            if (header == null || header.length == 0) {
                close();
                throw new IllegalArgumentException(
                        "CSV chunk is empty: " + file
                );
            }
        }

        String[] nextRow() {
            if (closed) {
                throw new IllegalStateException(
                        "Chunk reader is already closed."
                );
            }

            return parser.parseNext();
        }

        void close() {
            if (closed) {
                return;
            }

            closed = true;
            parser.stopParsing();
        }
    }
}
