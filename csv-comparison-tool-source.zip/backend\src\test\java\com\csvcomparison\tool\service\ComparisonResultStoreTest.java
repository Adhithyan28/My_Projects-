package com.csvcomparison.tool.service;

import com.csvcomparison.tool.model.ComparisonResult;
import com.csvcomparison.tool.model.RepeatedRecord;
import com.csvcomparison.tool.model.ResultPage;
import com.csvcomparison.tool.model.ResultType;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ComparisonResultStoreTest {

    @TempDir
    Path tempDirectory;

    @Test
    void returnsRepeatedRecordsAsTypedRows() throws Exception {
        Path repeatedFile = tempDirectory.resolve("repeated.csv");
        List<Long> offsets;
        try (ResultFileWriter writer = new ResultFileWriter(repeatedFile)) {
            writer.writeRepeatedRecord(new RepeatedRecord(
                    "LATEST",
                    "42",
                    new String[]{"42", "duplicate"}
            ));
            offsets = writer.getPageOffsets();
        }

        ComparisonResult result = new ComparisonResult(
                "comparison-1",
                List.of("id", "value"),
                0,
                0,
                0,
                1
        );
        ComparisonResultStore store = new ComparisonResultStore();
        store.save(
                result,
                new ComparisonResultStore.ResultFiles(Map.of(
                        ResultType.REPEATED,
                        new ComparisonResultStore.ResultFile(
                                repeatedFile,
                                offsets,
                                1
                        )
                ))
        );

        ResultPage page = store.readPage(
                "comparison-1",
                ResultType.REPEATED,
                0,
                100
        );

        assertTrue(page.records().isEmpty());
        assertEquals(1, page.repeatedRecords().size());
        assertEquals(1, page.totalPages());
        RepeatedRecord repeated = page.repeatedRecords().getFirst();
        assertEquals("LATEST", repeated.source());
        assertEquals("42", repeated.id());
        assertTrue(Arrays.equals(
                new String[]{"42", "duplicate"},
                repeated.record()
        ));
    }
}
