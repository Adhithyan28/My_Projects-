
        package com.csvcomparison.tool.engine;

import com.csvcomparison.tool.model.ComparisonResult;
import com.csvcomparison.tool.model.RepeatedRecord;
import com.csvcomparison.tool.model.ResultType;
import com.csvcomparison.tool.service.ComparisonResultStore;
import com.csvcomparison.tool.service.ResultFileWriter;
import com.univocity.parsers.csv.CsvParser;
import com.univocity.parsers.csv.CsvParserSettings;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

@Component
public class HashMapComparisonEngine {

    private final CsvHeaderValidator headerValidator;
    private final ComparisonResultStore resultStore;

    public HashMapComparisonEngine(
            CsvHeaderValidator headerValidator,
            ComparisonResultStore resultStore) {

        this.headerValidator = headerValidator;
        this.resultStore = resultStore;
    }

    public ComparisonResult compare(
            Path oldCsv,
            Path newCsv) throws IOException {

        String[] headers =
                headerValidator.validateAndGetHeader(oldCsv, newCsv);

        String comparisonId = UUID.randomUUID().toString();

        Path directory =
                resultStore.createResultDirectory(comparisonId);

        Path addedFile = directory.resolve("added.csv");
        Path updatedFile = directory.resolve("updated.csv");
        Path updatedPreviousFile = directory.resolve("updated-previous.csv");
        Path missingFile = directory.resolve("missing.csv");
        Path repeatedFile = directory.resolve("repeated.csv");

        try {
            Map<String, String[]> oldRecords = new HashMap<>();

            long addedCount = 0;
            long updatedCount = 0;
            long missingCount = 0;

            Set<String> seenNewKeys = new HashSet<>();

            try (
                    ResultFileWriter addedWriter =
                            new ResultFileWriter(addedFile);
                    ResultFileWriter updatedWriter =
                            new ResultFileWriter(updatedFile);
                    ResultFileWriter updatedPreviousWriter =
                            new ResultFileWriter(updatedPreviousFile);
                    ResultFileWriter missingWriter =
                            new ResultFileWriter(missingFile);
                    ResultFileWriter repeatedWriter =
                            new ResultFileWriter(repeatedFile)
            ) {

                // -------------------------------------------------
                // 1. Read the previous CSV.
                //
                // Store the first occurrence of each key.
                // Record every subsequent occurrence as repeated.
                // -------------------------------------------------

                CsvParser oldParser =
                        new CsvParser(createParserSettings());

                try {
                    oldParser.beginParsing(oldCsv.toFile());
                    oldParser.parseNext(); // Skip header.

                    String[] oldRow;

                    while ((oldRow = oldParser.parseNext()) != null) {

                        validateRow(
                                oldRow,
                                headers.length,
                                "previous"
                        );

                        String key = oldRow[0];

                        String[] existingRow =
                                oldRecords.putIfAbsent(key, oldRow);

                        if (existingRow != null) {

                            repeatedWriter.writeRepeatedRecord(
                                    new RepeatedRecord(
                                            "PREVIOUS",
                                            key,
                                            oldRow
                                    )
                            );
                        }
                    }
                } finally {
                    oldParser.stopParsing();
                }

                // -------------------------------------------------
                // 2. Read the latest CSV and compare by key.
                //
                // Duplicate keys no longer terminate the comparison.
                // Record subsequent occurrences as repeated and
                // skip normal comparison for those occurrences.
                // -------------------------------------------------

                CsvParser newParser =
                        new CsvParser(createParserSettings());

                try {
                    newParser.beginParsing(newCsv.toFile());
                    newParser.parseNext(); // Skip header.

                    String[] newRow;

                    while ((newRow = newParser.parseNext()) != null) {

                        validateRow(
                                newRow,
                                headers.length,
                                "latest"
                        );

                        String key = newRow[0];

                        // Detect duplicate keys in the latest CSV.
                        // Keep the first occurrence for comparison.
                        if (!seenNewKeys.add(key)) {

                            repeatedWriter.writeRepeatedRecord(
                                    new RepeatedRecord(
                                            "LATEST",
                                            key,
                                            newRow
                                    )
                            );

                            continue;
                        }

                        // Remove the matching previous row so it
                        // cannot later be reported as missing.
                        String[] oldRow = oldRecords.remove(key);

                        if (oldRow == null) {

                            // Key exists only in the latest CSV.
                            addedWriter.writeRecord(newRow);
                            addedCount++;

                        } else if (!Arrays.equals(oldRow, newRow)) {

                            // Same key, but one or more columns differ.
                            // Store the latest version as updated.
                            updatedWriter.writeRecord(newRow);
                            updatedPreviousWriter.writeRecord(oldRow);
                            updatedCount++;
                        }

                        // Identical rows are unchanged.
                    }
                } finally {
                    newParser.stopParsing();
                }

                // -------------------------------------------------
                // 3. Any remaining first occurrences from the
                // previous CSV are missing from the latest CSV.
                // -------------------------------------------------

                for (String[] oldRow : oldRecords.values()) {

                    missingWriter.writeRecord(oldRow);
                    missingCount++;
                }

                // -------------------------------------------------
                // 4. Build the summary and register result files
                // with their pagination indexes.
                // -------------------------------------------------

                long repeatedCount =
                        repeatedWriter.getRecordCount();

                ComparisonResult result = new ComparisonResult(
                        comparisonId,
                        Arrays.asList(headers),
                        addedCount,
                        updatedCount,
                        missingCount,
                        repeatedCount
                );

                ComparisonResultStore.ResultFiles resultFiles =
                        new ComparisonResultStore.ResultFiles(
                                Map.of(
                                        ResultType.ADDED,
                                        new ComparisonResultStore.ResultFile(
                                                addedFile,
                                                addedWriter.getPageOffsets(),
                                                addedWriter.getRecordCount()
                                        ),

                                        ResultType.UPDATED,
                                        new ComparisonResultStore.ResultFile(
                                                updatedFile,
                                                updatedWriter.getPageOffsets(),
                                                updatedWriter.getRecordCount()
                                        ),

                                        ResultType.MISSING,
                                        new ComparisonResultStore.ResultFile(
                                                missingFile,
                                                missingWriter.getPageOffsets(),
                                                missingWriter.getRecordCount()
                                        ),

                                        ResultType.REPEATED,
                                        new ComparisonResultStore.ResultFile(
                                                repeatedFile,
                                                repeatedWriter.getPageOffsets(),
                                                repeatedWriter.getRecordCount()
                                        )
                                ),
                                updatedPreviousFile
                        );

                resultStore.save(result, resultFiles);

                return result;
            }

        } catch (Exception e) {

            deleteDirectory(directory);

            if (e instanceof IOException ioException) {
                throw ioException;
            }

            throw new IOException(
                    "HashMap comparison failed.",
                    e
            );
        }
    }

    private void validateRow(
            String[] row,
            int expectedColumns,
            String source) throws IOException {

        if (row.length != expectedColumns) {
            throw new IOException(
                    "Invalid column count in " + source + " CSV."
            );
        }

        if (row[0] == null || row[0].isBlank()) {
            throw new IOException(
                    "Blank key found in " + source + " CSV."
            );
        }
    }

    private CsvParserSettings createParserSettings() {

        CsvParserSettings settings = new CsvParserSettings();

        settings.setHeaderExtractionEnabled(false);
        settings.setLineSeparatorDetectionEnabled(true);

        return settings;
    }

    private void deleteDirectory(Path directory) {

        try (var paths = Files.walk(directory)) {

            paths.sorted(Comparator.reverseOrder())
                    .forEach(path -> {
                        try {
                            Files.deleteIfExists(path);
                        } catch (IOException ignored) {
                            // Preserve the original comparison error.
                        }
                    });

        } catch (IOException ignored) {
            // Preserve the original comparison error.
        }
    }
}
