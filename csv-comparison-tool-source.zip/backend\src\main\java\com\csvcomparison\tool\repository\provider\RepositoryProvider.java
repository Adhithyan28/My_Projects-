package com.csvcomparison.tool.repository.provider;

import com.csvcomparison.tool.model.RepositoryPublishResult;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

/**
 * Platform adapter for repository hosting services.
 *
 * Add a platform by implementing this contract and registering it as a Spring
 * component. Controllers and CSV comparison logic stay platform-independent.
 */
public interface RepositoryProvider {

    String getProviderName();

    String buildAuthorizationUrl(String state);

    String exchangeCodeForAccessToken(String code);

    List<RepositorySummary> getRepositories(String accessToken);

    List<String> getBranches(String accessToken, String repositoryId);

    List<String> getFiles(
            String accessToken,
            String repositoryId,
            String branch
    );

    void downloadFile(
            String accessToken,
            String repositoryId,
            String branch,
            String filePath,
            Path destination
    ) throws IOException;

    RepositoryPublishResult publishComparison(
            String accessToken,
            String comparisonId,
            String repositoryId,
            String sourceBranch,
            String destinationPath,
            String commitMessage
    ) throws IOException;

    record RepositorySummary(
            String id,
            String fullName,
            String defaultBranch,
            String description
    ) {
    }
}
