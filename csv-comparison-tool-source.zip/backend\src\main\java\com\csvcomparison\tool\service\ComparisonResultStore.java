package com.csvcomparison.tool.service;

import com.csvcomparison.tool.model.ComparisonResult;
import com.csvcomparison.tool.model.RepeatedRecord;
import com.csvcomparison.tool.model.ResultPage;
import com.csvcomparison.tool.model.ResultType;
import org.springframework.stereotype.Component;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class ComparisonResultStore {

    private final Map<String, StoredComparison> comparisons =
            new ConcurrentHashMap<>();

    private final ResultFileReader resultFileReader =
            new ResultFileReader();

    private volatile String latestComparisonId;

    public Path createResultDirectory(String comparisonId)
            throws IOException {
        return Files.createTempDirectory(
                "csv-result-" + comparisonId
        );
    }

    public void save(
            ComparisonResult result,
            ResultFiles resultFiles
    ) {
        comparisons.put(
                result.comparisonId(),
                new StoredComparison(result, resultFiles)
        );

        latestComparisonId = result.comparisonId();
    }

    public ComparisonResult get() {
        if (latestComparisonId == null) {
            return null;
        }

        return get(latestComparisonId);
    }

    public ComparisonResult get(String comparisonId) {
        StoredComparison stored = comparisons.get(comparisonId);

        return stored == null ? null : stored.result();
    }

    public ResultPage readPage(
            String comparisonId,
            ResultType type,
            int page,
            int size
    ) throws IOException {

        StoredComparison stored = comparisons.get(comparisonId);

        if (stored == null) {
            return null;
        }

        ResultFile resultFile = stored.resultFiles()
                .files()
                .get(type);

        if (resultFile == null) {
            return null;
        }

        List<String[]> rows = resultFileReader.readPage(
                resultFile.path(),
                resultFile.offsets(),
                page,
                size
        );

        if (type == ResultType.REPEATED) {
            List<RepeatedRecord> repeatedRecords = rows.stream()
                    .map(row -> {
                        if (row.length < 2) {
                            throw new IllegalStateException(
                                    "Stored repeated result row is missing its source or key."
                            );
                        }

                        return new RepeatedRecord(
                                row[0],
                                row[1],
                                java.util.Arrays.copyOfRange(row, 2, row.length)
                        );
                    })
                    .toList();

            return new ResultPage(
                    page,
                    size,
                    resultFile.count(),
                    totalPages(resultFile.count(), size),
                    List.of(),
                    repeatedRecords
            );
        }

        return new ResultPage(
                page,
                size,
                resultFile.count(),
                totalPages(resultFile.count(), size),
                rows,
                List.of()
        );
    }

    private long totalPages(long totalRecords, int size) {
        return totalRecords / size
                + (totalRecords % size == 0 ? 0 : 1);
    }

    public Path exportAddedCsv(String comparisonId)
            throws IOException {
        return exportCsv(comparisonId, ResultType.ADDED);
    }

    public Path exportUpdatedCsv(String comparisonId)
            throws IOException {
        return exportCsv(comparisonId, ResultType.UPDATED);
    }

    public Path exportUpdatedExcel(
            String comparisonId,
            UpdatedRecordsExcelExporter exporter
    ) throws IOException {
        StoredComparison stored = comparisons.get(comparisonId);
        if (stored == null) {
            throw new IllegalArgumentException("Comparison not found.");
        }

        ResultFile updatedFile = stored.resultFiles()
                .files()
                .get(ResultType.UPDATED);
        Path previousFile = stored.resultFiles().updatedPreviousPath();
        if (updatedFile == null || previousFile == null) {
            throw new IllegalStateException(
                    "Updated record values are not available for the Excel report."
            );
        }

        Path exportFile = Files.createTempFile(
                "csv-updated-highlights-",
                ".xlsx"
        );
        try {
            exporter.write(
                    stored.result().headers(),
                    updatedFile.path(),
                    previousFile,
                    exportFile
            );
        } catch (IOException | RuntimeException exception) {
            Files.deleteIfExists(exportFile);
            throw exception;
        }
        return exportFile;
    }

    public Path exportCsv(
            String comparisonId,
            ResultType type
    ) throws IOException {

        StoredComparison stored = comparisons.get(comparisonId);

        if (stored == null) {
            throw new IllegalArgumentException(
                    "Comparison not found."
            );
        }

        ResultFile resultFile = stored.resultFiles()
                .files()
                .get(type);

        if (resultFile == null) {
            throw new IllegalStateException(
                    "Generated " + type.name().toLowerCase()
                            + ".csv was not found."
            );
        }

        String prefix = type == ResultType.ADDED
                ? "csv-added-export-"
                : "csv-updated-export-";

        Path exportFile = Files.createTempFile(prefix, ".csv");

        try (BufferedWriter writer = Files.newBufferedWriter(
                exportFile,
                StandardCharsets.UTF_8
        )) {
            writer.write(toCsvLine(
                    stored.result().headers().toArray(new String[0])
            ));
            writer.newLine();

            try (var reader = Files.newBufferedReader(
                    resultFile.path(),
                    StandardCharsets.UTF_8
            )) {
                char[] buffer = new char[64 * 1024];
                int length;

                while ((length = reader.read(buffer)) != -1) {
                    writer.write(buffer, 0, length);
                }
            }
        } catch (IOException | RuntimeException ex) {
            Files.deleteIfExists(exportFile);
            throw ex;
        }

        return exportFile;
    }

    private String toCsvLine(String[] record) {
        StringBuilder builder = new StringBuilder();

        for (int i = 0; i < record.length; i++) {
            if (i > 0) {
                builder.append(',');
            }

            String value = record[i] == null ? "" : record[i];

            if (value.contains(",")
                    || value.contains("\"")
                    || value.contains("\n")
                    || value.contains("\r")) {
                builder.append('"')
                        .append(value.replace("\"", "\"\""))
                        .append('"');
            } else {
                builder.append(value);
            }
        }

        return builder.toString();
    }

    public boolean contains(String comparisonId) {
        return comparisons.containsKey(comparisonId);
    }

    public void clear() {
        for (StoredComparison stored : comparisons.values()) {
            deleteResultFiles(stored.resultFiles());
        }

        comparisons.clear();
        latestComparisonId = null;
    }

    private void deleteResultFiles(ResultFiles resultFiles) {
        if (resultFiles == null
                || resultFiles.files() == null
                || resultFiles.files().isEmpty()) {
            return;
        }

        Path directory = resultFiles.files()
                .values()
                .iterator()
                .next()
                .path()
                .getParent();

        if (directory == null) {
            return;
        }

        try (var paths = Files.walk(directory)) {
            paths.sorted(Comparator.reverseOrder())
                    .forEach(path -> {
                        try {
                            Files.deleteIfExists(path);
                        } catch (IOException ignored) {
                            // Best-effort cleanup.
                        }
                    });
        } catch (IOException ignored) {
            // Best-effort cleanup.
        }
    }

    public record ResultFiles(
            Map<ResultType, ResultFile> files,
            Path updatedPreviousPath
    ) {
        public ResultFiles(Map<ResultType, ResultFile> files) {
            this(files, null);
        }
    }

    public record ResultFile(
            Path path,
            List<Long> offsets,
            long count
    ) {
    }

    private record StoredComparison(
            ComparisonResult result,
            ResultFiles resultFiles
    ) {
    }
}