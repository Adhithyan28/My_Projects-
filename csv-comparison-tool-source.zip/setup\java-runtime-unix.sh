ensure_java_runtime() {
    java_major_version() {
        java -version 2>&1 | awk -F '"' '/version/ { split($2, v, "."); print v[1]; exit }'
    }

    java_major=""
    if command -v java >/dev/null 2>&1; then
        java_major=$(java_major_version)
    fi

    if [ -n "$java_major" ] && [ "$java_major" -ge 21 ]; then
        echo "Java $java_major detected."
        return
    fi

    printf "Java 21 or newer is required. Install it now? [y/N] "
    IFS= read -r answer
    case "$answer" in
        y|Y|yes|YES) ;;
        *) echo "Install Java 21+ and run this script again." >&2; return 1 ;;
    esac

    os_name=$(uname -s)
    if [ "$os_name" = "Darwin" ]; then
        if ! command -v brew >/dev/null 2>&1; then
            printf "Homebrew is required to install Java automatically. Install Homebrew now? [y/N] "
            IFS= read -r install_brew
            case "$install_brew" in
                y|Y|yes|YES)
                    if ! command -v curl >/dev/null 2>&1; then
                        echo "curl is required to install Homebrew." >&2
                        return 1
                    fi
                    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
                    ;;
                *) echo "Install Java 21+ manually and rerun." >&2; return 1 ;;
            esac
        fi
        brew install --cask temurin@21
        if [ -x /usr/libexec/java_home ]; then
            export JAVA_HOME=$(/usr/libexec/java_home -v 21)
            export PATH="$JAVA_HOME/bin:$PATH"
        fi
    elif [ "$os_name" = "Linux" ]; then
        if command -v apt-get >/dev/null 2>&1; then
            if [ "$(id -u)" -eq 0 ]; then
                apt-get update
                apt-get install -y openjdk-21-jre-headless
            elif command -v sudo >/dev/null 2>&1; then
                sudo apt-get update
                sudo apt-get install -y openjdk-21-jre-headless
            else
                echo "Install Java 21+ with your package manager and rerun." >&2
                return 1
            fi
        elif command -v dnf >/dev/null 2>&1; then
            if [ "$(id -u)" -eq 0 ]; then
                dnf install -y java-21-openjdk
            elif command -v sudo >/dev/null 2>&1; then
                sudo dnf install -y java-21-openjdk
            else
                echo "Install Java 21+ with your package manager and rerun." >&2
                return 1
            fi
        else
            echo "Automatic Java installation is not supported by this Linux package manager." >&2
            echo "Install Java 21+ and rerun." >&2
            return 1
        fi
    else
        echo "Unsupported operating system: $os_name. Install Java 21+ and rerun." >&2
        return 1
    fi

    java_major=$(java_major_version)
    if [ -z "$java_major" ] || [ "$java_major" -lt 21 ]; then
        echo "Java installation did not become available. Reopen your terminal and rerun." >&2
        return 1
    fi
    echo "Java $java_major is ready."
}

find_free_port() {
    preferred_port=$1
    port=$preferred_port

    while [ "$port" -le 65535 ]; do
        if command -v python3 >/dev/null 2>&1; then
            if python3 -c 'import socket,sys; s=socket.socket(); s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1); s.bind(("127.0.0.1",int(sys.argv[1]))); s.close()' "$port" >/dev/null 2>&1; then
                printf '%s\n' "$port"
                return 0
            fi
        elif command -v nc >/dev/null 2>&1; then
            if ! nc -z 127.0.0.1 "$port" >/dev/null 2>&1; then
                printf '%s\n' "$port"
                return 0
            fi
        elif command -v lsof >/dev/null 2>&1; then
            if ! lsof -iTCP:"$port" -sTCP:LISTEN -n -P >/dev/null 2>&1; then
                printf '%s\n' "$port"
                return 0
            fi
        else
            echo "Port selection requires python3, nc, or lsof." >&2
            return 1
        fi
        port=$((port + 1))
    done

    echo "No free TCP port is available starting at $preferred_port." >&2
    return 1
}

set_local_application_urls() {
    selected_port=$1
    if [ -z "${APP_FRONTEND_URL:-}" ] \
            || [ "$APP_FRONTEND_URL" = "http://localhost:8080" ]; then
        export APP_FRONTEND_URL="http://localhost:$selected_port"
    fi

    default_callback="http://localhost:8080/api/connections/github/callback"
    if [ -z "${GITHUB_OAUTH_REDIRECT_URI:-}" ] \
            || [ "$GITHUB_OAUTH_REDIRECT_URI" = "$default_callback" ]; then
        export GITHUB_OAUTH_REDIRECT_URI="http://localhost:$selected_port/api/connections/github/callback"
    fi
}

import_local_oauth_environment() {
    oauth_file=$1
    [ -f "$oauth_file" ] || return 0

    while IFS='=' read -r key value || [ -n "$key" ]; do
        case "$key" in
            GITHUB_OAUTH_CLIENT_ID)
                [ -n "${GITHUB_OAUTH_CLIENT_ID:-}" ] || export GITHUB_OAUTH_CLIENT_ID=$value
                ;;
            GITHUB_OAUTH_CLIENT_SECRET)
                [ -n "${GITHUB_OAUTH_CLIENT_SECRET:-}" ] || export GITHUB_OAUTH_CLIENT_SECRET=$value
                ;;
            GITHUB_OAUTH_REDIRECT_URI)
                [ -n "${GITHUB_OAUTH_REDIRECT_URI:-}" ] || export GITHUB_OAUTH_REDIRECT_URI=$value
                ;;
        esac
    done < "$oauth_file"
}

configure_local_oauth_environment() {
    oauth_file=$1
    if { [ -z "${GITHUB_OAUTH_CLIENT_ID:-}" ] \
            || [ -z "${GITHUB_OAUTH_CLIENT_SECRET:-}" ]; }; then
        if [ ! -t 0 ]; then
            echo "No terminal is available for OAuth setup. Continuing without GitHub OAuth."
            return 0
        fi

        printf "GitHub OAuth is optional. Leave both credentials empty for CSV-only use.\n"
        printf "GitHub OAuth client ID: "
        IFS= read -r client_id
        printf "GitHub OAuth client secret (input hidden): "
        stty -echo
        IFS= read -r client_secret
        stty echo
        printf "\n"

        if [ -z "$client_id" ] && [ -z "$client_secret" ]; then
            printf "Continuing without GitHub OAuth.\n"
            return 0
        fi
        if [ -z "$client_id" ] || [ -z "$client_secret" ]; then
            echo "Enter both OAuth values, or leave both empty for CSV-only use." >&2
            return 1
        fi

        printf "GitHub callback URI [http://localhost:8080/api/connections/github/callback]: "
        IFS= read -r redirect_uri
        redirect_uri=${redirect_uri:-http://localhost:8080/api/connections/github/callback}

        case "$client_id$client_secret$redirect_uri" in
            *"
"*)
                echo "OAuth values cannot contain line breaks." >&2
                return 1
                ;;
        esac

        umask 077
        {
            printf 'GITHUB_OAUTH_CLIENT_ID=%s\n' "$client_id"
            printf 'GITHUB_OAUTH_CLIENT_SECRET=%s\n' "$client_secret"
            printf 'GITHUB_OAUTH_REDIRECT_URI=%s\n' "$redirect_uri"
        } > "$oauth_file"
        chmod 600 "$oauth_file"
        printf "OAuth settings saved locally; this file must not be shared.\n"
    fi

    import_local_oauth_environment "$oauth_file"
}
