package com.csvcomparison.tool.controller;

import com.csvcomparison.tool.repository.auth.OAuthStateService;
import com.csvcomparison.tool.repository.provider.ProviderSessionKeys;
import com.csvcomparison.tool.repository.provider.RepositoryProvider;
import com.csvcomparison.tool.repository.provider.RepositoryProviderRegistry;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.view.RedirectView;

import java.util.Map;

@RestController
@RequestMapping("/api/connections/{provider}")
public class RepositoryConnectionController {

    private final RepositoryProviderRegistry providerRegistry;
    private final OAuthStateService oauthStateService;
    private final String frontendUrl;

    public RepositoryConnectionController(
            RepositoryProviderRegistry providerRegistry,
            OAuthStateService oauthStateService,
            @Value("${app.frontend-url:http://localhost:5173}")
            String frontendUrl
    ) {
        this.providerRegistry = providerRegistry;
        this.oauthStateService = oauthStateService;
        this.frontendUrl = frontendUrl.replaceAll("/+$", "");
    }

    @GetMapping("/authorize")
    public ResponseEntity<Map<String, String>> authorize(
            @PathVariable String provider,
            HttpSession session
    ) {
        try {
            RepositoryProvider repositoryProvider =
                    providerRegistry.get(provider);
            String normalizedProvider = repositoryProvider.getProviderName();
            session.removeAttribute(
                    ProviderSessionKeys.tokenKey(normalizedProvider)
            );

            String state = oauthStateService.createState(
                    session,
                    normalizedProvider
            );
            return ResponseEntity.ok(Map.of(
                    "authorizationUrl",
                    repositoryProvider.buildAuthorizationUrl(state)
            ));
        } catch (IllegalStateException exception) {
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                    .body(Map.of("error", exception.getMessage()));
        } catch (IllegalArgumentException exception) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", exception.getMessage()));
        }
    }

    @GetMapping("/callback")
    public RedirectView callback(
            @PathVariable String provider,
            @RequestParam(required = false) String code,
            @RequestParam(required = false) String state,
            @RequestParam(required = false) String error,
            HttpServletRequest request,
            HttpSession session
    ) {
        RepositoryProvider repositoryProvider =
                providerRegistry.get(provider);
        String normalizedProvider = repositoryProvider.getProviderName();

        if (error != null) {
            return redirect(normalizedProvider + "Error=access_denied");
        }
        if (code == null || code.isBlank()) {
            return redirect(normalizedProvider + "Error=missing_code");
        }
        if (!oauthStateService.validateAndConsumeState(
                session, state, normalizedProvider
        )) {
            return redirect(normalizedProvider + "Error=invalid_state");
        }

        try {
            String accessToken =
                    repositoryProvider.exchangeCodeForAccessToken(code);
            request.changeSessionId();
            session.setAttribute(
                    ProviderSessionKeys.tokenKey(normalizedProvider),
                    accessToken
            );
            return redirect("connected=" + normalizedProvider);
        } catch (RuntimeException exception) {
            session.removeAttribute(
                    ProviderSessionKeys.tokenKey(normalizedProvider)
            );
            return redirect(
                    normalizedProvider + "Error=token_exchange_failed"
            );
        }
    }

    private RedirectView redirect(String query) {
        RedirectView redirectView =
                new RedirectView(frontendUrl + "/?" + query);
        redirectView.setStatusCode(HttpStatus.FOUND);
        redirectView.setExposeModelAttributes(false);
        return redirectView;
    }
}
