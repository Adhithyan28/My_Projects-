package com.csvcomparison.tool.service;

import com.univocity.parsers.csv.CsvParser;
import com.univocity.parsers.csv.CsvParserSettings;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Objects;

@Component
public class UpdatedRecordsExcelExporter {

    private static final int MAX_ROWS_PER_SHEET = 1_048_575;
    private static final int MAX_COLUMNS = 16_384;

    public void write(
            List<String> headers,
            Path latestCsv,
            Path previousCsv,
            Path destination
    ) throws IOException {
        if (headers.size() > MAX_COLUMNS) {
            throw new IOException(
                    "The updated records exceed Excel's maximum of 16,384 columns."
            );
        }

        CsvParser latestParser = createParser();
        CsvParser previousParser = createParser();
        latestParser.beginParsing(latestCsv.toFile());
        previousParser.beginParsing(previousCsv.toFile());

        try (SXSSFWorkbook workbook = new SXSSFWorkbook(100);
             OutputStream output = Files.newOutputStream(destination)) {
            workbook.setCompressTempFiles(true);

            CellStyle headerStyle = workbook.createCellStyle();
            Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerStyle.setFont(headerFont);

            CellStyle changedStyle = workbook.createCellStyle();
            changedStyle.setFillForegroundColor(
                    IndexedColors.LIGHT_YELLOW.getIndex()
            );
            changedStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

            int sheetNumber = 1;
            SXSSFSheet updatedSheet = createSheet(
                    workbook,
                    "Updated " + sheetNumber,
                    headers,
                    headerStyle
            );
            SXSSFSheet previousSheet = createSheet(
                    workbook,
                    "Previous " + sheetNumber,
                    headers,
                    headerStyle
            );
            int rowIndex = 1;
            String[] latestRow;
            String[] previousRow;

            while ((latestRow = latestParser.parseNext()) != null) {
                previousRow = previousParser.parseNext();
                if (previousRow == null) {
                    throw new IOException(
                            "Updated rows do not match their previous values."
                    );
                }
                validateRow(latestRow, headers.size());
                validateRow(previousRow, headers.size());

                if (rowIndex > MAX_ROWS_PER_SHEET) {
                    sheetNumber++;
                    updatedSheet = createSheet(
                            workbook,
                            "Updated " + sheetNumber,
                            headers,
                            headerStyle
                    );
                    previousSheet = createSheet(
                            workbook,
                            "Previous " + sheetNumber,
                            headers,
                            headerStyle
                    );
                    rowIndex = 1;
                }

                Row updatedExcelRow = updatedSheet.createRow(rowIndex);
                Row previousExcelRow = previousSheet.createRow(rowIndex);

                for (int column = 0; column < headers.size(); column++) {
                    Cell updatedCell = updatedExcelRow.createCell(column);
                    updatedCell.setCellValue(latestRow[column]);
                    if (!Objects.equals(latestRow[column], previousRow[column])) {
                        updatedCell.setCellStyle(changedStyle);
                    }

                    previousExcelRow.createCell(column)
                            .setCellValue(previousRow[column]);
                }
                rowIndex++;
            }

            if (previousParser.parseNext() != null) {
                throw new IOException(
                        "Updated rows do not match their previous values."
                );
            }

            workbook.write(output);
        } catch (IOException | RuntimeException exception) {
            Files.deleteIfExists(destination);
            throw exception;
        } finally {
            latestParser.stopParsing();
            previousParser.stopParsing();
        }
    }

    private SXSSFSheet createSheet(
            SXSSFWorkbook workbook,
            String name,
            List<String> headers,
            CellStyle headerStyle
    ) {
        SXSSFSheet sheet = workbook.createSheet(name);
        Row headerRow = sheet.createRow(0);
        for (int column = 0; column < headers.size(); column++) {
            Cell cell = headerRow.createCell(column);
            cell.setCellValue(headers.get(column));
            cell.setCellStyle(headerStyle);
            int width = Math.min(
                    50,
                    Math.max(12, headers.get(column).length() + 2)
            );
            sheet.setColumnWidth(column, width * 256);
        }
        sheet.createFreezePane(0, 1);
        if (!headers.isEmpty()) {
            sheet.setAutoFilter(new CellRangeAddress(
                    0,
                    0,
                    0,
                    headers.size() - 1
            ));
        }
        return sheet;
    }

    private CsvParser createParser() {
        CsvParserSettings settings = new CsvParserSettings();
        settings.setHeaderExtractionEnabled(false);
        settings.setLineSeparatorDetectionEnabled(true);
        return new CsvParser(settings);
    }

    private void validateRow(String[] row, int expectedColumns)
            throws IOException {
        if (row.length != expectedColumns) {
            throw new IOException(
                    "Stored updated row has an unexpected number of columns."
            );
        }
    }
}
