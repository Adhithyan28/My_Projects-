package com.csvcomparison.tool.controller;

import com.csvcomparison.tool.model.ComparisonResult;
import com.csvcomparison.tool.model.ResultPage;
import com.csvcomparison.tool.model.ResultType;
import com.csvcomparison.tool.service.CsvComparisonService;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

@RestController
@RequestMapping("/api/comparisons")
public class CsvComparisonController {

    private final CsvComparisonService comparisonService;

    public CsvComparisonController(
            CsvComparisonService comparisonService
    ) {
        this.comparisonService =
                comparisonService;
    }

    @PostMapping(
            consumes =
                    MediaType.MULTIPART_FORM_DATA_VALUE
    )
    public ResponseEntity<ComparisonResult> compare(
            @RequestParam("oldFile")
            MultipartFile oldFile,

            @RequestParam("newFile")
            MultipartFile newFile
    ) throws IOException {

        Path oldCsv =
                Files.createTempFile(
                        "old-csv-",
                        ".csv"
                );

        Path newCsv =
                Files.createTempFile(
                        "new-csv-",
                        ".csv"
                );

        try {

            oldFile.transferTo(oldCsv);
            newFile.transferTo(newCsv);

            ComparisonResult result =
                    comparisonService.compare(
                            oldCsv,
                            newCsv
                    );

            return ResponseEntity.ok(
                    result
            );

        } finally {

            Files.deleteIfExists(
                    oldCsv
            );

            Files.deleteIfExists(
                    newCsv
            );
        }
    }

    @GetMapping("/latest")
    public ResponseEntity<ComparisonResult>
    getLatestComparison() {

        ComparisonResult result =
                comparisonService
                        .getLatestComparison();

        if (result == null) {
            return ResponseEntity
                    .notFound()
                    .build();
        }

        return ResponseEntity.ok(
                result
        );
    }

    @GetMapping("/{comparisonId}")
    public ResponseEntity<ComparisonResult>
    getComparison(
            @PathVariable String comparisonId
    ) {

        ComparisonResult result =
                comparisonService
                        .getComparison(
                                comparisonId
                        );

        if (result == null) {

            return ResponseEntity
                    .notFound()
                    .build();
        }

        return ResponseEntity.ok(
                result
        );
    }

    @GetMapping(
            "/{comparisonId}/results/{type}"
    )
    public ResponseEntity<ResultPage> getResults(
            @PathVariable String comparisonId,

            @PathVariable ResultType type,

            @RequestParam(
                    defaultValue = "0"
            )
            int page,

            @RequestParam(
                    defaultValue = "100"
            )
            int size
    ) throws IOException {

        if (page < 0) {

            return ResponseEntity
                    .badRequest()
                    .build();
        }

        if (size <= 0 || size > 1000) {

            return ResponseEntity
                    .badRequest()
                    .build();
        }

        ResultPage result =
                comparisonService.getResultPage(
                        comparisonId,
                        type,
                        page,
                        size
                );

        if (result == null) {

            return ResponseEntity
                    .notFound()
                    .build();
        }

        return ResponseEntity.ok(
                result
        );
    }
}