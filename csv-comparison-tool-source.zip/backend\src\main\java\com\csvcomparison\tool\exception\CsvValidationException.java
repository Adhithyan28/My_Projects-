package com.csvcomparison.tool.exception;

public class CsvValidationException extends RuntimeException {

    public CsvValidationException(String message) {
        super(message);
    }
}