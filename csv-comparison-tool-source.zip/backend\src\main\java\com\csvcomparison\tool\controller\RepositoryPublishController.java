package com.csvcomparison.tool.controller;

import com.csvcomparison.tool.model.RepositoryPublishRequest;
import com.csvcomparison.tool.repository.provider.ProviderSessionKeys;
import com.csvcomparison.tool.repository.provider.RepositoryProvider;
import com.csvcomparison.tool.repository.provider.RepositoryProviderRegistry;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientResponseException;

import java.io.IOException;
import java.util.Map;

@RestController
@RequestMapping("/api/repository-comparisons")
public class RepositoryPublishController {

    private final RepositoryProviderRegistry providerRegistry;

    public RepositoryPublishController(
            RepositoryProviderRegistry providerRegistry
    ) {
        this.providerRegistry = providerRegistry;
    }

    @PostMapping("/{comparisonId}/publish")
    public ResponseEntity<?> publishAddedCsv(
            @PathVariable String comparisonId,
            @RequestBody RepositoryPublishRequest request,
            HttpSession session
    ) {
        if (request == null) {
            return ResponseEntity.badRequest()
                    .body(Map.of("message", "A publish request is required."));
        }

        String providerName = request.provider() == null
                || request.provider().isBlank()
                ? "github"
                : request.provider();

        RepositoryProvider provider;
        try {
            provider = providerRegistry.get(providerName);
        } catch (IllegalArgumentException exception) {
            return ResponseEntity.badRequest()
                    .body(Map.of("message", exception.getMessage()));
        }

        String token = ProviderSessionKeys.getToken(
                session,
                provider.getProviderName()
        );
        if (token == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of(
                    "message",
                    "Connect " + provider.getProviderName()
                            + " before publishing."
            ));
        }

        try {
            return ResponseEntity.ok(provider.publishComparison(
                    token,
                    comparisonId,
                    request.repositoryId(),
                    request.sourceBranch(),
                    request.destinationPath(),
                    request.commitMessage()
            ));
        } catch (IllegalArgumentException exception) {
            return ResponseEntity.badRequest()
                    .body(Map.of("message", exception.getMessage()));
        } catch (IllegalStateException exception) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("message", exception.getMessage()));
        } catch (IOException exception) {
            return ResponseEntity.internalServerError().body(Map.of(
                    "message",
                    "Could not prepare the generated CSV for publishing."
            ));
        } catch (RestClientResponseException exception) {
            int status = exception.getStatusCode().value();
            HttpStatus responseStatus = switch (status) {
                case 401 -> HttpStatus.UNAUTHORIZED;
                case 403 -> HttpStatus.FORBIDDEN;
                case 404 -> HttpStatus.NOT_FOUND;
                default -> HttpStatus.BAD_GATEWAY;
            };
            return ResponseEntity.status(responseStatus).body(Map.of(
                    "message",
                    "The repository provider could not complete publishing."
            ));
        }
    }
}
