#!/usr/bin/env sh
set -eu

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
PROJECT_ROOT=$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd)
CONFIG_PATH="$PROJECT_ROOT/backend/oauth.env"

printf "GitHub OAuth client ID: "
IFS= read -r CLIENT_ID
printf "GitHub OAuth client secret (input hidden): "
stty -echo
IFS= read -r CLIENT_SECRET
stty echo
printf "\n"

if [ -z "$CLIENT_ID" ] && [ -z "$CLIENT_SECRET" ]; then
    umask 077
    printf 'GITHUB_OAUTH_SETUP_SKIPPED=true\n' > "$CONFIG_PATH"
    chmod 600 "$CONFIG_PATH"
    printf "No OAuth credentials entered. Continuing without GitHub integration.\n"
    exit 0
fi

if [ -z "$CLIENT_ID" ] || [ -z "$CLIENT_SECRET" ]; then
    printf "Enter both OAuth values, or leave both empty for CSV-only use.\n" >&2
    exit 1
fi

printf "GitHub callback URI [http://localhost:8080/api/connections/github/callback]: "
IFS= read -r REDIRECT_URI
REDIRECT_URI=${REDIRECT_URI:-http://localhost:8080/api/connections/github/callback}

umask 077
{
    printf 'GITHUB_OAUTH_CLIENT_ID=%s\n' "$CLIENT_ID"
    printf 'GITHUB_OAUTH_CLIENT_SECRET=%s\n' "$CLIENT_SECRET"
    printf 'GITHUB_OAUTH_REDIRECT_URI=%s\n' "$REDIRECT_URI"
} > "$CONFIG_PATH"

chmod 600 "$CONFIG_PATH"
printf "OAuth settings saved to backend/oauth.env.\n"
printf "This file is git-ignored. Restart the backend to load the new settings.\n"
