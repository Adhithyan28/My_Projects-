package com.csvcomparison.tool.model;

public record RepeatedRecord(

        String source,

        String id,

        String[] record

) {
}