
package com.csvcomparison.tool.service;

import com.csvcomparison.tool.model.ComparisonResult;
import com.csvcomparison.tool.model.RepositoryPublishResult;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.util.UriComponentsBuilder;
import tools.jackson.databind.JsonNode;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

@Service
public class RepositoryPublishService {

    private static final String GITHUB_API = "https://api.github.com";
    private static final long MAX_FILE_BYTES = 10L * 1024 * 1024;

    private final ComparisonResultStore resultStore;
    private final UpdatedRecordsExcelExporter excelExporter;
    private final RestClient restClient;

    public RepositoryPublishService(
            ComparisonResultStore resultStore,
            UpdatedRecordsExcelExporter excelExporter
    ) {
        this.resultStore = resultStore;
        this.excelExporter = excelExporter;
        this.restClient = RestClient.builder()
                .baseUrl(GITHUB_API)
                .build();
    }

    /**
     * Publishes added.csv, updated.csv, and an Excel change report together
     * in one Git commit.
     *
     * destinationPath specifies the path for added.csv.
     * updated.csv is placed in the same directory.
     */
    public RepositoryPublishResult publishAddedCsv(
            String comparisonId,
            String repositoryId,
            String sourceBranch,
            String destinationPath,
            String commitMessage,
            String accessToken
    ) throws IOException {

        if (accessToken == null || accessToken.isBlank()) {
            throw new IllegalArgumentException(
                    "Connect your GitHub account first."
            );
        }

        if (sourceBranch == null || sourceBranch.isBlank()) {
            throw new IllegalArgumentException(
                    "Source branch is required."
            );
        }

        if (destinationPath == null || destinationPath.isBlank()) {
            destinationPath = "comparison-results/added.csv";
        }

        validateDestinationPath(destinationPath);

        String updatedDestinationPath = siblingUpdatedPath(destinationPath);
        ComparisonResult comparison = resultStore.get(comparisonId);
        if (comparison == null) {
            throw new IllegalArgumentException("Comparison not found.");
        }
        boolean hasUpdatedRecords = comparison.updatedRecordCount() > 0;
        String highlightedReportDestinationPath = hasUpdatedRecords
                ? siblingReportPath(destinationPath)
                : null;

        if (commitMessage == null || commitMessage.isBlank()) {
            commitMessage = "Add CSV comparison results";
        }

        String[] repository = decodeRepositoryId(repositoryId);
        String owner = repository[0];
        String repo = repository[1];

        Path addedFile = resultStore.exportAddedCsv(comparisonId);
        Path updatedFile = null;
        Path highlightedReportFile = null;

        String newBranch = "csv-comparison-"
                + UUID.randomUUID().toString().substring(0, 8);

        boolean branchCreated = false;

        try {
            updatedFile = resultStore.exportUpdatedCsv(comparisonId);
            if (hasUpdatedRecords) {
                highlightedReportFile = resultStore.exportUpdatedExcel(
                        comparisonId,
                        excelExporter
                );
            }

            validateFileSize(addedFile);
            validateFileSize(updatedFile);
            if (highlightedReportFile != null) {
                validateFileSize(highlightedReportFile);
            }

            // 1. Get the source branch's latest commit and tree.
            JsonNode branchDetails = githubGet(
                    accessToken,
                    branchUri(owner, repo, sourceBranch),
                    "GET source branch",
                    JsonNode.class
            );

            String sourceSha = branchDetails.path("commit")
                    .path("sha")
                    .asText();

            String sourceTreeSha = branchDetails.path("commit")
                    .path("commit")
                    .path("tree")
                    .path("sha")
                    .asText();

            if (sourceSha.isBlank() || sourceTreeSha.isBlank()) {
                throw new IllegalStateException(
                        "Could not determine the source branch commit and tree."
                );
            }

            // 2. Create a new branch from the source commit.
            Map<String, Object> refBody = Map.of(
                    "ref", "refs/heads/" + newBranch,
                    "sha", sourceSha
            );

            githubPost(
                    accessToken,
                    "/repos/" + owner + "/" + repo + "/git/refs",
                    refBody,
                    "CREATE branch",
                    JsonNode.class
            );

            branchCreated = true;

            // 3. Create blobs for the generated CSVs and Excel report.
            String addedBlobSha = createBlob(
                    accessToken,
                    owner,
                    repo,
                    addedFile
            );

            String updatedBlobSha = createBlob(
                    accessToken,
                    owner,
                    repo,
                    updatedFile
            );
            // 4. Add all generated files to one Git tree.
            List<Map<String, Object>> treeEntries = new java.util.ArrayList<>(
                    List.of(
                            createTreeEntry(destinationPath, addedBlobSha),
                            createTreeEntry(updatedDestinationPath, updatedBlobSha)
                    )
            );
            if (highlightedReportFile != null) {
                String highlightedReportBlobSha = createBlob(
                        accessToken,
                        owner,
                        repo,
                        highlightedReportFile
                );
                treeEntries.add(createTreeEntry(
                            highlightedReportDestinationPath,
                            highlightedReportBlobSha
                ));
            }

            Map<String, Object> treeBody = Map.of(
                    "base_tree", sourceTreeSha,
                    "tree", treeEntries
            );

            JsonNode createdTree = githubPost(
                    accessToken,
                    "/repos/" + owner + "/" + repo + "/git/trees",
                    treeBody,
                    "CREATE result tree",
                    JsonNode.class
            );

            String treeSha = createdTree.path("sha").asText();

            if (treeSha.isBlank()) {
                throw new IllegalStateException(
                        "GitHub did not return the generated tree SHA."
                );
            }

            // 5. Create one commit containing every generated result file.
            Map<String, Object> commitBody = Map.of(
                    "message", commitMessage,
                    "tree", treeSha,
                    "parents", List.of(sourceSha)
            );

            JsonNode createdCommit = githubPost(
                    accessToken,
                    "/repos/" + owner + "/" + repo + "/git/commits",
                    commitBody,
                    "CREATE comparison-results commit",
                    JsonNode.class
            );

            String commitSha = createdCommit.path("sha").asText();
            String commitUrl = createdCommit.path("html_url").asText();

            if (commitSha.isBlank()) {
                throw new IllegalStateException(
                        "GitHub did not return the new commit SHA."
                );
            }

            // 6. Update the new branch to point to the combined commit.
            Map<String, Object> updateRefBody = Map.of(
                    "sha", commitSha,
                    "force", false
            );

            githubPatch(
                    accessToken,
                    "/repos/" + owner + "/" + repo
                            + "/git/refs/heads/" + newBranch,
                    updateRefBody,
                    "UPDATE branch to combined commit",
                    JsonNode.class
            );

            // 7. Build URLs for the published files.
            String fileUrl = "https://github.com/"
                    + owner + "/" + repo
                    + "/blob/" + newBranch + "/" + destinationPath;

            String updatedFileUrl = "https://github.com/"
                    + owner + "/" + repo
                    + "/blob/" + newBranch + "/" + updatedDestinationPath;
            String highlightedReportUrl = highlightedReportDestinationPath == null
                    ? null
                    : "https://github.com/"
                            + owner + "/" + repo
                            + "/blob/" + newBranch + "/"
                            + highlightedReportDestinationPath;

            return new RepositoryPublishResult(
                    owner + "/" + repo,
                    newBranch,
                    destinationPath,
                    commitSha,
                    commitUrl,
                    fileUrl,
                    updatedDestinationPath,
                    updatedFileUrl,
                    highlightedReportDestinationPath,
                    highlightedReportUrl,
                    hasUpdatedRecords
                            ? "The CSV files and highlighted Excel change report were committed successfully."
                            : "The CSV files were committed successfully."
            );

        } catch (IOException ex) {
            cleanupIncompleteBranch(
                    branchCreated,
                    accessToken,
                    owner,
                    repo,
                    newBranch
            );
            throw ex;

        } catch (RuntimeException ex) {
            cleanupIncompleteBranch(
                    branchCreated,
                    accessToken,
                    owner,
                    repo,
                    newBranch
            );
            throw ex;

        } finally {
            Files.deleteIfExists(addedFile);

            if (updatedFile != null) {
                Files.deleteIfExists(updatedFile);
            }
            if (highlightedReportFile != null) {
                Files.deleteIfExists(highlightedReportFile);
            }
        }
    }

    private void cleanupIncompleteBranch(
            boolean branchCreated,
            String token,
            String owner,
            String repo,
            String branch
    ) {
        if (!branchCreated) {
            return;
        }

        try {
            deleteBranch(token, owner, repo, branch);
        } catch (RuntimeException cleanupError) {
            System.err.println(
                    "Could not remove incomplete branch: " + branch
            );
        }
    }

    private String createBlob(
            String token,
            String owner,
            String repo,
            Path file
    ) throws IOException {

        byte[] fileBytes = Files.readAllBytes(file);

        Map<String, Object> blobBody = Map.of(
                "content",
                Base64.getEncoder().encodeToString(fileBytes),
                "encoding",
                "base64"
        );

        JsonNode blob = githubPost(
                token,
                "/repos/" + owner + "/" + repo + "/git/blobs",
                blobBody,
                "CREATE comparison file blob",
                JsonNode.class
        );

        String sha = blob.path("sha").asText();

        if (sha.isBlank()) {
            throw new IllegalStateException(
                    "GitHub did not return a comparison file blob SHA."
            );
        }

        return sha;
    }

    private Map<String, Object> createTreeEntry(
            String path,
            String blobSha
    ) {
        Map<String, Object> entry = new HashMap<>();
        entry.put("path", path);
        entry.put("mode", "100644");
        entry.put("type", "blob");
        entry.put("sha", blobSha);
        return entry;
    }

    private void validateFileSize(Path file) throws IOException {
        if (Files.size(file) > MAX_FILE_BYTES) {
            throw new IllegalArgumentException(
                    "Each generated comparison file must not exceed the 10 MiB publishing limit."
            );
        }
    }

    private String siblingUpdatedPath(String addedPath) {
        int lastSlash = addedPath.lastIndexOf('/');

        if (lastSlash < 0) {
            return "updated.csv";
        }

        return addedPath.substring(0, lastSlash + 1) + "updated.csv";
    }

    private String siblingReportPath(String addedPath) {
        int lastSlash = addedPath.lastIndexOf('/');
        String directory = lastSlash < 0
                ? ""
                : addedPath.substring(0, lastSlash + 1);
        return directory + "updated-changes.xlsx";
    }

    private void validateDestinationPath(String path) {
        if (path.startsWith("/")
                || path.contains("\\")
                || path.contains("..")
                || path.endsWith("/")
                || path.isBlank()) {
            throw new IllegalArgumentException(
                    "Invalid destination file path."
            );
        }

        if (!path.toLowerCase(Locale.ROOT).endsWith(".csv")) {
            throw new IllegalArgumentException(
                    "The destination file must end in .csv."
            );
        }
    }

    private void deleteBranch(
            String token,
            String owner,
            String repo,
            String branch
    ) {
        String uri = "/repos/" + owner + "/" + repo
                + "/git/refs/heads/" + branch;

        try {
            restClient.delete()
                    .uri(uri)
                    .headers(headers -> setHeaders(headers, token))
                    .retrieve()
                    .toBodilessEntity();
        } catch (RestClientResponseException ex) {
            logGitHubError("DELETE cleanup branch", uri, ex);
            throw ex;
        }
    }

    private <T> T githubGet(
            String token,
            String uri,
            String operation,
            Class<T> responseType
    ) {
        try {
            return restClient.get()
                    .uri(uri)
                    .headers(headers -> setHeaders(headers, token))
                    .retrieve()
                    .body(responseType);
        } catch (RestClientResponseException ex) {
            logGitHubError(operation, uri, ex);
            throw ex;
        }
    }

    private <T> T githubPost(
            String token,
            String uri,
            Object body,
            String operation,
            Class<T> responseType
    ) {
        try {
            return restClient.post()
                    .uri(uri)
                    .headers(headers -> setHeaders(headers, token))
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(body)
                    .retrieve()
                    .body(responseType);
        } catch (RestClientResponseException ex) {
            logGitHubError(operation, uri, ex);
            throw ex;
        }
    }

    private <T> T githubPatch(
            String token,
            String uri,
            Object body,
            String operation,
            Class<T> responseType
    ) {
        try {
            return restClient.patch()
                    .uri(uri)
                    .headers(headers -> setHeaders(headers, token))
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(body)
                    .retrieve()
                    .body(responseType);
        } catch (RestClientResponseException ex) {
            logGitHubError(operation, uri, ex);
            throw ex;
        }
    }

    private void logGitHubError(
            String operation,
            String uri,
            RestClientResponseException ex
    ) {
        System.err.println("=== GitHub API Error ===");
        System.err.println("Operation: " + operation);
        System.err.println("URI: " + uri);
        System.err.println("HTTP status: " + ex.getStatusCode().value());
        System.err.println("Response: " + ex.getResponseBodyAsString());
        System.err.println("========================");
    }

    private void setHeaders(HttpHeaders headers, String token) {
        headers.setBearerAuth(token);
        headers.setAccept(List.of(MediaType.APPLICATION_JSON));
        headers.set("X-GitHub-Api-Version", "2022-11-28");
    }

    private String branchUri(
            String owner,
            String repo,
            String branch
    ) {
        return UriComponentsBuilder
                .fromPath("/repos/{owner}/{repo}/branches/{branch}")
                .encode()
                .buildAndExpand(owner, repo, branch)
                .toUriString();
    }

    private String[] decodeRepositoryId(String repositoryId) {
        if (repositoryId == null || repositoryId.isBlank()) {
            throw new IllegalArgumentException("Repository is required.");
        }

        try {
            String fullName = new String(
                    Base64.getUrlDecoder().decode(repositoryId),
                    StandardCharsets.UTF_8
            );

            String[] parts = fullName.split("/", -1);

            if (parts.length != 2
                    || parts[0].isBlank()
                    || parts[1].isBlank()) {
                throw new IllegalArgumentException();
            }

            return parts;

        } catch (IllegalArgumentException ex) {
            throw new IllegalArgumentException(
                    "Invalid repository identifier."
            );
        }
    }
}
