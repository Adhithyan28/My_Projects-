package com.csvcomparison.tool.controller;

import com.csvcomparison.tool.repository.provider.ProviderSessionKeys;
import com.csvcomparison.tool.repository.provider.RepositoryProvider;
import com.csvcomparison.tool.repository.provider.RepositoryProviderRegistry;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientResponseException;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/repositories")
public class RepositoryController {

    private final RepositoryProviderRegistry providerRegistry;

    public RepositoryController(RepositoryProviderRegistry providerRegistry) {
        this.providerRegistry = providerRegistry;
    }

    @GetMapping
    public ResponseEntity<?> getRepositories(
            @RequestParam(defaultValue = "github") String provider,
            HttpSession session
    ) {
        try {
            RepositoryProvider selected = providerRegistry.get(provider);
            String token = requireToken(session, selected.getProviderName());
            return ResponseEntity.ok(selected.getRepositories(token));
        } catch (IllegalStateException exception) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("error", exception.getMessage()));
        } catch (IllegalArgumentException exception) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", exception.getMessage()));
        } catch (RestClientResponseException exception) {
            return ResponseEntity.status(
                            exception.getStatusCode().value() == 401
                                    ? HttpStatus.UNAUTHORIZED
                                    : HttpStatus.BAD_GATEWAY
                    )
                    .body(Map.of(
                            "error",
                            "The repository provider could not return repositories."
                    ));
        }
    }

    @GetMapping("/{id}/branches")
    public ResponseEntity<?> getBranches(
            @PathVariable String id,
            @RequestParam(defaultValue = "github") String provider,
            HttpSession session
    ) {
        try {
            RepositoryProvider selected = providerRegistry.get(provider);
            String token = requireToken(session, selected.getProviderName());
            return ResponseEntity.ok(selected.getBranches(token, id));
        } catch (IllegalStateException exception) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("error", exception.getMessage()));
        } catch (IllegalArgumentException exception) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", exception.getMessage()));
        } catch (RestClientResponseException exception) {
            return ResponseEntity.status(HttpStatus.BAD_GATEWAY)
                    .body(Map.of(
                            "error",
                            "The repository provider could not return branches."
                    ));
        }
    }

    @GetMapping("/{id}/files")
    public ResponseEntity<?> getFiles(
            @PathVariable String id,
            @RequestParam String branch,
            @RequestParam(defaultValue = "github") String provider,
            HttpSession session
    ) {
        if (branch == null || branch.isBlank()) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "A branch is required."));
        }

        try {
            RepositoryProvider selected = providerRegistry.get(provider);
            String token = requireToken(session, selected.getProviderName());
            List<String> files = selected.getFiles(token, id, branch);
            return ResponseEntity.ok(files);
        } catch (IllegalStateException exception) {
            if ("This repository tree is too large to list completely."
                    .equals(exception.getMessage())) {
                return ResponseEntity.status(HttpStatus.PAYLOAD_TOO_LARGE)
                        .body(Map.of("error", exception.getMessage()));
            }
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("error", exception.getMessage()));
        } catch (IllegalArgumentException exception) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", exception.getMessage()));
        } catch (RestClientResponseException exception) {
            return ResponseEntity.status(HttpStatus.BAD_GATEWAY)
                    .body(Map.of(
                            "error",
                            "The repository provider could not return files."
                    ));
        }
    }

    private String requireToken(HttpSession session, String provider) {
        String token = ProviderSessionKeys.getToken(session, provider);
        if (token == null) {
            throw new IllegalStateException(
                    "Connect " + provider + " before browsing repositories."
            );
        }
        return token;
    }
}
