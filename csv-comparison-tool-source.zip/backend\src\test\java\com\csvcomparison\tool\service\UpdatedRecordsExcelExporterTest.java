package com.csvcomparison.tool.service;

import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

class UpdatedRecordsExcelExporterTest {

    @TempDir
    Path tempDirectory;

    @Test
    void highlightsChangedLatestCellsAndKeepsPreviousValues() throws Exception {
        Path previousCsv = Files.writeString(
                tempDirectory.resolve("previous.csv"),
                "1,10,old\n"
        );
        Path updatedCsv = Files.writeString(
                tempDirectory.resolve("updated.csv"),
                "1,12,\"new, value\"\n"
        );
        Path report = tempDirectory.resolve("updated-changes.xlsx");

        new UpdatedRecordsExcelExporter().write(
                List.of("id", "amount", "description"),
                updatedCsv,
                previousCsv,
                report
        );

        try (InputStream input = Files.newInputStream(report);
             XSSFWorkbook workbook = new XSSFWorkbook(input)) {
            var updated = workbook.getSheet("Updated 1").getRow(1);
            var previous = workbook.getSheet("Previous 1").getRow(1);

            assertEquals("1", updated.getCell(0).getStringCellValue());
            assertEquals("12", updated.getCell(1).getStringCellValue());
            assertEquals(
                    "new, value",
                    updated.getCell(2).getStringCellValue()
            );
            assertEquals(
                    FillPatternType.NO_FILL,
                    updated.getCell(0).getCellStyle().getFillPattern()
            );
            assertEquals(
                    FillPatternType.SOLID_FOREGROUND,
                    updated.getCell(1).getCellStyle().getFillPattern()
            );
            assertEquals(
                    IndexedColors.LIGHT_YELLOW.getIndex(),
                    updated.getCell(1).getCellStyle()
                            .getFillForegroundColor()
            );
            assertEquals(
                    FillPatternType.SOLID_FOREGROUND,
                    updated.getCell(2).getCellStyle().getFillPattern()
            );
            assertNotEquals(
                    updated.getCell(2).getStringCellValue(),
                    previous.getCell(2).getStringCellValue()
            );
            assertEquals("old", previous.getCell(2).getStringCellValue());
        }
    }
}
