
package com.csvcomparison.tool.engine;

import com.csvcomparison.tool.model.ComparisonResult;
import com.csvcomparison.tool.model.ResultType;
import com.csvcomparison.tool.service.ComparisonResultStore;
import com.csvcomparison.tool.service.ResultFileWriter;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Component
public class ExternalSortMergeComparisonEngine {

    private final CsvHeaderValidator headerValidator;
    private final ExternalSorter externalSorter;
    private final KWayMerger kWayMerger;
    private final ComparisonResultStore resultStore;

    public ExternalSortMergeComparisonEngine(
            CsvHeaderValidator headerValidator,
            ExternalSorter externalSorter,
            KWayMerger kWayMerger,
            ComparisonResultStore resultStore
    ) {
        this.headerValidator = headerValidator;
        this.externalSorter = externalSorter;
        this.kWayMerger = kWayMerger;
        this.resultStore = resultStore;
    }

    public ComparisonResult compare(
            Path oldCsv,
            Path newCsv
    ) throws IOException {

        String[] headers =
                headerValidator.validateAndGetHeader(oldCsv, newCsv);

        String comparisonId = UUID.randomUUID().toString();
        Path directory = resultStore.createResultDirectory(comparisonId);

        Path addedFile = directory.resolve("added.csv");
        Path updatedFile = directory.resolve("updated.csv");
        Path updatedPreviousFile = directory.resolve("updated-previous.csv");
        Path missingFile = directory.resolve("missing.csv");
        Path repeatedFile = directory.resolve("repeated.csv");

        try {
            StoredComparison comparison;
            try (
                    ExternalSorter.SortedChunks oldChunks =
                            externalSorter.sortWithOriginalPosition(oldCsv);
                    ExternalSorter.SortedChunks newChunks =
                            externalSorter.sortWithOriginalPosition(newCsv)
            ) {
                comparison = compareSortedChunks(
                        headers,
                        comparisonId,
                        oldChunks.paths(),
                        newChunks.paths(),
                        addedFile,
                        updatedFile,
                        updatedPreviousFile,
                        missingFile,
                        repeatedFile
                );
            }

            resultStore.save(comparison.result(), comparison.resultFiles());
            return comparison.result();
        } catch (Exception exception) {
            try {
                deleteDirectory(directory);
            } catch (IOException cleanupException) {
                exception.addSuppressed(cleanupException);
            }

            if (exception instanceof IOException ioException) {
                throw ioException;
            }

            throw new IOException(
                    "External Sort-Merge comparison failed.",
                    exception
            );
        }
    }

    private StoredComparison compareSortedChunks(
            String[] headers,
            String comparisonId,
            List<Path> oldChunks,
            List<Path> newChunks,
            Path addedFile,
            Path updatedFile,
            Path updatedPreviousFile,
            Path missingFile,
            Path repeatedFile
    ) throws IOException {
        long addedCount = 0;
        long updatedCount = 0;
        long missingCount = 0;

        try (
                ResultFileWriter addedWriter =
                        new ResultFileWriter(addedFile);
                ResultFileWriter updatedWriter =
                        new ResultFileWriter(updatedFile);
                ResultFileWriter updatedPreviousWriter =
                        new ResultFileWriter(updatedPreviousFile);
                ResultFileWriter missingWriter =
                        new ResultFileWriter(missingFile);
                ResultFileWriter repeatedWriter =
                        new ResultFileWriter(repeatedFile);

                KWayMerger.RowIterator oldRows =
                        kWayMerger.streamUniqueByKey(
                                oldChunks,
                                "PREVIOUS",
                                repeatedWriter::writeRepeatedRecord
                        );

                KWayMerger.RowIterator newRows =
                        kWayMerger.streamUniqueByKey(
                                newChunks,
                                "LATEST",
                                repeatedWriter::writeRepeatedRecord
                        )
        ) {
            String[] oldRow = nextOrNull(oldRows);
            String[] newRow = nextOrNull(newRows);

            while (oldRow != null && newRow != null) {
                int comparison = oldRow[0].compareTo(newRow[0]);

                if (comparison < 0) {
                    missingWriter.writeRecord(oldRow);
                    missingCount++;
                    oldRow = nextOrNull(oldRows);
                } else if (comparison > 0) {
                    addedWriter.writeRecord(newRow);
                    addedCount++;
                    newRow = nextOrNull(newRows);
                } else {
                    if (!Arrays.equals(oldRow, newRow)) {
                        updatedWriter.writeRecord(newRow);
                        updatedPreviousWriter.writeRecord(oldRow);
                        updatedCount++;
                    }

                    oldRow = nextOrNull(oldRows);
                    newRow = nextOrNull(newRows);
                }
            }

            while (oldRow != null) {
                missingWriter.writeRecord(oldRow);
                missingCount++;
                oldRow = nextOrNull(oldRows);
            }

            while (newRow != null) {
                addedWriter.writeRecord(newRow);
                addedCount++;
                newRow = nextOrNull(newRows);
            }

            ComparisonResult result = new ComparisonResult(
                    comparisonId,
                    Arrays.asList(headers),
                    addedCount,
                    updatedCount,
                    missingCount,
                    repeatedWriter.getRecordCount()
            );

            ComparisonResultStore.ResultFiles resultFiles =
                    new ComparisonResultStore.ResultFiles(
                            Map.of(
                                    ResultType.ADDED,
                                    new ComparisonResultStore.ResultFile(
                                            addedFile,
                                            addedWriter.getPageOffsets(),
                                            addedWriter.getRecordCount()
                                    ),
                                    ResultType.UPDATED,
                                    new ComparisonResultStore.ResultFile(
                                            updatedFile,
                                            updatedWriter.getPageOffsets(),
                                            updatedWriter.getRecordCount()
                                    ),
                                    ResultType.MISSING,
                                    new ComparisonResultStore.ResultFile(
                                            missingFile,
                                            missingWriter.getPageOffsets(),
                                            missingWriter.getRecordCount()
                                    ),
                                    ResultType.REPEATED,
                                    new ComparisonResultStore.ResultFile(
                                            repeatedFile,
                                            repeatedWriter.getPageOffsets(),
                                            repeatedWriter.getRecordCount()
                                    )
                            ),
                            updatedPreviousFile
                    );
            return new StoredComparison(result, resultFiles);
        }
    }

    private String[] nextOrNull(
            KWayMerger.RowIterator iterator
    ) {
        return iterator.hasNext() ? iterator.next() : null;
    }

    private void deleteDirectory(Path directory) throws IOException {
        if (!Files.exists(directory)) {
            return;
        }

        try (var paths = Files.walk(directory)) {
            for (Path path : paths.sorted(
                    java.util.Comparator.reverseOrder()
            ).toList()) {
                Files.deleteIfExists(path);
            }
        }
    }

    private record StoredComparison(
            ComparisonResult result,
            ComparisonResultStore.ResultFiles resultFiles
    ) {
    }
}
