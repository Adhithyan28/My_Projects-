#!/bin/bash

set -e

echo ""
echo "========================================"
echo "       CSV Comparison Tool - Run (macOS/Linux)"
echo "========================================"
echo ""

# --------------------------------------------------
# Find an available TCP port
# --------------------------------------------------

port_is_listening() {
    local port=$1

    if command -v lsof >/dev/null 2>&1; then
        lsof -iTCP:"$port" -sTCP:LISTEN -n -P >/dev/null 2>&1
        return $?
    fi

    if command -v nc >/dev/null 2>&1; then
        nc -z localhost "$port" >/dev/null 2>&1
        return $?
    fi

    if command -v python3 >/dev/null 2>&1; then
        python3 -c 'import socket,sys; s=socket.socket(); s.settimeout(.3); sys.exit(0 if s.connect_ex(("127.0.0.1", int(sys.argv[1]))) == 0 else 1)' "$port"
        return $?
    fi

    echo "Port checks require lsof, nc, or python3." >&2
    return 2
}

find_free_port() {
    local port=$1

    if ! command -v lsof >/dev/null 2>&1 \
            && ! command -v nc >/dev/null 2>&1 \
            && ! command -v python3 >/dev/null 2>&1; then
        echo "Port checks require lsof, nc, or python3." >&2
        exit 1
    fi

    while port_is_listening "$port"; do
        port=$((port + 1))
    done

    echo "$port"
}

# --------------------------------------------------
# Locate project
# --------------------------------------------------

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

BACKEND_DIR="$PROJECT_ROOT/backend"
FRONTEND_DIR="$PROJECT_ROOT/frontend"

echo "Project root:"
echo "  $PROJECT_ROOT"
echo ""

# --------------------------------------------------
# Validate project structure
# --------------------------------------------------

if [[ ! -d "$BACKEND_DIR" ]]; then
    echo "Backend directory was not found:"
    echo "  $BACKEND_DIR"
    exit 1
fi

if [[ ! -d "$FRONTEND_DIR" ]]; then
    echo "Frontend directory was not found:"
    echo "  $FRONTEND_DIR"
    exit 1
fi

if [[ ! -x "$BACKEND_DIR/mvnw" ]]; then
    echo "Maven Wrapper was not found or is not executable:"
    echo "  $BACKEND_DIR/mvnw"
    echo ""
    echo "Run:"
    echo "  chmod +x backend/mvnw"
    exit 1
fi

if [[ ! -f "$FRONTEND_DIR/package.json" ]]; then
    echo "Frontend package.json was not found:"
    echo "  $FRONTEND_DIR/package.json"
    exit 1
fi

echo "Project structure verified."
echo ""

# --------------------------------------------------
# Check Java
# --------------------------------------------------

echo "Checking Java..."
. "$SCRIPT_DIR/java-runtime-unix.sh"
ensure_java_runtime

# --------------------------------------------------
# Check Node.js
# --------------------------------------------------

echo ""
echo "Checking Node.js..."

if ! command -v node >/dev/null 2>&1; then
    echo "Node.js was not found."
    echo "Please run setup-macos.sh first."
    exit 1
fi

if ! command -v npm >/dev/null 2>&1; then
    echo "npm was not found."
    echo "Please run setup-macos.sh first."
    exit 1
fi

node_version=$(node --version)
npm_version=$(npm --version)

echo "Node.js $node_version detected."
echo "npm $npm_version detected."

echo ""
echo "Required software verified."
echo ""

# --------------------------------------------------
# Configure optional GitHub OAuth once
# --------------------------------------------------

OAUTH_CONFIG="$BACKEND_DIR/oauth.env"
import_local_oauth_environment "$OAUTH_CONFIG"
configure_local_oauth_environment "$OAUTH_CONFIG"

# --------------------------------------------------
# Find available ports
# --------------------------------------------------

BACKEND_PORT=$(find_free_port 8080)
FRONTEND_PORT=$(find_free_port 5173)

echo "Selected ports:"
echo "  Backend:  $BACKEND_PORT"
echo "  Frontend: $FRONTEND_PORT"
echo ""

if [[ "$BACKEND_PORT" -ne 8080 ]]; then
    echo "Port 8080 is already in use. Using backend port $BACKEND_PORT."
fi

if [[ "$FRONTEND_PORT" -ne 5173 ]]; then
    echo "Port 5173 is already in use. Using frontend port $FRONTEND_PORT."
fi

echo ""

# --------------------------------------------------
# Start backend
# --------------------------------------------------

echo "Starting backend on port $BACKEND_PORT..."

cd "$BACKEND_DIR"

./mvnw spring-boot:run \
    -Dspring-boot.run.arguments="--server.port=$BACKEND_PORT" \
    > "$PROJECT_ROOT/backend-run.log" 2>&1 &

BACKEND_PID=$!

echo "Backend process started."
echo "Backend PID: $BACKEND_PID"
echo "Backend port: $BACKEND_PORT"
echo ""

# --------------------------------------------------
# Wait for backend
# --------------------------------------------------

echo "Waiting for backend to become ready..."

BACKEND_READY=false

for ((i=1; i<=30; i++)); do
    sleep 1

    if port_is_listening "$BACKEND_PORT"; then
        BACKEND_READY=true
        break
    fi

    printf "."
done

echo ""

if [[ "$BACKEND_READY" != true ]]; then
    echo "Backend did not become ready within 30 seconds."

    if kill -0 "$BACKEND_PID" 2>/dev/null; then
        kill "$BACKEND_PID" 2>/dev/null || true
    fi

    exit 1
fi

echo "Backend is ready on port $BACKEND_PORT."
echo ""

# --------------------------------------------------
# Start frontend
# --------------------------------------------------

echo "Starting frontend on port $FRONTEND_PORT..."

cd "$FRONTEND_DIR"

BACKEND_PORT="$BACKEND_PORT" npm run dev -- --host localhost --port "$FRONTEND_PORT" \
    > "$PROJECT_ROOT/frontend-run.log" 2>&1 &

FRONTEND_PID=$!

echo "Frontend process started."
echo "Frontend PID: $FRONTEND_PID"
echo "Frontend port: $FRONTEND_PORT"
echo ""

# --------------------------------------------------
# Wait for frontend
# --------------------------------------------------

echo "Waiting for frontend to become ready..."

FRONTEND_READY=false

for ((i=1; i<=30; i++)); do
    sleep 1

    if port_is_listening "$FRONTEND_PORT"; then
        FRONTEND_READY=true
        break
    fi

    printf "."
done

echo ""

if [[ "$FRONTEND_READY" != true ]]; then
    echo "Frontend did not become ready within 30 seconds."

    if kill -0 "$FRONTEND_PID" 2>/dev/null; then
        kill "$FRONTEND_PID" 2>/dev/null || true
    fi

    if kill -0 "$BACKEND_PID" 2>/dev/null; then
        kill "$BACKEND_PID" 2>/dev/null || true
    fi

    exit 1
fi

echo "Frontend is ready on port $FRONTEND_PORT."
echo ""

# --------------------------------------------------
# Open browser
# --------------------------------------------------

echo "Opening application in your browser..."

if command -v open >/dev/null 2>&1; then
    open "http://localhost:$FRONTEND_PORT"
elif command -v xdg-open >/dev/null 2>&1; then
    xdg-open "http://localhost:$FRONTEND_PORT" >/dev/null 2>&1 &
else
    echo "Open http://localhost:$FRONTEND_PORT in your browser."
fi

echo ""
echo "========================================"
echo "       Application is running!"
echo "========================================"
echo ""
echo "Frontend: http://localhost:$FRONTEND_PORT"
echo "Backend:  http://localhost:$BACKEND_PORT"
echo ""
echo "Press Ctrl+C to stop the application."
echo ""

# --------------------------------------------------
# Cleanup
# --------------------------------------------------

cleanup() {
    echo ""
    echo "Stopping application..."

    if kill -0 "$FRONTEND_PID" 2>/dev/null; then
        kill "$FRONTEND_PID" 2>/dev/null || true
        echo "Frontend stopped."
    fi

    if kill -0 "$BACKEND_PID" 2>/dev/null; then
        kill "$BACKEND_PID" 2>/dev/null || true
        echo "Backend stopped."
    fi

    echo ""
    echo "Application stopped."
}

trap cleanup INT TERM

# --------------------------------------------------
# Keep application running
# --------------------------------------------------

while true; do
    if ! kill -0 "$BACKEND_PID" 2>/dev/null; then
        echo "Backend process has stopped."
        cleanup
        exit 1
    fi

    if ! kill -0 "$FRONTEND_PID" 2>/dev/null; then
        echo "Frontend process has stopped."
        cleanup
        exit 1
    fi

    sleep 1
done