
package com.csvcomparison.tool.model;

public record RepositoryPublishRequest(
        String repositoryId,
        String sourceBranch,
        String destinationPath,
        String commitMessage,
        String provider
) {}
