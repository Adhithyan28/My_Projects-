package com.csvcomparison.tool.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.util.unit.DataSize;

@ConfigurationProperties(prefix = "csv.comparison")
public class CsvComparisonProperties {

    private String chunkSize = "64MB";
    private DataSize inMemoryThreshold = DataSize.ofMegabytes(32);

    public String getChunkSize() {
        return chunkSize;
    }

    public void setChunkSize(String chunkSize) {
        this.chunkSize = chunkSize;
    }

    public DataSize getInMemoryThreshold() {
        return inMemoryThreshold;
    }

    public void setInMemoryThreshold(DataSize inMemoryThreshold) {
        this.inMemoryThreshold = inMemoryThreshold;
    }
}