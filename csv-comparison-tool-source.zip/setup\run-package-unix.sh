#!/usr/bin/env sh
set -eu

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
JAR_PATH="$SCRIPT_DIR/csv-comparison-tool.jar"
OAUTH_CONFIG="$SCRIPT_DIR/oauth.env"

if [ ! -f "$JAR_PATH" ]; then
    echo "csv-comparison-tool.jar was not found beside this script." >&2
    exit 1
fi

. "$SCRIPT_DIR/java-runtime-unix.sh"
ensure_java_runtime
import_local_oauth_environment "$OAUTH_CONFIG"
configure_local_oauth_environment "$OAUTH_CONFIG"

PREFERRED_PORT=${PORT:-8080}
PORT=$(find_free_port "$PREFERRED_PORT")
if [ "$PORT" -ne "$PREFERRED_PORT" ]; then
    printf "Port %s is busy; using port %s instead.\n" "$PREFERRED_PORT" "$PORT"
fi
set_local_application_urls "$PORT"

cd "$SCRIPT_DIR"
printf "Starting the embedded frontend and backend at http://localhost:%s\n" "$PORT"
java -jar "$JAR_PATH" "--server.port=$PORT" &
APP_PID=$!

cleanup() {
    if kill -0 "$APP_PID" 2>/dev/null; then
        kill "$APP_PID" 2>/dev/null || true
        wait "$APP_PID" 2>/dev/null || true
    fi
}
trap cleanup INT TERM

READY=false
attempt=0
while [ "$attempt" -lt 60 ]; do
    if ! kill -0 "$APP_PID" 2>/dev/null; then
        wait "$APP_PID"
        echo "Application stopped before it was ready." >&2
        exit 1
    fi

    if command -v curl >/dev/null 2>&1 \
            && curl --silent --fail "http://localhost:$PORT/" >/dev/null; then
        READY=true
        break
    fi

    sleep 1
    attempt=$((attempt + 1))
done

if [ "$READY" != true ]; then
    echo "Application did not become ready. Check the Java output above." >&2
    cleanup
    exit 1
fi

if command -v open >/dev/null 2>&1; then
    open "http://localhost:$PORT"
elif command -v xdg-open >/dev/null 2>&1; then
    xdg-open "http://localhost:$PORT" >/dev/null 2>&1 &
else
    echo "Open http://localhost:$PORT in your browser."
fi

echo "Application is ready. Press Ctrl+C to stop it."
wait "$APP_PID"
