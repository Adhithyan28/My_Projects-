import { useState } from 'react'
import RepositoryWorkspace from './components/RepositoryWorkspace'
import { compareCsvFiles, getResultPage } from './services/comparisonApi'
import type {
  ComparisonResult,
  RepeatedRecord,
  ResultCategory,
  ResultType as ApiResultType,
} from './types/comparison'
import ResultTable from './components/ResultTable'
import './App.css'

type Workflow = 'repository' | 'local'

function App() {
  const [workflow, setWorkflow] = useState<Workflow>('repository')

  const [oldFile, setOldFile] = useState<File | null>(null)
  const [newFile, setNewFile] = useState<File | null>(null)
  const [result, setResult] = useState<ComparisonResult | null>(null)
  const [selectedResult, setSelectedResult] = useState<ResultCategory>('added')
  const [records, setRecords] = useState<string[][]>([])
  const [repeatedRecords, setRepeatedRecords] = useState<RepeatedRecord[]>([])
  const [loading, setLoading] = useState(false)
  const [resultsLoading, setResultsLoading] = useState(false)
  const [currentPage, setCurrentPage] = useState(0)
  const [pageSize] = useState(100)
  const [totalRecords, setTotalRecords] = useState(0)
  const [error, setError] = useState<string | null>(null)

  const handleFileChange = (
      type: 'old' | 'new',
      event: React.ChangeEvent<HTMLInputElement>,
  ) => {
    const file = event.target.files?.[0] ?? null


    if (type === 'old') {
      setOldFile(file)
    } else {
      setNewFile(file)
    }

    setResult(null)
    setSelectedResult('added')
    setRecords([])
    setRepeatedRecords([])
    setCurrentPage(0)
    setTotalRecords(0)
    setError(null)


  }

  const loadResultPage = async (
      comparisonId: string,
      type: ResultCategory,
      page: number,
  ) => {
    setResultsLoading(true)
    setError(null)

    try {
      const backendType = type.toUpperCase() as ApiResultType

      const resultPage = await getResultPage(
          comparisonId,
          backendType,
          page,
          pageSize,
      )

      setRecords(resultPage.records ?? [])
      setRepeatedRecords(resultPage.repeatedRecords ?? [])
      setCurrentPage(resultPage.page)
      setTotalRecords(resultPage.totalRecords)
    } catch (err) {
      setError(
          err instanceof Error
              ? err.message
              : 'Failed to load comparison results.',
      )

      setRecords([])
      setRepeatedRecords([])
      setTotalRecords(0)
    } finally {
      setResultsLoading(false)
    }
  }

  const handleCompare = async () => {
    if (!oldFile || !newFile) {
      setError('Please select both CSV files.')
      return
    }


    setLoading(true)
    setError(null)
    setResult(null)
    setSelectedResult('added')
    setRecords([])
    setRepeatedRecords([])
    setCurrentPage(0)
    setTotalRecords(0)

    try {
      const comparisonResult = await compareCsvFiles(oldFile, newFile)

      setResult(comparisonResult)

      await loadResultPage(
          comparisonResult.comparisonId,
          'added',
          0,
      )
    } catch (err) {
      setError(
          err instanceof Error
              ? err.message
              : 'Something went wrong while comparing the files.',
      )
    } finally {
      setLoading(false)
    }


  }

  const handleResultSelection = async (type: ResultCategory) => {
    if (!result) return


    setSelectedResult(type)

    await loadResultPage(result.comparisonId, type, 0)


  }

  const handleReset = () => {
    setOldFile(null)
    setNewFile(null)
    setResult(null)
    setSelectedResult('added')
    setRecords([])
    setRepeatedRecords([])
    setCurrentPage(0)
    setTotalRecords(0)
    setError(null)
  }

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`


    if (bytes < 1024 * 1024) {
      return `${(bytes / 1024).toFixed(1)} KB`
    }

    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`

  }

  const filesReady = oldFile !== null && newFile !== null

  const selectedCount = result === null
      ? 0
      : selectedResult === 'added'
          ? result.addedRecordCount
          : selectedResult === 'updated'
              ? result.updatedRecordCount
              : selectedResult === 'missing'
                  ? result.missingRecordCount
                  : result.repeatedRecordCount

  const selectedTitle = selectedResult === 'added'
      ? 'Added Records'
      : selectedResult === 'updated'
          ? 'Updated Records'
          : selectedResult === 'missing'
              ? 'Missing Records'
              : 'Repeated Records'

  const totalPages = Math.ceil(totalRecords / pageSize)
  const hasPreviousPage = currentPage > 0
  const hasNextPage = currentPage + 1 < totalPages

  return ( <div className="app"> <header className="navbar"> <div className="navbar-inner"> <div className="logo"> <div className="logo-mark">CSV</div> <div className="logo-text">
        CSV Compare <small>File comparison tool</small> </div> </div>


        <div className="workflow-switch">
          <button
              type="button"
              className={workflow === 'repository' ? 'active' : ''}
              onClick={() => setWorkflow('repository')}
          >
            Repository
          </button>

          <button
              type="button"
              className={workflow === 'local' ? 'active' : ''}
              onClick={() => setWorkflow('local')}
          >
            Local CSV
          </button>
        </div>

        <div className="secure-badge">🔒 Secure processing</div>
      </div>
      </header>

        {workflow === 'repository' ? (
            <RepositoryWorkspace
                onUseLocalFiles={() => {
                  setWorkflow('local')
                  setError(null)
                }}
            />
        ) : (
            <main className="main">
              <section className="hero">
                <div className="hero-badge">
                  ⚡ SIMPLE · FAST · ACCURATE
                </div>

                <h1>
                  Compare CSV files
                  <br />
                  <span>without the manual work.</span>
                </h1>

                <p>
                  Upload your previous and latest CSV files.
                  <br />
                  Instantly discover what has changed.
                </p>

                <div className="hero-features">
                  <span>✓ No installation</span>
                  <span>✓ Easy to use</span>
                  <span>✓ Large CSV support</span>
                </div>
              </section>

              <section className="tool-card">
                <div className="tool-header">
                  <div className="tool-title">
                    <div className="tool-title-icon">📊</div>
                    <div>
                      <h2>Compare your files</h2>
                      <p>Upload both CSV files to start the comparison.</p>
                    </div>
                  </div>

                  {filesReady && !loading && (
                      <button
                          type="button"
                          className="reset-button"
                          onClick={handleReset}
                      >
                        ↻ <span>Reset</span>
                      </button>
                  )}
                </div>

                <div className="progress">
                  <div className="progress-step completed">
                    <span>✓</span>
                    Upload
                  </div>

                  <div className="progress-line" />

                  <div className={`progress-step ${filesReady ? 'completed' : ''}`}>
                    <span>{filesReady ? '✓' : '2'}</span>
                    Compare
                  </div>

                  <div className="progress-line" />

                  <div className={`progress-step ${result ? 'completed' : ''}`}>
                    <span>{result ? '✓' : '3'}</span>
                    Results
                  </div>
                </div>

                <div className="upload-grid">
                  <div className="upload-column">
                    <div className="upload-title">
                      <div className="number-badge">01</div>
                      <div>
                        <h3>Previous CSV</h3>
                        <p>Your old version</p>
                      </div>
                    </div>

                    <label className={`drop-zone ${oldFile ? 'has-file' : ''}`}>
                      <input
                          type="file"
                          accept=".csv,text/csv"
                          onChange={(event) => handleFileChange('old', event)}
                      />

                      {!oldFile ? (
                          <div className="upload-empty">
                            <div className="upload-icon">📁</div>
                            <strong>Upload previous CSV</strong>
                            <span>Drag &amp; drop your file here</span>
                            <span className="browse-link">Browse files</span>
                          </div>
                      ) : (
                          <div className="file-selected">
                            <div className="file-icon">📄</div>
                            <div className="file-details">
                              <strong title={oldFile.name}>{oldFile.name}</strong>
                              <span>CSV file · {formatFileSize(oldFile.size)}</span>
                            </div>
                            <div className="file-check">✓</div>
                          </div>
                      )}
                    </label>
                  </div>

                  <div className="comparison-divider">
                    <div className="divider-line" />
                    <div className="vs-circle">VS</div>
                    <div className="divider-line" />
                  </div>

                  <div className="upload-column">
                    <div className="upload-title">
                      <div className="number-badge">02</div>
                      <div>
                        <h3>Latest CSV</h3>
                        <p>Your new version</p>
                      </div>
                    </div>

                    <label className={`drop-zone ${newFile ? 'has-file' : ''}`}>
                      <input
                          type="file"
                          accept=".csv,text/csv"
                          onChange={(event) => handleFileChange('new', event)}
                      />

                      {!newFile ? (
                          <div className="upload-empty">
                            <div className="upload-icon">📁</div>
                            <strong>Upload latest CSV</strong>
                            <span>Drag &amp; drop your file here</span>
                            <span className="browse-link">Browse files</span>
                          </div>
                      ) : (
                          <div className="file-selected">
                            <div className="file-icon">📄</div>
                            <div className="file-details">
                              <strong title={newFile.name}>{newFile.name}</strong>
                              <span>CSV file · {formatFileSize(newFile.size)}</span>
                            </div>
                            <div className="file-check">✓</div>
                          </div>
                      )}
                    </label>
                  </div>
                </div>

                <div className="action-area">
                  <button
                      type="button"
                      className="compare-button"
                      disabled={!filesReady || loading}
                      onClick={handleCompare}
                  >
                    {loading ? (
                        <>
                          <span className="spinner" />
                          Comparing files...
                        </>
                    ) : (
                        <>
                          <span>⚡</span>
                          Compare CSV files
                          <span className="button-arrow">→</span>
                        </>
                    )}
                  </button>

                  <p>🔒 Your files are processed securely</p>
                </div>

                {error && (
                    <div className="error-box" role="alert">
                      <div className="error-icon">!</div>
                      <div>
                        <strong>Comparison failed</strong>
                        <p>{error}</p>
                      </div>
                    </div>
                )}
              </section>

              {result && (
                  <section className="results-card">
                    <div className="results-header">
                      <div className="results-title">
                        <div className="success-icon">✓</div>
                        <div>
                          <span>COMPARISON COMPLETE</span>
                          <h2>Your results are ready</h2>
                          <p>We've compared the records in both CSV files.</p>
                        </div>
                      </div>
                    </div>

                    <div className="result-summary">
                      <button
                          type="button"
                          className={`result-summary-item ${selectedResult === 'added' ? 'active' : ''}`}
                          onClick={() => handleResultSelection('added')}
                      >
                        <div className="stat-icon">➕</div>
                        <div>
                          <strong>{result.addedRecordCount}</strong>
                          <span>Added Records</span>
                        </div>
                      </button>

                      <button
                          type="button"
                          className={`result-summary-item ${selectedResult === 'updated' ? 'active' : ''}`}
                          onClick={() => handleResultSelection('updated')}
                      >
                        <div className="stat-icon">✏️</div>
                        <div>
                          <strong>{result.updatedRecordCount}</strong>
                          <span>Updated Records</span>
                        </div>
                      </button>

                      <button
                          type="button"
                          className={`result-summary-item ${selectedResult === 'missing' ? 'active' : ''}`}
                          onClick={() => handleResultSelection('missing')}
                      >
                        <div className="stat-icon">➖</div>
                        <div>
                          <strong>{result.missingRecordCount}</strong>
                          <span>Missing Records</span>
                        </div>
                      </button>

                      <button
                          type="button"
                          className={`result-summary-item ${selectedResult === 'repeated' ? 'active' : ''}`}
                          onClick={() => handleResultSelection('repeated')}
                      >
                        <div className="stat-icon">🔁</div>
                        <div>
                          <strong>{result.repeatedRecordCount}</strong>
                          <span>Repeated Records</span>
                        </div>
                      </button>
                    </div>

                    <div className="results-divider" />

                    <div className="result-info-bar">
                      <span>📌 {selectedTitle}</span>
                      <span>
              {selectedCount === 0
                  ? `No ${selectedResult} records found`
                  : `${selectedCount} ${selectedCount === 1 ? 'record' : 'records'}`}
            </span>
                    </div>

                    {resultsLoading ? (
                        <div className="result-loading">
                          <span className="spinner" />
                          Loading results...
                        </div>
                    ) : (
                        <ResultTable
                            headers={result.headers}
                            records={records}
                            repeatedRecords={repeatedRecords}
                            type={selectedResult}
                        />
                    )}

                    {totalPages > 1 && (
                        <div className="pagination">
                          <button
                              type="button"
                              disabled={!hasPreviousPage || resultsLoading}
                              onClick={() =>
                                  loadResultPage(
                                      result.comparisonId,
                                      selectedResult,
                                      currentPage - 1,
                                  )
                              }
                          >
                            ← Previous
                          </button>

                          <span>
                Page {currentPage + 1} of {totalPages}
              </span>

                          <button
                              type="button"
                              disabled={!hasNextPage || resultsLoading}
                              onClick={() =>
                                  loadResultPage(
                                      result.comparisonId,
                                      selectedResult,
                                      currentPage + 1,
                                  )
                              }
                          >
                            Next →
                          </button>
                        </div>
                    )}

                    <div className="result-actions">
                      <button
                          type="button"
                          className="secondary-button"
                          onClick={handleReset}
                      >
                        ↻ Compare another pair
                      </button>
                    </div>
                  </section>
              )}

              <section className="how-section">
                <div className="section-heading">
                  <span>✦ HOW IT WORKS</span>
                  <h2>Compare files in three simple steps</h2>
                  <p>No complicated setup. Just upload, compare, and review.</p>
                </div>

                <div className="steps">
                  <div className="step">
                    <div className="step-icon">📤</div>
                    <div>
                      <span>STEP 01</span>
                      <h3>Upload</h3>
                      <p>Select your previous and latest CSV files.</p>
                    </div>
                  </div>

                  <div className="step">
                    <div className="step-icon">⚡</div>
                    <div>
                      <span>STEP 02</span>
                      <h3>Compare</h3>
                      <p>Our comparison engine checks both files.</p>
                    </div>
                  </div>

                  <div className="step">
                    <div className="step-icon">🔍</div>
                    <div>
                      <span>STEP 03</span>
                      <h3>Review</h3>
                      <p>Review added, updated, missing, and repeated records.</p>
                    </div>
                  </div>
                </div>
              </section>
            </main>
        )}

        <footer className="footer">
          <div className="footer-inner">
            <div className="footer-brand">
              <div className="footer-logo">CSV</div>
              <strong>CSV Compare</strong>
            </div>

            <span>Built for fast and simple CSV comparison</span>
          </div>
        </footer>
      </div>


  )
}

export default App
