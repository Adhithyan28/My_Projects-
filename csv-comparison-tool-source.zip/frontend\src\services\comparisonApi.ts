import type {
    ComparisonResult,
    ResultPage,
    ResultType,
} from '../types/comparison'

export async function compareCsvFiles(
    oldFile: File,
    newFile: File,
): Promise<ComparisonResult> {
    const formData = new FormData()

    formData.append('oldFile', oldFile)
    formData.append('newFile', newFile)

    const response = await fetch('/api/comparisons', {
        method: 'POST',
        body: formData,
    })

    if (!response.ok) {
        const errorBody = await response.json().catch(() => null)

        throw new Error(
            errorBody?.error ||
            errorBody?.message ||
            'Failed to compare CSV files.',
        )
    }

    return response.json() as Promise<ComparisonResult>
}

export async function getResultPage(
    comparisonId: string,
    type: ResultType,
    page: number = 0,
    size: number = 100,
): Promise<ResultPage> {
    const response = await fetch(
        `/api/comparisons/${encodeURIComponent(comparisonId)}/results/${type}?page=${page}&size=${size}`,
    )

    if (!response.ok) {
        const errorBody = await response.json().catch(() => null)

        throw new Error(
            errorBody?.error ||
            errorBody?.message ||
            'Failed to load comparison results.',
        )
    }

    return response.json() as Promise<ResultPage>
}