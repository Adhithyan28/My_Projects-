package com.csvcomparison.tool.repository.provider.github;

import com.csvcomparison.tool.model.RepositoryPublishResult;
import com.csvcomparison.tool.repository.auth.GitHubOAuthService;
import com.csvcomparison.tool.repository.provider.RepositoryProvider;
import com.csvcomparison.tool.service.RepositoryPublishService;
import org.springframework.http.HttpHeaders;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;
import tools.jackson.databind.JsonNode;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientResponseException;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

@Component
public class GitHubRepositoryProvider implements RepositoryProvider {

    private static final String GITHUB_API =
            "https://api.github.com";

    private final RestClient restClient;
    private final String accessToken;
    private final GitHubOAuthService oauthService;
    private final RepositoryPublishService publishService;

    public GitHubRepositoryProvider(
            @Value("${github.access-token:}") String accessToken,
            GitHubOAuthService oauthService,
            RepositoryPublishService publishService) {

        this.accessToken = accessToken;
        this.oauthService = oauthService;
        this.publishService = publishService;

        this.restClient = RestClient.builder()
                .baseUrl(GITHUB_API)
                .defaultHeader(
                        HttpHeaders.ACCEPT,
                        "application/vnd.github+json")
                .defaultHeader(
                        HttpHeaders.USER_AGENT,
                        "CSV-Comparison-Tool")
                .defaultHeader(
                        "X-GitHub-Api-Version",
                        "2022-11-28")
                .build();
    }

    @Override
    public String getProviderName() {
        return "github";
    }

    @Override
    public String buildAuthorizationUrl(String state) {
        return oauthService.buildAuthorizationUrl(state);
    }

    @Override
    public String exchangeCodeForAccessToken(String code) {
        return oauthService.exchangeCodeForAccessToken(code);
    }

    @Override
    public List<RepositorySummary> getRepositories(String token) {
        JsonNode response = authenticatedGet(
                token,
                "/user/repos?sort=updated&per_page=100"
        );
        List<RepositorySummary> repositories = new ArrayList<>();

        if (response != null && response.isArray()) {
            for (JsonNode repository : response) {
                String fullName = repository.path("full_name").asText();
                if (fullName.isBlank()) {
                    continue;
                }

                repositories.add(new RepositorySummary(
                        encodeRepositoryId(fullName),
                        fullName,
                        repository.path("default_branch").asText(),
                        repository.path("description").isNull()
                                ? null
                                : repository.path("description").asText()
                ));
            }
        }

        return repositories;
    }

    @Override
    public List<String> getBranches(String token, String repositoryId) {
        String[] repository = decodeRepositoryId(repositoryId);
        JsonNode response = authenticatedGet(
                token,
                "/repos/" + repository[0] + "/" + repository[1]
                        + "/branches?per_page=100"
        );
        List<String> branches = new ArrayList<>();

        if (response != null && response.isArray()) {
            for (JsonNode branch : response) {
                String name = branch.path("name").asText();
                if (!name.isBlank()) {
                    branches.add(name);
                }
            }
        }

        return branches;
    }

    @Override
    public List<String> getFiles(
            String token,
            String repositoryId,
            String branch
    ) {
        String[] repository = decodeRepositoryId(repositoryId);
        JsonNode response = authenticatedGet(
                token,
                UriComponentsBuilder.fromUriString(GITHUB_API)
                        .pathSegment(
                                "repos", repository[0], repository[1],
                                "git", "trees", branch
                        )
                        .queryParam("recursive", "1")
                        .build()
                        .encode(StandardCharsets.UTF_8)
                        .toUriString()
        );
        List<String> files = new ArrayList<>();

        if (response != null && response.path("tree").isArray()) {
            for (JsonNode entry : response.path("tree")) {
                if ("blob".equals(entry.path("type").asText())) {
                    String path = entry.path("path").asText();
                    if (!path.isBlank()) {
                        files.add(path);
                    }
                }
            }
        }

        if (response != null && response.path("truncated").asBoolean()) {
            throw new IllegalStateException(
                    "This repository tree is too large to list completely."
            );
        }

        return files;
    }

    @Override
    public void downloadFile(
            String token,
            String repositoryId,
            String branch,
            String filePath,
            Path destination
    ) throws IOException {
        String[] repository = decodeRepositoryId(repositoryId);
        String[] pathSegments = validateRepositoryPath(filePath);

        UriComponentsBuilder builder = UriComponentsBuilder
                .fromUriString(GITHUB_API)
                .pathSegment(
                        "repos", repository[0], repository[1], "contents"
                );
        for (String segment : pathSegments) {
            builder.pathSegment(segment);
        }

        var uri = builder.queryParam("ref", branch)
                .build()
                .encode(StandardCharsets.UTF_8)
                .toUri();

        restClient.get()
                .uri(uri)
                .headers(headers -> setHeaders(headers, token))
                .header(HttpHeaders.ACCEPT, "application/vnd.github.raw+json")
                .exchange((request, response) -> {
                    if (!response.getStatusCode().is2xxSuccessful()) {
                        throw new RestClientResponseException(
                                "GitHub file download failed.",
                                response.getStatusCode().value(),
                                response.getStatusText(),
                                response.getHeaders(),
                                null,
                                StandardCharsets.UTF_8
                        );
                    }

                    try (InputStream input = response.getBody()) {
                        Files.copy(
                                input,
                                destination,
                                StandardCopyOption.REPLACE_EXISTING
                        );
                    }
                    return null;
                });
    }

    @Override
    public RepositoryPublishResult publishComparison(
            String token,
            String comparisonId,
            String repositoryId,
            String sourceBranch,
            String destinationPath,
            String commitMessage
    ) throws IOException {
        return publishService.publishAddedCsv(
                comparisonId,
                repositoryId,
                sourceBranch,
                destinationPath,
                commitMessage,
                token
        );
    }

    /**
     * Checks GitHub API access by making a fresh request.
     *
     * For public repositories, authentication is optional.
     * For private repositories, configure a GitHub access token.
     */
    public boolean isConnectionAvailable() {
        try {
            if (accessToken != null && !accessToken.isBlank()) {
                restClient.get()
                        .uri("/user")
                        .header(
                                HttpHeaders.AUTHORIZATION,
                                "Bearer " + accessToken)
                        .retrieve()
                        .toBodilessEntity();

                return true;
            }

            restClient.get()
                    .uri("/rate_limit")
                    .retrieve()
                    .toBodilessEntity();

            return true;

        } catch (RestClientResponseException exception) {
            return false;
        } catch (Exception exception) {
            return false;
        }
    }

    /**
     * Fetches the latest metadata for a repository.
     * This makes a new GitHub API request each time it is called.
     */
    public String getRepositoryMetadata(
            String owner,
            String repository) {

        validateRepositoryName(owner, "owner");
        validateRepositoryName(repository, "repository");

        try {
            RestClient.RequestHeadersSpec<?> request = restClient.get()
                    .uri("/repos/{owner}/{repository}",
                            owner, repository);

            if (accessToken != null && !accessToken.isBlank()) {
                request = request.header(
                        HttpHeaders.AUTHORIZATION,
                        "Bearer " + accessToken);
            }

            return request.retrieve()
                    .body(String.class);

        } catch (RestClientResponseException exception) {
            throw new IllegalStateException(
                    "GitHub repository request failed with HTTP status "
                            + exception.getStatusCode().value(),
                    exception);
        }
    }

    private void validateRepositoryName(
            String value,
            String fieldName) {

        if (value == null || value.isBlank()
                || !value.matches("[A-Za-z0-9_.-]+")) {
            throw new IllegalArgumentException(
                    "Invalid GitHub " + fieldName);
        }
    }

    private JsonNode authenticatedGet(String token, String uri) {
        RestClient.RequestHeadersSpec<?> request = restClient.get().uri(uri);
        if (token != null && !token.isBlank()) {
            request = request.header(HttpHeaders.AUTHORIZATION, "Bearer " + token);
        }
        return request.retrieve().body(JsonNode.class);
    }

    private void setHeaders(HttpHeaders headers, String token) {
        if (token != null && !token.isBlank()) {
            headers.setBearerAuth(token);
        }
        headers.set("X-GitHub-Api-Version", "2022-11-28");
    }

    private String encodeRepositoryId(String fullName) {
        return Base64.getUrlEncoder()
                .withoutPadding()
                .encodeToString(fullName.getBytes(StandardCharsets.UTF_8));
    }

    private String[] decodeRepositoryId(String id) {
        try {
            String fullName = new String(
                    Base64.getUrlDecoder().decode(id),
                    StandardCharsets.UTF_8
            );
            String[] parts = fullName.split("/", -1);
            if (parts.length != 2
                    || !parts[0].matches("[A-Za-z0-9_.-]+")
                    || !parts[1].matches("[A-Za-z0-9_.-]+")) {
                throw new IllegalArgumentException();
            }
            return parts;
        } catch (IllegalArgumentException exception) {
            throw new IllegalArgumentException(
                    "Invalid repository identifier."
            );
        }
    }

    private String[] validateRepositoryPath(String path) {
        if (path == null || path.isBlank()) {
            throw new IllegalArgumentException(
                    "Repository file path is required."
            );
        }
        String[] segments = path.split("/", -1);
        for (String segment : segments) {
            if (segment.isBlank()
                    || ".".equals(segment)
                    || "..".equals(segment)) {
                throw new IllegalArgumentException(
                        "Invalid repository file path."
                );
            }
        }
        return segments;
    }
}