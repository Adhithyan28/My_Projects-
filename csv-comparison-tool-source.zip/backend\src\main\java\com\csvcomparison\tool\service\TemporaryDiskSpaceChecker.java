package com.csvcomparison.tool.service;

import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;

@Component
public class TemporaryDiskSpaceChecker {

    private static final long WORKING_SPACE_MULTIPLIER = 3;
    private static final long SAFETY_RESERVE_BYTES = 64L * 1024 * 1024;

    public void ensureAvailable(long combinedInputBytes) throws IOException {
        Path temporaryDirectory = Path.of(
                System.getProperty("java.io.tmpdir")
        );
        long usableBytes = Files.getFileStore(temporaryDirectory)
                .getUsableSpace();
        ensureAvailable(combinedInputBytes, usableBytes);
    }

    static void ensureAvailable(
            long combinedInputBytes,
            long usableBytes
    ) throws IOException {
        long requiredBytes = requiredBytes(combinedInputBytes);
        if (usableBytes < requiredBytes) {
            throw new IOException(
                    "Not enough free space in the temporary storage location "
                            + "(need approximately "
                            + formatMegabytes(requiredBytes)
                            + ", available "
                            + formatMegabytes(usableBytes)
                            + "). Free disk space and retry the comparison."
            );
        }
    }

    static long requiredBytes(long combinedInputBytes) {
        if (combinedInputBytes < 0) {
            throw new IllegalArgumentException(
                    "Combined CSV size cannot be negative."
            );
        }

        try {
            return Math.addExact(
                    Math.multiplyExact(
                            combinedInputBytes,
                            WORKING_SPACE_MULTIPLIER
                    ),
                    SAFETY_RESERVE_BYTES
            );
        } catch (ArithmeticException exception) {
            return Long.MAX_VALUE;
        }
    }

    private static String formatMegabytes(long bytes) {
        return String.format(
                Locale.ROOT,
                "%.0f MB",
                bytes / (1024.0 * 1024.0)
        );
    }
}
