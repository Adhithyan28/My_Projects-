package com.csvcomparison.tool.service;

import com.csvcomparison.tool.config.CsvComparisonProperties;
import com.csvcomparison.tool.engine.ExternalSortMergeComparisonEngine;
import com.csvcomparison.tool.engine.HashMapComparisonEngine;
import com.csvcomparison.tool.model.ComparisonResult;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.springframework.util.unit.DataSize;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

class CsvComparisonServiceTest {

    @TempDir
    Path tempDirectory;

    private HashMapComparisonEngine hashMapEngine;
    private ExternalSortMergeComparisonEngine externalSortEngine;
    private TemporaryDiskSpaceChecker diskSpaceChecker;
    private CsvComparisonService service;
    private ComparisonResult expectedResult;

    @BeforeEach
    void setUp() {
        hashMapEngine = mock(HashMapComparisonEngine.class);
        externalSortEngine = mock(ExternalSortMergeComparisonEngine.class);
        diskSpaceChecker = mock(TemporaryDiskSpaceChecker.class);

        CsvComparisonProperties properties = new CsvComparisonProperties();
        properties.setInMemoryThreshold(DataSize.ofBytes(8));

        service = new CsvComparisonService(
                hashMapEngine,
                externalSortEngine,
                properties,
                mock(ComparisonResultStore.class),
                diskSpaceChecker
        );
        expectedResult = new ComparisonResult(
                "comparison-id",
                List.of("id"),
                0,
                0,
                0,
                0
        );
    }

    @Test
    void usesHashMapEngineWhenCombinedInputFitsThreshold() throws IOException {
        Path oldCsv = createCsv("old.csv", "1234");
        Path newCsv = createCsv("new.csv", "5678");
        when(hashMapEngine.compare(oldCsv, newCsv)).thenReturn(expectedResult);

        assertSame(expectedResult, service.compare(oldCsv, newCsv));

        verify(hashMapEngine).compare(oldCsv, newCsv);
        verifyNoInteractions(externalSortEngine, diskSpaceChecker);
    }

    @Test
    void usesExternalSortWhenCombinedInputExceedsThreshold() throws IOException {
        Path oldCsv = createCsv("old.csv", "1234");
        Path newCsv = createCsv("new.csv", "56789");
        when(externalSortEngine.compare(oldCsv, newCsv)).thenReturn(expectedResult);

        assertSame(expectedResult, service.compare(oldCsv, newCsv));

        verify(externalSortEngine).compare(oldCsv, newCsv);
        verify(diskSpaceChecker).ensureAvailable(9);
        verifyNoInteractions(hashMapEngine);
    }

    private Path createCsv(String name, String contents) throws IOException {
        Path file = tempDirectory.resolve(name);
        return Files.writeString(file, contents);
    }
}
