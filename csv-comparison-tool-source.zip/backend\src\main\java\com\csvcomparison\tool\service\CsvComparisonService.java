
        package com.csvcomparison.tool.service;

        import com.csvcomparison.tool.config.CsvComparisonProperties;
        import com.csvcomparison.tool.engine.ExternalSortMergeComparisonEngine;
        import com.csvcomparison.tool.engine.HashMapComparisonEngine;
        import com.csvcomparison.tool.model.ComparisonResult;
        import com.csvcomparison.tool.model.ResultPage;
        import com.csvcomparison.tool.model.ResultType;

import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

@Service
public class CsvComparisonService {

    private static final long HEAP_FRACTION_FOR_IN_MEMORY_INPUT = 32;

    private final HashMapComparisonEngine hashMapComparisonEngine;
    private final ExternalSortMergeComparisonEngine externalSortMergeEngine;
    private final CsvComparisonProperties properties;
    private final ComparisonResultStore resultStore;
    private final TemporaryDiskSpaceChecker diskSpaceChecker;

    public CsvComparisonService(
            HashMapComparisonEngine hashMapComparisonEngine,
            ExternalSortMergeComparisonEngine externalSortMergeEngine,
            CsvComparisonProperties properties,
            ComparisonResultStore resultStore,
            TemporaryDiskSpaceChecker diskSpaceChecker
    ) {
        this.hashMapComparisonEngine = hashMapComparisonEngine;
        this.externalSortMergeEngine = externalSortMergeEngine;
        this.properties = properties;
        this.resultStore = resultStore;
        this.diskSpaceChecker = diskSpaceChecker;
    }

    /**
     * Uses the in-memory engine only when the combined input size is below
     * both the configured limit and a conservative fraction of the JVM heap.
     * Larger comparisons use external sorting to bound memory usage.
     */
    public ComparisonResult compare(
            Path oldCsv,
            Path newCsv
    ) throws IOException {

        long maxInMemoryBytes = Math.min(
                properties.getInMemoryThreshold().toBytes(),
                Runtime.getRuntime().maxMemory()
                        / HEAP_FRACTION_FOR_IN_MEMORY_INPUT
        );
        long oldSize = Files.size(oldCsv);
        long newSize = Files.size(newCsv);

        if (oldSize <= maxInMemoryBytes
                && newSize <= maxInMemoryBytes - oldSize) {
            return hashMapComparisonEngine.compare(oldCsv, newCsv);
        }

        long combinedInputBytes;
        try {
            combinedInputBytes = Math.addExact(oldSize, newSize);
        } catch (ArithmeticException exception) {
            throw new IOException(
                    "Combined CSV input size exceeds the supported range.",
                    exception
            );
        }
        diskSpaceChecker.ensureAvailable(combinedInputBytes);
        return externalSortMergeEngine.compare(oldCsv, newCsv);
    }

    public ComparisonResult getLatestComparison() {
        return resultStore.get();
    }

    public ComparisonResult getComparison(String comparisonId) {
        return resultStore.get(comparisonId);
    }

    public ResultPage getResultPage(
            String comparisonId,
            ResultType type,
            int page,
            int size
    ) throws IOException {

        return resultStore.readPage(
                comparisonId,
                type,
                page,
                size
        );
    }
}
