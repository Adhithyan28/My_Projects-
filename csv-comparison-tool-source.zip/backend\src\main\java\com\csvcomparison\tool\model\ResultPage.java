package com.csvcomparison.tool.model;

import java.util.List;

public record ResultPage(
        int page,
        int size,
        long totalRecords,
        long totalPages,
        List<String[]> records,
        List<RepeatedRecord> repeatedRecords
) {
}