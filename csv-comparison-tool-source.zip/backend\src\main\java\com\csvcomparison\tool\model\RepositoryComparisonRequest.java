
package com.csvcomparison.tool.model;

public record RepositoryComparisonRequest(
        String repositoryId,
        String oldBranch,
        String newBranch,
        String oldPath,
        String newPath,
        String provider
) {
}
