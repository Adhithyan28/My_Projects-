$ErrorActionPreference = "Stop"


# --------------------------------------------------
# Find an available TCP port
# --------------------------------------------------

function Find-FreePort {
    param (
        [int]$PreferredPort
    )

    $port = $PreferredPort

    while ($true) {
        $inUse = Get-NetTCPConnection `
            -LocalPort $port `
            -State Listen `
            -ErrorAction SilentlyContinue

        if (-not $inUse) {
            return $port
        }

        $port++
    }
}


Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "       CSV Comparison Tool - Run" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# --------------------------------------------------
# Locate project
# --------------------------------------------------

$scriptDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$projectRoot = Split-Path -Parent $scriptDirectory

$backendPath = Join-Path $projectRoot "backend"
$frontendPath = Join-Path $projectRoot "frontend"

Write-Host "Project root:" -ForegroundColor Cyan
Write-Host "  $projectRoot"
Write-Host ""

# --------------------------------------------------
# Validate project structure
# --------------------------------------------------

if (-not (Test-Path $backendPath -PathType Container)) {
    Write-Host "Backend directory was not found:" -ForegroundColor Red
    Write-Host "  $backendPath" -ForegroundColor Red
    exit 1
}

if (-not (Test-Path $frontendPath -PathType Container)) {
    Write-Host "Frontend directory was not found:" -ForegroundColor Red
    Write-Host "  $frontendPath" -ForegroundColor Red
    exit 1
}

if (-not (Test-Path (Join-Path $backendPath "mvnw.cmd") -PathType Leaf)) {
    Write-Host "Maven Wrapper was not found:" -ForegroundColor Red
    Write-Host "  $backendPath\mvnw.cmd" -ForegroundColor Red
    exit 1
}

if (-not (Test-Path (Join-Path $frontendPath "package.json") -PathType Leaf)) {
    Write-Host "Frontend package.json was not found:" -ForegroundColor Red
    Write-Host "  $frontendPath\package.json" -ForegroundColor Red
    exit 1
}

Write-Host "Project structure verified." -ForegroundColor Green
Write-Host ""

# --------------------------------------------------
# Check Java
# --------------------------------------------------

Write-Host "Checking Java..." -ForegroundColor Cyan

. (Join-Path $scriptDirectory "java-runtime-windows.ps1")
Ensure-JavaRuntime

# --------------------------------------------------
# Check Node.js
# --------------------------------------------------

Write-Host ""
Write-Host "Checking Node.js..." -ForegroundColor Cyan

if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
    Write-Host "Node.js was not found." -ForegroundColor Red
    Write-Host "Please run setup-windows.ps1 first." -ForegroundColor Yellow
    exit 1
}

if (-not (Get-Command npm -ErrorAction SilentlyContinue)) {
    Write-Host "npm was not found." -ForegroundColor Red
    Write-Host "Please run setup-windows.ps1 first." -ForegroundColor Yellow
    exit 1
}

$nodeVersion = node --version
$npmVersion = npm --version

Write-Host "Node.js $nodeVersion detected." -ForegroundColor Green
Write-Host "npm $npmVersion detected." -ForegroundColor Green

Write-Host ""
Write-Host "Required software verified." -ForegroundColor Green
Write-Host ""

# --------------------------------------------------
# Configure optional GitHub OAuth and set process environment
# --------------------------------------------------

$oauthConfigPath = Join-Path $backendPath "oauth.env"
Import-LocalOAuthEnvironment $oauthConfigPath
Set-LocalOAuthEnvironment $oauthConfigPath


# --------------------------------------------------
# Find available ports
# --------------------------------------------------

$backendPort = Find-FreePort -PreferredPort 8080
$frontendPort = Find-FreePort -PreferredPort 5173

Write-Host "Selected ports:" -ForegroundColor Cyan
Write-Host "  Backend:  $backendPort"
Write-Host "  Frontend: $frontendPort"
Write-Host ""

if ($backendPort -ne 8080) {
    Write-Host "Port 8080 is already in use. Using backend port $backendPort." -ForegroundColor Yellow
}

if ($frontendPort -ne 5173) {
    Write-Host "Port 5173 is already in use. Using frontend port $frontendPort." -ForegroundColor Yellow
}

Write-Host ""


# --------------------------------------------------
# Start backend
# --------------------------------------------------

Write-Host "Starting backend on port $backendPort..." -ForegroundColor Cyan

$backendProcess = Start-Process `
    -FilePath "cmd.exe" `
    -ArgumentList "/c", "mvnw.cmd spring-boot:run -Dspring-boot.run.arguments=--server.port=$backendPort" `
    -WorkingDirectory $backendPath `
    -PassThru

Write-Host "Backend process started." -ForegroundColor Green
Write-Host "Backend PID: $($backendProcess.Id)" -ForegroundColor DarkGray
Write-Host "Backend port: $backendPort" -ForegroundColor DarkGray
Write-Host ""

# --------------------------------------------------
# Wait for backend
# --------------------------------------------------

Write-Host "Waiting for backend to become ready..." -ForegroundColor Cyan

$backendReady = $false

for ($i = 1; $i -le 30; $i++) {
    Start-Sleep -Seconds 1

    try {
        $connection = Test-NetConnection `
           -ComputerName "localhost" `
           -Port $backendPort `
           -WarningAction SilentlyContinue

        if ($connection.TcpTestSucceeded) {
            $backendReady = $true
            break
        }
    }
    catch {
        # Backend is not ready yet.
    }

    Write-Host "." -NoNewline
}

Write-Host ""

if (-not $backendReady) {
    Write-Host "Backend did not become ready within 30 seconds." -ForegroundColor Red

    if (-not $backendProcess.HasExited) {
        Stop-Process -Id $backendProcess.Id -Force
    }

    exit 1
}

Write-Host "Backend is ready on port $backendPort." -ForegroundColor Green
Write-Host ""

# --------------------------------------------------
# Start frontend
# --------------------------------------------------

Write-Host "Starting frontend on port $frontendPort..." -ForegroundColor Cyan

$frontendProcess = Start-Process `
    -FilePath "cmd.exe" `
    -ArgumentList "/k", "set BACKEND_PORT=$backendPort&& npm run dev -- --port $frontendPort" `
    -WorkingDirectory $frontendPath `
    -PassThru

Write-Host "Frontend process started." -ForegroundColor Green
Write-Host "Frontend PID: $($frontendProcess.Id)" -ForegroundColor DarkGray
Write-Host "Frontend port: $frontendPort" -ForegroundColor DarkGray
Write-Host ""

# --------------------------------------------------
# Wait for frontend
# --------------------------------------------------

Write-Host "Waiting for frontend to become ready..." -ForegroundColor Cyan

$frontendReady = $false

for ($i = 1; $i -le 30; $i++) {
    Start-Sleep -Seconds 1

    try {
        $connection = Test-NetConnection `
    		-ComputerName "localhost" `
    		-Port $frontendPort `
    		-WarningAction SilentlyContinue

        if ($connection.TcpTestSucceeded) {
            $frontendReady = $true
            break
        }
    }
    catch {
        # Frontend is not ready yet.
    }

    Write-Host "." -NoNewline
}

Write-Host ""

if (-not $frontendReady) {
    Write-Host "Frontend did not become ready within 30 seconds." -ForegroundColor Red
    exit 1
}

Write-Host "Frontend is ready on port $frontendPort." -ForegroundColor Green
Write-Host ""

# --------------------------------------------------
# Open browser
# --------------------------------------------------

Write-Host "Opening application in your browser..." -ForegroundColor Cyan

Start-Process "http://localhost:$frontendPort"

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "       Application is running!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""
Write-Host "Frontend: http://localhost:$frontendPort" -ForegroundColor Cyan
Write-Host "Backend:  http://localhost:$backendPort" -ForegroundColor Cyan
Write-Host ""

# --------------------------------------------------
# Keep application running and handle Ctrl+C
# --------------------------------------------------

Write-Host "Press Ctrl+C to stop the application." -ForegroundColor Yellow
Write-Host ""

try {
    while ($true) {
        Start-Sleep -Seconds 1

        if ($backendProcess.HasExited) {
            Write-Host "Backend process has stopped." -ForegroundColor Red
            break
        }

        if ($frontendProcess.HasExited) {
            Write-Host "Frontend process has stopped." -ForegroundColor Red
            break
        }
    }
}
finally {
    Write-Host ""
    Write-Host "Stopping application..." -ForegroundColor Yellow

    if ($frontendProcess -and -not $frontendProcess.HasExited) {
        taskkill /PID $frontendProcess.Id /T /F 2>$null | Out-Null
        Write-Host "Frontend stopped." -ForegroundColor Green
    }

    if ($backendProcess -and -not $backendProcess.HasExited) {
        taskkill /PID $backendProcess.Id /T /F 2>$null | Out-Null
        Write-Host "Backend stopped." -ForegroundColor Green
    }

    Write-Host ""
    Write-Host "Application stopped." -ForegroundColor Green
}