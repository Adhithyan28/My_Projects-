package com.csvcomparison.tool.service;

import com.univocity.parsers.csv.CsvParser;
import com.univocity.parsers.csv.CsvParserSettings;

import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import static com.csvcomparison.tool.service.ResultFileWriter.INDEX_INTERVAL;

public class ResultFileReader {

    public List<String[]> readPage(
            Path file,
            List<Long> offsets,
            int page,
            int size
    ) throws IOException {

        validateArguments(file, offsets, page, size);

        if (offsets.isEmpty()) {
            return List.of();
        }

        long targetRecord = (long) page * size;
        long offsetIndexLong = targetRecord / INDEX_INTERVAL;

        if (offsetIndexLong >= offsets.size()) {
            return List.of();
        }

        int offsetIndex = (int) offsetIndexLong;
        long fileOffset = offsets.get(offsetIndex);

        long recordsToSkip =
                targetRecord - ((long) offsetIndex * INDEX_INTERVAL);

        try (FileChannel channel = FileChannel.open(file);
             InputStream inputStream = Channels.newInputStream(channel)) {

            channel.position(fileOffset);

            CsvParserSettings settings = new CsvParserSettings();
            settings.setHeaderExtractionEnabled(false);
            settings.setLineSeparatorDetectionEnabled(true);

            CsvParser parser = new CsvParser(settings);
            parser.beginParsing(inputStream);

            try {
                for (long i = 0; i < recordsToSkip; i++) {
                    if (parser.parseNext() == null) {
                        return List.of();
                    }
                }

                List<String[]> records = new ArrayList<>(size);

                for (int i = 0; i < size; i++) {
                    String[] row = parser.parseNext();

                    if (row == null) {
                        break;
                    }

                    records.add(row);
                }

                return records;
            } finally {
                parser.stopParsing();
            }
        }
    }

    private void validateArguments(
            Path file,
            List<Long> offsets,
            int page,
            int size
    ) {
        if (file == null) {
            throw new IllegalArgumentException(
                    "Result file cannot be null."
            );
        }

        if (offsets == null) {
            throw new IllegalArgumentException(
                    "Result file offsets cannot be null."
            );
        }

        if (page < 0) {
            throw new IllegalArgumentException(
                    "Page number cannot be negative."
            );
        }

        if (size <= 0) {
            throw new IllegalArgumentException(
                    "Page size must be greater than zero."
            );
        }
    }
}