export type ResultType = 'ADDED' | 'UPDATED' | 'MISSING' | 'REPEATED'

export type ResultCategory = 'added' | 'updated' | 'missing' | 'repeated'

export interface RepeatedRecord {
    source: 'PREVIOUS' | 'LATEST'
    id: string
    record: string[]
}

export interface ComparisonResult {
    comparisonId: string
    headers: string[]
    addedRecordCount: number
    updatedRecordCount: number
    missingRecordCount: number
    repeatedRecordCount: number
}

export interface ResultPage {
    page: number
    size: number
    totalRecords: number
    totalPages: number
    records: string[][]
    repeatedRecords?: RepeatedRecord[]
}