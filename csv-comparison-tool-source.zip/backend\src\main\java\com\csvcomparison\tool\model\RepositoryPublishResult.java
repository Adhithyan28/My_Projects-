
package com.csvcomparison.tool.model;

public record RepositoryPublishResult(
        String repository,
        String branchName,
        String destinationPath,
        String commitSha,
        String commitUrl,
        String fileUrl,
        String updatedDestinationPath,
        String updatedFileUrl,
        String highlightedReportDestinationPath,
        String highlightedReportUrl,
        String message
) {
    public RepositoryPublishResult(
            String repository,
            String branchName,
            String destinationPath,
            String commitSha,
            String commitUrl,
            String fileUrl,
            String updatedDestinationPath,
            String updatedFileUrl,
            String message
    ) {
        this(
                repository,
                branchName,
                destinationPath,
                commitSha,
                commitUrl,
                fileUrl,
                updatedDestinationPath,
                updatedFileUrl,
                null,
                null,
                message
        );
    }
}
