function Ensure-JavaRuntime {
    $javaCommand = Get-Command java -ErrorAction SilentlyContinue
    $javaMajor = 0

    if ($javaCommand) {
        $versionLine = cmd /c "java -version 2>&1" | Select-Object -First 1
        if ($versionLine -match 'version "(\d+)') {
            $javaMajor = [int]$Matches[1]
        }
    }

    if ($javaMajor -ge 21) {
        Write-Host "Java $javaMajor detected." -ForegroundColor Green
        return
    }

    if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
        throw "Java 21+ is required. Install Eclipse Temurin 21, reopen PowerShell, and rerun this script (winget is unavailable)."
    }

    $answer = Read-Host "Java 21 or newer is required. Install Eclipse Temurin 21 with winget now? [Y/n]"
    if ($answer -and $answer -notmatch "^[Yy]$") {
        throw "Java installation was skipped."
    }

    winget install --id EclipseAdoptium.Temurin.21.JDK --exact `
        --accept-source-agreements --accept-package-agreements
    if ($LASTEXITCODE -ne 0) {
        throw "Java installation failed. Install Java 21+ and rerun."
    }

    $machinePath = [Environment]::GetEnvironmentVariable("Path", "Machine")
    $userPath = [Environment]::GetEnvironmentVariable("Path", "User")
    $env:Path = "$machinePath;$userPath"

    $javaHome = Get-ChildItem "$env:ProgramFiles\Eclipse Adoptium" `
        -Directory -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -match "^jdk-21" } |
        Select-Object -First 1
    if ($javaHome) {
        $env:Path = (Join-Path $javaHome.FullName "bin") + ";" + $env:Path
    }

    $versionLine = cmd /c "java -version 2>&1" | Select-Object -First 1
    if ($versionLine -notmatch 'version "(\d+)' -or [int]$Matches[1] -lt 21) {
        throw "Java was installed, but is not available yet. Reopen PowerShell and rerun."
    }

    Write-Host "Java $($Matches[1]) is ready." -ForegroundColor Green
}

function Find-FreePort([int]$PreferredPort) {
    $port = $PreferredPort
    while ($port -le 65535) {
        $listener = $null
        try {
            $listener = [System.Net.Sockets.TcpListener]::new(
                [System.Net.IPAddress]::Loopback,
                $port
            )
            $listener.Start()
            return $port
        }
        catch [System.Net.Sockets.SocketException] {
            $port++
        }
        finally {
            if ($listener) {
                $listener.Stop()
            }
        }
    }
    throw "No free TCP port is available starting at $PreferredPort."
}

function Set-LocalApplicationUrls([int]$Port) {
    if (-not $env:APP_FRONTEND_URL `
            -or $env:APP_FRONTEND_URL -eq "http://localhost:8080") {
        $env:APP_FRONTEND_URL = "http://localhost:$Port"
    }

    $defaultCallback = "http://localhost:8080/api/connections/github/callback"
    if (-not $env:GITHUB_OAUTH_REDIRECT_URI `
            -or $env:GITHUB_OAUTH_REDIRECT_URI -eq $defaultCallback) {
        $env:GITHUB_OAUTH_REDIRECT_URI = `
            "http://localhost:$Port/api/connections/github/callback"
    }
}

function Import-LocalOAuthEnvironment([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        return
    }

    foreach ($line in [System.IO.File]::ReadAllLines($Path)) {
        if ($line -match '^(GITHUB_OAUTH_CLIENT_ID|GITHUB_OAUTH_CLIENT_SECRET|GITHUB_OAUTH_REDIRECT_URI)=(.*)$') {
            if (-not [Environment]::GetEnvironmentVariable($Matches[1], "Process")) {
                [Environment]::SetEnvironmentVariable($Matches[1], $Matches[2], "Process")
            }
        }
    }
}

function Set-LocalOAuthEnvironment([string]$Path) {
    if ((-not $env:GITHUB_OAUTH_CLIENT_ID -or -not $env:GITHUB_OAUTH_CLIENT_SECRET) `
            ) {
        Write-Host "GitHub OAuth is optional. Leave both credentials empty for CSV-only use."
        $clientId = Read-Host "GitHub OAuth client ID"
        $secretSecure = Read-Host "GitHub OAuth client secret (input hidden)" -AsSecureString
        $secretPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secretSecure)
        try {
            $clientSecret = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($secretPointer)
        }
        finally {
            [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($secretPointer)
        }

        if (-not $clientId -and -not $clientSecret) {
            Write-Host "Continuing without GitHub OAuth."
            return
        }
        if (-not $clientId -or -not $clientSecret) {
            throw "Enter both OAuth values, or leave both empty for CSV-only use."
        }

        $redirectUri = Read-Host "GitHub callback URI [http://localhost:8080/api/connections/github/callback]"
        if (-not $redirectUri) {
            $redirectUri = "http://localhost:8080/api/connections/github/callback"
        }
        foreach ($value in @($clientId, $clientSecret, $redirectUri)) {
            if ($value.Contains("`n") -or $value.Contains("`r")) {
                throw "OAuth values cannot contain line breaks."
            }
        }

        $settings = @(
            "GITHUB_OAUTH_CLIENT_ID=$clientId"
            "GITHUB_OAUTH_CLIENT_SECRET=$clientSecret"
            "GITHUB_OAUTH_REDIRECT_URI=$redirectUri"
        )
        $utf8WithoutBom = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllLines($Path, $settings, $utf8WithoutBom)
        Write-Host "OAuth settings saved locally; this file must not be shared."
    }

    Import-LocalOAuthEnvironment $Path
}
