package com.csvcomparison.tool.repository.provider;

import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Component
public class RepositoryProviderRegistry {

    private final Map<String, RepositoryProvider> providers;

    public RepositoryProviderRegistry(List<RepositoryProvider> providers) {
        this.providers = providers.stream().collect(Collectors.toUnmodifiableMap(
                provider -> normalize(provider.getProviderName()),
                Function.identity()
        ));
    }

    public RepositoryProvider get(String providerName) {
        RepositoryProvider provider = providers.get(normalize(providerName));

        if (provider == null) {
            throw new IllegalArgumentException(
                    "Unsupported repository provider: " + providerName
            );
        }

        return provider;
    }

    private String normalize(String providerName) {
        if (providerName == null || providerName.isBlank()) {
            throw new IllegalArgumentException(
                    "Repository provider is required."
            );
        }

        return providerName.trim().toLowerCase(Locale.ROOT);
    }
}
