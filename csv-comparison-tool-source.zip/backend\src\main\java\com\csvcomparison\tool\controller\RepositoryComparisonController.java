package com.csvcomparison.tool.controller;

import com.csvcomparison.tool.model.ComparisonResult;
import com.csvcomparison.tool.model.RepositoryComparisonRequest;
import com.csvcomparison.tool.repository.provider.ProviderSessionKeys;
import com.csvcomparison.tool.repository.provider.RepositoryProvider;
import com.csvcomparison.tool.repository.provider.RepositoryProviderRegistry;
import com.csvcomparison.tool.service.CsvComparisonService;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientResponseException;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

@RestController
@RequestMapping("/api/repository-comparisons")
public class RepositoryComparisonController {

    private final CsvComparisonService comparisonService;
    private final RepositoryProviderRegistry providerRegistry;

    public RepositoryComparisonController(
            CsvComparisonService comparisonService,
            RepositoryProviderRegistry providerRegistry
    ) {
        this.comparisonService = comparisonService;
        this.providerRegistry = providerRegistry;
    }

    @PostMapping
    public ResponseEntity<?> compareRepositoryFiles(
            @RequestBody RepositoryComparisonRequest request,
            HttpSession session
    ) {
        if (!isValidRequest(request)) {
            return ResponseEntity.badRequest().body(Map.of(
                    "error",
                    "Provide a repository, both branches, and both CSV paths."
            ));
        }

        String providerName = request.provider() == null
                || request.provider().isBlank()
                ? "github"
                : request.provider();

        RepositoryProvider provider;
        try {
            provider = providerRegistry.get(providerName);
        } catch (IllegalArgumentException exception) {
            return ResponseEntity.badRequest().body(
                    Map.of("error", exception.getMessage())
            );
        }

        String token = ProviderSessionKeys.getToken(
                session,
                provider.getProviderName()
        );
        if (token == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of(
                    "error",
                    "Connect " + provider.getProviderName()
                            + " before comparing repository files."
            ));
        }

        if (!isCsvPath(request.oldPath()) || !isCsvPath(request.newPath())) {
            return ResponseEntity.badRequest().body(Map.of(
                    "error",
                    "Both selected files must have a .csv extension."
            ));
        }

        Path oldCsv = null;
        Path newCsv = null;
        try {
            oldCsv = Files.createTempFile("repository-old-", ".csv");
            newCsv = Files.createTempFile("repository-new-", ".csv");

            provider.downloadFile(
                    token,
                    request.repositoryId(),
                    request.oldBranch(),
                    request.oldPath(),
                    oldCsv
            );
            provider.downloadFile(
                    token,
                    request.repositoryId(),
                    request.newBranch(),
                    request.newPath(),
                    newCsv
            );

            ComparisonResult result =
                    comparisonService.compare(oldCsv, newCsv);
            return ResponseEntity.ok(result);
        } catch (RestClientResponseException exception) {
            HttpStatus status = switch (exception.getStatusCode().value()) {
                case 401 -> HttpStatus.UNAUTHORIZED;
                case 403 -> HttpStatus.FORBIDDEN;
                case 404 -> HttpStatus.NOT_FOUND;
                default -> HttpStatus.BAD_GATEWAY;
            };
            return ResponseEntity.status(status).body(Map.of(
                    "error",
                    "The repository provider could not download the selected CSV files."
            ));
        } catch (IllegalArgumentException exception) {
            return ResponseEntity.badRequest().body(Map.of(
                    "error",
                    "Invalid repository file path."
            ));
        } catch (IOException exception) {
            return ResponseEntity.internalServerError().body(Map.of(
                    "error",
                    "The CSV files could not be downloaded or compared."
            ));
        } finally {
            deleteTemporaryFile(oldCsv);
            deleteTemporaryFile(newCsv);
        }
    }

    private boolean isValidRequest(RepositoryComparisonRequest request) {
        return request != null
                && notBlank(request.repositoryId())
                && notBlank(request.oldBranch())
                && notBlank(request.newBranch())
                && notBlank(request.oldPath())
                && notBlank(request.newPath());
    }

    private boolean notBlank(String value) {
        return value != null && !value.isBlank();
    }

    private boolean isCsvPath(String path) {
        return path != null
                && path.toLowerCase(java.util.Locale.ROOT).endsWith(".csv");
    }

    private void deleteTemporaryFile(Path file) {
        if (file == null) {
            return;
        }
        try {
            Files.deleteIfExists(file);
        } catch (IOException ignored) {
            // Cleanup failure must not hide the comparison result.
        }
    }
}
