package com.csvcomparison.tool.service;

import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class TemporaryDiskSpaceCheckerTest {

    @Test
    void requiresThreeTimesInputSizePlusSafetyReserve() {
        assertEquals(
                364L * 1024 * 1024,
                TemporaryDiskSpaceChecker.requiredBytes(100L * 1024 * 1024)
        );
    }

    @Test
    void rejectsComparisonWhenTemporaryDiskIsTooFull() {
        long required = TemporaryDiskSpaceChecker.requiredBytes(10);
        assertThrows(
                IOException.class,
                () -> TemporaryDiskSpaceChecker.ensureAvailable(
                        10,
                        required - 1
                )
        );
    }
}
