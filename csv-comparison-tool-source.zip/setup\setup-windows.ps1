$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "       CSV Comparison Tool - Setup" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

function Test-CommandExists {
    param (
        [string]$CommandName
    )

    return $null -ne (Get-Command $CommandName -ErrorAction SilentlyContinue)
}

function Get-JavaMajorVersion {
    if (-not (Test-CommandExists "java")) {
        return $null
    }

    try {
        $javaVersionLine = cmd /c "java -version 2>&1" | Select-Object -First 1

        if ($javaVersionLine -match 'version "(\d+)') {
            return [int]$Matches[1]
        }

        return $null
    }
    catch {
        return $null
    }
}

function Install-WithWinget {
    param (
        [string]$Id,
        [string]$Name
    )

    if (-not (Test-CommandExists "winget")) {
        Write-Host ""
        Write-Host "Windows Package Manager (winget) is not available." -ForegroundColor Red
        Write-Host "Please install the required software manually:" -ForegroundColor Yellow
        Write-Host "  $Name"
        exit 1
    }

    Write-Host ""
    Write-Host "Installing $Name..." -ForegroundColor Yellow

    winget install --id $Id --exact --accept-source-agreements --accept-package-agreements

    if ($LASTEXITCODE -ne 0) {
        Write-Host ""
        Write-Host "Failed to install $Name." -ForegroundColor Red
        exit 1
    }

    Write-Host "$Name installation completed." -ForegroundColor Green
}

# --------------------------------------------------
# Java
# --------------------------------------------------

Write-Host "Checking Java..." -ForegroundColor Cyan

$javaVersion = Get-JavaMajorVersion

if ($null -ne $javaVersion -and $javaVersion -ge 21) {
    Write-Host "Java $javaVersion detected." -ForegroundColor Green
}
else {
    if ($null -eq $javaVersion) {
        Write-Host "Java 21 or newer was not found." -ForegroundColor Yellow
    }
    else {
        Write-Host "Java $javaVersion detected, but Java 21 or newer is required." -ForegroundColor Yellow
    }

    $answer = Read-Host "Install Java 21 now? [Y/n]"

    if ($answer -eq "" -or $answer -match "^[Yy]$") {
        Install-WithWinget `
            -Id "EclipseAdoptium.Temurin.21.JDK" `
            -Name "Java 21 (Temurin JDK)"

        Write-Host ""
        Write-Host "Java was installed." -ForegroundColor Green
        Write-Host "Please restart this PowerShell window and run this setup script again." -ForegroundColor Yellow
        exit 0
    }
    else {
        Write-Host "Java installation skipped." -ForegroundColor Yellow
        exit 1
    }
}

# --------------------------------------------------
# Node.js / npm
# --------------------------------------------------

Write-Host ""
Write-Host "Checking Node.js..." -ForegroundColor Cyan

$nodeAvailable = Test-CommandExists "node"
$npmAvailable = Test-CommandExists "npm"

if ($nodeAvailable -and $npmAvailable) {
    $nodeVersion = node --version
    $npmVersion = npm --version

    Write-Host "Node.js $nodeVersion detected." -ForegroundColor Green
    Write-Host "npm $npmVersion detected." -ForegroundColor Green
}
else {
    Write-Host "Node.js and/or npm were not found." -ForegroundColor Yellow

    $answer = Read-Host "Install Node.js LTS now? [Y/n]"

    if ($answer -eq "" -or $answer -match "^[Yy]$") {
        Install-WithWinget `
            -Id "OpenJS.NodeJS.LTS" `
            -Name "Node.js LTS"

        Write-Host ""
        Write-Host "Node.js was installed." -ForegroundColor Green
        Write-Host "Please restart this PowerShell window and run this setup script again." -ForegroundColor Yellow
        exit 0
    }
    else {
        Write-Host "Node.js installation skipped." -ForegroundColor Yellow
        exit 1
    }
}

# --------------------------------------------------
# Frontend dependencies
# --------------------------------------------------

Write-Host ""
Write-Host "Installing frontend dependencies..." -ForegroundColor Cyan

$scriptDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$projectRoot = Split-Path -Parent $scriptDirectory
$frontendPath = Join-Path $projectRoot "frontend"

if (-not (Test-Path $frontendPath -PathType Container)) {
    Write-Host "Frontend directory was not found:" -ForegroundColor Red
    Write-Host $frontendPath -ForegroundColor Red
    exit 1
}

Push-Location $frontendPath

try {
    npm install

    if ($LASTEXITCODE -ne 0) {
        Write-Host ""
        Write-Host "npm install failed." -ForegroundColor Red
        exit 1
    }
}
finally {
    Pop-Location
}

# --------------------------------------------------
# Complete
# --------------------------------------------------

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "          Setup completed!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""
Write-Host "To start the application:" -ForegroundColor Cyan
Write-Host ""
Write-Host "Backend:" -ForegroundColor Yellow
Write-Host "  cd backend"
Write-Host "  .\mvnw.cmd spring-boot:run"
Write-Host ""
Write-Host "Frontend (open another terminal):" -ForegroundColor Yellow
Write-Host "  cd frontend"
Write-Host "  npm run dev"
Write-Host ""
Write-Host "Then open the URL shown by Vite, normally http://localhost:5173" -ForegroundColor Cyan
Write-Host ""