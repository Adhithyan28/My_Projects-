import { useEffect, useState } from "react"
import { useAuth } from "../context/AuthContext"
import LocationPicker from "../components/location/LocationPicker"


/* =========================================
 * CUSTOMER PROFILE PROPS
 * ========================================= */

interface CustomerProfileProps {
    onHome: () => void
    onStores: () => void
    onCategories: () => void
    onProducts: () => void
    onOrders: () => void
    onCart: () => void
    onAddressSaved?: (addressId: number) => void
}


/* =========================================
 * ADDRESS TYPE
 *
 * IMPORTANT:
 * Backend profile response returns:
 * "default": true/false
 *
 * So frontend must use "default" when
 * reading address data.
 * ========================================= */

interface Address {
    addressId: number
    addressLine: string
    city: string
    state: string
    pincode: string
    latitude: number
    longitude: number
    default: boolean
}


/* =========================================
 * CUSTOMER PROFILE DATA
 * ========================================= */

interface CustomerProfileData {
    userId: number
    firstName: string
    lastName: string
    email: string
    phone: string
    profileComplete: boolean
    addresses: Address[]
}


/* =========================================
 * ADDRESS FORM
 * ========================================= */

interface AddressForm {
    addressLine: string
    city: string
    state: string
    pincode: string
}


/* =========================================
 * LOCATION RESULT
 * ========================================= */

interface LocationResult {
    latitude: number
    longitude: number
}


/* =========================================
 * CUSTOMER PROFILE
 * ========================================= */

function CustomerProfile({
                             onHome,
                             onStores,
                             onCategories,
                             onProducts,
                             onOrders,
                             onCart,
                             onAddressSaved
                         }: CustomerProfileProps) {

    const { user, logout } = useAuth()


    /* =========================================
     * PROFILE STATE
     * ========================================= */

    const [profile, setProfile] =
        useState<CustomerProfileData | null>(null)

    const [firstName, setFirstName] =
        useState("")

    const [lastName, setLastName] =
        useState("")

    const [phone, setPhone] =
        useState("")


    /* =========================================
     * LOADING / SAVING
     * ========================================= */

    const [loading, setLoading] =
        useState(true)

    const [saving, setSaving] =
        useState(false)


    /* =========================================
     * MESSAGES
     * ========================================= */

    const [message, setMessage] =
        useState("")

    const [error, setError] =
        useState("")


    /* =========================================
     * ADDRESS FORM STATE
     * ========================================= */

    const [showAddressForm, setShowAddressForm] =
        useState(false)

    const [editingAddressId, setEditingAddressId] =
        useState<number | null>(null)

    const [addressForm, setAddressForm] =
        useState<AddressForm>({
            addressLine: "",
            city: "",
            state: "",
            pincode: ""
        })


    /* =========================================
     * LOCATION STATE
     * ========================================= */

    const [location, setLocation] =
        useState<LocationResult | null>(null)

    const [locationConfirmed, setLocationConfirmed] =
        useState(false)

    const [findingLocation, setFindingLocation] =
        useState(false)

    const [savingAddress, setSavingAddress] =
        useState(false)


    /* =========================================
     * RESPONSE MESSAGE HELPER
     * ========================================= */

    const getResponseMessage = async (
        response: Response
    ): Promise<string> => {

        const text =
            await response.text()

        if (!text) {
            return "Something went wrong. Please try again."
        }

        try {

            const data =
                JSON.parse(text)

            if (typeof data === "string") {
                return data
            }

            if (data.message) {
                return data.message
            }

            if (data.error) {
                return data.error
            }

            return text

        } catch {

            return text
        }
    }


    /* =========================================
     * LOAD PROFILE
     * ========================================= */

    const loadProfile = async () => {

        if (!user?.token) {

            setError(
                "Your login session is missing. Please login again."
            )

            setLoading(false)

            return
        }

        setLoading(true)
        setError("")

        try {

            const response =
                await fetch(
                    "http://localhost:8080/api/customer/profile",
                    {
                        method: "GET",

                        headers: {
                            Authorization:
                                `Bearer ${user.token}`
                        }
                    }
                )

            const result =
                await getResponseMessage(response)

            if (!response.ok) {
                throw new Error(result)
            }

            const data =
                JSON.parse(result) as CustomerProfileData

            setProfile(data)

            setFirstName(
                data.firstName || ""
            )

            setLastName(
                data.lastName || ""
            )

            setPhone(
                data.phone || ""
            )

        } catch (error) {

            console.error(
                "Customer profile error:",
                error
            )

            if (error instanceof Error) {

                setError(
                    error.message
                )

            } else {

                setError(
                    "Unable to load your profile."
                )
            }

        } finally {

            setLoading(false)
        }
    }


    /* =========================================
     * LOAD PROFILE ON PAGE LOAD
     * ========================================= */

    useEffect(() => {

        loadProfile()

    }, [user?.token])


    /* =========================================
     * SAVE PROFILE
     * ========================================= */

    const handleSaveProfile = async () => {

        setMessage("")
        setError("")


        if (!firstName.trim()) {

            setError(
                "First name is required."
            )

            return
        }


        if (!lastName.trim()) {

            setError(
                "Last name is required."
            )

            return
        }


        if (
            !/^[6-9][0-9]{9}$/.test(
                phone.trim()
            )
        ) {

            setError(
                "Please enter a valid 10-digit Indian mobile number."
            )

            return
        }


        if (!user?.token) {

            setError(
                "Your login session is missing. Please login again."
            )

            return
        }


        setSaving(true)

        try {

            const response =
                await fetch(
                    "http://localhost:8080/api/customer/profile",
                    {
                        method: "PUT",

                        headers: {
                            "Content-Type":
                                "application/json",

                            Authorization:
                                `Bearer ${user.token}`
                        },

                        body:
                            JSON.stringify({
                                firstName:
                                    firstName.trim(),

                                lastName:
                                    lastName.trim(),

                                phone:
                                    phone.trim()
                            })
                    }
                )


            const result =
                await getResponseMessage(response)


            if (!response.ok) {
                throw new Error(result)
            }


            const data =
                JSON.parse(
                    result
                ) as CustomerProfileData


            setProfile(data)

            setFirstName(
                data.firstName || ""
            )

            setLastName(
                data.lastName || ""
            )

            setPhone(
                data.phone || ""
            )


            setMessage(
                "Profile details saved successfully."
            )

        } catch (error) {

            console.error(
                "Profile update error:",
                error
            )

            if (error instanceof Error) {

                setError(
                    error.message
                )

            } else {

                setError(
                    "Unable to update your profile."
                )
            }

        } finally {

            setSaving(false)
        }
    }


    /* =========================================
     * RESET ADDRESS FORM
     * ========================================= */

    const resetAddressForm = () => {

        setAddressForm({
            addressLine: "",
            city: "",
            state: "",
            pincode: ""
        })

        setLocation(null)

        setLocationConfirmed(false)

        setEditingAddressId(null)

        setShowAddressForm(false)

        setError("")

        setMessage("")
    }


    /* =========================================
     * ADD NEW ADDRESS
     * ========================================= */

    const handleAddAddress = () => {

        setMessage("")
        setError("")

        setEditingAddressId(null)

        setAddressForm({
            addressLine: "",
            city: "",
            state: "",
            pincode: ""
        })

        setLocation(null)

        setLocationConfirmed(false)

        setShowAddressForm(true)
    }


    /* =========================================
     * EDIT ADDRESS
     * ========================================= */

    const handleEditAddress = (
        address: Address
    ) => {

        setMessage("")
        setError("")

        setEditingAddressId(
            address.addressId
        )

        setAddressForm({
            addressLine:
            address.addressLine,

            city:
            address.city,

            state:
            address.state,

            pincode:
            address.pincode
        })

        setLocation({
            latitude:
            address.latitude,

            longitude:
            address.longitude
        })

        setLocationConfirmed(true)

        setShowAddressForm(true)
    }


    /* =========================================
     * ADDRESS FIELD CHANGE
     * ========================================= */

    const handleAddressFieldChange = (
        field: keyof AddressForm,
        value: string
    ) => {

        setAddressForm(
            previous => ({
                ...previous,
                [field]: value
            })
        )

        setLocation(null)

        setLocationConfirmed(false)

        setError("")
    }


    /* =========================================
     * FIND LOCATION
     * ========================================= */

    const handleFindLocation = async () => {

        setMessage("")
        setError("")


        if (!addressForm.addressLine.trim()) {

            setError(
                "Address line is required."
            )

            return
        }


        if (!addressForm.city.trim()) {

            setError(
                "City is required."
            )

            return
        }


        if (!addressForm.state.trim()) {

            setError(
                "State is required."
            )

            return
        }


        if (
            !/^[1-9][0-9]{5}$/.test(
                addressForm.pincode.trim()
            )
        ) {

            setError(
                "Please enter a valid 6-digit Indian pincode."
            )

            return
        }


        if (!user?.token) {

            setError(
                "Your login session is missing. Please login again."
            )

            return
        }


        setFindingLocation(true)

        try {

            const response =
                await fetch(
                    "http://localhost:8080/api/location/search",
                    {
                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/json",

                            Authorization:
                                `Bearer ${user.token}`
                        },

                        body:
                            JSON.stringify({
                                addressLine:
                                    addressForm.addressLine.trim(),

                                city:
                                    addressForm.city.trim(),

                                state:
                                    addressForm.state.trim(),

                                pincode:
                                    addressForm.pincode.trim()
                            })
                    }
                )


            const result =
                await getResponseMessage(
                    response
                )


            if (!response.ok) {

                throw new Error(result)
            }


            const data =
                JSON.parse(
                    result
                ) as LocationResult


            if (
                typeof data.latitude !== "number" ||
                typeof data.longitude !== "number"
            ) {

                throw new Error(
                    "Location coordinates were not returned."
                )
            }


            setLocation({
                latitude:
                data.latitude,

                longitude:
                data.longitude
            })


            setLocationConfirmed(false)


            setMessage(
                "Location found. Please verify the marker on the map and confirm it."
            )

        } catch (error) {

            console.error(
                "Customer address location error:",
                error
            )

            if (error instanceof Error) {

                setError(
                    error.message
                )

            } else {

                setError(
                    "Unable to find this location."
                )
            }

        } finally {

            setFindingLocation(false)
        }
    }


    /* =========================================
     * LOCATION CHANGE
     * ========================================= */

    const handleLocationChange = (
        latitude: number,
        longitude: number
    ) => {

        setLocation({
            latitude,
            longitude
        })

        setLocationConfirmed(false)

        setMessage("")
        setError("")
    }


    /* =========================================
     * CONFIRM LOCATION
     * ========================================= */

    const handleConfirmLocation = () => {

        if (!location) {

            setError(
                "Please find or select a location first."
            )

            return
        }

        setLocationConfirmed(true)

        setMessage(
            "Location confirmed."
        )

        setError("")
    }


    /* =========================================
     * SAVE ADDRESS
     * ========================================= */

    const handleSaveAddress = async () => {

        setMessage("")
        setError("")


        if (!addressForm.addressLine.trim()) {

            setError(
                "Address line is required."
            )

            return
        }


        if (!addressForm.city.trim()) {

            setError(
                "City is required."
            )

            return
        }


        if (!addressForm.state.trim()) {

            setError(
                "State is required."
            )

            return
        }


        if (
            !/^[1-9][0-9]{5}$/.test(
                addressForm.pincode.trim()
            )
        ) {

            setError(
                "Please enter a valid 6-digit Indian pincode."
            )

            return
        }


        if (!location) {

            setError(
                "Please find the location and select it on the map."
            )

            return
        }


        if (!locationConfirmed) {

            setError(
                "Please confirm the location on the map before saving."
            )

            return
        }


        if (!user?.token) {

            setError(
                "Your login session is missing. Please login again."
            )

            return
        }


        setSavingAddress(true)

        try {

            const isEditing =
                editingAddressId !== null


            const url =
                isEditing
                    ? `http://localhost:8080/api/customer/addresses/${editingAddressId}`
                    : "http://localhost:8080/api/customer/addresses"


            const method =
                isEditing
                    ? "PUT"
                    : "POST"


            /*
             * IMPORTANT:
             *
             * Backend REQUEST expects "isDefault".
             *
             * Backend RESPONSE returns "default".
             *
             * Therefore we continue sending isDefault here.
             */

            const response =
                await fetch(
                    url,
                    {
                        method,

                        headers: {
                            "Content-Type":
                                "application/json",

                            Authorization:
                                `Bearer ${user.token}`
                        },

                        body:
                            JSON.stringify({

                                addressLine:
                                    addressForm.addressLine.trim(),

                                city:
                                    addressForm.city.trim(),

                                state:
                                    addressForm.state.trim(),

                                pincode:
                                    addressForm.pincode.trim(),

                                latitude:
                                location.latitude,

                                longitude:
                                location.longitude,

                                isDefault:
                                    isEditing
                                        ? profile?.addresses.find(
                                        address =>
                                            address.addressId ===
                                            editingAddressId
                                    )?.default ?? false
                                        : (
                                            profile?.addresses.length ===
                                            0
                                        )
                            })
                    }
                )


            const result =
                await getResponseMessage(
                    response
                )


            if (!response.ok) {

                throw new Error(result)
            }


            if (!isEditing) {

                let savedAddress: Address | null =
                    null

                try {

                    savedAddress =
                        JSON.parse(
                            result
                        ) as Address

                } catch {

                    savedAddress = null
                }


                await loadProfile()


                if (
                    savedAddress &&
                    typeof savedAddress.addressId ===
                    "number" &&
                    onAddressSaved
                ) {

                    onAddressSaved(
                        savedAddress.addressId
                    )

                    return
                }


                setMessage(
                    "Address added successfully."
                )

            } else {

                await loadProfile()

                setMessage(
                    "Address updated successfully."
                )
            }


            setAddressForm({
                addressLine: "",
                city: "",
                state: "",
                pincode: ""
            })

            setLocation(null)

            setLocationConfirmed(false)

            setEditingAddressId(null)

            setShowAddressForm(false)

        } catch (error) {

            console.error(
                "Customer address save error:",
                error
            )

            if (error instanceof Error) {

                setError(
                    error.message
                )

            } else {

                setError(
                    "Unable to save the address."
                )
            }

        } finally {

            setSavingAddress(false)
        }
    }


    /* =========================================
     * DELETE ADDRESS
     * ========================================= */

    const handleDeleteAddress = async (
        addressId: number
    ) => {

        setMessage("")
        setError("")


        if (!user?.token) {

            setError(
                "Your login session is missing. Please login again."
            )

            return
        }


        const address =
            profile?.addresses.find(
                item =>
                    item.addressId ===
                    addressId
            )


        if (!address) {
            return
        }


        if (
            profile?.addresses.length === 1
        ) {

            setError(
                "You must keep at least one address in your profile."
            )

            return
        }


        /*
         * Backend response uses "default",
         * not "isDefault".
         */

        if (address.default) {

            setError(
                "Set another address as default before deleting this address."
            )

            return
        }


        try {

            const response =
                await fetch(
                    `http://localhost:8080/api/customer/addresses/${addressId}`,
                    {
                        method: "DELETE",

                        headers: {
                            Authorization:
                                `Bearer ${user.token}`
                        }
                    }
                )


            const result =
                await getResponseMessage(
                    response
                )


            if (!response.ok) {

                throw new Error(result)
            }


            await loadProfile()


            setMessage(
                "Address deleted successfully."
            )

        } catch (error) {

            console.error(
                "Customer address delete error:",
                error
            )

            if (error instanceof Error) {

                setError(
                    error.message
                )

            } else {

                setError(
                    "Unable to delete the address."
                )
            }
        }
    }


    /* =========================================
     * SET DEFAULT ADDRESS
     * ========================================= */

    const handleSetDefaultAddress = async (
        addressId: number
    ) => {

        console.log(
            "================================="
        )

        console.log(
            "SET DEFAULT BUTTON CLICKED"
        )

        console.log(
            "ADDRESS ID:",
            addressId
        )

        console.log(
            "================================="
        )

        setMessage("")
        setError("")


        if (!user?.token) {

            console.error(
                "No authentication token found."
            )

            setError(
                "Your login session is missing. Please login again."
            )

            return
        }


        try {

            console.log(
                "Sending request to backend..."
            )


            const response =
                await fetch(
                    `http://localhost:8080/api/customer/addresses/${addressId}/default`,
                    {
                        method: "PUT",

                        headers: {
                            "Content-Type":
                                "application/json",

                            Authorization:
                                `Bearer ${user.token}`
                        }
                    }
                )


            console.log(
                "Backend response status:",
                response.status
            )


            const result =
                await getResponseMessage(
                    response
                )


            console.log(
                "Backend response:",
                result
            )


            if (!response.ok) {

                throw new Error(
                    result
                )
            }


            /*
             * Reload profile so the frontend receives
             * the new "default": true/false values.
             */

            await loadProfile()


            console.log(
                "Default address updated successfully."
            )


            setMessage(
                "Default address updated successfully."
            )

        } catch (error) {

            console.error(
                "Set default address error:",
                error
            )

            if (error instanceof Error) {

                setError(
                    error.message
                )

            } else {

                setError(
                    "Unable to change the default address."
                )
            }
        }
    }


    /* =========================================
     * RENDER
     * ========================================= */

    return (

        <div className="customer-dashboard">

            {/* ==================================
             * HEADER
             * ================================== */}

            <header className="customer-header">

                <div
                    className="customer-logo"
                    onClick={onHome}
                    style={{
                        cursor: "pointer"
                    }}
                >
                    Local<span>Mart</span>
                </div>


                <div className="customer-search">

                    <span className="search-icon">
                        🔍
                    </span>

                    <input
                        type="text"
                        placeholder="Search products or stores..."
                    />

                </div>


                <div className="customer-location">

                    <span className="location-icon">
                        📍
                    </span>

                    <div>

                        <small>
                            Deliver to
                        </small>

                        <strong>
                            {
                                profile?.addresses.find(
                                    address =>
                                        address.default
                                )?.city ||
                                "Select address"
                            }
                        </strong>

                    </div>

                </div>


                <div className="customer-header-actions">

                    <button
                        className="header-icon-button"
                        title="Cart"
                        type="button"
                        onClick={onCart}
                    >
                        🛒
                    </button>


                    <button
                        className="customer-profile"
                        type="button"
                        onClick={() => {}}
                        title="My Profile"
                    >

                        <div className="profile-avatar">

                            {user?.email
                                ?.charAt(0)
                                .toUpperCase()}

                        </div>


                        <div className="profile-details">

                            <strong>
                                Customer
                            </strong>

                            <small>
                                {user?.email}
                            </small>

                        </div>

                    </button>


                    <button
                        className="logout-button"
                        onClick={logout}
                        type="button"
                    >
                        Logout
                    </button>

                </div>

            </header>


            {/* ==================================
             * NAVIGATION
             * ================================== */}

            <nav className="customer-navigation">

                <div className="navigation-inner">

                    <button
                        onClick={onHome}
                        type="button"
                    >
                        Home
                    </button>

                    <button
                        onClick={onStores}
                        type="button"
                    >
                        Stores
                    </button>

                    <button
                        onClick={onCategories}
                        type="button"
                    >
                        Categories
                    </button>

                    <button
                        onClick={onProducts}
                        type="button"
                    >
                        Products
                    </button>

                    <button
                        onClick={onOrders}
                        type="button"
                    >
                        Orders
                    </button>

                    <button
                        className="nav-active"
                        type="button"
                    >
                        My Profile
                    </button>

                </div>

            </nav>


            {/* ==================================
             * MAIN
             * ================================== */}

            <main className="customer-main">

                <section className="customer-section">

                    <div className="section-header">

                        <div>

                            <span className="section-label">
                                ACCOUNT
                            </span>

                            <h2>
                                My Profile
                            </h2>

                            <p>
                                Manage your personal details
                                and saved delivery addresses.
                            </p>

                        </div>

                    </div>


                    {/* ==================================
                     * LOADING
                     * ================================== */}

                    {loading && (

                        <p className="message">
                            Loading your profile...
                        </p>

                    )}


                    {!loading && (

                        <>

                            {/* ==================================
                             * PROFILE STATUS
                             * ================================== */}

                            <div
                                style={{
                                    marginBottom:
                                        "24px",

                                    padding:
                                        "16px 20px",

                                    borderRadius:
                                        "12px",

                                    border:
                                        "1px solid #e2e8e2",

                                    background:
                                        profile?.profileComplete
                                            ? "#f1f8f1"
                                            : "#fff8e8"
                                }}
                            >

                                <strong>

                                    {profile?.profileComplete
                                        ? "✓ Profile complete"
                                        : "⚠ Profile incomplete"}

                                </strong>


                                <p
                                    style={{
                                        margin:
                                            "6px 0 0",

                                        fontSize:
                                            "14px"
                                    }}
                                >

                                    {profile?.profileComplete
                                        ? "Your profile is ready for ordering."
                                        : "Complete your profile and add a default delivery address before placing an order."}

                                </p>

                            </div>


                            {/* ==================================
                             * PERSONAL INFORMATION
                             * ================================== */}

                            <div
                                style={{
                                    background:
                                        "#ffffff",

                                    border:
                                        "1px solid #e2e8e2",

                                    borderRadius:
                                        "16px",

                                    padding:
                                        "24px",

                                    marginBottom:
                                        "24px"
                                }}
                            >

                                <h3>
                                    Personal Information
                                </h3>


                                <div
                                    style={{
                                        display:
                                            "grid",

                                        gridTemplateColumns:
                                            "repeat(auto-fit, minmax(220px, 1fr))",

                                        gap:
                                            "18px",

                                        marginTop:
                                            "20px"
                                    }}
                                >

                                    <div>

                                        <label>
                                            First Name
                                        </label>

                                        <input
                                            className="input"
                                            type="text"
                                            value={
                                                firstName
                                            }
                                            onChange={e =>
                                                setFirstName(
                                                    e.target.value
                                                )
                                            }
                                            placeholder="Enter first name"
                                        />

                                    </div>


                                    <div>

                                        <label>
                                            Last Name
                                        </label>

                                        <input
                                            className="input"
                                            type="text"
                                            value={
                                                lastName
                                            }
                                            onChange={e =>
                                                setLastName(
                                                    e.target.value
                                                )
                                            }
                                            placeholder="Enter last name"
                                        />

                                    </div>


                                    <div>

                                        <label>
                                            Email
                                        </label>

                                        <input
                                            className="input"
                                            type="email"
                                            value={
                                                profile?.email ||
                                                ""
                                            }
                                            disabled
                                        />

                                    </div>


                                    <div>

                                        <label>
                                            Mobile Number
                                        </label>

                                        <input
                                            className="input"
                                            type="tel"
                                            maxLength={10}
                                            value={phone}
                                            onChange={e =>
                                                setPhone(
                                                    e.target.value.replace(
                                                        /\D/g,
                                                        ""
                                                    )
                                                )
                                            }
                                            placeholder="10-digit mobile number"
                                        />

                                    </div>

                                </div>


                                <button
                                    className="primary-button"
                                    type="button"
                                    onClick={
                                        handleSaveProfile
                                    }
                                    disabled={saving}
                                    style={{
                                        marginTop:
                                            "20px"
                                    }}
                                >

                                    {saving
                                        ? "Saving..."
                                        : "Save Profile"}

                                </button>

                            </div>


                            {/* ==================================
                             * SAVED ADDRESSES
                             * ================================== */}

                            <div
                                style={{
                                    background:
                                        "#ffffff",

                                    border:
                                        "1px solid #e2e8e2",

                                    borderRadius:
                                        "16px",

                                    padding:
                                        "24px"
                                }}
                            >

                                <div
                                    style={{
                                        display:
                                            "flex",

                                        justifyContent:
                                            "space-between",

                                        alignItems:
                                            "center",

                                        gap:
                                            "16px",

                                        flexWrap:
                                            "wrap"
                                    }}
                                >

                                    <div>

                                        <h3>
                                            Saved Addresses
                                        </h3>

                                        <p>
                                            Add and manage
                                            your delivery
                                            addresses.
                                        </p>

                                    </div>


                                    {!showAddressForm && (

                                        <button
                                            className="primary-button"
                                            type="button"
                                            onClick={
                                                handleAddAddress
                                            }
                                        >
                                            + Add New Address
                                        </button>

                                    )}

                                </div>


                                {/* ==================================
                                 * ADDRESS FORM
                                 * ================================== */}

                                {showAddressForm && (

                                    <div
                                        style={{
                                            marginTop:
                                                "24px",

                                            padding:
                                                "22px",

                                            border:
                                                "1px solid #dce5dc",

                                            borderRadius:
                                                "14px",

                                            background:
                                                "#fafcf9"
                                        }}
                                    >

                                        <div
                                            style={{
                                                display:
                                                    "flex",

                                                justifyContent:
                                                    "space-between",

                                                alignItems:
                                                    "center",

                                                gap:
                                                    "12px",

                                                marginBottom:
                                                    "20px"
                                            }}
                                        >

                                            <h3>

                                                {editingAddressId !== null
                                                    ? "Edit Address"
                                                    : "Add New Address"}

                                            </h3>


                                            <button
                                                type="button"
                                                onClick={
                                                    resetAddressForm
                                                }
                                                style={{
                                                    border:
                                                        "none",

                                                    background:
                                                        "transparent",

                                                    cursor:
                                                        "pointer",

                                                    fontSize:
                                                        "14px"
                                                }}
                                            >
                                                Cancel
                                            </button>

                                        </div>


                                        <div
                                            style={{
                                                display:
                                                    "grid",

                                                gridTemplateColumns:
                                                    "repeat(auto-fit, minmax(220px, 1fr))",

                                                gap:
                                                    "18px"
                                            }}
                                        >

                                            <div
                                                style={{
                                                    gridColumn:
                                                        "1 / -1"
                                                }}
                                            >

                                                <label>
                                                    Address Line
                                                </label>

                                                <input
                                                    className="input"
                                                    type="text"
                                                    value={
                                                        addressForm.addressLine
                                                    }
                                                    onChange={e =>
                                                        handleAddressFieldChange(
                                                            "addressLine",
                                                            e.target.value
                                                        )
                                                    }
                                                    placeholder="Enter your complete address"
                                                />

                                            </div>


                                            <div>

                                                <label>
                                                    City
                                                </label>

                                                <input
                                                    className="input"
                                                    type="text"
                                                    value={
                                                        addressForm.city
                                                    }
                                                    onChange={e =>
                                                        handleAddressFieldChange(
                                                            "city",
                                                            e.target.value
                                                        )
                                                    }
                                                    placeholder="Enter city"
                                                />

                                            </div>


                                            <div>

                                                <label>
                                                    State
                                                </label>

                                                <input
                                                    className="input"
                                                    type="text"
                                                    value={
                                                        addressForm.state
                                                    }
                                                    onChange={e =>
                                                        handleAddressFieldChange(
                                                            "state",
                                                            e.target.value
                                                        )
                                                    }
                                                    placeholder="Enter state"
                                                />

                                            </div>


                                            <div>

                                                <label>
                                                    Pincode
                                                </label>

                                                <input
                                                    className="input"
                                                    type="text"
                                                    maxLength={6}
                                                    value={
                                                        addressForm.pincode
                                                    }
                                                    onChange={e =>
                                                        handleAddressFieldChange(
                                                            "pincode",
                                                            e.target.value.replace(
                                                                /\D/g,
                                                                ""
                                                            )
                                                        )
                                                    }
                                                    placeholder="6-digit pincode"
                                                />

                                            </div>

                                        </div>


                                        {/* ==================================
                                         * FIND LOCATION
                                         * ================================== */}

                                        <button
                                            className="secondary-button"
                                            type="button"
                                            onClick={
                                                handleFindLocation
                                            }
                                            disabled={
                                                findingLocation
                                            }
                                            style={{
                                                marginTop:
                                                    "20px"
                                            }}
                                        >

                                            {findingLocation
                                                ? "Finding Location..."
                                                : "📍 Find Location"}

                                        </button>


                                        {/* ==================================
                                         * LOCATION PICKER
                                         * ================================== */}

                                        {location && (

                                            <div
                                                style={{
                                                    marginTop:
                                                        "20px"
                                                }}
                                            >

                                                <LocationPicker
                                                    initialLatitude={
                                                        location.latitude
                                                    }

                                                    initialLongitude={
                                                        location.longitude
                                                    }

                                                    onLocationChange={
                                                        handleLocationChange
                                                    }

                                                    onConfirm={
                                                        handleConfirmLocation
                                                    }
                                                />


                                                {locationConfirmed && (

                                                    <p
                                                        style={{
                                                            marginTop:
                                                                "12px",

                                                            padding:
                                                                "12px 16px",

                                                            borderRadius:
                                                                "10px",

                                                            background:
                                                                "#f1f8f1",

                                                            border:
                                                                "1px solid #c9dfd0",

                                                            color:
                                                                "#237a57"
                                                        }}
                                                    >

                                                        ✓ Location confirmed.
                                                        You can now save this address.

                                                    </p>

                                                )}

                                            </div>

                                        )}


                                        {/* ==================================
                                         * SAVE / CANCEL
                                         * ================================== */}

                                        <div
                                            style={{
                                                display:
                                                    "flex",

                                                gap:
                                                    "12px",

                                                flexWrap:
                                                    "wrap",

                                                marginTop:
                                                    "20px"
                                            }}
                                        >

                                            <button
                                                className="primary-button"
                                                type="button"
                                                onClick={
                                                    handleSaveAddress
                                                }
                                                disabled={
                                                    savingAddress
                                                }
                                            >

                                                {savingAddress
                                                    ? "Saving Address..."
                                                    : editingAddressId !== null
                                                        ? "Update Address"
                                                        : "Save Address"}

                                            </button>


                                            <button
                                                className="secondary-button"
                                                type="button"
                                                onClick={
                                                    resetAddressForm
                                                }
                                            >
                                                Cancel
                                            </button>

                                        </div>

                                    </div>

                                )}


                                {/* ==================================
                                 * NO ADDRESSES
                                 * ================================== */}

                                {profile &&
                                    profile.addresses.length === 0 &&
                                    !showAddressForm && (

                                        <div
                                            style={{
                                                marginTop:
                                                    "20px",

                                                padding:
                                                    "24px",

                                                textAlign:
                                                    "center",

                                                border:
                                                    "1px dashed #cfd8cf",

                                                borderRadius:
                                                    "12px"
                                            }}
                                        >

                                            <strong>
                                                No saved addresses
                                            </strong>

                                            <p>
                                                Add your first
                                                delivery address
                                                to complete
                                                your profile.
                                            </p>


                                            <button
                                                className="primary-button"
                                                type="button"
                                                onClick={
                                                    handleAddAddress
                                                }
                                            >
                                                + Add Address
                                            </button>

                                        </div>

                                    )}


                                {/* ==================================
                                 * ADDRESS LIST
                                 * ================================== */}

                                {profile &&
                                    profile.addresses.length > 0 && (

                                        <div
                                            style={{
                                                display:
                                                    "grid",

                                                gap:
                                                    "16px",

                                                marginTop:
                                                    "20px"
                                            }}
                                        >

                                            {profile.addresses.map(
                                                address => (

                                                    <div
                                                        key={
                                                            address.addressId
                                                        }
                                                        style={{
                                                            padding:
                                                                "18px",

                                                            border:
                                                                address.default
                                                                    ? "2px solid #5b8c5a"
                                                                    : "1px solid #e2e8e2",

                                                            borderRadius:
                                                                "12px"
                                                        }}
                                                    >

                                                        <div
                                                            style={{
                                                                display:
                                                                    "flex",

                                                                justifyContent:
                                                                    "space-between",

                                                                alignItems:
                                                                    "center",

                                                                gap:
                                                                    "12px",

                                                                flexWrap:
                                                                    "wrap"
                                                            }}
                                                        >

                                                            <strong>

                                                                {address.default
                                                                    ? "Default Address"
                                                                    : "Saved Address"}

                                                            </strong>


                                                            {address.default && (

                                                                <span
                                                                    style={{
                                                                        fontSize:
                                                                            "13px",

                                                                        fontWeight:
                                                                            600,

                                                                        color:
                                                                            "#237a57"
                                                                    }}
                                                                >

                                                                    ✓ Default

                                                                </span>

                                                            )}

                                                        </div>


                                                        <p
                                                            style={{
                                                                lineHeight:
                                                                    "1.6"
                                                            }}
                                                        >

                                                            {
                                                                address.addressLine
                                                            }

                                                            <br />

                                                            {
                                                                address.city
                                                            }

                                                            ,{" "}

                                                            {
                                                                address.state
                                                            }

                                                            {" "}

                                                            -{" "}

                                                            {
                                                                address.pincode
                                                            }

                                                        </p>


                                                        <div
                                                            style={{
                                                                display:
                                                                    "flex",

                                                                gap:
                                                                    "10px",

                                                                flexWrap:
                                                                    "wrap",

                                                                marginTop:
                                                                    "14px"
                                                            }}
                                                        >

                                                            {!address.default && (

                                                                <button
                                                                    className="secondary-button"
                                                                    type="button"
                                                                    onClick={() => {

                                                                        console.log(
                                                                            "BUTTON CLICK:",
                                                                            address.addressId
                                                                        )

                                                                        handleSetDefaultAddress(
                                                                            address.addressId
                                                                        )
                                                                    }}
                                                                >
                                                                    Set as Default
                                                                </button>

                                                            )}


                                                            <button
                                                                className="secondary-button"
                                                                type="button"
                                                                onClick={() =>
                                                                    handleEditAddress(
                                                                        address
                                                                    )
                                                                }
                                                            >
                                                                Edit
                                                            </button>


                                                            {!address.default && (

                                                                <button
                                                                    className="secondary-button"
                                                                    type="button"
                                                                    onClick={() =>
                                                                        handleDeleteAddress(
                                                                            address.addressId
                                                                        )
                                                                    }
                                                                >
                                                                    Delete
                                                                </button>

                                                            )}

                                                        </div>

                                                    </div>

                                                )
                                            )}

                                        </div>

                                    )}

                            </div>

                        </>
                    )}


                    {/* ==================================
                     * SUCCESS MESSAGE
                     * ================================== */}

                    {message && (

                        <p className="message">
                            {message}
                        </p>

                    )}


                    {/* ==================================
                     * ERROR MESSAGE
                     * ================================== */}

                    {error && (

                        <p className="message">
                            {error}
                        </p>

                    )}

                </section>

            </main>


            {/* ==================================
             * FOOTER
             * ================================== */}

            <footer className="customer-footer">

                <div className="footer-content">

                    <div>

                        <div className="customer-logo">
                            Local<span>Mart</span>
                        </div>

                        <p>
                            Shop local. Live local.
                        </p>

                    </div>


                    <div className="footer-links">

                        <button
                            onClick={onStores}
                            type="button"
                        >
                            Stores
                        </button>

                        <button
                            onClick={onCategories}
                            type="button"
                        >
                            Categories
                        </button>

                        <button
                            onClick={onProducts}
                            type="button"
                        >
                            Products
                        </button>

                        <button
                            onClick={onOrders}
                            type="button"
                        >
                            Orders
                        </button>

                        <button
                            onClick={onCart}
                            type="button"
                        >
                            Cart
                        </button>

                    </div>

                </div>

            </footer>

        </div>
    )
}


export default CustomerProfile