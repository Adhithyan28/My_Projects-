import React, { useState } from "react";
import { useAuth } from "../context/AuthContext";
import "./ChangePassword.css";

interface ChangePasswordProps {
    onPasswordChanged: () => void;
}

const ChangePassword: React.FC<ChangePasswordProps> = ({
                                                           onPasswordChanged
                                                       }) => {

    const { user, login } = useAuth();

    const [currentPassword, setCurrentPassword] =
        useState("");

    const [newPassword, setNewPassword] =
        useState("");

    const [confirmPassword, setConfirmPassword] =
        useState("");

    const [showCurrentPassword, setShowCurrentPassword] =
        useState(false);

    const [showNewPassword, setShowNewPassword] =
        useState(false);

    const [showConfirmPassword, setShowConfirmPassword] =
        useState(false);

    const [error, setError] =
        useState("");

    const [success, setSuccess] =
        useState("");

    const [loading, setLoading] =
        useState(false);


    const handleChangePassword = async (
        event: React.FormEvent
    ) => {

        event.preventDefault();

        setError("");
        setSuccess("");


        if (!currentPassword.trim()) {

            setError(
                "Current password is required."
            );

            return;
        }


        if (!newPassword.trim()) {

            setError(
                "New password is required."
            );

            return;
        }


        if (!confirmPassword.trim()) {

            setError(
                "Please confirm your new password."
            );

            return;
        }


        if (newPassword !== confirmPassword) {

            setError(
                "New password and confirm password do not match."
            );

            return;
        }


        if (currentPassword === newPassword) {

            setError(
                "New password must be different from the current password."
            );

            return;
        }


        if (!user?.token) {

            setError(
                "Authentication session is missing. Please login again."
            );

            return;
        }


        setLoading(true);


        try {

            const response =
                await fetch(
                    "http://localhost:8080/api/users/change-password",
                    {
                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/json",

                            Authorization:
                                `Bearer ${user.token}`
                        },

                        body: JSON.stringify({
                            currentPassword,
                            newPassword
                        })
                    }
                );


            const data =
                await response.json()
                    .catch(() => null);


            if (!response.ok) {

                setError(
                    data?.message ||
                    data?.error ||
                    "Failed to change password."
                );

                return;
            }


            /*
             * The backend has already changed the password.
             *
             * We keep the existing JWT/session and only
             * update the frontend authentication state so
             * App.tsx will know that password rotation is
             * complete.
             */
            login({
                ...user,
                passwordChangeRequired: false
            });


            setSuccess(
                "Password changed successfully."
            );


            setCurrentPassword("");
            setNewPassword("");
            setConfirmPassword("");


            /*
             * Give the success message a moment to be visible
             * before returning to the normal application flow.
             */
            setTimeout(() => {
                onPasswordChanged();
            }, 800);

        } catch (error) {

            console.error(
                "Password change failed:",
                error
            );

            setError(
                "Unable to connect to the server. Please try again."
            );

        } finally {

            setLoading(false);
        }
    };


    return (
        <div className="change-password">

            <h1>Change Password</h1>

            <p className="change-password-description">
                Your password has expired.
                Please create a new password to continue.
            </p>


            <form
                className="change-password-form"
                onSubmit={handleChangePassword}
            >

                <label className="change-password-label">
                    Current password
                </label>

                <div className="change-password-input-container">

                    <input
                        type={
                            showCurrentPassword
                                ? "text"
                                : "password"
                        }

                        className="change-password-input"

                        placeholder="Current password"

                        value={currentPassword}

                        onChange={(event) =>
                            setCurrentPassword(
                                event.target.value
                            )
                        }

                        disabled={loading}
                    />

                    <button
                        type="button"
                        className="change-password-show-button"
                        onClick={() =>
                            setShowCurrentPassword(
                                !showCurrentPassword
                            )
                        }
                        disabled={loading}
                    >
                        {showCurrentPassword
                            ? "Hide"
                            : "Show"}
                    </button>

                </div>


                <label className="change-password-label">
                    New password
                </label>

                <div className="change-password-input-container">

                    <input
                        type={
                            showNewPassword
                                ? "text"
                                : "password"
                        }

                        className="change-password-input"

                        placeholder="New password"

                        value={newPassword}

                        onChange={(event) =>
                            setNewPassword(
                                event.target.value
                            )
                        }

                        disabled={loading}
                    />

                    <button
                        type="button"
                        className="change-password-show-button"
                        onClick={() =>
                            setShowNewPassword(
                                !showNewPassword
                            )
                        }
                        disabled={loading}
                    >
                        {showNewPassword
                            ? "Hide"
                            : "Show"}
                    </button>

                </div>


                <label className="change-password-label">
                    Confirm new password
                </label>

                <div className="change-password-input-container">

                    <input
                        type={
                            showConfirmPassword
                                ? "text"
                                : "password"
                        }

                        className="change-password-input"

                        placeholder="Confirm new password"

                        value={confirmPassword}

                        onChange={(event) =>
                            setConfirmPassword(
                                event.target.value
                            )
                        }

                        disabled={loading}
                    />

                    <button
                        type="button"
                        className="change-password-show-button"
                        onClick={() =>
                            setShowConfirmPassword(
                                !showConfirmPassword
                            )
                        }
                        disabled={loading}
                    >
                        {showConfirmPassword
                            ? "Hide"
                            : "Show"}
                    </button>

                </div>


                {error && (
                    <p className="change-password-error">
                        {error}
                    </p>
                )}


                {success && (
                    <p className="change-password-success">
                        {success}
                    </p>
                )}


                <button
                    type="submit"
                    className="change-password-button"
                    disabled={loading}
                >
                    {loading
                        ? "Changing password..."
                        : "Change Password"}
                </button>

            </form>

        </div>
    );
};

export default ChangePassword;