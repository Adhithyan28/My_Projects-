# LocalMart — Order Management

## 1. Overview

The Order Management Module is responsible for managing the lifecycle of a customer's purchase after the shopping cart moves into checkout.

An order is the central business object that connects:

```text id="9z6n2m"
Customer
    |
    v
Order
    |
    +--> Store
    |
    +--> Products
    |
    +--> Payment
    |
    +--> Delivery Partner
    |
    v
Customer Address
```

The order module coordinates the transition from a customer's selected cart items into an actual purchase and then through fulfillment and delivery.

The overall lifecycle is:

```text id="q3r8x1"
Cart
  |
  v
Checkout
  |
  v
Order
  |
  v
Payment
  |
  v
Store Processing
  |
  v
Delivery Partner
  |
  v
Customer
```

---

# 2. Purpose of the Order Module

The Order Management Module is responsible for the business lifecycle of an order.

Its responsibilities include:

* Creating orders
* Associating orders with customers
* Associating orders with stores
* Creating order items
* Maintaining order totals
* Associating delivery addresses
* Managing order status
* Supporting payment information
* Providing orders to store owners
* Providing delivery orders to delivery partners
* Allowing customers to view their orders
* Supporting the transition from store fulfillment to delivery

The order module is therefore one of the central modules of LocalMart.

---

# 3. Order Management Architecture

The basic architecture follows the standard LocalMart backend design:

```text id="n6c2v8"
React Frontend
      |
      | HTTP
      v
OrderController
      |
      v
OrderService
      |
      +------------------+
      |                  |
      v                  v
OrderRepository    OrderItemRepository
      |                  |
      +---------+--------+
                |
                v
            PostgreSQL
```

The order module also interacts with:

```text id="k4p9w2"
             ORDER
                |
      +---------+---------+
      |         |         |
      v         v         v
   Customer   Store     Payment
                         |
                         v
                      Delivery
                         |
                         v
                    Delivery Partner
```

---

# 4. Order as a Business Entity

The backend contains an `Order` entity representing a purchase.

An order is different from a cart.

```text id="h8x3m5"
Cart
 |
 | Customer's current selection
 v
Checkout
 |
 v
Order
 |
 | Recorded purchase
 v
Fulfillment
```

The cart can change repeatedly.

The order represents the purchase after the order-creation process.

---

# 5. Order and Customer

Every customer order belongs to the customer who placed it.

Conceptually:

```text id="f2k7q9"
Customer
   |
   +--> Order 1
   |
   +--> Order 2
   |
   +--> Order 3
```

The customer's authenticated identity provides the basis for accessing their orders.

```text id="r5w1c8"
JWT
 |
 v
Authenticated User
 |
 v
Customer
 |
 v
Customer Orders
```

This relationship is important for data ownership and authorization.

---

# 6. Order and Store

Orders also have store context.

The relationship can be represented as:

```text id="p3n7x6"
Customer
    |
    v
  Order
    |
    v
  Store
    |
    v
Store Owner
```

This allows the store owner to process orders associated with their store.

---

# 7. Order and Products

An order contains order items.

The relationship is:

```text id="v8m2q4"
Order
 |
 +--> OrderItem
 |      |
 |      +--> Product
 |
 +--> OrderItem
        |
        +--> Product
```

An order can therefore contain multiple purchased products.

---

# 8. Order Item

The backend contains:

```text id="7k4s2p"
OrderItem
```

An order item represents a product included in an order.

Conceptually:

```text id="m1x8v3"
OrderItem
 |
 +--> Product
 |
 +--> Quantity
 |
 +--> Price / Amount
```

The exact fields depend on the current entity implementation.

The purpose is to represent the product-level portion of an order.

---

# 9. Why Order Items Are Required

An order may contain multiple products.

For example:

```text id="d9q2w6"
Order
 |
 +--> Milk × 2
 |
 +--> Bread × 1
 |
 +--> Eggs × 1
```

A separate `OrderItem` representation allows each purchased product to be represented independently.

This creates a one-to-many relationship:

```text id="n7x3m9"
Order
  |
  +--> OrderItem
  +--> OrderItem
  +--> OrderItem
```

---

# 10. Cart to Order

The order creation process starts with the cart.

```text id="j5r8k2"
Cart
 |
 +--> Product A × 2
 +--> Product B × 1
 |
 v
Checkout
 |
 v
Order
 |
 +--> OrderItem A × 2
 +--> OrderItem B × 1
```

The cart provides the customer's selected products.

The order module converts the purchase information into an order representation.

---

# 11. Order Creation Flow

The high-level order creation flow is:

```text id="c6m1v4"
Customer
   |
   v
Cart
   |
   v
Checkout
   |
   v
Create Order Request
   |
   v
OrderController
   |
   v
OrderService
   |
   +--> Validate Customer
   |
   +--> Validate Cart
   |
   +--> Validate Products
   |
   +--> Calculate Order Information
   |
   +--> Create Order
   |
   +--> Create Order Items
   |
   v
PostgreSQL
```

The exact validation and calculation rules are determined by the current `OrderService`.

---

# 12. Create Order Request

The backend contains:

```text id="8y2p7n"
CreateOrderRequest
```

This DTO represents the request data required when creating an order.

The request follows the normal DTO flow:

```text id="q7w3m1"
JSON
 |
 v
CreateOrderRequest
 |
 v
OrderController
 |
 v
OrderService
```

This separates the HTTP request representation from the persistence entity.

---

# 13. Order Item Request

The backend also contains:

```text id="v3k9x5"
OrderItemRequest
```

This represents order-item information supplied during the order creation process.

Conceptually:

```text id="u8m2p6"
CreateOrderRequest
 |
 +--> OrderItemRequest
 |      |
 |      +--> Product
 |      +--> Quantity
 |
 +--> OrderItemRequest
        |
        +--> Product
        +--> Quantity
```

---

# 14. Order Controller

`OrderController` acts as the HTTP/API boundary for order-related operations.

Its responsibilities include:

* Receiving order requests
* Receiving delivery-fee requests
* Calling `OrderService`
* Returning order-related responses

The general structure is:

```text id="r4w8c2"
HTTP Request
     |
     v
OrderController
     |
     v
OrderService
```

The controller should delegate business decisions to the service layer.

---

# 15. Order Service

`OrderService` is the primary business-logic layer for orders.

It coordinates information from several parts of LocalMart.

Conceptually:

```text id="x2m7q5"
                 OrderService
                      |
        +-------------+-------------+
        |             |             |
        v             v             v
      Cart         Product        Address
        |             |             |
        +-------------+-------------+
                      |
                      v
                    Order
```

It can also interact with payment and delivery-related services.

---

# 16. Order Repository

`OrderRepository` provides persistence access for orders.

```text id="p8n3w6"
OrderService
     |
     v
OrderRepository
     |
     v
PostgreSQL
```

The repository abstracts database operations from the order business logic.

---

# 17. Order Item Repository

`OrderItemRepository` handles persistence of individual order items.

```text id="f5x1m8"
OrderService
     |
     v
OrderItemRepository
     |
     v
PostgreSQL
```

Together:

```text id="w2q7c4"
OrderRepository
      +
OrderItemRepository
      |
      v
Order Data
```

---

# 18. Customer Address and Order

An order requires a delivery destination.

The customer selects an address during checkout.

```text id="k8v4p2"
Customer
   |
   v
Saved Addresses
   |
   v
Selected Address
   |
   v
Order
```

This allows the order to retain the delivery context required for fulfillment.

---

# 19. Delivery Fee

The order system includes delivery-fee functionality.

The customer-side request uses:

```text id="c1n7x9"
storeId
addressId
```

Conceptually:

```text id="t4m8q2"
Store
  |
  v
Store Location
        +
Customer Address
  |
  v
Customer Location
        |
        v
Road Distance
        |
        v
Delivery Fee
```

The delivery-fee calculation connects order processing with the location subsystem.

---

# 20. Delivery Fee Request

The backend contains:

```text id="w6r3k1"
DeliveryFeeRequest
```

This DTO represents the information required for delivery-fee calculation.

The request flow is:

```text id="p9x2m7"
React
 |
 v
DeliveryFeeRequest
 |
 v
OrderController
 |
 v
OrderService
 |
 v
Location / Distance Services
 |
 v
Delivery Fee
```

The delivery-fee result can then be used during checkout.

---

# 21. Location and Delivery Calculation

The order module does not itself need to perform raw geographic calculations.

Instead, it can rely on location-related services.

The architecture is:

```text id="q5m8v2"
OrderService
     |
     v
RoadDistanceService
     |
     v
OSRM
     |
     v
Road Distance
```

The store and customer coordinates provide the geographic inputs.

```text id="m3x7p9"
Store Coordinates
       +
Customer Coordinates
       |
       v
OSRM
       |
       v
Road Distance / Duration
```

---

# 22. Order Total

The final order amount can involve multiple components.

Conceptually:

```text id="f8k2w5"
Product Price × Quantity
          |
          v
     Item Amounts
          |
          v
    Order Subtotal
          |
          +--> Delivery Fee
          |
          v
      Order Total
```

The exact calculation is determined by the current order implementation.

The backend should remain authoritative for important monetary calculations.

---

# 23. Order and Payment

Payment is associated with the order lifecycle.

The relationship is:

```text id="v6p3n8"
Order
 |
 v
Order Total
 |
 v
Payment
 |
 v
Payment Gateway
```

LocalMart contains a `Payment` entity and a `RazorpayService`.

The payment architecture is documented separately in:

```text id="q8r1m4"
docs/10-payment-system.md
```

---

# 24. Payment and Order State

Payment and order are related but represent different concepts.

```text id="c5m9x2"
Payment
 |
 +--> Payment information/status

Order
 |
 +--> Purchase information/status
```

A payment result should not be confused with the complete fulfillment state of an order.

For example:

```text id="w7k3p5"
Payment
   |
   v
Successful
   |
   v
Order
   |
   v
Fulfillment
   |
   v
Delivery
```

---

# 25. Order Status

An order moves through operational states.

The delivery-related statuses used in LocalMart include:

```text id="r2x8m4"
READY_FOR_PICKUP
       |
       v
ACCEPTED
       |
       v
PICKED_UP
       |
       v
OUT_FOR_DELIVERY
       |
       v
DELIVERED
```

These statuses describe the operational delivery progression of an order.

The exact complete order-status model may contain additional states depending on the implementation.

---

# 26. READY_FOR_PICKUP

`READY_FOR_PICKUP` represents the stage where the order is ready for collection from the store by a delivery partner.

Conceptually:

```text id="g5q2n7"
Customer Order
      |
      v
Store Processing
      |
      v
READY_FOR_PICKUP
```

At this point, the delivery process can move toward delivery-partner assignment/acceptance.

---

# 27. ACCEPTED

`ACCEPTED` represents the stage where a delivery partner has accepted the delivery.

```text id="x7m3c8"
READY_FOR_PICKUP
       |
       v
Delivery Partner
       |
       v
ACCEPTED
```

The delivery partner then becomes responsible for the next stages of the delivery process.

---

# 28. PICKED_UP

`PICKED_UP` indicates that the delivery partner has collected the order from the store.

```text id="q1v8m4"
Store
  |
  v
Order
  |
  v
Delivery Partner
  |
  v
PICKED_UP
```

The order is now physically with the delivery partner.

---

# 29. OUT_FOR_DELIVERY

`OUT_FOR_DELIVERY` represents the stage where the delivery partner is travelling toward the customer.

```text id="k4x7p2"
Store
  |
  v
Delivery Partner
  |
  v
Customer Address
       |
       v
OUT_FOR_DELIVERY
```

Location functionality can participate in this part of the system.

---

# 30. DELIVERED

`DELIVERED` represents the completion of the delivery lifecycle.

```text id="m8q3v6"
OUT_FOR_DELIVERY
       |
       v
Customer
       |
       v
DELIVERED
```

At this stage the order has completed the delivery progression.

---

# 31. Store Owner Order Processing

The store owner needs access to orders associated with their store.

LocalMart contains:

```text id="v3n7p1"
StoreOwnerOrderController
```

for store-owner order operations.

The relationship is:

```text id="f6m2x9"
Customer
   |
   v
Order
   |
   v
Store
   |
   v
Store Owner
```

This allows the store side to process relevant orders without exposing unrelated customer orders.

---

# 32. Store Owner Order Flow

The store-side flow can be represented as:

```text id="h7q4m1"
Customer
   |
   v
Order Created
   |
   v
Store
   |
   v
Store Owner
   |
   v
Process Order
   |
   v
READY_FOR_PICKUP
```

Once the order reaches the pickup stage, the delivery workflow can continue.

---

# 33. Delivery Partner Order Flow

Delivery partners interact with orders through delivery-specific endpoints.

The general flow is:

```text id="r5x8n3"
Order
   |
   v
READY_FOR_PICKUP
   |
   v
Available Deliveries
   |
   v
Delivery Partner
   |
   v
Accept
   |
   v
ACCEPTED
   |
   v
PICKED_UP
   |
   v
OUT_FOR_DELIVERY
   |
   v
DELIVERED
```

The delivery-partner workflow is documented separately in:

```text id="b2k6v9"
docs/flows/20-delivery-partner-flow.md
```

---

# 34. Customer Order View

Customers can access their orders through the customer Orders page.

The general flow is:

```text id="m9p3x7"
Customer
   |
   v
Orders Page
   |
   | HTTP
   v
OrderController
   |
   v
OrderService
   |
   v
OrderRepository
   |
   v
PostgreSQL
   |
   v
Order Response
   |
   v
React
```

This allows the customer interface to display the current order information.

---

# 35. Delivery Order Response

The backend contains:

```text id="x6q2m8"
DeliveryOrderResponse
```

This DTO represents order information relevant to delivery-partner operations.

This illustrates an important architectural principle:

```text id="j4v7p1"
Same Order
     |
     +--> Customer representation
     |
     +--> Store-owner representation
     |
     +--> Delivery-partner representation
```

Different roles can receive different views of the same underlying order.

---

# 36. Role-Specific Order Access

Order operations are role-dependent.

| Role             | Order Interaction                            |
| ---------------- | -------------------------------------------- |
| CUSTOMER         | Create/view own orders                       |
| STORE_OWNER      | Process orders associated with their store   |
| DELIVERY_PARTNER | Accept and deliver assigned/available orders |
| ADMIN            | Administrative oversight where supported     |

This separation is important for authorization and data ownership.

---

# 37. Order Ownership

A customer should only access their own customer orders.

A store owner should only access orders belonging to their store.

A delivery partner should only access delivery orders available or assigned to them according to the delivery workflow.

Conceptually:

```text id="e8m3q6"
                 ORDER
                   |
       +-----------+-----------+
       |           |           |
       v           v           v
   Customer      Store      Delivery
    Owner        Owner       Partner
```

Each role receives access based on its relationship with the order.

---

# 38. Order Security

Order operations are protected by the application's authentication and authorization architecture.

The general request flow is:

```text id="t7w2p9"
HTTP Request
     |
     v
JWT
     |
     v
Spring Security
     |
     v
Authenticated User
     |
     v
OrderController
     |
     v
OrderService
```

The service layer should additionally apply business-level ownership checks where required.

---

# 39. Order Data Integrity

Order data is important because it represents a purchase.

The backend therefore needs to preserve relationships between:

```text id="q8m3x5"
Order
 |
 +--> Customer
 |
 +--> Store
 |
 +--> Order Items
 |
 +--> Products
 |
 +--> Address
 |
 +--> Payment
```

Incorrect relationships could result in serious business-data problems.

---

# 40. Product Price and Order Data

Products can change over time.

An order, however, represents a historical purchase.

Therefore the order system should distinguish current product information from the information relevant to the completed purchase.

Conceptually:

```text id="p4x7m2"
Current Product
      |
      v
Checkout
      |
      v
Order Item
      |
      v
Historical Purchase Information
```

The exact snapshotting behavior depends on the current `OrderItem` implementation.

The order should not blindly depend on future changes to the product catalog when representing an already-created purchase.

---

# 41. Order and Cart Separation

The cart and order have different responsibilities.

| Cart                    | Order                        |
| ----------------------- | ---------------------------- |
| Current selection       | Recorded purchase            |
| Frequently modified     | Enters fulfillment lifecycle |
| Customer shopping state | Business transaction         |
| Before checkout         | After order creation         |
| Contains cart items     | Contains order items         |

Relationship:

```text id="n6v2c8"
Cart
 |
 v
Checkout
 |
 v
Order
```

---

# 42. Order and Delivery Separation

The Order Module represents the purchase.

The Delivery Module represents fulfillment.

```text id="u4p8m3"
Order
 |
 v
Delivery
 |
 v
Delivery Partner
```

The order contains the business context required for delivery, while delivery-specific behavior is handled by delivery functionality.

---

# 43. Order and Payment Separation

Similarly, the Order Module and Payment Module have separate responsibilities.

```text id="y2q6n9"
Order
 |
 +--> Purchase information
 |
 v
Payment
 |
 +--> Payment processing information
```

The payment provider processes payment.

LocalMart maintains its own order and payment information.

---

# 44. Order Database Structure

The conceptual database relationship is:

```text id="m7x3p8"
users
  |
  +------> orders
              |
              +------> order_items
              |             |
              |             v
              |          products
              |
              +------> payments
              |
              +------> address
```

Store information also participates in the order relationship:

```text id="c8v2m5"
store_details
      |
      v
    orders
```

The exact foreign-key structure is defined by the current entity mappings and database schema.

---

# 45. Order Request/Response Architecture

A typical order request follows:

```text id="w4p9n2"
React
  |
  | JSON
  v
OrderController
  |
  v
CreateOrderRequest
  |
  v
OrderService
  |
  v
Repositories
  |
  v
PostgreSQL
```

The response travels back:

```text id="g6m2x8"
PostgreSQL
   |
   v
Repositories
   |
   v
OrderService
   |
   v
Response DTO
   |
   v
OrderController
   |
   v
JSON
   |
   v
React
```

---

# 46. Order Lifecycle

The complete high-level lifecycle can be represented as:

```text id="j3q8m5"
Cart
 |
 v
Checkout
 |
 v
Order Created
 |
 v
Payment
 |
 v
Store Processing
 |
 v
READY_FOR_PICKUP
 |
 v
Delivery Partner Accepts
 |
 v
ACCEPTED
 |
 v
PICKED_UP
 |
 v
OUT_FOR_DELIVERY
 |
 v
DELIVERED
```

The exact placement of payment confirmation and additional order states depends on the implemented payment/order workflow.

---

# 47. Complete Order Architecture

The order system connects nearly every major LocalMart module:

```text id="b8m4x2"
                         CUSTOMER
                            |
                            v
                           CART
                            |
                            v
                         CHECKOUT
                            |
             +--------------+--------------+
             |                             |
             v                             v
       DELIVERY FEE                     PAYMENT
             |                             |
             +--------------+--------------+
                            |
                            v
                          ORDER
                            |
                  +---------+---------+
                  |                   |
                  v                   v
               STORE              DELIVERY
                  |                   |
                  v                   v
            Store Owner        Delivery Partner
                  |                   |
                  +---------+---------+
                            |
                            v
                         CUSTOMER
```

---

# 48. Order Module Backend Components

The major order-related backend components include:

### Controllers

```text id="r9m3v7"
OrderController
StoreOwnerOrderController
```

### Services

```text id="q4x8p2"
OrderService
```

### DTOs

```text id="m7c2n5"
CreateOrderRequest
OrderItemRequest
DeliveryFeeRequest
DeliveryOrderResponse
```

### Entities

```text id="x3p8v6"
Order
OrderItem
Payment
```

### Repositories

```text id="f5m2q9"
OrderRepository
OrderItemRepository
PaymentRepository
```

The order system also interacts with:

```text id="n8v4x1"
CartService
ProductService
CustomerAddressService
RoadDistanceService
RazorpayService
```

where required by the implementation.

---

# 49. Order Module and Other Modules

The order module sits near the center of LocalMart's business architecture.

```text id="z6q3m8"
                 ORDER MANAGEMENT
                        |
       +----------------+----------------+
       |                |                |
       v                v                v
      CART           PAYMENT          STORE
       |                |                |
       +----------------+----------------+
                        |
                        v
                    DELIVERY
                        |
                        v
                     CUSTOMER
```

This is why order management is one of the most important business workflows in the application.

---

# 50. Business Rules

The order system must enforce important business rules.

Examples include:

* Customer must be authenticated.
* Customer must own the order being accessed.
* Products must be valid before creating an order.
* Cart information must be valid before checkout.
* Quantities must be valid.
* Store relationships must be valid.
* Delivery information must correspond to the selected destination.
* Payment information must be associated with the appropriate purchase.
* Order status transitions must follow valid business rules.
* Store owners must only process their store's orders.
* Delivery partners must only operate on orders permitted by the delivery workflow.

The exact rules are defined by the current service implementation.

---

# 51. Error Handling

Order operations can fail for several reasons.

Examples include:

```text id="w2m8q4"
Invalid order request
Customer not found
Product not found
Cart not found
Invalid quantity
Invalid address
Invalid store
Payment failure
Invalid order status transition
Unauthorized order access
```

The application's centralized exception-handling mechanism can convert service exceptions into appropriate HTTP responses.

---

# 52. Order Security Principles

### Authentication

Only authenticated users should perform protected order operations.

### Customer ownership

Customers should only access their own orders.

### Store ownership

Store owners should only access orders associated with their stores.

### Delivery authorization

Delivery partners should only access orders allowed by their delivery workflow.

### Server-side calculations

Important totals and delivery charges should be validated/calculated by the backend.

### State validation

Order status changes should follow the permitted lifecycle.

---

# 53. End-to-End Customer Order Journey

From the customer's perspective:

```text id="p6x2m8"
Browse Products
      |
      v
Add to Cart
      |
      v
Review Cart
      |
      v
Select Address
      |
      v
Calculate Delivery Fee
      |
      v
Checkout
      |
      v
Payment
      |
      v
Create Order
      |
      v
Store Processing
      |
      v
READY_FOR_PICKUP
      |
      v
Delivery Partner
      |
      v
ACCEPTED
      |
      v
PICKED_UP
      |
      v
OUT_FOR_DELIVERY
      |
      v
DELIVERED
```

---

# 54. End-to-End Store Owner Journey

From the store owner's perspective:

```text id="y7m3q8"
Store Owner
     |
     v
Own Store
     |
     v
Receive Order
     |
     v
Review Order
     |
     v
Prepare Order
     |
     v
READY_FOR_PICKUP
     |
     v
Delivery Partner
```

The store owner therefore controls the store-side preparation stage.

---

# 55. End-to-End Delivery Partner Journey

From the delivery partner's perspective:

```text id="c4x8m2"
Available Delivery
       |
       v
Accept Order
       |
       v
ACCEPTED
       |
       v
Travel to Store
       |
       v
PICKED_UP
       |
       v
Travel to Customer
       |
       v
OUT_FOR_DELIVERY
       |
       v
DELIVERED
```

This workflow is connected to the order status maintained by the backend.

---

# 56. Order Module Design Principles

### Order is the central transaction

The order connects shopping, payment, store fulfillment, and delivery.

### Cart and order are separate

A cart is a temporary shopping state; an order represents a purchase.

### Role-specific access

Customers, store owners, and delivery partners interact with the same order differently.

### Backend authority

Important order data and calculations are controlled by the backend.

### Persistent order history

Orders are persisted so that purchase information can be retrieved after checkout.

### State-driven fulfillment

The order status represents its operational progress.

### Modular responsibilities

Payment and delivery are integrated with orders but remain separate modules.

---

# 57. Complete Order Data Flow

The complete backend flow can be summarized as:

```text id="v9q2m6"
Customer
   |
   v
Cart
   |
   v
OrderController
   |
   v
OrderService
   |
   +--> ProductRepository
   |
   +--> CartRepository
   |
   +--> CartItemRepository
   |
   +--> AddressRepository
   |
   +--> OrderRepository
   |
   +--> OrderItemRepository
   |
   +--> Payment
   |
   v
PostgreSQL
   |
   v
Order Created
   |
   +--> Store Owner
   |
   +--> Delivery Partner
   |
   v
Customer
```

---

# 58. Summary

The Order Management Module is the central transaction-management component of LocalMart.

Its primary lifecycle is:

```text id="k5m8x3"
Cart
  |
  v
Checkout
  |
  v
Order
  |
  v
Payment
  |
  v
Store Processing
  |
  v
READY_FOR_PICKUP
  |
  v
ACCEPTED
  |
  v
PICKED_UP
  |
  v
OUT_FOR_DELIVERY
  |
  v
DELIVERED
```

The order connects the major LocalMart modules:

```text id="f8q2m7"
                   CUSTOMER
                      |
                      v
                    CART
                      |
                      v
                  CHECKOUT
                      |
          +-----------+-----------+
          |                       |
          v                       v
      DELIVERY FEE             PAYMENT
          |                       |
          +-----------+-----------+
                      |
                      v
                    ORDER
                      |
             +--------+--------+
             |                 |
             v                 v
           STORE           DELIVERY
             |                 |
             v                 v
       STORE OWNER      DELIVERY PARTNER
             |                 |
             +--------+--------+
                      |
                      v
                   CUSTOMER
```

At the backend level:

```text id="m3x7p9"
React
  |
  v
OrderController
  |
  v
OrderService
  |
  +--> OrderRepository
  +--> OrderItemRepository
  +--> CartRepository
  +--> CartItemRepository
  +--> ProductRepository
  +--> AddressRepository
  |
  v
PostgreSQL
```

The Order Module therefore acts as the central bridge between **shopping, payment, store fulfillment, and delivery**, transforming a customer's cart selection into a persistent transaction that moves through the LocalMart fulfillment lifecycle.
