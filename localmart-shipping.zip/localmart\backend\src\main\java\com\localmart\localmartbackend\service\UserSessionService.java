
        package com.localmart.localmartbackend.service;

import com.localmart.localmartbackend.entity.UserSession;
import com.localmart.localmartbackend.repository.UserSessionRepository;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

@Service
public class UserSessionService {

    private static final long SESSION_EXPIRATION_HOURS = 24;

    private final UserSessionRepository userSessionRepository;

    public UserSessionService(
            UserSessionRepository userSessionRepository) {

        this.userSessionRepository =
                userSessionRepository;
    }

    // ============================================================
    // CREATE SESSION
    // ============================================================

    @Transactional
    public UserSession createSession(Long userId) {

        LocalDateTime now =
                LocalDateTime.now();

        // --------------------------------------------------------
        // CHECK EXISTING SESSION
        // --------------------------------------------------------

        Optional<UserSession> existingSession =
                userSessionRepository.findByUserId(userId);

        if (existingSession.isPresent()) {

            UserSession session =
                    existingSession.get();

            // ----------------------------------------------------
            // EXPIRED SESSION
            // ----------------------------------------------------

            if (session.getExpiresAt() != null &&
                    !session.getExpiresAt().isAfter(now)) {

                userSessionRepository.delete(session);

                userSessionRepository.flush();

            } else {

                throw new AccountAlreadyInUseException();
            }
        }

        // --------------------------------------------------------
        // CREATE NEW SESSION
        // --------------------------------------------------------

        UserSession session =
                new UserSession();

        session.setUserId(userId);

        session.setSessionId(
                UUID.randomUUID().toString()
        );

        session.setCreatedAt(now);

        session.setExpiresAt(
                now.plusHours(
                        SESSION_EXPIRATION_HOURS
                )
        );

        session.setLastActivity(now);

        try {

            return userSessionRepository.saveAndFlush(
                    session
            );

        } catch (DataIntegrityViolationException exception) {

            /*
             * This protects against two login requests arriving
             * at almost exactly the same time.
             *
             * The database UNIQUE constraint on user_id ensures
             * that only one session can be created.
             */

            throw new AccountAlreadyInUseException();
        }
    }

    // ============================================================
    // VALIDATE SESSION
    // ============================================================

    @Transactional
    public boolean isSessionValid(
            Long userId,
            String sessionId) {

        if (userId == null ||
                sessionId == null ||
                sessionId.isBlank()) {

            return false;
        }

        Optional<UserSession> optionalSession =
                userSessionRepository.findByUserId(userId);

        if (optionalSession.isEmpty()) {
            return false;
        }

        UserSession session =
                optionalSession.get();

        // --------------------------------------------------------
        // SESSION ID MUST MATCH
        // --------------------------------------------------------

        if (!sessionId.equals(
                session.getSessionId())) {

            return false;
        }

        LocalDateTime now =
                LocalDateTime.now();

        // --------------------------------------------------------
        // SESSION EXPIRED
        // --------------------------------------------------------

        if (session.getExpiresAt() == null ||
                !session.getExpiresAt().isAfter(now)) {

            userSessionRepository.delete(session);

            return false;
        }

        // --------------------------------------------------------
        // UPDATE LAST ACTIVITY
        // --------------------------------------------------------

        session.setLastActivity(now);

        userSessionRepository.save(session);

        return true;
    }

    // ============================================================
    // GET SESSION
    // ============================================================

    public Optional<UserSession> getSession(
            Long userId) {

        return userSessionRepository
                .findByUserId(userId);
    }

    // ============================================================
    // LOGOUT
    // ============================================================

    @Transactional
    public void logout(
            String sessionId) {

        if (sessionId == null ||
                sessionId.isBlank()) {

            System.out.println(
                    "USER SESSION SERVICE -> LOGOUT SKIPPED: SESSION ID EMPTY"
            );

            return;
        }

        System.out.println(
                "USER SESSION SERVICE -> DELETING SESSION ID = "
                        + sessionId
        );

        userSessionRepository
                .deleteBySessionId(sessionId);

        System.out.println(
                "USER SESSION SERVICE -> SESSION DELETE REQUEST COMPLETED"
        );
    }

    // ============================================================
    // LOGOUT BY USER
    // ============================================================

    @Transactional
    public void logoutByUserId(
            Long userId) {

        if (userId == null) {

            System.out.println(
                    "USER SESSION SERVICE -> LOGOUT BY USER SKIPPED: USER ID EMPTY"
            );

            return;
        }

        System.out.println(
                "USER SESSION SERVICE -> DELETING SESSION FOR USER ID = "
                        + userId
        );

        userSessionRepository
                .deleteByUserId(userId);

        System.out.println(
                "USER SESSION SERVICE -> USER SESSION DELETE REQUEST COMPLETED"
        );
    }

    // ============================================================
    // ACCOUNT ALREADY IN USE
    // ============================================================

    public static class AccountAlreadyInUseException
            extends RuntimeException {

        public AccountAlreadyInUseException() {

            super(
                    "This account is currently being used on another device. Please log out from that device before trying again."
            );
        }
    }
}
