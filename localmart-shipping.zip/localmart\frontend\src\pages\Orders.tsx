import { useEffect, useState } from "react"
import { useAuth } from "../context/AuthContext"

interface BackendOrderItem {
    orderItemId: number
    productId: number
    productName: string
    unit: string
    quantity: number
    unitPrice: number
    totalPrice: number
}

interface BackendOrder {
    orderId: number
    orderNumber: string
    customerId: number
    storeId: number
    subtotal: number
    deliveryFee: number
    total: number
    paymentMethod: string
    paymentStatus: string
    orderStatus:
        | "PLACED"
        | "CONFIRMED"
        | "PREPARING"
        | "READY_FOR_PICKUP"
        | "OUT_FOR_DELIVERY"
        | "DELIVERED"
        | "CANCELLED"
    deliveryName: string
    deliveryPhone: string
    deliveryAddress: string
    deliveryCity: string
    deliveryPincode: string
    createdAt: string
    updatedAt: string
    items: BackendOrderItem[]
}

interface BackendStore {
    storeId: number
    storeName: string
}

interface OrderItem {
    productId: number
    productName: string
    category: string
    price: number
    quantity: number
    unit: string
    icon: string
}

interface Order {
    id: number
    orderNumber: string
    orderDate: string
    storeId: number
    storeName: string
    items: OrderItem[]
    subtotal: number
    deliveryFee: number
    total: number
    status:
        | "PLACED"
        | "CONFIRMED"
        | "PREPARING"
        | "READY_FOR_PICKUP"
        | "OUT_FOR_DELIVERY"
        | "DELIVERED"
        | "CANCELLED"
}

interface OrdersProps {
    onHome: () => void
    onStores: () => void
    onCategories: () => void
    onProducts: () => void
    onCart: () => void
}

const API_BASE_URL = "http://localhost:8080"

const statusLabels: Record<Order["status"], string> = {
    PLACED: "Placed",
    CONFIRMED: "Confirmed",
    PREPARING: "Preparing",
    READY_FOR_PICKUP: "Ready for Pickup",
    OUT_FOR_DELIVERY: "Out for Delivery",
    DELIVERED: "Delivered",
    CANCELLED: "Cancelled",
}

function Orders({
                    onHome,
                    onStores,
                    onCategories,
                    onProducts,
                    onCart,
                }: OrdersProps) {

    const { user, logout } = useAuth()

    const [orders, setOrders] = useState<Order[]>([])
    const [loading, setLoading] = useState(true)
    const [error, setError] = useState("")


    /* =========================================
     * FETCH ORDERS
     * ========================================= */

    useEffect(() => {

        const fetchOrders = async () => {

            if (!user?.token) {

                setOrders([])
                setLoading(false)

                return
            }

            try {

                setLoading(true)
                setError("")


                /* =================================
                 * FETCH CUSTOMER ORDERS
                 * ================================= */

                const response = await fetch(
                    `${API_BASE_URL}/api/orders`,
                    {
                        method: "GET",
                        headers: {
                            Authorization:
                                `Bearer ${user.token}`,
                        },
                    }
                )


                if (!response.ok) {

                    throw new Error(
                        `Failed to load orders (${response.status})`
                    )
                }


                const backendOrders: BackendOrder[] =
                    await response.json()


                /* =================================
                 * FETCH STORES ONCE
                 *
                 * The previous code fetched
                 * /api/stores once for every storeId.
                 *
                 * We only need one request because
                 * the endpoint already returns all stores.
                 * ================================= */

                const storeMap = new Map<number, string>()


                try {

                    const storeResponse = await fetch(
                        `${API_BASE_URL}/api/stores`,
                        {
                            method: "GET",
                            headers: {
                                Authorization:
                                    `Bearer ${user.token}`,
                            },
                        }
                    )


                    if (storeResponse.ok) {

                        const stores: BackendStore[] =
                            await storeResponse.json()


                        stores.forEach((store) => {

                            storeMap.set(
                                store.storeId,
                                store.storeName
                            )

                        })
                    }

                } catch {

                    /*
                     * Store name is optional for rendering.
                     *
                     * If the store request fails, the order
                     * will display "Store #ID".
                     */

                }


                /* =================================
                 * MAP BACKEND ORDERS
                 * ================================= */

                const mappedOrders: Order[] =
                    backendOrders.map(
                        (backendOrder) => ({

                            id:
                            backendOrder.orderId,


                            orderNumber:
                            backendOrder.orderNumber,


                            orderDate:
                                new Date(
                                    backendOrder.createdAt
                                ).toLocaleString(
                                    "en-IN",
                                    {
                                        day: "2-digit",
                                        month: "short",
                                        year: "numeric",
                                        hour: "2-digit",
                                        minute: "2-digit",
                                        hour12: true,
                                    }
                                ),


                            storeId:
                            backendOrder.storeId,


                            storeName:
                                storeMap.get(
                                    backendOrder.storeId
                                ) ||
                                `Store #${backendOrder.storeId}`,


                            /* =============================
                             * ORDER ITEMS
                             * ============================= */

                            items:
                                backendOrder.items.map(
                                    (item) => ({

                                        productId:
                                        item.productId,


                                        productName:
                                        item.productName,


                                        category:
                                            "",


                                        price:
                                            Number(
                                                item.unitPrice
                                            ),


                                        quantity:
                                        item.quantity,


                                        unit:
                                        item.unit,


                                        icon:
                                            "🛒",
                                    })
                                ),


                            subtotal:
                                Number(
                                    backendOrder.subtotal
                                ),


                            deliveryFee:
                                Number(
                                    backendOrder.deliveryFee
                                ),


                            total:
                                Number(
                                    backendOrder.total
                                ),


                            status:
                            backendOrder.orderStatus,

                        })
                    )


                setOrders(mappedOrders)

            } catch (err) {

                console.error(
                    "Failed to fetch customer orders:",
                    err
                )


                setError(
                    "Unable to load your orders. Please try again."
                )

            } finally {

                setLoading(false)

            }
        }


        fetchOrders()

    }, [user?.token])


    /* =========================================
     * STATUS CSS CLASS
     * ========================================= */

    const getStatusClass = (
        status: Order["status"]
    ) => {

        return `order-status order-status-${status.toLowerCase()}`

    }


    /* =========================================
     * RENDER
     * ========================================= */

    return (

        <div className="customer-dashboard">


            {/* ==================================
             * HEADER
             * ================================== */}

            <header className="customer-header">

                <button
                    className="customer-logo"
                    type="button"
                    onClick={onHome}
                >

                    <span className="logo-icon">
                        🛒
                    </span>

                    <span>
                        LocalMart
                    </span>

                </button>


                <div className="customer-search">

                    <span className="search-icon">
                        ⌕
                    </span>

                    <input
                        type="text"
                        placeholder="Search products, stores..."
                    />

                </div>


                <div className="customer-location">

                    <span>
                        📍
                    </span>

                    <div>

                        <small>
                            Deliver to
                        </small>

                        <strong>
                            Chennai
                        </strong>

                    </div>

                </div>


                <button
                    className="customer-cart-button"
                    type="button"
                    onClick={onCart}
                >
                    🛒
                </button>


                <div className="customer-profile">

                    <div className="profile-avatar">

                        {user?.email
                            ?.charAt(0)
                            .toUpperCase() || "U"}

                    </div>


                    <div className="profile-info">

                        <span>
                            Customer
                        </span>

                        <strong>
                            {user?.email || "User"}
                        </strong>

                    </div>

                </div>


                <button
                    className="customer-logout"
                    type="button"
                    onClick={logout}
                >
                    Logout
                </button>

            </header>


            {/* ==================================
             * NAVIGATION
             * ================================== */}

            <nav className="customer-nav">

                <button
                    type="button"
                    onClick={onHome}
                >
                    Home
                </button>


                <button
                    type="button"
                    onClick={onStores}
                >
                    Stores
                </button>




                <button
                    type="button"
                    onClick={onProducts}
                >
                    Products
                </button>


                <button
                    type="button"
                    className="nav-active"
                >
                    Orders
                </button>

            </nav>


            {/* ==================================
             * MAIN
             * ================================== */}

            <main className="orders-main">

                <div className="orders-container">


                    {/* =================================
                     * PAGE HEADING
                     * ================================= */}

                    <section className="orders-heading">

                        <div>

                            <p className="section-eyebrow">
                                YOUR SHOPPING
                            </p>

                            <h1>
                                My Orders
                            </h1>

                            <p>
                                Track and manage your LocalMart orders.
                            </p>

                        </div>

                    </section>


                    {/* =================================
                     * ORDER COUNT
                     * ================================= */}

                    <div className="orders-title">

                        <div>

                            <h2>
                                Order History
                            </h2>

                            <p>

                                {loading
                                    ? "Loading orders..."
                                    : `${orders.length} order${
                                        orders.length !== 1
                                            ? "s"
                                            : ""
                                    } found`}

                            </p>

                        </div>

                    </div>


                    {/* =================================
                     * LOADING
                     * ================================= */}

                    {loading ? (

                        <section className="orders-empty">

                            <div className="orders-empty-icon">
                                📦
                            </div>

                            <h2>
                                Loading your orders...
                            </h2>

                            <p>
                                Please wait while we fetch your order history.
                            </p>

                        </section>

                    ) : error ? (

                        /* =================================
                         * ERROR
                         * ================================= */

                        <section className="orders-empty">

                            <div className="orders-empty-icon">
                                ⚠️
                            </div>

                            <h2>
                                Unable to load orders
                            </h2>

                            <p>
                                {error}
                            </p>

                            <button
                                type="button"
                                onClick={() =>
                                    window.location.reload()
                                }
                            >
                                Try Again
                            </button>

                        </section>

                    ) : orders.length === 0 ? (

                        /* =================================
                         * NO ORDERS
                         * ================================= */

                        <section className="orders-empty">

                            <div className="orders-empty-icon">
                                📦
                            </div>

                            <h2>
                                No orders yet
                            </h2>

                            <p>
                                Your completed and active orders
                                will appear here.
                            </p>

                            <button
                                type="button"
                                onClick={onProducts}
                            >
                                Start Shopping
                            </button>

                        </section>

                    ) : (

                        /* =================================
                         * ORDERS LIST
                         * ================================= */

                        <section className="orders-list">

                            {orders.map((order) => (

                                <article
                                    className="order-card"
                                    key={order.id}
                                >


                                    {/* =================================
                                     * ORDER HEADER
                                     * ================================= */}

                                    <div className="order-card-header">

                                        <div>

                                            <span className="order-label">
                                                Order
                                            </span>

                                            <h3>
                                                {order.orderNumber}
                                            </h3>

                                            <p>
                                                {order.orderDate}
                                            </p>

                                        </div>


                                        <span
                                            className={getStatusClass(
                                                order.status
                                            )}
                                        >

                                            {statusLabels[
                                                    order.status
                                                    ] ||
                                                order.status}

                                        </span>

                                    </div>


                                    {/* =================================
                                     * STORE
                                     * ================================= */}

                                    <div className="order-store">

                                        <div className="order-store-icon">
                                            🏪
                                        </div>

                                        <div>

                                            <span>
                                                Ordered from
                                            </span>

                                            <strong>
                                                {order.storeName}
                                            </strong>

                                        </div>

                                    </div>


                                    {/* =================================
                                     * ITEMS
                                     * ================================= */}

                                    <div className="order-items">

                                        {order.items.map(
                                            (item) => (

                                                <div
                                                    className="order-item"
                                                    key={
                                                        item.productId
                                                    }
                                                >

                                                    <div className="order-item-image">

                                                        {item.icon}

                                                    </div>


                                                    <div className="order-item-details">

                                                        <strong>

                                                            {
                                                                item.productName
                                                            }

                                                        </strong>

                                                        <span>

                                                            {
                                                                item.unit
                                                            }

                                                        </span>

                                                    </div>


                                                    <div className="order-item-quantity">

                                                        ×{" "}
                                                        {
                                                            item.quantity
                                                        }

                                                    </div>


                                                    <strong className="order-item-price">

                                                        ₹
                                                        {(
                                                            item.price *
                                                            item.quantity
                                                        ).toFixed(0)}

                                                    </strong>

                                                </div>

                                            )
                                        )}

                                    </div>


                                    {/* =================================
                                     * TOTAL
                                     * ================================= */}

                                    <div className="order-card-footer">

                                        <div className="order-total-details">


                                            <div>

                                                <span>
                                                    Subtotal
                                                </span>

                                                <strong>

                                                    ₹
                                                    {order.subtotal.toFixed(
                                                        0
                                                    )}

                                                </strong>

                                            </div>


                                            <div>

                                                <span>
                                                    Delivery Fee
                                                </span>

                                                <strong>

                                                    ₹
                                                    {order.deliveryFee.toFixed(
                                                        0
                                                    )}

                                                </strong>

                                            </div>


                                        </div>


                                        <div className="order-total">

                                            <span>
                                                Total
                                            </span>

                                            <strong>

                                                ₹
                                                {order.total.toFixed(
                                                    0
                                                )}

                                            </strong>

                                        </div>

                                    </div>

                                </article>

                            ))}

                        </section>

                    )}

                </div>

            </main>


            {/* ==================================
             * FOOTER
             * ================================== */}

            <footer className="customer-footer">

                <div className="footer-content">


                    <div className="footer-brand">

                        <div className="footer-logo">
                            🛒 LocalMart
                        </div>

                        <p>
                            Your local stores,
                            delivered to your door.
                        </p>

                    </div>


                    <div className="footer-links">

                        <button
                            type="button"
                            onClick={onHome}
                        >
                            Home
                        </button>


                        <button
                            type="button"
                            onClick={onStores}
                        >
                            Stores
                        </button>


                        <button
                            type="button"
                            onClick={onCategories}
                        >
                            Categories
                        </button>


                        <button
                            type="button"
                            onClick={onProducts}
                        >
                            Products
                        </button>


                        <button
                            type="button"
                            className="footer-active"
                        >
                            Orders
                        </button>


                        <button
                            type="button"
                            onClick={onCart}
                        >
                            Cart
                        </button>

                    </div>

                </div>


                <div className="footer-bottom">

                    <span>
                        © 2026 LocalMart
                    </span>

                    <span>
                        Shop local. Live local.
                    </span>

                </div>

            </footer>

        </div>
    )
}

export default Orders