package com.localmart.localmartbackend.controller;

import com.localmart.localmartbackend.dto.StoreResponse;
import com.localmart.localmartbackend.service.StoreService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/stores")
@CrossOrigin(origins = {
        "http://localhost:5174",
        "http://localhost:5175"
})
public class StoreController {

    private final StoreService storeService;

    public StoreController(StoreService storeService) {
        this.storeService = storeService;
    }

    @GetMapping
    public ResponseEntity<List<StoreResponse>> getAllStores() {

        return ResponseEntity.ok(
                storeService.getAllStores()
        );
    }
}