package com.localmart.localmartbackend.service;

import com.localmart.localmartbackend.dto.CustomerAddressRequest;
import com.localmart.localmartbackend.dto.CustomerProfileResponse;
import com.localmart.localmartbackend.entity.Address;
import com.localmart.localmartbackend.entity.Role;
import com.localmart.localmartbackend.entity.User;
import com.localmart.localmartbackend.repository.AddressRepository;
import com.localmart.localmartbackend.repository.RoleRepository;
import com.localmart.localmartbackend.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
public class CustomerAddressService {

    private static final int ROLE_CUSTOMER = 1;

    private static final Pattern PINCODE_PATTERN =
            Pattern.compile("^[1-9][0-9]{5}$");

    private final AddressRepository addressRepository;
    private final UserRepository userRepository;
    private final RoleRepository roleRepository;

    public CustomerAddressService(
            AddressRepository addressRepository,
            UserRepository userRepository,
            RoleRepository roleRepository) {

        this.addressRepository = addressRepository;
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
    }

    @Transactional(readOnly = true)
    public List<CustomerProfileResponse.AddressInfo> getAddresses(
            Long userId) {

        getCustomer(userId);

        return addressRepository.findByUserId(userId)
                .stream()
                .map(this::convertAddress)
                .collect(Collectors.toList());
    }

    @Transactional
    public CustomerProfileResponse.AddressInfo addAddress(
            Long userId,
            CustomerAddressRequest request) {

        getCustomer(userId);

        validateAddressRequest(request);

        List<Address> existingAddresses =
                addressRepository.findByUserId(userId);

        boolean makeDefault =
                existingAddresses.isEmpty()
                        || Boolean.TRUE.equals(
                        request.getIsDefault()
                );

        if (makeDefault) {
            clearDefaultAddresses(existingAddresses);
        }

        Address address = new Address();

        address.setUserId(userId);

        address.setAddressLine(
                request.getAddressLine().trim()
        );

        address.setCity(
                request.getCity().trim()
        );

        address.setState(
                request.getState().trim()
        );

        address.setPincode(
                request.getPincode().trim()
        );

        address.setLatitude(
                request.getLatitude()
        );

        address.setLongitude(
                request.getLongitude()
        );

        address.setIsDefault(makeDefault);

        Address savedAddress =
                addressRepository.save(address);

        return convertAddress(savedAddress);
    }

    @Transactional
    public CustomerProfileResponse.AddressInfo updateAddress(
            Long userId,
            Long addressId,
            CustomerAddressRequest request) {

        getCustomer(userId);

        validateAddressRequest(request);

        Address address =
                getCustomerAddress(
                        userId,
                        addressId
                );

        List<Address> existingAddresses =
                addressRepository.findByUserId(userId);

        boolean currentlyDefault =
                Boolean.TRUE.equals(
                        address.getIsDefault()
                );

        boolean requestedDefault =
                Boolean.TRUE.equals(
                        request.getIsDefault()
                );

        if (requestedDefault) {

            clearDefaultAddresses(existingAddresses);

            address.setIsDefault(true);

        } else if (currentlyDefault) {

            throw new RuntimeException(
                    "The default address cannot be changed to a non-default address. Set another address as default first."
            );

        } else {

            address.setIsDefault(false);
        }

        address.setAddressLine(
                request.getAddressLine().trim()
        );

        address.setCity(
                request.getCity().trim()
        );

        address.setState(
                request.getState().trim()
        );

        address.setPincode(
                request.getPincode().trim()
        );

        address.setLatitude(
                request.getLatitude()
        );

        address.setLongitude(
                request.getLongitude()
        );

        Address savedAddress =
                addressRepository.save(address);

        return convertAddress(savedAddress);
    }

    @Transactional
    public void deleteAddress(
            Long userId,
            Long addressId) {

        getCustomer(userId);

        Address address =
                getCustomerAddress(
                        userId,
                        addressId
                );

        List<Address> existingAddresses =
                addressRepository.findByUserId(userId);

        if (existingAddresses.size() == 1) {

            throw new RuntimeException(
                    "You must keep at least one address in your profile."
            );
        }

        boolean deletingDefault =
                Boolean.TRUE.equals(
                        address.getIsDefault()
                );

        addressRepository.delete(address);

        if (deletingDefault) {

            List<Address> remainingAddresses =
                    addressRepository.findByUserId(userId);

            if (remainingAddresses.isEmpty()) {

                throw new RuntimeException(
                        "Customer must have at least one address."
                );
            }

            Address newDefault =
                    remainingAddresses.get(0);

            newDefault.setIsDefault(true);

            addressRepository.save(newDefault);
        }
    }

    /*
     * ============================================================
     * SET DEFAULT ADDRESS
     * ============================================================
     *
     * The selected address becomes the ONLY default address.
     *
     * Example:
     *
     * Address 1 -> true
     * Address 2 -> false
     * Address 3 -> false
     *
     * User selects Address 3:
     *
     * Address 1 -> false
     * Address 2 -> false
     * Address 3 -> true
     *
     * Everything happens inside one transaction.
     */
    @Transactional
    public CustomerProfileResponse.AddressInfo setDefaultAddress(
            Long userId,
            Long addressId) {

        getCustomer(userId);

        /*
         * First verify that the address exists
         * and belongs to this customer.
         */
        Address selectedAddress =
                getCustomerAddress(
                        userId,
                        addressId
                );

        /*
         * Get all addresses belonging to this customer.
         */
        List<Address> existingAddresses =
                addressRepository.findByUserId(userId);

        /*
         * Explicitly set ONLY the selected address
         * as default.
         */
        for (Address address : existingAddresses) {

            if (address.getAddressId().equals(addressId)) {

                address.setIsDefault(true);

            } else {

                address.setIsDefault(false);
            }
        }

        /*
         * Save all addresses together.
         */
        List<Address> savedAddresses =
                addressRepository.saveAll(
                        existingAddresses
                );

        /*
         * Find the selected address from the saved list.
         */
        Address savedSelectedAddress =
                savedAddresses.stream()
                        .filter(address ->
                                address.getAddressId()
                                        .equals(addressId)
                        )
                        .findFirst()
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Unable to save default address"
                                )
                        );

        return convertAddress(
                savedSelectedAddress
        );
    }

    private Address getCustomerAddress(
            Long userId,
            Long addressId) {

        if (addressId == null) {

            throw new RuntimeException(
                    "Address ID is required"
            );
        }

        Address address =
                addressRepository.findById(addressId)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Address not found"
                                )
                        );

        if (!userId.equals(address.getUserId())) {

            throw new RuntimeException(
                    "You are not allowed to access this address"
            );
        }

        return address;
    }

    private void clearDefaultAddresses(
            List<Address> addresses) {

        for (Address address : addresses) {

            if (Boolean.TRUE.equals(
                    address.getIsDefault())) {

                address.setIsDefault(false);
            }
        }

        addressRepository.saveAll(addresses);
    }

    private void validateAddressRequest(
            CustomerAddressRequest request) {

        if (request == null) {

            throw new RuntimeException(
                    "Address request is required"
            );
        }

        if (isBlank(request.getAddressLine())) {

            throw new RuntimeException(
                    "Address line is required"
            );
        }

        if (isBlank(request.getCity())) {

            throw new RuntimeException(
                    "City is required"
            );
        }

        if (isBlank(request.getState())) {

            throw new RuntimeException(
                    "State is required"
            );
        }

        if (isBlank(request.getPincode())) {

            throw new RuntimeException(
                    "Pincode is required"
            );
        }

        String pincode =
                request.getPincode().trim();

        if (!PINCODE_PATTERN.matcher(pincode).matches()) {

            throw new RuntimeException(
                    "Please enter a valid 6-digit Indian pincode"
            );
        }

        validateCoordinates(
                request.getLatitude(),
                request.getLongitude()
        );
    }

    private void validateCoordinates(
            BigDecimal latitude,
            BigDecimal longitude) {

        if (latitude == null ||
                longitude == null) {

            throw new RuntimeException(
                    "Location coordinates are required. Please confirm the location on the map."
            );
        }

        if (latitude.compareTo(
                BigDecimal.valueOf(-90)
        ) < 0 ||
                latitude.compareTo(
                        BigDecimal.valueOf(90)
                ) > 0) {

            throw new RuntimeException(
                    "Invalid latitude"
            );
        }

        if (longitude.compareTo(
                BigDecimal.valueOf(-180)
        ) < 0 ||
                longitude.compareTo(
                        BigDecimal.valueOf(180)
                ) > 0) {

            throw new RuntimeException(
                    "Invalid longitude"
            );
        }
    }

    private User getCustomer(Long userId) {

        if (userId == null) {

            throw new RuntimeException(
                    "User is not authenticated"
            );
        }

        User user =
                userRepository.findById(userId)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Customer account not found"
                                )
                        );

        Role role =
                roleRepository.findByUserId(userId)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "User role not found"
                                )
                        );

        if (role.getRole() != ROLE_CUSTOMER) {

            throw new RuntimeException(
                    "Only customers can manage addresses"
            );
        }

        return user;
    }

    private CustomerProfileResponse.AddressInfo
    convertAddress(Address address) {

        CustomerProfileResponse.AddressInfo info =
                new CustomerProfileResponse.AddressInfo();

        info.setAddressId(
                address.getAddressId()
        );

        info.setAddressLine(
                address.getAddressLine()
        );

        info.setCity(
                address.getCity()
        );

        info.setState(
                address.getState()
        );

        info.setPincode(
                address.getPincode()
        );

        info.setLatitude(
                address.getLatitude()
        );

        info.setLongitude(
                address.getLongitude()
        );

        info.setDefault(
                Boolean.TRUE.equals(
                        address.getIsDefault()
                )
        );

        return info;
    }

    private boolean isBlank(String value) {

        return value == null ||
                value.trim().isEmpty();
    }
}