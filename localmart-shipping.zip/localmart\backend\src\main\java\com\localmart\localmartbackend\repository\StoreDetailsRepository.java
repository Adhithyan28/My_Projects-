
        package com.localmart.localmartbackend.repository;

import com.localmart.localmartbackend.entity.StoreDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface StoreDetailsRepository
        extends JpaRepository<StoreDetails, Long> {

    Optional<StoreDetails> findByUserId(Long userId);

    Optional<StoreDetails> findByGstNumber(String gstNumber);

    boolean existsByGstNumber(String gstNumber);
}

