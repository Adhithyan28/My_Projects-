package com.localmart.localmartbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LocalmartBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
