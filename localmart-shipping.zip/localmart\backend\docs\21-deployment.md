# LocalMart — Deployment

## 1. Overview

Deployment is the process of moving LocalMart from a local development environment to an environment where the application can be accessed and used by its intended users.

LocalMart consists of multiple components that must work together:

* React + TypeScript frontend
* Spring Boot backend
* PostgreSQL database
* Authentication infrastructure
* External API integrations
* Payment infrastructure
* Email/SMS services
* Location and routing services

The deployment architecture therefore needs to ensure that these components can communicate securely and reliably.

---

# 2. Current Development Architecture

During development, LocalMart runs primarily on the developer's machine.

The current development setup is:

```text
Browser
   |
   v
React + Vite
localhost:5174
   |
   | HTTP API
   v
Spring Boot
localhost:8080
   |
   | JDBC
   v
PostgreSQL
localmart_db
```

The backend also communicates with external services when required:

```text
                         ┌── Google
                         │
                         ├── X OAuth
                         │
Spring Boot ─────────────┼── Message Central
                         │
                         ├── SMTP
                         │
                         ├── Razorpay
                         │
                         ├── Geocoding API
                         │
                         └── OSRM
```

This architecture is suitable for development but should not simply be exposed directly to the public Internet as a production deployment.

---

# 3. Production Deployment Architecture

A production deployment separates the public-facing application from internal infrastructure.

A conceptual LocalMart production architecture is:

```text
                    Internet
                       |
                       v
                 HTTPS / Domain
                       |
              ┌────────┴────────┐
              |                 |
              v                 v
        React Frontend      API Server
                              |
                              v
                       Spring Boot
                              |
             ┌────────────────┼────────────────┐
             ↓                ↓                ↓
        PostgreSQL      External Services   Security
```

The exact cloud provider, hosting platform, or infrastructure can be selected independently.

The important architectural requirement is that the application components remain properly separated.

---

# 4. Frontend Deployment

The LocalMart frontend is built using:

```text
React
TypeScript
Vite
```

During development, Vite provides the development server.

For production, the frontend should first be built into static assets.

Conceptually:

```text
React + TypeScript
        |
        v
      Vite
        |
        v
Production build
        |
        v
HTML / CSS / JavaScript assets
        |
        v
Web server / static hosting
```

The development server is therefore not the same thing as the production frontend server.

---

# 5. Frontend Build Process

The general production process is:

```text
Source Code
    ↓
npm install
    ↓
npm run build
    ↓
Vite production build
    ↓
dist/
    ↓
Deploy static files
```

The resulting build contains the browser resources required to run the React application.

A production deployment should serve these files through an appropriate web server or static hosting service.

---

# 6. Frontend Environment Configuration

The frontend contains environment-dependent configuration.

For example:

```text
VITE_GOOGLE_CLIENT_ID
```

is used by the Google authentication integration.

The development environment may use:

```text
http://localhost:8080
```

as the backend API location, while production will use the deployed backend address.

Conceptually:

```text
Development
React
   ↓
localhost backend

Production
React
   ↓
Production API
```

Environment-specific frontend configuration should therefore be prepared before creating the production build.

---

# 7. Backend Deployment

The LocalMart backend is a Java Spring Boot application.

The backend can be packaged as an executable application artifact.

The general flow is:

```text
Java Source Code
       ↓
Maven
       ↓
Compile
       ↓
Package
       ↓
Spring Boot application JAR
       ↓
Production server
```

The Maven Wrapper included in the project can be used to build the application without requiring a separately installed Maven version.

On Windows, the project contains:

```text
mvnw.cmd
```

The backend application can therefore be built using the Maven Wrapper.

---

# 8. Backend Runtime

The Spring Boot application uses an embedded server.

The development environment currently uses:

```text
8080
```

as the backend port.

In production, the externally exposed port does not necessarily need to be 8080.

A reverse proxy or load balancer can receive HTTPS traffic and forward requests to the Spring Boot application.

Conceptually:

```text
Internet
   |
 HTTPS :443
   |
   v
Reverse Proxy
   |
   | internal HTTP
   v
Spring Boot
   |
 internal port
```

This allows the application server to remain behind an infrastructure layer.

---

# 9. PostgreSQL Deployment

The LocalMart backend depends on PostgreSQL for persistent data.

The production database should be separate from the development database.

Development:

```text
localmart_db
    ↓
Developer PostgreSQL
```

Production:

```text
localmart_db
    ↓
Production PostgreSQL
```

The application should connect to the production database using production-specific configuration.

The production database must also be protected from direct public access wherever possible.

---

# 10. Database Schema Management

LocalMart currently uses:

```text
spring.jpa.hibernate.ddl-auto=validate
```

This is important for deployment.

The application expects the database schema to already exist and match the JPA entity mappings.

The startup flow is:

```text
Spring Boot starts
       ↓
Hibernate loads entity mappings
       ↓
PostgreSQL connection established
       ↓
Schema validation
       ↓
Compatible?
    /       \
  YES        NO
   ↓          ↓
Startup     Startup
continues   fails
```

Therefore, deployment must include a controlled process for creating or updating the production database schema.

The application itself should not be relied upon to automatically modify the production schema when using `validate`.

---

# 11. Database Backup

The production PostgreSQL database contains important application data.

Examples include:

* Users
* Roles
* Addresses
* Stores
* Products
* Cart data
* Orders
* Payments
* Delivery information
* Sessions
* Application requests

A production deployment should therefore include a database backup strategy.

Conceptually:

```text
Production PostgreSQL
        |
        ├── Backup
        ├── Backup
        └── Backup
```

Backups should be stored separately from the primary database so that database failure does not destroy both the original data and its backups.

---

# 12. Environment Variables

Production configuration should not be hardcoded into the application.

Sensitive values should be supplied through the deployment environment.

Examples include:

```text
Database credentials
JWT signing configuration
Google configuration
X OAuth credentials
Message Central credentials
SMTP credentials
Razorpay credentials
Geocoding API credentials
```

The deployment environment provides these values to Spring Boot.

Conceptually:

```text
Production Environment
        |
        ↓
Environment Variables
        |
        ↓
Spring Boot Configuration
        |
        ↓
Application Services
```

---

# 13. Secret Management

Secrets must be treated differently from ordinary configuration.

Examples:

```text
Database password
JWT secret
OAuth client secret
SMTP password
Payment secret key
SMS provider credentials
```

These should not be placed in:

```text
Git repository
Frontend JavaScript
Public documentation
Public Docker images
Public configuration files
```

A production deployment should use the secret-management mechanism provided by the chosen hosting infrastructure.

---

# 14. HTTPS

Production LocalMart should use HTTPS.

The communication path should become:

```text
Browser
   |
   | HTTPS
   v
Production frontend/API
```

rather than relying on plain HTTP for public traffic.

HTTPS protects data while it travels between the user's browser and the server.

This is particularly important for LocalMart because requests can contain:

* Authentication information
* JWTs
* User information
* Addresses
* Order information
* Payment-related information

---

# 15. Domain Configuration

A production deployment normally uses a domain name rather than:

```text
localhost
```

For example, conceptually:

```text
https://localmart.example
```

for the frontend and:

```text
https://api.localmart.example
```

for the backend.

These are examples of an architecture, not actual LocalMart domains.

The domain configuration must correspond to the actual deployment environment.

---

# 16. CORS in Production

During development, the frontend and backend use different local origins.

For example:

```text
Frontend
http://localhost:5174

Backend
http://localhost:8080
```

In production, the frontend origin changes.

Therefore, `CorsConfig` must be configured for the actual production frontend origin.

Conceptually:

```text
Browser
   |
   | Origin: production frontend
   v
Spring Boot
   |
   | CORS validation
   v
Allowed / rejected
```

The production configuration should avoid unnecessarily allowing arbitrary origins.

---

# 17. Authentication Deployment

LocalMart's authentication system contains:

* Password authentication
* Email OTP
* SMS OTP
* TOTP
* Google authentication
* X authentication
* JWT
* User sessions

Deployment must therefore preserve the configuration required by each mechanism.

The general flow remains:

```text
Browser
   ↓
Authentication API
   ↓
Spring Security
   ↓
UserService
   ↓
Authentication provider
   ↓
UserSessionService
   ↓
JwtService
   ↓
JWT
```

The deployment environment does not change this application flow; it changes where the application and supporting services run.

---

# 18. External API Deployment

LocalMart depends on several external services.

The production backend must be able to communicate with them.

Conceptually:

```text
                 ┌── Google
                 │
                 ├── X
                 │
Spring Boot ─────┼── Message Central
                 │
                 ├── SMTP
                 │
                 ├── Razorpay
                 │
                 ├── Geocoding
                 │
                 └── OSRM
```

Network access, credentials, API URLs, redirect URIs, and provider-specific production settings must be configured appropriately.

---

# 19. Google Authentication in Production

Google authentication requires the deployed application configuration to correspond to the registered Google application.

The flow is:

```text
Browser
   ↓
Google Identity Services
   ↓
Google credential
   ↓
LocalMart backend
   ↓
GoogleTokenVerificationService
   ↓
User authentication
```

Production deployment may require different Google configuration from local development.

The authorized origins and redirect-related settings must therefore match the production frontend.

---

# 20. X OAuth in Production

The X OAuth integration also depends on application configuration.

The production deployment must use the configuration associated with the production application.

Conceptually:

```text
User
 ↓
LocalMart
 ↓
X OAuth
 ↓
X identity
 ↓
LocalMart backend
 ↓
LocalMart session/JWT
```

OAuth configuration should be checked after deployment because incorrect callback or application settings can prevent authentication from completing.

---

# 21. Email Deployment

Email OTP functionality depends on the configured SMTP service.

Production flow:

```text
User
   ↓
LocalMart
   ↓
EmailService
   ↓
SMTP provider
   ↓
User email inbox
```

Production SMTP credentials should be supplied through protected configuration.

Email delivery should also be tested after deployment.

---

# 22. SMS and WhatsApp Deployment

LocalMart uses Message Central-related services for authentication messaging.

The deployment environment must contain the required provider configuration and credentials.

The conceptual flow is:

```text
LocalMart
    ↓
MessageCentral service
    ↓
Message Central
    ↓
SMS / WhatsApp
    ↓
User
```

Provider availability, subscription status, account credits, and production credentials are external operational dependencies and should be verified before production use.

---

# 23. Payment Deployment

Razorpay is used for payment processing.

The deployment must distinguish between test and production payment configuration.

Conceptually:

```text
Development
     ↓
Razorpay test environment

Production
     ↓
Razorpay production environment
```

Payment-related secret credentials must remain on the backend.

The production payment flow should be tested carefully before accepting real transactions.

---

# 24. Location and Routing Deployment

LocalMart uses location-related services for address and delivery functionality.

The production backend communicates with:

```text
Geocoding service
OSRM
```

while the browser can obtain device location through:

```text
navigator.geolocation.getCurrentPosition()
```

The production flow can therefore involve:

```text
Customer browser
      ↓
Browser Geolocation API
      ↓
Coordinates
      ↓
LocalMart backend
      ↓
Location / delivery logic
      ↓
Geocoding / OSRM
```

The browser location API requires user permission.

External routing/geocoding services require appropriate network access and configuration.

---

# 25. Security Configuration During Deployment

Production security should be stricter than local development.

Important areas include:

### JWT

Protect signing configuration.

### CORS

Allow only required frontend origins.

### Database

Avoid exposing PostgreSQL directly to the public Internet.

### Credentials

Store secrets outside source control.

### HTTPS

Encrypt public communication.

### Rate Limiting

LocalMart contains:

```text
RateLimitFilter
```

which provides application-level rate-limiting functionality.

Production rate limits should be reviewed according to the expected traffic and authentication endpoints.

### Logging

Logs should not expose:

* Passwords
* OTP values
* JWT secrets
* API credentials
* Payment secrets

---

# 26. Deployment Sequence

A controlled deployment can follow this sequence:

```text
1. Prepare production infrastructure
             ↓
2. Prepare PostgreSQL
             ↓
3. Configure production environment variables
             ↓
4. Prepare database schema
             ↓
5. Build backend
             ↓
6. Deploy backend
             ↓
7. Verify backend startup
             ↓
8. Configure frontend environment
             ↓
9. Build frontend
             ↓
10. Deploy frontend
             ↓
11. Configure domain / HTTPS
             ↓
12. Configure CORS
             ↓
13. Verify external integrations
             ↓
14. Run application tests
             ↓
15. Perform end-to-end verification
```

---

# 27. Backend Deployment Verification

After deploying the backend, verify:

```text
Backend starts successfully
        ↓
Database connection succeeds
        ↓
Hibernate schema validation succeeds
        ↓
Spring Security initializes
        ↓
Controllers are registered
        ↓
External integrations can connect
        ↓
API requests work
```

A failed schema validation, missing environment variable, invalid credential, or unavailable external dependency can prevent successful operation.

---

# 28. Frontend Deployment Verification

After deploying the frontend, verify:

* Application loads.
* Static assets load correctly.
* API URL points to the production backend.
* Google authentication configuration works.
* Login works.
* Registration works.
* Protected API requests contain authentication information.
* CORS allows required requests.
* Cart operations work.
* Checkout works.
* Payment integration works.
* Order functionality works.

---

# 29. End-to-End Deployment Verification

Because LocalMart is a full-stack system, testing only the frontend or backend independently is not sufficient.

A basic production verification flow is:

```text
User
 ↓
Frontend
 ↓
Backend API
 ↓
Authentication
 ↓
Database
 ↓
Store/Product data
 ↓
Cart
 ↓
Checkout
 ↓
Payment
 ↓
Order
 ↓
Store owner
 ↓
Delivery partner
 ↓
Delivery status
```

This verifies that the major components communicate correctly after deployment.

---

# 30. Failure Handling During Deployment

Deployment should account for failures in different layers.

### Database failure

```text
Backend
   ↓
Database unavailable
   ↓
Application cannot perform persistence operations
```

### External service failure

For example:

```text
LocalMart
   ↓
External API unavailable
   ↓
Integration operation fails
```

The application should handle these failures through its existing service and exception-handling architecture.

### Configuration failure

```text
Missing environment variable
        ↓
Service initialization failure
        ↓
Application may fail to start
```

This is why deployment configuration should be validated before exposing the application to users.

---

# 31. Deployment and Application Architecture

Deployment does not replace LocalMart's layered application architecture.

The backend remains:

```text
Controller
    ↓
Service
    ↓
Repository
    ↓
Database
```

Security remains around the request pipeline:

```text
HTTP Request
    ↓
Security Filters
    ↓
Controller
    ↓
Service
    ↓
Repository
```

External integrations remain behind their dedicated services:

```text
Service
   ↓
Integration Service
   ↓
External Provider
```

Deployment simply determines where these components execute.

---

# 32. Development vs Production

| Area            | Development                  | Production                         |
| --------------- | ---------------------------- | ---------------------------------- |
| Frontend        | Vite dev server              | Built static application           |
| Backend         | Local Spring Boot            | Deployed Spring Boot application   |
| Database        | Local PostgreSQL             | Production PostgreSQL              |
| Frontend URL    | localhost                    | Production domain                  |
| Backend URL     | localhost                    | Production API domain              |
| HTTPS           | Usually not required locally | Required for public traffic        |
| Credentials     | Local environment            | Protected production configuration |
| Payment         | Test configuration           | Production configuration           |
| OAuth           | Development configuration    | Production configuration           |
| CORS            | Local frontend origin        | Production frontend origin         |
| Database access | Local machine                | Restricted production network      |

---

# 33. Deployment Artifacts

The important deployment artifacts are:

### Frontend

```text
React source
    ↓
Vite
    ↓
Production build
```

### Backend

```text
Java source
    ↓
Maven
    ↓
Spring Boot JAR
```

### Database

```text
PostgreSQL schema
+
Production data
```

### Configuration

```text
Environment-specific variables
+
External service credentials
```

Together:

```text
Frontend build
      +
Backend JAR
      +
PostgreSQL
      +
Configuration
      +
External services
      ↓
Complete LocalMart deployment
```

---

# 34. Deployment Checklist

## Infrastructure

* [ ] Production server/environment is available.
* [ ] PostgreSQL is available.
* [ ] Network connectivity is configured.
* [ ] Domain is configured.
* [ ] HTTPS is configured.

## Backend

* [ ] Java runtime is available.
* [ ] Backend builds successfully.
* [ ] Production configuration is available.
* [ ] Database connection works.
* [ ] Hibernate schema validation succeeds.
* [ ] Spring Security starts successfully.
* [ ] API endpoints respond correctly.

## Database

* [ ] Production database exists.
* [ ] Required schema exists.
* [ ] Schema matches JPA entities.
* [ ] Database credentials are protected.
* [ ] Backup strategy exists.

## Frontend

* [ ] Dependencies install successfully.
* [ ] Production build succeeds.
* [ ] Production API configuration is correct.
* [ ] Static files are deployed.
* [ ] Application loads through the production domain.

## Authentication

* [ ] Password login works.
* [ ] Email OTP works.
* [ ] SMS OTP works.
* [ ] TOTP functionality works where configured.
* [ ] Google login works.
* [ ] X login works.
* [ ] JWT authentication works.
* [ ] Logout invalidates the appropriate session.

## Business functionality

* [ ] Customer profile works.
* [ ] Address management works.
* [ ] Store browsing works.
* [ ] Product browsing works.
* [ ] Cart works.
* [ ] Delivery fee calculation works.
* [ ] Checkout works.
* [ ] Payment works.
* [ ] Orders work.
* [ ] Store-owner functionality works.
* [ ] Delivery-partner functionality works.
* [ ] Location functionality works.

## Security

* [ ] Secrets are not committed.
* [ ] HTTPS is enabled.
* [ ] CORS is restricted.
* [ ] JWT configuration is protected.
* [ ] Database is not publicly exposed.
* [ ] Rate limiting is configured.
* [ ] Sensitive information is not written to logs.

---

# 35. Future Deployment Improvements

As LocalMart grows, the deployment architecture can be expanded.

Potential improvements include:

* Reverse proxy
* Load balancing
* Containerization
* Docker
* CI/CD pipelines
* Automated database migrations
* Centralized logging
* Monitoring
* Metrics
* Health checks
* Automated backups
* Secret-management services
* Horizontal backend scaling
* Redis for distributed caching/rate limiting where appropriate
* Separate staging environment

These are deployment improvements rather than requirements of the current development architecture.

---

# 36. Deployment Architecture Summary

The overall production model can be represented as:

```text
                         INTERNET
                            |
                         HTTPS
                            |
                     ┌──────┴──────┐
                     |             |
                     v             v
              React Frontend   API Gateway /
              Static Build     Reverse Proxy
                                   |
                                   v
                            Spring Boot
                              Backend
                                   |
                ┌──────────────────┼──────────────────┐
                |                  |                  |
                v                  v                  v
           PostgreSQL       Authentication       External APIs
                                |                  |
                                |          ┌───────┼────────┐
                                |          ↓       ↓        ↓
                                |       Google  Razorpay  OSRM
                                |       X       SMTP      Geocoding
                                |       SMS/WhatsApp
                                |
                                v
                           JWT / Sessions
```

The exact infrastructure components may change depending on the hosting provider, but the logical architecture remains the same.

---

# 37. Key Takeaways

LocalMart deployment consists of more than simply starting the Spring Boot application.

The complete deployment includes:

1. **Building and deploying the React frontend.**
2. **Building and deploying the Spring Boot backend.**
3. **Preparing a production PostgreSQL database.**
4. **Providing environment-specific configuration.**
5. **Protecting secrets and credentials.**
6. **Configuring HTTPS and production domains.**
7. **Configuring CORS for the production frontend.**
8. **Configuring authentication providers.**
9. **Configuring payment, email, SMS, routing, and geocoding services.**
10. **Verifying the complete customer-to-delivery workflow.**
11. **Maintaining database backups.**
12. **Monitoring failures and operational issues.**

The fundamental deployment relationship is:

```text
Source Code
     ↓
Build
     ↓
Deployment Artifacts
     ↓
Production Infrastructure
     ↓
Configuration
     ↓
External Services
     ↓
Running LocalMart
```

The deployment environment should change the **infrastructure and configuration**, not the core business rules of the LocalMart application.
