
        package com.localmart.localmartbackend.smsotp.controller;

import com.localmart.localmartbackend.smsotp.dto.SmsOtpSendRequest;
import com.localmart.localmartbackend.smsotp.dto.SmsOtpVerifyRequest;
import com.localmart.localmartbackend.smsotp.service.SmsOtpFlowService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/sms-otp")
public class SmsOtpController {

    private final SmsOtpFlowService smsOtpFlowService;

    public SmsOtpController(
            SmsOtpFlowService smsOtpFlowService) {

        this.smsOtpFlowService =
                smsOtpFlowService;
    }

    /*
     * SEND SMS OTP
     *
     * POST /api/sms-otp/send
     */
    @PostMapping("/send")
    public ResponseEntity<?> sendOtp(
            @RequestBody SmsOtpSendRequest request) {

        smsOtpFlowService.sendOtp(
                request.getMobileNumber()
        );

        return ResponseEntity.ok(
                Map.of(
                        "success", true,
                        "message",
                        "OTP sent successfully."
                )
        );
    }

    /*
     * VERIFY SMS OTP
     *
     * POST /api/sms-otp/verify
     */
    @PostMapping("/verify")
    public ResponseEntity<?> verifyOtp(
            @RequestBody SmsOtpVerifyRequest request) {

        smsOtpFlowService.verifyOtp(
                request.getMobileNumber(),
                request.getOtp()
        );

        return ResponseEntity.ok(
                Map.of(
                        "success", true,
                        "message",
                        "OTP verified successfully."
                )
        );
    }
}
