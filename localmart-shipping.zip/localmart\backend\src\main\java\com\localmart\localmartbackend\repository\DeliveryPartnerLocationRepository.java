package com.localmart.localmartbackend.repository;

import com.localmart.localmartbackend.entity.DeliveryPartnerLocation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DeliveryPartnerLocationRepository
        extends JpaRepository<DeliveryPartnerLocation, Long> {

    /*
     * Find all delivery partners having the requested
     * availability status.
     *
     * Example:
     *
     * AVAILABLE
     *     ↓
     * returns all currently available partners
     */
    List<DeliveryPartnerLocation> findByAvailabilityStatus(
            String availabilityStatus
    );
}