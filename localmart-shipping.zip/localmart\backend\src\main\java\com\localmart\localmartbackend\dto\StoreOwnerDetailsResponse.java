
        package com.localmart.localmartbackend.dto;

import java.math.BigDecimal;

public class StoreOwnerDetailsResponse {

    private Long storeId;

    private String firstName;
    private String lastName;
    private String ownerName;
    private String email;
    private String phone;

    private String storeName;
    private String businessType;
    private String gstNumber;

    private String addressLine;
    private String city;
    private String state;
    private String pincode;

    private BigDecimal latitude;
    private BigDecimal longitude;

    public StoreOwnerDetailsResponse() {
    }

    public StoreOwnerDetailsResponse(
            Long storeId,
            String firstName,
            String lastName,
            String ownerName,
            String email,
            String phone,
            String storeName,
            String businessType,
            String gstNumber,
            String addressLine,
            String city,
            String state,
            String pincode,
            BigDecimal latitude,
            BigDecimal longitude
    ) {
        this.storeId = storeId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.ownerName = ownerName;
        this.email = email;
        this.phone = phone;
        this.storeName = storeName;
        this.businessType = businessType;
        this.gstNumber = gstNumber;
        this.addressLine = addressLine;
        this.city = city;
        this.state = state;
        this.pincode = pincode;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public Long getStoreId() {
        return storeId;
    }

    public void setStoreId(Long storeId) {
        this.storeId = storeId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public String getBusinessType() {
        return businessType;
    }

    public void setBusinessType(String businessType) {
        this.businessType = businessType;
    }

    public String getGstNumber() {
        return gstNumber;
    }

    public void setGstNumber(String gstNumber) {
        this.gstNumber = gstNumber;
    }

    public String getAddressLine() {
        return addressLine;
    }

    public void setAddressLine(String addressLine) {
        this.addressLine = addressLine;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public BigDecimal getLatitude() {
        return latitude;
    }

    public void setLatitude(BigDecimal latitude) {
        this.latitude = latitude;
    }

    public BigDecimal getLongitude() {
        return longitude;
    }

    public void setLongitude(BigDecimal longitude) {
        this.longitude = longitude;
    }
}
