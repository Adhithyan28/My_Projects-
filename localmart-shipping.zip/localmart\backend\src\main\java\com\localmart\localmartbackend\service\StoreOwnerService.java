
        package com.localmart.localmartbackend.service;

import com.localmart.localmartbackend.dto.StoreOwnerDetailsRequest;
import com.localmart.localmartbackend.dto.StoreOwnerDetailsResponse;
import com.localmart.localmartbackend.entity.Address;
import com.localmart.localmartbackend.entity.StoreDetails;
import com.localmart.localmartbackend.entity.User;
import com.localmart.localmartbackend.repository.AddressRepository;
import com.localmart.localmartbackend.repository.StoreDetailsRepository;
import com.localmart.localmartbackend.repository.UserRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Optional;

@Service
public class StoreOwnerService {

    private final UserRepository userRepository;
    private final StoreDetailsRepository storeDetailsRepository;
    private final AddressRepository addressRepository;
    private final GeocodingService geocodingService;

    public StoreOwnerService(
            UserRepository userRepository,
            StoreDetailsRepository storeDetailsRepository,
            AddressRepository addressRepository,
            GeocodingService geocodingService
    ) {
        this.userRepository = userRepository;
        this.storeDetailsRepository = storeDetailsRepository;
        this.addressRepository = addressRepository;
        this.geocodingService = geocodingService;
    }

    public StoreOwnerDetailsResponse getStoreDetails(Long userId) {

        User user = userRepository.findById(userId)
                .orElseThrow(() ->
                        new RuntimeException("User not found"));

        StoreDetails storeDetails =
                storeDetailsRepository.findByUserId(userId)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Store details not found"
                                ));

        Optional<Address> addressOptional =
                addressRepository.findByUserIdAndIsDefaultTrue(userId);

        Address address =
                addressOptional.orElse(null);

        return buildResponse(
                user,
                storeDetails,
                address
        );
    }

    @Transactional
    public StoreOwnerDetailsResponse updateStoreDetails(
            Long userId,
            StoreOwnerDetailsRequest request
    ) {

        User user = userRepository.findById(userId)
                .orElseThrow(() ->
                        new RuntimeException("User not found"));

        StoreDetails storeDetails =
                storeDetailsRepository.findByUserId(userId)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Store details not found"
                                ));

        validateRequest(request);

        String firstName = clean(request.getFirstName());
        String lastName = clean(request.getLastName());
        String phone = clean(request.getPhone());

        if (!phone.matches("^[6-9][0-9]{9}$")) {
            throw new RuntimeException(
                    "Please enter a valid Indian mobile number."
            );
        }

        Optional<User> phoneUser =
                userRepository.findByPhone(phone);

        if (phoneUser.isPresent()
                && !phoneUser.get().getUserId().equals(userId)) {

            throw new RuntimeException(
                    "This phone number is already registered."
            );
        }

        String storeName =
                clean(request.getStoreName());

        String businessType =
                clean(request.getBusinessType());

        String gstNumber =
                clean(request.getGstNumber());

        if (!gstNumber.isEmpty()) {

            Optional<StoreDetails> gstStore =
                    storeDetailsRepository.findByGstNumber(
                            gstNumber
                    );

            if (gstStore.isPresent()
                    && !gstStore.get().getStoreId()
                    .equals(storeDetails.getStoreId())) {

                throw new RuntimeException(
                        "This GST number is already registered."
                );
            }
        }

        String addressLine =
                clean(request.getAddressLine());

        String city =
                clean(request.getCity());

        String state =
                clean(request.getState());

        String pincode =
                clean(request.getPincode());

        if (!pincode.matches("^[0-9]{6}$")) {
            throw new RuntimeException(
                    "Please enter a valid 6-digit pincode."
            );
        }

        /*
         * Coordinates must come from the map confirmation.
         *
         * The backend no longer automatically replaces them
         * with coordinates obtained from the typed address.
         */
        BigDecimal latitude = request.getLatitude();
        BigDecimal longitude = request.getLongitude();

        validateCoordinates(latitude, longitude);

        /*
         * Update user information.
         */
        user.setFirstName(firstName);
        user.setLastName(lastName);
        user.setPhone(phone);

        userRepository.save(user);

        /*
         * Update store information.
         */
        storeDetails.setStoreName(storeName);
        storeDetails.setBusinessType(businessType);
        storeDetails.setGstNumber(
                gstNumber.isEmpty() ? null : gstNumber
        );

        storeDetailsRepository.save(storeDetails);

        /*
         * Find the owner's default address.
         *
         * The store location is represented by the owner's
         * default address, as defined by the LocalMart database design.
         */
        Optional<Address> existingAddressOptional =
                addressRepository.findByUserIdAndIsDefaultTrue(
                        userId
                );

        Address address;

        if (existingAddressOptional.isEmpty()) {

            address = new Address();

            address.setUserId(userId);
            address.setAddressLine(addressLine);
            address.setCity(city);
            address.setState(state);
            address.setPincode(pincode);

        } else {

            address =
                    existingAddressOptional.get();

            address.setAddressLine(addressLine);
            address.setCity(city);
            address.setState(state);
            address.setPincode(pincode);
        }

        /*
         * Always use the coordinates explicitly confirmed
         * by the Store Owner on the map.
         */
        address.setLatitude(latitude);
        address.setLongitude(longitude);
        address.setIsDefault(true);

        addressRepository.save(address);

        return buildResponse(
                user,
                storeDetails,
                address
        );
    }

    private void validateRequest(
            StoreOwnerDetailsRequest request
    ) {

        if (request == null) {
            throw new RuntimeException(
                    "Store details request cannot be empty."
            );
        }

        if (isBlank(request.getFirstName())) {
            throw new RuntimeException(
                    "First name is required."
            );
        }

        if (isBlank(request.getLastName())) {
            throw new RuntimeException(
                    "Last name is required."
            );
        }

        if (isBlank(request.getPhone())) {
            throw new RuntimeException(
                    "Phone number is required."
            );
        }

        if (isBlank(request.getStoreName())) {
            throw new RuntimeException(
                    "Store name is required."
            );
        }

        if (isBlank(request.getBusinessType())) {
            throw new RuntimeException(
                    "Business type is required."
            );
        }

        if (isBlank(request.getAddressLine())) {
            throw new RuntimeException(
                    "Address is required."
            );
        }

        if (isBlank(request.getCity())) {
            throw new RuntimeException(
                    "City is required."
            );
        }

        if (isBlank(request.getState())) {
            throw new RuntimeException(
                    "State is required."
            );
        }

        if (isBlank(request.getPincode())) {
            throw new RuntimeException(
                    "Pincode is required."
            );
        }
    }

    private void validateCoordinates(
            BigDecimal latitude,
            BigDecimal longitude
    ) {

        if (latitude == null || longitude == null) {
            throw new RuntimeException(
                    "Please select and confirm the store location on the map."
            );
        }

        if (latitude.compareTo(BigDecimal.valueOf(-90)) < 0
                || latitude.compareTo(BigDecimal.valueOf(90)) > 0) {

            throw new RuntimeException(
                    "Invalid latitude."
            );
        }

        if (longitude.compareTo(BigDecimal.valueOf(-180)) < 0
                || longitude.compareTo(BigDecimal.valueOf(180)) > 0) {

            throw new RuntimeException(
                    "Invalid longitude."
            );
        }
    }

    private StoreOwnerDetailsResponse buildResponse(
            User user,
            StoreDetails storeDetails,
            Address address
    ) {

        String ownerName =
                (clean(user.getFirstName()) + " "
                        + clean(user.getLastName())).trim();

        return new StoreOwnerDetailsResponse(
                storeDetails.getStoreId(),
                user.getFirstName(),
                user.getLastName(),
                ownerName,
                user.getEmail(),
                user.getPhone(),
                storeDetails.getStoreName(),
                storeDetails.getBusinessType(),
                storeDetails.getGstNumber(),
                address != null
                        ? address.getAddressLine()
                        : null,
                address != null
                        ? address.getCity()
                        : null,
                address != null
                        ? address.getState()
                        : null,
                address != null
                        ? address.getPincode()
                        : null,
                address != null
                        ? address.getLatitude()
                        : null,
                address != null
                        ? address.getLongitude()
                        : null
        );
    }

    private String clean(String value) {

        if (value == null) {
            return "";
        }

        return value.trim();
    }

    private boolean isBlank(String value) {

        return value == null
                || value.trim().isEmpty();
    }
}
