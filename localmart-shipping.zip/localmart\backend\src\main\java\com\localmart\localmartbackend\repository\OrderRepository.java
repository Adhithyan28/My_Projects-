package com.localmart.localmartbackend.repository;

import com.localmart.localmartbackend.entity.Order;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface OrderRepository
        extends JpaRepository<Order, Long> {

    List<Order> findByCustomerIdOrderByCreatedAtDesc(
            Long customerId
    );

    List<Order> findByStoreIdOrderByCreatedAtDesc(
            Long storeId
    );

    List<Order> findByDeliveryPartnerIdOrderByCreatedAtDesc(
            Long deliveryPartnerId
    );

    List<Order>
    findByOrderStatusAndDeliveryPartnerIdIsNullOrderByCreatedAtAsc(
            String orderStatus
    );

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("""
            SELECT o
            FROM Order o
            WHERE o.orderId = :orderId
            """)
    Optional<Order> findByIdForUpdate(
            @Param("orderId") Long orderId
    );

    Optional<Order> findByOrderNumber(
            String orderNumber
    );
}