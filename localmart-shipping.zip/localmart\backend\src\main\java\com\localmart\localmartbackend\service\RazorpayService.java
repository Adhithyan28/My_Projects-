package com.localmart.localmartbackend.service;

import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.Utils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class RazorpayService {

    private final String keyId;
    private final String keySecret;

    public RazorpayService(
            @Value("${razorpay.key.id}") String keyId,
            @Value("${razorpay.key.secret}") String keySecret
    ) {
        this.keyId = keyId;
        this.keySecret = keySecret;
    }

    /*
     * =============================================================
     * CREATE RAZORPAY ORDER
     * =============================================================
     *
     * Razorpay expects the amount in the smallest currency unit.
     *
     * For INR:
     *
     * ₹100.00
     *      ↓
     * 10000 paise
     */
    public Order createOrder(
            long amountInPaise,
            String currency,
            String receipt
    ) {

        try {

            RazorpayClient razorpayClient =
                    new RazorpayClient(
                            keyId,
                            keySecret
                    );

            JSONObject options =
                    new JSONObject();

            options.put(
                    "amount",
                    amountInPaise
            );

            options.put(
                    "currency",
                    currency
            );

            options.put(
                    "receipt",
                    receipt
            );

            return razorpayClient
                    .orders
                    .create(options);

        } catch (Exception exception) {

            throw new RuntimeException(
                    "Unable to create Razorpay order",
                    exception
            );
        }
    }

    /*
     * =============================================================
     * VERIFY RAZORPAY PAYMENT SIGNATURE
     * =============================================================
     *
     * Razorpay Checkout returns:
     *
     * razorpay_order_id
     * razorpay_payment_id
     * razorpay_signature
     *
     * We verify the signature using the Razorpay secret.
     */
    public boolean verifyPaymentSignature(
            String razorpayOrderId,
            String razorpayPaymentId,
            String razorpaySignature
    ) {

        try {

            JSONObject options =
                    new JSONObject();

            options.put(
                    "razorpay_order_id",
                    razorpayOrderId
            );

            options.put(
                    "razorpay_payment_id",
                    razorpayPaymentId
            );

            options.put(
                    "razorpay_signature",
                    razorpaySignature
            );

            return Utils.verifyPaymentSignature(
                    options,
                    keySecret
            );

        } catch (Exception exception) {

            throw new RuntimeException(
                    "Unable to verify Razorpay payment signature",
                    exception
            );
        }
    }

    /*
     * =============================================================
     * RAZORPAY KEY ID
     * =============================================================
     *
     * Key ID is safe to send to the frontend.
     *
     * NEVER send keySecret to the frontend.
     */
    public String getKeyId() {
        return keyId;
    }
}