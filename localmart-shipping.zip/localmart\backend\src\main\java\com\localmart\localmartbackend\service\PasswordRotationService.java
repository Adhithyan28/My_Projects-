package com.localmart.localmartbackend.service;

import com.localmart.localmartbackend.entity.UserPasswordHistory;
import com.localmart.localmartbackend.repository.UserPasswordHistoryRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class PasswordRotationService {

    // ============================================================
    // PASSWORD ROTATION CONFIGURATION
    // ============================================================

    private static final int PASSWORD_EXPIRY_DAYS = 30;

    // ============================================================
    // REPOSITORY
    // ============================================================

    private final UserPasswordHistoryRepository
            userPasswordHistoryRepository;

    // ============================================================
    // CONSTRUCTOR
    // ============================================================

    public PasswordRotationService(
            UserPasswordHistoryRepository
                    userPasswordHistoryRepository) {

        this.userPasswordHistoryRepository =
                userPasswordHistoryRepository;
    }

    // ============================================================
    // CHECK PASSWORD EXPIRY
    // ============================================================

    public boolean isPasswordExpired(
            Long userId) {

        UserPasswordHistory history =
                userPasswordHistoryRepository
                        .findTopByUserIdOrderByChangedAtDesc(
                                userId
                        )
                        .orElse(null);

        /*
         * If there is no password-history record,
         * there is currently no rotation information
         * available for this user.
         */
        if (history == null ||
                history.getChangedAt() == null) {

            return false;
        }

        LocalDateTime expiryTime =
                history.getChangedAt()
                        .plusDays(
                                PASSWORD_EXPIRY_DAYS
                        );

        return !expiryTime.isAfter(
                LocalDateTime.now()
        );
    }
}