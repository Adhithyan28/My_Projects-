package com.localmart.localmartbackend.service;

import com.localmart.localmartbackend.dto.DeliveryPartnerProfileResponse;
import com.localmart.localmartbackend.dto.UpdateDeliveryPartnerProfileRequest;
import com.localmart.localmartbackend.entity.DeliveryPartner;
import com.localmart.localmartbackend.entity.User;
import com.localmart.localmartbackend.entity.VehicleDetails;
import com.localmart.localmartbackend.repository.DeliveryPartnerRepository;
import com.localmart.localmartbackend.repository.UserRepository;
import com.localmart.localmartbackend.repository.VehicleDetailsRepository;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import org.springframework.http.HttpStatus;

@Service
public class DeliveryPartnerProfileService {

    private final UserRepository userRepository;
    private final DeliveryPartnerRepository deliveryPartnerRepository;
    private final VehicleDetailsRepository vehicleDetailsRepository;

    public DeliveryPartnerProfileService(
            UserRepository userRepository,
            DeliveryPartnerRepository deliveryPartnerRepository,
            VehicleDetailsRepository vehicleDetailsRepository) {

        this.userRepository = userRepository;
        this.deliveryPartnerRepository = deliveryPartnerRepository;
        this.vehicleDetailsRepository = vehicleDetailsRepository;
    }

    @Transactional(readOnly = true)
    public DeliveryPartnerProfileResponse getProfile(Long userId) {

        User user = userRepository.findById(userId)
                .orElseThrow(() ->
                        new ResponseStatusException(
                                HttpStatus.NOT_FOUND,
                                "User not found"
                        )
                );

        DeliveryPartner deliveryPartner =
                deliveryPartnerRepository.findById(userId)
                        .orElseThrow(() ->
                                new ResponseStatusException(
                                        HttpStatus.NOT_FOUND,
                                        "Delivery partner profile not found"
                                )
                        );

        VehicleDetails vehicle =
                vehicleDetailsRepository.findById(
                        deliveryPartner.getVehicleId()
                ).orElseThrow(() ->
                        new ResponseStatusException(
                                HttpStatus.NOT_FOUND,
                                "Vehicle details not found"
                        )
                );

        DeliveryPartnerProfileResponse response =
                new DeliveryPartnerProfileResponse();

        response.setFirstName(user.getFirstName());
        response.setLastName(user.getLastName());
        response.setEmail(user.getEmail());

        response.setEmergencyContactPhone(
                deliveryPartner.getEmergencyContactPhone()
        );

        response.setVehicleType(
                vehicle.getVehicleType()
        );

        response.setVehicleNumber(
                vehicle.getVehicleNumber()
        );

        response.setDrivingLicenceNumber(
                deliveryPartner.getDrivingLicenceNumber()
        );

        return response;
    }

    @Transactional
    public DeliveryPartnerProfileResponse updateProfile(
            Long userId,
            UpdateDeliveryPartnerProfileRequest request) {

        if (request == null) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Request body is required"
            );
        }

        String firstName = clean(request.getFirstName());
        String lastName = clean(request.getLastName());
        String emergencyContactPhone =
                clean(request.getEmergencyContactPhone());

        if (firstName == null || firstName.isBlank()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "First name is required"
            );
        }

        if (lastName == null || lastName.isBlank()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Last name is required"
            );
        }

        if (firstName.length() > 100) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "First name is too long"
            );
        }

        if (lastName.length() > 100) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Last name is too long"
            );
        }

        if (emergencyContactPhone != null
                && !emergencyContactPhone.isBlank()
                && !emergencyContactPhone.matches("\\d{10,15}")) {

            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Emergency contact phone must contain 10 to 15 digits"
            );
        }

        User user = userRepository.findById(userId)
                .orElseThrow(() ->
                        new ResponseStatusException(
                                HttpStatus.NOT_FOUND,
                                "User not found"
                        )
                );

        DeliveryPartner deliveryPartner =
                deliveryPartnerRepository.findById(userId)
                        .orElseThrow(() ->
                                new ResponseStatusException(
                                        HttpStatus.NOT_FOUND,
                                        "Delivery partner profile not found"
                                )
                        );

        /*
         * --------------------------------------------------------
         * ONLY EDITABLE FIELDS ARE UPDATED
         * --------------------------------------------------------
         */

        user.setFirstName(firstName);
        user.setLastName(lastName);

        if (emergencyContactPhone == null
                || emergencyContactPhone.isBlank()) {

            deliveryPartner.setEmergencyContactPhone(null);

        } else {

            deliveryPartner.setEmergencyContactPhone(
                    emergencyContactPhone
            );
        }

        userRepository.save(user);
        deliveryPartnerRepository.save(deliveryPartner);

        return getProfile(userId);
    }

    private String clean(String value) {

        if (value == null) {
            return null;
        }

        return value.trim();
    }
}