package com.localmart.localmartbackend.dto;

import java.math.BigDecimal;

public class StoreResponse {

    private Long storeId;
    private String storeName;
    private String businessType;
    private String city;
    private String state;
    private BigDecimal latitude;
    private BigDecimal longitude;

    public StoreResponse() {
    }

    public StoreResponse(
            Long storeId,
            String storeName,
            String businessType,
            String city,
            String state,
            BigDecimal latitude,
            BigDecimal longitude
    ) {
        this.storeId = storeId;
        this.storeName = storeName;
        this.businessType = businessType;
        this.city = city;
        this.state = state;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public Long getStoreId() {
        return storeId;
    }

    public void setStoreId(Long storeId) {
        this.storeId = storeId;
    }

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public String getBusinessType() {
        return businessType;
    }

    public void setBusinessType(String businessType) {
        this.businessType = businessType;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public BigDecimal getLatitude() {
        return latitude;
    }

    public void setLatitude(BigDecimal latitude) {
        this.latitude = latitude;
    }

    public BigDecimal getLongitude() {
        return longitude;
    }

    public void setLongitude(BigDecimal longitude) {
        this.longitude = longitude;
    }
}