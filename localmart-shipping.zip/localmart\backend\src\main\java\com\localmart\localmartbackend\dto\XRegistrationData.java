package com.localmart.localmartbackend.dto;

import java.time.LocalDateTime;

public record XRegistrationData(
        String xId,
        String email,
        String name,
        String username,
        LocalDateTime expiresAt
) {
}