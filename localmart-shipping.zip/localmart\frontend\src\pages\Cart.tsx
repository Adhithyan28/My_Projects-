import { useAuth } from "../context/AuthContext"
import { useEffect, useState } from "react"

interface CartItem {
    cartItemId: number
    productId: number
    productName: string
    category: string
    description: string
    price: number
    unit: string
    quantity: number
    stockQuantity: number
    icon: string
    isAvailable: boolean
    storeId: number
    storeName: string
    itemTotal: number
}

interface CartResponse {
    cartId: number
    customerId: number
    items: CartItem[]
    subtotal: number
    itemCount: number
    storeId: number | null
    storeName: string | null
}

interface AddressInfo {
    addressId: number
    addressLine: string
    city: string
    state: string
    pincode: string
    latitude: number
    longitude: number
    isDefault: boolean
}

interface DeliveryFeeResponse {
    distanceKm: number
    deliveryFee: number
}

interface CartProps {
    onHome: () => void
    onStores: () => void
    onCategories: () => void
    onProducts: () => void
    onOrders: () => void
    onCheckout: () => void
}

function Cart({
                  onHome,
                  onStores,
                  onCategories,
                  onProducts,
                  onOrders,
                  onCheckout,
              }: CartProps) {

    const { user, logout } = useAuth()

    const [cart, setCart] =
        useState<CartResponse | null>(null)

    const [loading, setLoading] =
        useState(true)

    const [error, setError] =
        useState("")

    const [updatingItemId, setUpdatingItemId] =
        useState<number | null>(null)

    const [clearingCart, setClearingCart] =
        useState(false)

    /* ==========================================
     * DELIVERY ADDRESS
     * ========================================== */

    const [addresses, setAddresses] =
        useState<AddressInfo[]>([])

    const [selectedAddressId, setSelectedAddressId] =
        useState<number | null>(null)

    const [loadingAddress, setLoadingAddress] =
        useState(true)

    /* ==========================================
     * DELIVERY FEE
     * ========================================== */

    const [deliveryFee, setDeliveryFee] =
        useState(0)

    const [deliveryDistanceKm, setDeliveryDistanceKm] =
        useState<number | null>(null)

    const [loadingDeliveryFee, setLoadingDeliveryFee] =
        useState(false)

    const [deliveryFeeError, setDeliveryFeeError] =
        useState("")


    /* ==========================================
     * AUTH TOKEN
     * ========================================== */

    const token =
        user?.token


    /* ==========================================
     * LOAD CART FROM DATABASE
     * ========================================== */

    const loadCart = async () => {

        if (!token) {

            setLoading(false)

            setError(
                "Please login to view your cart."
            )

            return
        }

        try {

            setLoading(true)
            setError("")

            const response =
                await fetch(
                    "/api/cart",
                    {
                        method: "GET",

                        headers: {
                            Authorization:
                                `Bearer ${token}`,
                        },
                    }
                )

            if (!response.ok) {

                if (response.status === 401) {

                    throw new Error(
                        "Your session has expired. Please login again."
                    )
                }

                throw new Error(
                    "Unable to load your cart."
                )
            }

            const data: CartResponse =
                await response.json()

            setCart(data)

        } catch (err) {

            console.error(
                "Failed to load cart:",
                err
            )

            setError(
                err instanceof Error
                    ? err.message
                    : "Unable to load your cart."
            )

        } finally {

            setLoading(false)

        }
    }


    /* ==========================================
     * LOAD CART WHEN PAGE OPENS
     * ========================================== */

    useEffect(() => {

        loadCart()

    }, [token])


    /* ==========================================
     * LOAD CUSTOMER ADDRESSES
     * ========================================== */

    useEffect(() => {

        const loadAddresses = async () => {

            if (!token) {

                setAddresses([])
                setSelectedAddressId(null)
                setLoadingAddress(false)

                return
            }

            try {

                setLoadingAddress(true)

                const response =
                    await fetch(
                        "/api/customer/addresses",
                        {
                            method: "GET",

                            headers: {
                                Authorization:
                                    `Bearer ${token}`,
                            },
                        }
                    )

                if (!response.ok) {

                    throw new Error(
                        "Unable to load delivery addresses."
                    )
                }

                const data: AddressInfo[] =
                    await response.json()

                setAddresses(data)

                /*
                 * Prefer the customer's default address.
                 *
                 * If there is no default address,
                 * use the first saved address.
                 */

                const defaultAddress =
                    data.find(
                        address =>
                            address.isDefault === true
                    )

                if (defaultAddress) {

                    setSelectedAddressId(
                        defaultAddress.addressId
                    )

                } else if (data.length > 0) {

                    setSelectedAddressId(
                        data[0].addressId
                    )

                } else {

                    setSelectedAddressId(null)
                }

            } catch (err) {

                console.error(
                    "Failed to load customer addresses:",
                    err
                )

                setAddresses([])
                setSelectedAddressId(null)

            } finally {

                setLoadingAddress(false)
            }
        }

        loadAddresses()

    }, [token])


    /* ==========================================
     * CART DATA
     * ========================================== */

    const cartItems =
        cart?.items || []

    const itemCount =
        cart?.itemCount || 0

    const subtotal =
        Number(cart?.subtotal || 0)

    const storeId =
        cart?.storeId || null


    /* ==========================================
     * CALCULATE DELIVERY FEE
     * ========================================== */

    useEffect(() => {

        const calculateDeliveryFee = async () => {

            /*
             * We need:
             *
             * 1. Logged-in customer
             * 2. Cart items
             * 3. Store ID
             * 4. Customer address
             */

            if (
                !token ||
                cartItems.length === 0 ||
                !storeId ||
                !selectedAddressId
            ) {

                setDeliveryFee(0)
                setDeliveryDistanceKm(null)
                setDeliveryFeeError("")
                setLoadingDeliveryFee(false)

                return
            }

            try {

                setLoadingDeliveryFee(true)
                setDeliveryFeeError("")

                const response =
                    await fetch(
                        "/api/orders/calculate-delivery-fee",
                        {
                            method: "POST",

                            headers: {
                                "Content-Type":
                                    "application/json",

                                Authorization:
                                    `Bearer ${token}`,
                            },

                            body:
                                JSON.stringify({
                                    storeId:
                                    storeId,

                                    addressId:
                                    selectedAddressId,
                                }),
                        }
                    )

                if (!response.ok) {

                    let message =
                        "Unable to calculate delivery fee."

                    try {

                        const errorData =
                            await response.json()

                        if (errorData?.message) {

                            message =
                                errorData.message
                        }

                    } catch {
                        // Keep default message.
                    }

                    throw new Error(message)
                }

                const data:
                    DeliveryFeeResponse =
                    await response.json()

                setDeliveryDistanceKm(
                    Number(data.distanceKm)
                )

                setDeliveryFee(
                    Number(data.deliveryFee)
                )

            } catch (err) {

                console.error(
                    "Failed to calculate delivery fee:",
                    err
                )

                setDeliveryFee(0)
                setDeliveryDistanceKm(null)

                setDeliveryFeeError(
                    err instanceof Error
                        ? err.message
                        : "Unable to calculate delivery fee."
                )

            } finally {

                setLoadingDeliveryFee(false)
            }
        }

        calculateDeliveryFee()

    }, [
        token,
        storeId,
        selectedAddressId,
        cartItems.length,
        subtotal,
    ])


    /* ==========================================
     * TOTAL
     * ========================================== */

    const total =
        subtotal +
        deliveryFee


    /* ==========================================
     * UPDATE QUANTITY IN DATABASE
     * ========================================== */

    const updateQuantity = async (
        cartItemId: number,
        quantity: number
    ) => {

        if (!token) {

            alert(
                "Please login to update your cart."
            )

            return
        }

        if (quantity < 1) {
            return
        }

        try {

            setUpdatingItemId(cartItemId)
            setError("")

            const response =
                await fetch(
                    `/api/cart/items/${cartItemId}?quantity=${quantity}`,
                    {
                        method: "PUT",

                        headers: {
                            Authorization:
                                `Bearer ${token}`,
                        },
                    }
                )

            if (!response.ok) {

                let message =
                    "Unable to update cart item."

                try {

                    const errorData =
                        await response.json()

                    if (errorData?.message) {

                        message =
                            errorData.message
                    }

                } catch {
                    // Backend may return an empty error response.
                }

                throw new Error(message)
            }

            const updatedCart:
                CartResponse =
                await response.json()

            setCart(updatedCart)

        } catch (err) {

            console.error(
                "Failed to update cart:",
                err
            )

            alert(
                err instanceof Error
                    ? err.message
                    : "Unable to update cart item."
            )

        } finally {

            setUpdatingItemId(null)

        }
    }


    /* ==========================================
     * INCREASE QUANTITY
     * ========================================== */

    const increaseQuantity = (
        item: CartItem
    ) => {

        if (
            item.quantity >=
            item.stockQuantity
        ) {

            alert(
                `Only ${item.stockQuantity} item${
                    item.stockQuantity !== 1
                        ? "s"
                        : ""
                } available in stock.`
            )

            return
        }

        updateQuantity(
            item.cartItemId,
            item.quantity + 1
        )
    }


    /* ==========================================
     * DECREASE QUANTITY
     * ========================================== */

    const decreaseQuantity = (
        item: CartItem
    ) => {

        if (item.quantity <= 1) {

            removeItem(
                item.cartItemId
            )

            return
        }

        updateQuantity(
            item.cartItemId,
            item.quantity - 1
        )
    }


    /* ==========================================
     * REMOVE ITEM FROM DATABASE
     * ========================================== */

    const removeItem = async (
        cartItemId: number
    ) => {

        if (!token) {

            alert(
                "Please login to update your cart."
            )

            return
        }

        try {

            setUpdatingItemId(cartItemId)
            setError("")

            const response =
                await fetch(
                    `/api/cart/items/${cartItemId}`,
                    {
                        method: "DELETE",

                        headers: {
                            Authorization:
                                `Bearer ${token}`,
                        },
                    }
                )

            if (!response.ok) {

                throw new Error(
                    "Unable to remove item from cart."
                )
            }

            const updatedCart:
                CartResponse =
                await response.json()

            setCart(updatedCart)

        } catch (err) {

            console.error(
                "Failed to remove cart item:",
                err
            )

            alert(
                err instanceof Error
                    ? err.message
                    : "Unable to remove item from cart."
            )

        } finally {

            setUpdatingItemId(null)

        }
    }


    /* ==========================================
     * CLEAR CART FROM DATABASE
     * ========================================== */

    const clearCart = async () => {

        if (!token) {

            alert(
                "Please login to update your cart."
            )

            return
        }

        try {

            setClearingCart(true)
            setError("")

            const response =
                await fetch(
                    "/api/cart",
                    {
                        method: "DELETE",

                        headers: {
                            Authorization:
                                `Bearer ${token}`,
                        },
                    }
                )

            if (!response.ok) {

                throw new Error(
                    "Unable to clear cart."
                )
            }

            const updatedCart:
                CartResponse =
                await response.json()

            setCart(updatedCart)

        } catch (err) {

            console.error(
                "Failed to clear cart:",
                err
            )

            alert(
                err instanceof Error
                    ? err.message
                    : "Unable to clear cart."
            )

        } finally {

            setClearingCart(false)

        }
    }


    /* ==========================================
     * GROUP CART ITEMS BY STORE
     * ========================================== */

    const storeGroups =
        cartItems.reduce(
            (
                groups: Record<number, CartItem[]>,
                item
            ) => {

                if (!groups[item.storeId]) {
                    groups[item.storeId] = []
                }

                groups[item.storeId].push(item)

                return groups

            },
            {}
        )

    const storeIds =
        Object.keys(storeGroups).map(
            Number
        )


    /* ==========================================
     * CHECKOUT
     * ========================================== */

    const handleCheckout = () => {

        if (cartItems.length === 0) {

            alert(
                "Your cart is empty."
            )

            return
        }

        onCheckout()
    }


    return (

        <div className="customer-dashboard">


            {/* ==================================
             * HEADER
             * ================================== */}

            <header className="customer-header">

                {/* LOGO */}

                <button
                    className="customer-logo"
                    type="button"
                    onClick={onHome}
                >

                    <span className="logo-icon">
                        🛒
                    </span>

                    <span>
                        LocalMart
                    </span>

                </button>


                {/* SEARCH */}

                <div className="customer-search">

                    <span className="search-icon">
                        ⌕
                    </span>

                    <input
                        type="text"
                        placeholder="Search products, stores..."
                    />

                </div>


                {/* LOCATION */}

                <div className="customer-location">

                    <span>
                        📍
                    </span>

                    <div>

                        <small>
                            Deliver to
                        </small>

                        <strong>
                            {
                                addresses.find(
                                    address =>
                                        address.addressId ===
                                        selectedAddressId
                                )?.city ||
                                "Select address"
                            }
                        </strong>

                    </div>

                </div>


                {/* PROFILE */}

                <div className="customer-profile">

                    <div className="profile-avatar">

                        {user?.email
                                ?.charAt(0)
                                .toUpperCase() ||
                            "U"}

                    </div>

                    <div className="profile-info">

                        <span>
                            Customer
                        </span>

                        <strong>
                            {user?.email ||
                                "User"}
                        </strong>

                    </div>

                </div>


                {/* LOGOUT */}

                <button
                    className="customer-logout"
                    type="button"
                    onClick={logout}
                >
                    Logout
                </button>

            </header>


            {/* ==================================
             * NAVIGATION
             * ================================== */}

            <nav className="customer-nav">

                <button
                    type="button"
                    onClick={onHome}
                >
                    Home
                </button>

                <button
                    type="button"
                    onClick={onStores}
                >
                    Stores
                </button>

                <button
                    type="button"
                    onClick={onCategories}
                >
                    Categories
                </button>

                <button
                    type="button"
                    onClick={onProducts}
                >
                    Products
                </button>

                <button
                    type="button"
                    onClick={onOrders}
                >
                    Orders
                </button>

            </nav>


            {/* ==================================
             * MAIN
             * ================================== */}

            <main className="cart-main">

                <div className="cart-container">


                    {/* ==================================
                     * PAGE HEADING
                     * ================================== */}

                    <div className="cart-page-heading">

                        <div>

                            <button
                                className="cart-back-button"
                                type="button"
                                onClick={onStores}
                            >
                                ← Continue Shopping
                            </button>

                            <h1>
                                Your Cart
                            </h1>

                            <p>

                                {loading

                                    ? "Loading your cart..."

                                    : cartItems.length === 0

                                        ? "Your cart is currently empty"

                                        : `${itemCount} item${
                                            itemCount !== 1
                                                ? "s"
                                                : ""
                                        } in your cart`

                                }

                            </p>

                        </div>


                        {/* CLEAR CART */}

                        {cartItems.length > 0 && (

                            <button
                                className="cart-clear-button"
                                type="button"
                                onClick={clearCart}
                                disabled={clearingCart}
                            >
                                {clearingCart
                                    ? "Clearing..."
                                    : "Clear Cart"}
                            </button>

                        )}

                    </div>


                    {/* ==================================
                     * LOADING
                     * ================================== */}

                    {loading ? (

                        <section className="cart-empty">

                            <div className="cart-empty-icon">
                                🛒
                            </div>

                            <h2>
                                Loading your cart...
                            </h2>

                            <p>
                                Please wait while we load
                                your cart.
                            </p>

                        </section>

                    ) : error ? (

                        /* ==================================
                         * ERROR
                         * ================================== */

                        <section className="cart-empty">

                            <div className="cart-empty-icon">
                                ⚠️
                            </div>

                            <h2>
                                Unable to load cart
                            </h2>

                            <p>
                                {error}
                            </p>

                            <button
                                className="cart-shop-button"
                                type="button"
                                onClick={loadCart}
                            >
                                Try Again
                            </button>

                        </section>

                    ) : cartItems.length === 0 ? (

                        /* ==================================
                         * EMPTY CART
                         * ================================== */

                        <section className="cart-empty">

                            <div className="cart-empty-icon">
                                🛒
                            </div>

                            <h2>
                                Your cart is empty
                            </h2>

                            <p>
                                Looks like you haven't added
                                anything to your cart yet.
                            </p>

                            <button
                                className="cart-shop-button"
                                type="button"
                                onClick={onStores}
                            >
                                Browse Stores
                            </button>

                        </section>

                    ) : (

                        /* ==================================
                         * CART CONTENT
                         * ================================== */

                        <div className="cart-layout">


                            {/* ==================================
                             * LEFT SIDE
                             * ================================== */}

                            <section className="cart-items-section">


                                {/* ==================================
                                 * STORE GROUPS
                                 * ================================== */}

                                {storeIds.map(
                                    (storeId) => {

                                        const items =
                                            storeGroups[
                                                storeId
                                                ]

                                        const storeName =
                                            items[0]
                                                ?.storeName ||
                                            "Local Store"


                                        return (

                                            <div
                                                className="cart-store-group"
                                                key={storeId}
                                            >


                                                {/* STORE INFO */}

                                                <div className="cart-store-info">

                                                    <div className="cart-store-icon">
                                                        🏪
                                                    </div>

                                                    <div>

                                                        <span>
                                                            Shopping from
                                                        </span>

                                                        <strong>
                                                            {storeName}
                                                        </strong>

                                                    </div>

                                                </div>


                                                {/* CART ITEMS */}

                                                <div className="cart-items">

                                                    {items.map(
                                                        (item) => {

                                                            const isUpdating =
                                                                updatingItemId ===
                                                                item.cartItemId

                                                            return (

                                                                <article
                                                                    className="cart-item"
                                                                    key={item.cartItemId}
                                                                >


                                                                    {/* PRODUCT IMAGE */}

                                                                    <div className="cart-item-image">

                                                                        {item.icon ||
                                                                            "🛒"}

                                                                    </div>


                                                                    {/* PRODUCT DETAILS */}

                                                                    <div className="cart-item-details">

                                                                        <span className="cart-item-category">
                                                                            {
                                                                                item.category
                                                                            }
                                                                        </span>

                                                                        <h3>
                                                                            {
                                                                                item.productName
                                                                            }
                                                                        </h3>

                                                                        <p>
                                                                            {
                                                                                item.unit
                                                                            }
                                                                        </p>

                                                                        <strong className="cart-item-price">

                                                                            ₹
                                                                            {
                                                                                Number(
                                                                                    item.price
                                                                                ).toFixed(0)
                                                                            }

                                                                        </strong>

                                                                    </div>


                                                                    {/* QUANTITY */}

                                                                    <div className="cart-item-quantity">

                                                                        <button
                                                                            type="button"
                                                                            disabled={
                                                                                isUpdating
                                                                            }
                                                                            onClick={() =>
                                                                                decreaseQuantity(
                                                                                    item
                                                                                )
                                                                            }
                                                                        >
                                                                            −
                                                                        </button>

                                                                        <span>
                                                                            {
                                                                                item.quantity
                                                                            }
                                                                        </span>

                                                                        <button
                                                                            type="button"
                                                                            disabled={
                                                                                isUpdating ||
                                                                                item.quantity >=
                                                                                item.stockQuantity
                                                                            }
                                                                            onClick={() =>
                                                                                increaseQuantity(
                                                                                    item
                                                                                )
                                                                            }
                                                                        >
                                                                            +
                                                                        </button>

                                                                    </div>


                                                                    {/* TOTAL */}

                                                                    <div className="cart-item-total">

                                                                        <strong>

                                                                            ₹
                                                                            {Number(
                                                                                item.itemTotal
                                                                            ).toFixed(0)}

                                                                        </strong>

                                                                        <button
                                                                            className="cart-remove-button"
                                                                            type="button"
                                                                            disabled={
                                                                                isUpdating
                                                                            }
                                                                            onClick={() =>
                                                                                removeItem(
                                                                                    item.cartItemId
                                                                                )
                                                                            }
                                                                        >
                                                                            {isUpdating
                                                                                ? "Updating..."
                                                                                : "Remove"}
                                                                        </button>

                                                                    </div>

                                                                </article>

                                                            )

                                                        }
                                                    )}

                                                </div>

                                            </div>

                                        )

                                    }
                                )}

                            </section>


                            {/* ==================================
                             * RIGHT SIDE
                             * ================================== */}

                            <aside className="cart-summary">

                                <h2>
                                    Order Summary
                                </h2>


                                <div className="cart-summary-row">

                                    <span>
                                        Subtotal
                                    </span>

                                    <strong>
                                        ₹
                                        {subtotal.toFixed(0)}
                                    </strong>

                                </div>


                                <div className="cart-summary-row">

                                    <span>
                                        Delivery Fee
                                    </span>

                                    <strong>

                                        {loadingDeliveryFee
                                            ? "Calculating..."
                                            : deliveryFeeError
                                                ? "--"
                                                : `₹${deliveryFee.toFixed(0)}`}

                                    </strong>

                                </div>


                                {deliveryDistanceKm !== null &&
                                    !loadingDeliveryFee &&
                                    !deliveryFeeError && (

                                        <div
                                            style={{
                                                fontSize: "12px",
                                                color: "#6b7280",
                                                textAlign: "right",
                                                marginTop: "-6px",
                                                marginBottom: "8px",
                                            }}
                                        >

                                            Delivery distance:{" "}

                                            {deliveryDistanceKm.toFixed(2)}

                                            {" "}km

                                        </div>

                                    )}


                                {!loadingAddress &&
                                    addresses.length === 0 && (

                                        <div
                                            style={{
                                                fontSize: "12px",
                                                color: "#6b7280",
                                                marginTop: "4px",
                                                marginBottom: "8px",
                                            }}
                                        >
                                            Add a delivery address at
                                            checkout to calculate the
                                            delivery fee.
                                        </div>

                                    )}


                                <div className="cart-summary-divider" />


                                <div className="cart-summary-total">

                                    <span>
                                        Total
                                    </span>

                                    <strong>
                                        ₹
                                        {total.toFixed(0)}
                                    </strong>

                                </div>


                                <button
                                    className="cart-checkout-button"
                                    type="button"
                                    onClick={
                                        handleCheckout
                                    }
                                    disabled={
                                        loadingDeliveryFee ||
                                        !!deliveryFeeError
                                    }
                                >

                                    {loadingDeliveryFee
                                        ? "Calculating Delivery..."
                                        : "Proceed to Checkout"}

                                    <span>
                                        →
                                    </span>

                                </button>


                                <div className="cart-security">

                                    <span>
                                        🔒
                                    </span>

                                    <p>
                                        Secure checkout
                                    </p>

                                </div>

                            </aside>

                        </div>

                    )}

                </div>

            </main>


            {/* ==================================
             * FOOTER
             * ================================== */}

            <footer className="customer-footer">

                <div className="footer-content">


                    <div className="footer-brand">

                        <div className="footer-logo">
                            🛒 LocalMart
                        </div>

                        <p>
                            Your local stores,
                            delivered to your door.
                        </p>

                    </div>


                    <div className="footer-links">

                        <button
                            type="button"
                            onClick={onHome}
                        >
                            Home
                        </button>

                        <button
                            type="button"
                            onClick={onStores}
                        >
                            Stores
                        </button>

                        <button
                            type="button"
                            onClick={onCategories}
                        >
                            Categories
                        </button>

                        <button
                            type="button"
                            onClick={onProducts}
                        >
                            Products
                        </button>

                        <button
                            type="button"
                            onClick={onOrders}
                        >
                            Orders
                        </button>

                    </div>

                </div>


                <div className="footer-bottom">

                    <span>
                        © 2026 LocalMart
                    </span>

                    <span>
                        Shop local. Live local.
                    </span>

                </div>

            </footer>

        </div>
    )
}

export default Cart