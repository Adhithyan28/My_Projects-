package com.localmart.localmartbackend.controller;

import com.localmart.localmartbackend.dto.ChangePasswordRequest;
import com.localmart.localmartbackend.dto.GoogleAuthRequest;
import com.localmart.localmartbackend.dto.LoginOtpRequest;
import com.localmart.localmartbackend.dto.LoginRequest;
import com.localmart.localmartbackend.dto.RegistrationOtpRequest;
import com.localmart.localmartbackend.dto.UserRegistrationRequest;
import com.localmart.localmartbackend.dto.UserResponse;
import com.localmart.localmartbackend.dto.VerifyOtpRequest;
import com.localmart.localmartbackend.security.JwtService;
import com.localmart.localmartbackend.service.RegistrationVerificationService;
import com.localmart.localmartbackend.service.UserService;
import com.localmart.localmartbackend.service.UserSessionService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;

    private final RegistrationVerificationService
            registrationVerificationService;

    private final UserSessionService userSessionService;

    private final JwtService jwtService;

    public UserController(
            UserService userService,
            RegistrationVerificationService registrationVerificationService,
            UserSessionService userSessionService,
            JwtService jwtService) {

        this.userService =
                userService;

        this.registrationVerificationService =
                registrationVerificationService;

        this.userSessionService =
                userSessionService;

        this.jwtService =
                jwtService;
    }

    // =========================================================
    // REGISTER
    // =========================================================

    @PostMapping("/register")
    public ResponseEntity<UserResponse> register(
            @RequestBody UserRegistrationRequest request) {

        UserResponse response =
                userService.registerUser(request);

        return ResponseEntity.ok(response);
    }

    // =========================================================
    // REGISTER - SEND OTP
    // =========================================================

    @PostMapping("/register/send-otp")
    public ResponseEntity<?> sendRegistrationOtp(
            @RequestBody RegistrationOtpRequest request) {

        registrationVerificationService.sendOtp(
                request.getIdentifier()
        );

        return ResponseEntity.ok(
                Map.of(
                        "success",
                        true,
                        "message",
                        "OTP sent successfully."
                )
        );
    }

    // =========================================================
    // REGISTER - VERIFY OTP
    // =========================================================

    @PostMapping("/register/verify-otp")
    public ResponseEntity<?> verifyRegistrationOtp(
            @RequestBody VerifyOtpRequest request) {

        RegistrationVerificationService
                .RegistrationVerificationResult result =
                registrationVerificationService.verifyOtp(
                        request.getLogin(),
                        request.getOtp()
                );

        return ResponseEntity.ok(
                Map.of(
                        "success",
                        true,
                        "message",
                        "OTP verified successfully.",
                        "registrationToken",
                        result.registrationToken(),
                        "identifier",
                        result.identifier(),
                        "identifierType",
                        result.identifierType()
                )
        );
    }

    // =========================================================
    // LOGIN
    // =========================================================

    @PostMapping("/login")
    public ResponseEntity<UserResponse> login(
            @RequestBody LoginRequest request) {

        UserResponse response =
                userService.loginUser(request);

        return ResponseEntity.ok(response);
    }

    // =========================================================
    // LOGIN - SEND OTP
    // =========================================================

    @PostMapping("/login/send-otp")
    public ResponseEntity<?> sendLoginOtp(
            @RequestBody LoginOtpRequest request) {

        String message =
                userService.sendLoginOtp(request);

        return ResponseEntity.ok(
                Map.of(
                        "success",
                        true,
                        "message",
                        message
                )
        );
    }

    // =========================================================
    // LOGIN - VERIFY OTP
    // =========================================================

    @PostMapping("/login/verify")
    public ResponseEntity<UserResponse> verifyLoginOtp(
            @RequestBody VerifyOtpRequest request) {

        UserResponse response =
                userService.verifyLoginOtp(request);

        return ResponseEntity.ok(response);
    }

    // =========================================================
    // GOOGLE LOGIN
    // =========================================================

    @PostMapping("/google/login")
    public ResponseEntity<UserResponse> googleLogin(
            @RequestBody GoogleAuthRequest request) {

        UserResponse response =
                userService.googleLogin(request);

        return ResponseEntity.ok(response);
    }

    // =========================================================
    // GOOGLE REGISTER
    // =========================================================

    @PostMapping("/google/register")
    public ResponseEntity<?> googleRegister(
            @RequestBody GoogleAuthRequest request) {

        return ResponseEntity.ok(
                userService.googleRegister(request)
        );
    }

    // =========================================================
    // CHANGE PASSWORD
    // =========================================================

    @PostMapping("/change-password")
    public ResponseEntity<?> changePassword(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            )
            String authorizationHeader,
            @RequestBody ChangePasswordRequest request) {

        /*
         * -----------------------------------------------------
         * CHECK AUTHORIZATION HEADER
         * -----------------------------------------------------
         */

        if (authorizationHeader == null ||
                !authorizationHeader.startsWith("Bearer ")) {

            throw new RuntimeException(
                    "Authentication token is required"
            );
        }

        /*
         * -----------------------------------------------------
         * EXTRACT JWT
         * -----------------------------------------------------
         */

        String token =
                authorizationHeader.substring(7);

        /*
         * -----------------------------------------------------
         * CHANGE PASSWORD
         * -----------------------------------------------------
         */

        userService.changePassword(
                token,
                request
        );

        return ResponseEntity.ok(
                Map.of(
                        "success",
                        true,
                        "message",
                        "Password changed successfully."
                )
        );
    }

    // =========================================================
    // LOGOUT
    // =========================================================

    @PostMapping("/logout")
    public ResponseEntity<?> logout(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            )
            String authorizationHeader) {

        /*
         * -----------------------------------------------------
         * CHECK AUTHORIZATION HEADER
         * -----------------------------------------------------
         */

        if (authorizationHeader == null ||
                !authorizationHeader.startsWith("Bearer ")) {

            return ResponseEntity.ok(
                    Map.of(
                            "success",
                            true,
                            "message",
                            "Already logged out."
                    )
            );
        }

        /*
         * -----------------------------------------------------
         * EXTRACT JWT
         * -----------------------------------------------------
         */

        String token =
                authorizationHeader.substring(7);

        /*
         * -----------------------------------------------------
         * CHECK JWT
         * -----------------------------------------------------
         */

        if (!jwtService.isTokenValid(token)) {

            return ResponseEntity.ok(
                    Map.of(
                            "success",
                            true,
                            "message",
                            "Already logged out."
                    )
            );
        }

        /*
         * -----------------------------------------------------
         * EXTRACT SESSION ID
         * -----------------------------------------------------
         */

        String sessionId =
                jwtService.extractSessionId(token);

        /*
         * -----------------------------------------------------
         * DELETE SERVER-SIDE SESSION
         * -----------------------------------------------------
         */

        userSessionService.logout(
                sessionId
        );

        return ResponseEntity.ok(
                Map.of(
                        "success",
                        true,
                        "message",
                        "Logout successful."
                )
        );
    }
}