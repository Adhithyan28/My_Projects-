
import { createContext, useContext, useState } from "react"
import type { ReactNode } from "react"

export interface User {
    userId: number
    email: string
    role: string
    accountStatus: string
    token: string
    passwordChangeRequired: boolean
}

interface AuthContextType {
    user: User | null
    login: (userData: User) => void
    logout: () => Promise<void>
}

const AuthContext =
    createContext<AuthContextType | undefined>(undefined)

interface AuthProviderProps {
    children: ReactNode
}

export function AuthProvider({
    children
}: AuthProviderProps) {

    const [user, setUser] =
        useState<User | null>(() => {

            const savedUser =
                localStorage.getItem(
                    "localmart_user"
                )

            if (!savedUser) {
                return null
            }

            try {

                return JSON.parse(
                    savedUser
                )

            } catch {

                localStorage.removeItem(
                    "localmart_user"
                )

                return null
            }
        })


    const login = (userData: User) => {

        setUser(userData)

        localStorage.setItem(
            "localmart_user",
            JSON.stringify(userData)
        )
    }


    const logout = async () => {

        const savedUser =
            localStorage.getItem(
                "localmart_user"
            )

        /*
         * Tell the backend to delete the
         * server-side session.
         */
        if (savedUser) {

            try {

                const parsedUser =
                    JSON.parse(savedUser)

                if (parsedUser?.token) {

                    await fetch(
                        "http://localhost:8080/api/users/logout",
                        {
                            method: "POST",

                            headers: {
                                Authorization:
                                    `Bearer ${parsedUser.token}`
                            }
                        }
                    )
                }

            } catch (error) {

                console.error(
                    "Logout request failed:",
                    error
                )
            }
        }

        /*
         * Always clear the frontend authentication
         * state, even if the backend request fails.
         */
        setUser(null)

        localStorage.removeItem(
            "localmart_user"
        )
    }


    return (
        <AuthContext.Provider
            value={{
                user,
                login,
                logout
            }}
        >
            {children}
        </AuthContext.Provider>
    )
}


export function useAuth() {

    const context =
        useContext(AuthContext)

    if (context === undefined) {

        throw new Error(
            "useAuth must be used inside AuthProvider"
        )
    }

    return context
}
