
        package com.localmart.localmartbackend.smsotp.service;

import com.localmart.localmartbackend.service.MessageCentralOtpService;
import com.localmart.localmartbackend.smsotp.model.SmsOtpSession;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class SmsOtpFlowService {

    /*
     * Temporary SMS OTP sessions.
     *
     * Key   = normalized mobile number
     * Value = SMS OTP session
     */
    private final Map<String, SmsOtpSession> otpSessions =
            new ConcurrentHashMap<>();

    private final MessageCentralOtpService messageCentralOtpService;

    public SmsOtpFlowService(
            MessageCentralOtpService messageCentralOtpService) {

        this.messageCentralOtpService =
                messageCentralOtpService;
    }

    /*
     * SEND SMS OTP
     */
    public void sendOtp(String mobileNumber) {

        String normalizedMobile =
                normalizeIndianMobileNumber(mobileNumber);

        /*
         * Ask Message Central to generate
         * and send the OTP.
         *
         * Message Central returns a verificationId.
         */
        String verificationId =
                messageCentralOtpService.sendSmsOtp(
                        normalizedMobile
                );

        LocalDateTime createdAt =
                LocalDateTime.now();

        LocalDateTime expiresAt =
                createdAt.plusMinutes(5);

        /*
         * Store the verification session.
         */
        SmsOtpSession session =
                new SmsOtpSession(
                        normalizedMobile,
                        verificationId,
                        createdAt,
                        expiresAt
                );

        otpSessions.put(
                normalizedMobile,
                session
        );
    }

    /*
     * VERIFY SMS OTP
     */
    public void verifyOtp(
            String mobileNumber,
            String otp) {

        String normalizedMobile =
                normalizeIndianMobileNumber(mobileNumber);

        if (otp == null || otp.isBlank()) {

            throw new IllegalArgumentException(
                    "OTP is required."
            );
        }

        /*
         * Find the OTP session using
         * the mobile number.
         */
        SmsOtpSession session =
                otpSessions.get(normalizedMobile);

        if (session == null) {

            throw new RuntimeException(
                    "No OTP session found."
            );
        }

        /*
         * Check whether our temporary
         * session has expired.
         */
        if (session.isExpired()) {

            otpSessions.remove(
                    normalizedMobile
            );

            throw new RuntimeException(
                    "OTP has expired."
            );
        }

        /*
         * Ask Message Central to verify
         * the entered OTP.
         */
        boolean verified =
                messageCentralOtpService.verifyOtp(
                        session.getVerificationId(),
                        otp.trim()
                );

        if (!verified) {

            throw new RuntimeException(
                    "Invalid OTP."
            );
        }

        /*
         * Mark this session as verified.
         */
        session.setVerified(true);

        /*
         * OTP is single-use.
         *
         * Remove the session after
         * successful verification.
         */
        otpSessions.remove(
                normalizedMobile
        );
    }

    /*
     * NORMALIZE INDIAN MOBILE NUMBER
     */
    private String normalizeIndianMobileNumber(
            String mobileNumber) {

        if (mobileNumber == null
                || mobileNumber.isBlank()) {

            throw new IllegalArgumentException(
                    "Mobile number is required."
            );
        }

        String cleaned =
                mobileNumber
                        .trim()
                        .replaceAll(
                                "[^0-9]",
                                ""
                        );

        /*
         * Accept:
         *
         * 9876543210
         * 919876543210
         */
        if (cleaned.startsWith("91")
                && cleaned.length() == 12) {

            cleaned =
                    cleaned.substring(2);
        }

        if (cleaned.length() != 10) {

            throw new IllegalArgumentException(
                    "Invalid Indian mobile number."
            );
        }

        if (!cleaned.matches(
                "^[6-9][0-9]{9}$"
        )) {

            throw new IllegalArgumentException(
                    "Invalid Indian mobile number."
            );
        }

        return cleaned;
    }
}
