import { useState } from "react"
import { useAuth } from "../context/AuthContext"

import {
    DeliveryPartnerLocationProvider
} from "../context/DeliveryPartnerLocationContext"

import DeliveryPartnerSidebar
    from "../components/delivery-partner/DeliveryPartnerSidebar"

import DeliveryPartnerHome
    from "../components/delivery-partner/DeliveryPartnerHome"

import DeliveryPartnerLocation
    from "../components/delivery-partner/DeliveryPartnerLocation"

import DeliveryPartnerDeliveries
    from "../components/delivery-partner/DeliveryPartnerDeliveries"

import DeliveryPartnerProfile
    from "../components/delivery-partner/DeliveryPartnerProfile"

import "./DeliveryPartnerDashboard.css"

type DeliveryPartnerPage =
    | "dashboard"
    | "deliveries"
    | "location"
    | "profile"

function DeliveryPartnerDashboard() {

    const { logout } = useAuth()

    const [activePage, setActivePage] =
        useState<DeliveryPartnerPage>("dashboard")

    const renderPage = () => {

        switch (activePage) {

            case "deliveries":
                return <DeliveryPartnerDeliveries />

            case "location":
                return <DeliveryPartnerLocation />

            case "profile":
                return <DeliveryPartnerProfile />

            case "dashboard":
            default:
                return <DeliveryPartnerHome />
        }
    }

    return (

        <div className="delivery-dashboard">

            <DeliveryPartnerSidebar
                activePage={activePage}
                onNavigate={setActivePage}
                onLogout={logout}
            />

            <DeliveryPartnerLocationProvider>

                <main className="delivery-main">

                    {renderPage()}

                </main>

            </DeliveryPartnerLocationProvider>

        </div>
    )
}

export default DeliveryPartnerDashboard