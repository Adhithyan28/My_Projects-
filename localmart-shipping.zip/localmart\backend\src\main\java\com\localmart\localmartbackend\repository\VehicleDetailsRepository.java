
        package com.localmart.localmartbackend.repository;

import com.localmart.localmartbackend.entity.VehicleDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface VehicleDetailsRepository extends JpaRepository<VehicleDetails, Long> {

    boolean existsByVehicleNumber(String vehicleNumber);
}

