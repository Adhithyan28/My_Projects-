package com.localmart.localmartbackend.controller;

import com.localmart.localmartbackend.dto.DeliveryPartnerProfileResponse;
import com.localmart.localmartbackend.dto.UpdateDeliveryPartnerProfileRequest;
import com.localmart.localmartbackend.service.DeliveryPartnerProfileService;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/delivery-partner/profile")
public class DeliveryPartnerProfileController {

    private final DeliveryPartnerProfileService
            deliveryPartnerProfileService;

    public DeliveryPartnerProfileController(
            DeliveryPartnerProfileService deliveryPartnerProfileService) {

        this.deliveryPartnerProfileService =
                deliveryPartnerProfileService;
    }

    @GetMapping
    public ResponseEntity<DeliveryPartnerProfileResponse> getProfile(
            Authentication authentication) {

        System.out.println(
                "PROFILE CONTROLLER -> REACHED GET"
        );

        Long userId =
                getAuthenticatedUserId(authentication);

        System.out.println(
                "PROFILE CONTROLLER -> USER ID = "
                        + userId
        );

        DeliveryPartnerProfileResponse response =
                deliveryPartnerProfileService.getProfile(userId);

        return ResponseEntity.ok(response);
    }

    @PutMapping
    public ResponseEntity<DeliveryPartnerProfileResponse> updateProfile(
            Authentication authentication,
            @RequestBody UpdateDeliveryPartnerProfileRequest request) {

        System.out.println(
                "PROFILE CONTROLLER -> REACHED PUT"
        );

        Long userId =
                getAuthenticatedUserId(authentication);

        System.out.println(
                "PROFILE CONTROLLER -> USER ID = "
                        + userId
        );

        DeliveryPartnerProfileResponse response =
                deliveryPartnerProfileService.updateProfile(
                        userId,
                        request
                );

        return ResponseEntity.ok(response);
    }

    private Long getAuthenticatedUserId(
            Authentication authentication) {

        if (authentication == null
                || authentication.getPrincipal() == null) {

            throw new IllegalStateException(
                    "Authenticated user not found"
            );
        }

        Object principal =
                authentication.getPrincipal();

        if (!(principal instanceof Long)) {

            throw new IllegalStateException(
                    "Invalid authenticated user"
            );
        }

        return (Long) principal;
    }
}