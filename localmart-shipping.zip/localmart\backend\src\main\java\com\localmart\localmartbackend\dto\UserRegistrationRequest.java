package com.localmart.localmartbackend.dto;

import java.math.BigDecimal;

public class UserRegistrationRequest {

    private String registrationToken;

    private String email;
    private String password;
    private String role;

    private String firstName;
    private String lastName;

    private String fullName;
    private String ownerName;

    private String businessName;
    private String businessType;
    private String gstNumber;

    private String phone;

    private String addressLine;
    private String city;
    private String state;
    private String pincode;

    private BigDecimal latitude;
    private BigDecimal longitude;

    private String vehicleType;
    private String vehicleNumber;
    private String drivingLicenceNumber;


    // ============================================================
    // REGISTRATION TOKEN
    // ============================================================

    public String getRegistrationToken() {
        return registrationToken;
    }

    public void setRegistrationToken(
            String registrationToken) {

        this.registrationToken =
                registrationToken;
    }


    // ============================================================
    // EMAIL
    // ============================================================

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }


    // ============================================================
    // PASSWORD
    // ============================================================

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }


    // ============================================================
    // ROLE
    // ============================================================

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }


    // ============================================================
    // NAME
    // ============================================================

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /*
     * Kept for backward compatibility with the
     * current frontend/request structure.
     */
    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }


    // ============================================================
    // STORE
    // ============================================================

    public String getBusinessName() {
        return businessName;
    }

    public void setBusinessName(String businessName) {
        this.businessName = businessName;
    }

    public String getBusinessType() {
        return businessType;
    }

    public void setBusinessType(String businessType) {
        this.businessType = businessType;
    }

    public String getGstNumber() {
        return gstNumber;
    }

    public void setGstNumber(String gstNumber) {
        this.gstNumber = gstNumber;
    }


    // ============================================================
    // PHONE
    // ============================================================

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }


    // ============================================================
    // ADDRESS
    // ============================================================

    public String getAddressLine() {
        return addressLine;
    }

    public void setAddressLine(String addressLine) {
        this.addressLine = addressLine;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }


    // ============================================================
    // LOCATION
    // ============================================================

    public BigDecimal getLatitude() {
        return latitude;
    }

    public void setLatitude(BigDecimal latitude) {
        this.latitude = latitude;
    }

    public BigDecimal getLongitude() {
        return longitude;
    }

    public void setLongitude(BigDecimal longitude) {
        this.longitude = longitude;
    }


    // ============================================================
    // VEHICLE
    // ============================================================

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getVehicleNumber() {
        return vehicleNumber;
    }

    public void setVehicleNumber(String vehicleNumber) {
        this.vehicleNumber = vehicleNumber;
    }

    public String getDrivingLicenceNumber() {
        return drivingLicenceNumber;
    }

    public void setDrivingLicenceNumber(
            String drivingLicenceNumber) {

        this.drivingLicenceNumber =
                drivingLicenceNumber;
    }
}