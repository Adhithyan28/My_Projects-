# LocalMart — User Management

## 1. Overview

User management in LocalMart is responsible for managing the identity, role, account status, profile information, and lifecycle of users within the platform.

LocalMart supports multiple user types:

* Customer
* Store Owner
* Delivery Partner
* Administrator

Each user has a common account in the `users` data model, while role-specific information is maintained separately where required.

The user-management architecture is designed around the principle:

```text
Common User Information
        +
Role
        +
Role-Specific Information
        +
Account Status
        +
Application / Approval Status
```

This allows LocalMart to maintain a common identity model while supporting different responsibilities for each type of user.

---

# 2. User Management vs Authentication

User management and authentication are related but serve different purposes.

### Authentication

Authentication answers:

> "Who is this user?"

Examples include:

* Email/password login
* Mobile/password login
* Email OTP
* SMS OTP
* Google login
* X login
* JWT sessions

Authentication is documented in:

```text
docs/03-authentication.md
```

### User Management

User management answers:

> "What information and permissions does this user have within LocalMart?"

It includes:

* User identity
* Email
* Mobile number
* Name
* Role
* Account status
* Profile information
* Addresses
* Role-specific information
* Approval/application status

Therefore:

```text
Authentication
       ↓
Identifies the user

User Management
       ↓
Manages the user's LocalMart account
```

---

# 3. User Roles

LocalMart uses a role-based user model.

The current role codes are:

| Role             | Code | Purpose                              |
| ---------------- | ---: | ------------------------------------ |
| CUSTOMER         |    1 | Shops for products and places orders |
| STORE_OWNER      |    2 | Manages a store and its products     |
| DELIVERY_PARTNER |    3 | Handles order delivery               |
| ADMIN            |    4 | Manages and supervises the platform  |

The role determines which parts of the application the user can access.

Conceptually:

```text
                       USER
                         |
             +-----------+-----------+
             |           |           |
             v           v           v
        CUSTOMER   STORE_OWNER   DELIVERY_PARTNER
             |           |           |
             |           |           |
             +-----------+-----------+
                         |
                        ADMIN
```

The actual authorization rules are handled by the security layer.

---

# 4. Common User Account

The `User` entity represents the common identity of a LocalMart account.

The common account contains information such as:

```text
User
├── User ID
├── First Name
├── Last Name
├── Email
├── Phone
├── Password
├── Google ID (when applicable)
├── X ID (when applicable)
├── Account Status
├── Created At
└── Updated At
```

This common structure prevents duplicate identity information from being stored separately for every role.

For example, a store owner does not need a completely separate authentication identity from the common `User` account.

Instead:

```text
User
  |
  +--> Role = STORE_OWNER
  |
  +--> StoreDetails
```

---

# 5. User ID

Every LocalMart user has a unique user identifier.

The user ID is used as the common reference point between the user's account and other entities.

For example:

```text
User
 |
 +---- Role
 |
 +---- Address
 |
 +---- StoreDetails
 |
 +---- DeliveryPartner
 |
 +---- UserSession
 |
 +---- Orders
 |
 +---- Cart
```

This creates a central identity relationship across the system.

The user ID is therefore one of the most important identifiers in the LocalMart backend.

---

# 6. Name Management

LocalMart stores a user's name using:

```text
First Name
Last Name
```

The registration system can also derive first and last names from a supplied full name.

For social registration, the name can originate from the verified external account.

The general process is:

```text
User-provided name
        OR
Google account name
        OR
X account name
        ↓
Name processing
        ↓
First Name + Last Name
        ↓
User
```

This allows different registration methods to ultimately produce the same internal user representation.

---

# 7. Email Management

Email is an important user identifier in LocalMart.

It is used for functions including:

* Account registration
* Email OTP delivery
* Login
* Password-related communication
* Google account association
* User identification

Email values are normalized before being used by the backend.

The normalization process includes:

```text
Trim whitespace
      ↓
Convert to lowercase
      ↓
Use normalized email
```

For example:

```text
USER@EXAMPLE.COM
```

becomes:

```text
user@example.com
```

This helps maintain consistency when searching for users.

---

# 8. Mobile Number Management

LocalMart also supports Indian mobile numbers as a user identifier.

The backend normalizes phone numbers before processing them.

The system supports conversion of an Indian number containing the country code into the expected 10-digit representation.

For example:

```text
91XXXXXXXXXX
        ↓
XXXXXXXXXX
```

The normalized number is then used for:

* User lookup
* Registration
* SMS OTP
* Login OTP

The system validates the resulting number using an Indian mobile-number pattern.

---

# 9. Password Management

Passwords are not stored as plaintext.

During registration, the password passes through the configured `PasswordEncoder`.

Conceptually:

```text
Plain Password
      |
      v
PasswordEncoder
      |
      v
Encoded Password
      |
      v
User
      |
      v
Database
```

During password authentication:

```text
Entered Password
      |
      v
PasswordEncoder.matches()
      |
      v
Stored Encoded Password
```

The backend compares the supplied password with the stored encoded value instead of attempting to retrieve the original password.

This is an important security principle of the user-management system.

---

# 10. External Identity Associations

LocalMart can associate an account with external identity providers.

Currently supported external identities include:

```text
Google
X
```

A LocalMart user can therefore have external identifiers associated with the common user account.

Conceptually:

```text
User
 |
 +--> LocalMart identity
 |
 +--> Google ID
 |
 +--> X ID
```

These identifiers allow LocalMart to recognize an existing account when the user authenticates through a supported external provider.

Duplicate checks are performed during social registration to prevent the same external account from being registered multiple times.

---

# 11. Account Status

User accounts have an account status.

The current implementation uses:

| Status   | Code | Meaning                         |
| -------- | ---: | ------------------------------- |
| ACTIVE   |    1 | Account is active               |
| INACTIVE |    2 | Account is not currently active |
| BLOCKED  |    3 | Account has been blocked        |

The account status is different from the user's role.

For example:

```text
Role:
STORE_OWNER

Account Status:
INACTIVE
```

means:

> The user is a store owner, but their account is not currently active.

Therefore:

```text
Role ≠ Account Status
```

They represent different dimensions of the user account.

---

# 12. Account Status Lifecycle

A simplified lifecycle is:

```text
                 Registration
                      |
                      v
             +----------------+
             |    CUSTOMER    |
             |     ACTIVE     |
             +----------------+

             Store Owner /
             Delivery Partner
                      |
                      v
             +----------------+
             |   INACTIVE     |
             +----------------+
                      |
                      v
              Admin approval
                      |
                      v
             Account activation
                      |
                      v
             +----------------+
             |     ACTIVE     |
             +----------------+
```

An account can also become blocked:

```text
ACTIVE
  |
  v
BLOCKED
```

The exact administrative lifecycle is handled by the relevant admin functionality.

---

# 13. Customer Accounts

Customers are the primary shopping users of LocalMart.

A customer account can be associated with:

```text
User
 |
 +--> CUSTOMER Role
 |
 +--> Address
 |
 +--> Cart
 |
 +--> Orders
 |
 +--> User Session
```

Customers can use their account to:

* Browse stores
* Browse products
* Manage addresses
* Add products to the cart
* Calculate delivery charges
* Place orders
* Make payments
* Track orders
* View order history

The customer account starts as active after successful normal registration.

---

# 14. Store Owner Accounts

Store owners represent businesses participating in LocalMart.

Their common identity is stored in the user account, while business information is maintained separately.

Conceptually:

```text
User
 |
 +--> STORE_OWNER Role
 |
 +--> StoreDetails
 |
 +--> Address
 |
 +--> ApplicationRequest
```

Store-owner registration includes additional information such as:

* Business name
* Business type
* GST number when applicable

A store owner also goes through an application/approval process.

The account initially has an inactive status and the application begins in a pending state.

---

# 15. Delivery Partner Accounts

Delivery partners are responsible for delivering customer orders.

Their account structure can be represented as:

```text
User
 |
 +--> DELIVERY_PARTNER Role
 |
 +--> DeliveryPartner
 |       |
 |       +--> Vehicle
 |
 +--> Address
 |
 +--> ApplicationRequest
```

Delivery-partner registration requires information such as:

* Vehicle type
* Vehicle number
* Driving licence number

Vehicle information is maintained separately from the common user identity.

This allows vehicle information to be managed independently while still being associated with the delivery partner.

---

# 16. Administrator Accounts

Administrators have the highest-level management responsibilities within LocalMart.

The administrator role is represented by:

```text
ADMIN
```

with role code:

```text
4
```

The normal public registration flow does not accept `ADMIN` as a self-registration role.

This is an important distinction:

```text
Customer
Store Owner
Delivery Partner
        |
        v
Public registration

Administrator
        |
        v
Controlled administrative account
```

Administrators can participate in platform-management operations such as reviewing applications and managing platform users.

---

# 17. Role-Specific Data

LocalMart avoids putting every possible role-specific field into the common `User` structure.

Instead, role-specific information is maintained separately.

### Store owner

```text
User
  |
  +--> StoreDetails
```

### Delivery partner

```text
User
  |
  +--> DeliveryPartner
            |
            +--> VehicleDetails
```

This design provides separation between:

```text
Identity information
```

and:

```text
Business / operational information
```

---

# 18. Application and Approval Management

Store owners and delivery partners require platform approval.

When such a user registers, an `ApplicationRequest` is created.

The application contains information such as:

```text
User ID
Application Type
Application Status
Submitted At
```

Application types include:

| Application      | Code |
| ---------------- | ---: |
| STORE_OWNER      |    1 |
| DELIVERY_PARTNER |    2 |

Application statuses include:

| Status   | Code |
| -------- | ---: |
| PENDING  |    1 |
| APPROVED |    2 |
| REJECTED |    3 |

The relationship is:

```text
User
 |
 v
ApplicationRequest
 |
 +--> Application Type
 |
 +--> Application Status
 |
 +--> Submission Time
```

---

# 19. Account Status and Application Status

Account status and application status are separate concepts.

For example:

```text
Account Status:
INACTIVE

Application Status:
PENDING
```

This means:

> The user's account exists, but the user's application is still waiting for administrative review.

Another possible state is:

```text
Account Status:
INACTIVE

Application Status:
REJECTED
```

This means the application has been rejected.

The backend checks application status when determining whether an inactive account can proceed with login.

---

# 20. User Lookup

The backend can locate a user using supported identifiers.

The primary lookup mechanisms include:

```text
Email
Phone
Google ID
X ID
User ID
```

For email:

```text
Email
  ↓
Normalize
  ↓
UserRepository
  ↓
User
```

For mobile:

```text
Mobile Number
  ↓
Normalize
  ↓
UserRepository
  ↓
User
```

For social authentication:

```text
Google ID / X ID
       ↓
UserRepository
       ↓
User
```

This allows different authentication methods to resolve to the same LocalMart account.

---

# 21. Duplicate Prevention

User management contains several duplicate checks.

The system checks for duplicate:

```text
Email
Mobile number
Google account
X account
GST number
Vehicle number
Driving licence number
```

These checks protect the uniqueness of important identity and business information.

For example:

```text
New Email
   |
   v
existsByEmail()
   |
 +-----+
 |     |
Yes    No
 |     |
Reject Continue
```

The same principle is applied to other unique identifiers where appropriate.

---

# 22. User Sessions

A user account and a login session are separate concepts.

The user represents:

```text
Who the person is
```

The session represents:

```text
A particular authenticated login
```

Conceptually:

```text
User
 |
 +--> Session 1
 |
 +--> Session 2
 |
 +--> Session 3
```

LocalMart uses `UserSessionService` to manage server-side sessions.

When authentication succeeds, a session can be created for the user.

The session ID is then included in the generated JWT.

Conceptually:

```text
User
 ↓
Create Session
 ↓
Session ID
 ↓
Generate JWT
 ↓
Client
```

---

# 23. JWT and User Management

JWT is primarily part of authentication, but it carries user-management-related identity information required by the security layer.

The generated token includes information associated with:

```text
User ID
Email
Role
Session ID
```

The security system can then identify the authenticated user during subsequent requests.

Conceptually:

```text
HTTP Request
      |
      v
Authorization: Bearer JWT
      |
      v
JWT validation
      |
      v
User identity
      |
      v
Role / authorization
      |
      v
Protected endpoint
```

JWT therefore connects authentication with user authorization without replacing the underlying user record.

---

# 24. User Profile and Address

A user's address is maintained separately from the core user identity.

Conceptually:

```text
User
 |
 +--> Address
```

An address can contain information such as:

```text
Address Line
City
State
Pincode
Latitude
Longitude
Default Address
```

The separation allows a user's identity to remain independent from their physical address.

This is particularly important for LocalMart because location information is required for:

* Store discovery
* Delivery calculations
* Delivery distance
* Order delivery
* Customer address management

---

# 25. User Data Relationships

A simplified user-centered model is:

```text
                         USER
                           |
        +------------------+------------------+
        |                  |                  |
        v                  v                  v
      ROLE              ADDRESS           SESSION
        |
        |
   +----+-----------------------+
   |                            |
   v                            v
STORE OWNER               DELIVERY PARTNER
   |                            |
   v                            v
STORE DETAILS             VEHICLE DETAILS
                                |
                                v
                         DELIVERY PARTNER
```

For business approval:

```text
USER
 |
 v
APPLICATION REQUEST
```

For shopping:

```text
USER
 |
 +--> CART
 |
 +--> ORDER
 |
 +--> PAYMENT
```

This makes the user account the central identity around which the rest of the LocalMart system operates.

---

# 26. User Management Request Flow

A typical protected user-management request follows:

```text
Frontend
   |
   | HTTP Request
   v
Spring Security
   |
   | Validate JWT
   v
Controller
   |
   v
Service
   |
   v
Repository
   |
   v
PostgreSQL
   |
   v
Entity / DTO
   |
   v
HTTP Response
   |
   v
Frontend
```

The exact controller and service involved depends on the operation.

---

# 27. User Creation Flow

The common user creation process is:

```text
Registration
     |
     v
Verify identity
     |
     v
Validate registration data
     |
     v
Check duplicate email/phone
     |
     v
Determine role
     |
     v
Encode password
     |
     v
Create User
     |
     v
Save User
     |
     v
Create Role
     |
     v
Create role-specific data
     |
     v
Create application if required
```

This separates the common user creation operation from role-specific setup.

---

# 28. User Management and Database Design

The user-management design follows a normalized approach.

Instead of creating separate complete user tables such as:

```text
Customers
StoreOwners
DeliveryPartners
Admins
```

the system maintains a common user identity and associates roles and role-specific records with it.

Conceptually:

```text
                 USERS
                   |
                   v
                 ROLES
                   |
        +----------+----------+
        |                     |
        v                     v
 STORE DETAILS        DELIVERY PARTNER
                            |
                            v
                     VEHICLE DETAILS
```

This reduces duplication of common identity information.

---

# 29. User Lifecycle

The overall user lifecycle can be represented as:

```text
                    Registration
                         |
                         v
                  Identity Verified
                         |
                         v
                    User Created
                         |
              +----------+----------+
              |                     |
              v                     v
          CUSTOMER          BUSINESS ROLE
              |                     |
              v                     v
           ACTIVE               INACTIVE
                                    |
                                    v
                              Application Review
                                    |
                          +---------+---------+
                          |                   |
                          v                   v
                       Approved            Rejected
                          |
                          v
                    Account Activation
                          |
                          v
                        ACTIVE
```

An active account may subsequently become blocked according to administrative actions.

---

# 30. User Management Security Principles

The user-management architecture follows several important security principles.

### Password protection

Passwords are encoded before persistence.

### Identity verification

Registration can require verification before account creation.

### Duplicate prevention

Important identifiers are checked before creating accounts.

### Role separation

Different user types receive different roles.

### Account status control

Authentication checks the account's current status.

### Administrative approval

Store owners and delivery partners require an application and approval process.

### Session management

Authenticated users are associated with server-side sessions.

### Token-based authentication

JWTs are used to carry authenticated session information between requests.

---

# 31. Main Backend Components

The user-management functionality is distributed across several backend layers.

### Controller layer

Responsible for receiving HTTP requests and returning responses.

Important controller:

```text
UserController
```

### Service layer

Contains user-management and business logic.

Important services include:

```text
UserService
CustomerService
StoreOwnerService
DeliveryPartnerProfileService
UserSessionService
AdminService
```

### Repository layer

Provides persistence operations.

Important repositories include:

```text
UserRepository
RoleRepository
AddressRepository
ApplicationRequestRepository
StoreDetailsRepository
DeliveryPartnerRepository
VehicleDetailsRepository
UserSessionRepository
```

### Entity layer

Represents persistent domain objects.

Relevant entities include:

```text
User
Role
Address
ApplicationRequest
StoreDetails
DeliveryPartner
VehicleDetails
UserSession
```

---

# 32. Responsibility Separation

| Layer                | Responsibility                               |
| -------------------- | -------------------------------------------- |
| Controller           | HTTP communication                           |
| DTO                  | Request/response data representation         |
| Service              | User-management business rules               |
| Repository           | Database access                              |
| Entity               | Persistent domain representation             |
| Spring Security      | Authentication and authorization integration |
| `PasswordEncoder`    | Password encoding and verification           |
| `UserSessionService` | Login-session management                     |
| JWT service          | Token creation and validation                |
| PostgreSQL           | Persistent storage                           |

The architecture can therefore be summarized as:

```text
HTTP
 ↓
Controller
 ↓
Service
 ↓
Repository
 ↓
Database
```

with security operating around protected requests.

---

# 33. Important Design Distinctions

Several concepts in LocalMart should not be confused.

### User vs Role

```text
User = account identity
Role = responsibility/access category
```

### Role vs Account Status

```text
Role = what the user is
Status = whether the account is active
```

### Account Status vs Application Status

```text
Account Status = account lifecycle
Application Status = approval lifecycle
```

### User vs Session

```text
User = account
Session = authenticated login instance
```

### User vs Role-Specific Data

```text
User = common identity
Role-specific entity = additional information required by that role
```

These distinctions make the architecture easier to understand and maintain.

---

# 34. Example User Structures

### Customer

```text
User
├── Identity
├── Contact Information
├── Password
├── CUSTOMER Role
├── ACTIVE Status
├── Address
├── Cart
└── Orders
```

### Store Owner

```text
User
├── Identity
├── Contact Information
├── Password
├── STORE_OWNER Role
├── Account Status
├── Address
├── StoreDetails
└── ApplicationRequest
```

### Delivery Partner

```text
User
├── Identity
├── Contact Information
├── Password
├── DELIVERY_PARTNER Role
├── Account Status
├── Address
├── DeliveryPartner
├── VehicleDetails
└── ApplicationRequest
```

### Administrator

```text
User
├── Identity
├── ADMIN Role
├── Account Status
└── Administrative permissions
```

---

# 35. User Management Flow Summary

The user-management architecture can be summarized as:

```text
                         USER
                          |
             +------------+------------+
             |            |            |
             v            v            v
           ROLE        STATUS       SESSION
             |
       +-----+------+
       |            |
       v            v
 CUSTOMER      BUSINESS ROLES
                    |
             +------+------+
             |             |
             v             v
       STORE OWNER   DELIVERY PARTNER
             |             |
             v             v
       STORE DETAILS   VEHICLE DETAILS
             |             |
             +------+------+
                    |
                    v
             APPLICATION
                    |
                    v
              ADMIN REVIEW
```

The common identity remains centered on the `User` entity while other entities provide additional information required by the user's role.

---

# 36. Conclusion

LocalMart's user-management system provides a common identity model for all platform participants while separating role, account status, session, address, business, delivery, and approval information.

The core model is:

```text
                    USER
                      |
        +-------------+-------------+
        |             |             |
       ROLE         STATUS        SESSION
        |
        +-------------------+
        |                   |
     CUSTOMER          BUSINESS USER
                            |
                 +----------+----------+
                 |                     |
            STORE OWNER         DELIVERY PARTNER
                 |                     |
          STORE DETAILS          VEHICLE DETAILS
                 |                     |
                 +----------+----------+
                            |
                     APPLICATION
                            |
                       ADMIN REVIEW
```

This structure allows LocalMart to support multiple types of users without duplicating common identity information.

The most important architectural principle is:

> **A LocalMart user is a common identity; role, status, session, and role-specific entities describe how that identity participates in the platform.**

This design provides a foundation for authentication, authorization, customer operations, store management, delivery operations, order processing, and administrative management.
