
import { useState } from "react"
import { useAuth } from "../context/AuthContext"
import StoreOwnerSidebar from "../components/store-owner/StoreOwnerSidebar"
import StoreOwnerHome from "../components/store-owner/StoreOwnerHome"
import StoreOwnerStore from "../components/store-owner/StoreOwnerStore"
import StoreOwnerProducts from "../components/store-owner/StoreOwnerProducts"
import StoreOwnerOrders from "../components/store-owner/StoreOwnerOrders"
import "../components/store-owner/StoreOwnerDashboard.css"

type OwnerPage = "dashboard" | "store" | "products" | "orders"

function StoreOwnerDashboard() {

    const { logout } = useAuth()

    const [activePage, setActivePage] =
        useState<OwnerPage>("dashboard")

    const renderPage = () => {

        switch (activePage) {

            case "store":
                return <StoreOwnerStore />

            case "products":
                return <StoreOwnerProducts />

            case "orders":
                return <StoreOwnerOrders />

            case "dashboard":
            default:
                return <StoreOwnerHome />
        }
    }

    return (

        <div className="owner-dashboard">

            <StoreOwnerSidebar
                activePage={activePage}
                onNavigate={setActivePage}
                onLogout={logout}
            />

            <main className="owner-main">

                {renderPage()}

            </main>

        </div>
    )
}

export default StoreOwnerDashboard
