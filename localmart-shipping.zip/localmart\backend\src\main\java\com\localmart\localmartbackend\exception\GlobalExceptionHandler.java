package com.localmart.localmartbackend.exception;

import com.localmart.localmartbackend.service.UserSessionService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(
            UserSessionService.AccountAlreadyInUseException.class
    )
    public ResponseEntity<ApiErrorResponse> handleAccountAlreadyInUse(
            UserSessionService.AccountAlreadyInUseException exception) {

        ApiErrorResponse response =
                new ApiErrorResponse(
                        false,
                        "ACCOUNT_ALREADY_IN_USE",
                        exception.getMessage()
                );

        return ResponseEntity
                .status(HttpStatus.CONFLICT)
                .body(response);
    }

    public static class ApiErrorResponse {

        private boolean success;
        private String code;
        private String message;

        public ApiErrorResponse() {
        }

        public ApiErrorResponse(
                boolean success,
                String code,
                String message) {

            this.success = success;
            this.code = code;
            this.message = message;
        }

        public boolean isSuccess() {
            return success;
        }

        public void setSuccess(boolean success) {
            this.success = success;
        }

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }
}