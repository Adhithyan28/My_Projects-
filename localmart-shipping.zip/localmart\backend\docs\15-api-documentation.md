# LocalMart — API Documentation

## 1. Overview

LocalMart exposes a REST-based backend API that allows the React frontend and other authorized clients to communicate with the Spring Boot application.

The API follows the general architecture:

```text
React Frontend
      |
      | HTTP + JSON
      v
LocalMart REST API
      |
      v
Spring Boot Controller
      |
      v
Service Layer
      |
      v
Repository Layer
      |
      v
PostgreSQL
```

The backend API is organized around functional modules rather than placing all endpoints inside one controller.

---

# 2. Base URL

The LocalMart backend runs on port `8080` during local development.

The main API base path is:

```text
http://localhost:8080/api
```

Individual modules are exposed below this base path.

For example:

```text
/api/users
/api/cart
/api/orders
```

The frontend can access these endpoints directly or through the configured Vite `/api` proxy.

---

# 3. REST API Architecture

A request to LocalMart generally follows:

```text
HTTP Request
     |
     v
Controller
     |
     v
Service
     |
     v
Repository
     |
     v
Database
```

The response travels in the opposite direction:

```text
Database
     |
     v
Repository
     |
     v
Service
     |
     v
Controller
     |
     v
JSON Response
     |
     v
Frontend
```

---

# 4. API Controllers

The backend currently contains the following main controllers:

```text
controller/
├── AdminController.java
├── AdminDataController.java
├── AdminRequestController.java
├── CartController.java
├── CustomerAddressController.java
├── CustomerController.java
├── DeliveryPartnerLocationController.java
├── DeliveryPartnerProfileController.java
├── LocationController.java
├── OrderController.java
├── ProductController.java
├── StoreController.java
├── StoreOwnerController.java
├── StoreOwnerOrderController.java
├── UserController.java
└── XOAuthController.java
```

There is also a dedicated SMS OTP API:

```text
smsotp/
└── controller/
    └── SmsOtpController.java
```

Each controller provides the HTTP boundary for a specific application area.

---

# 5. HTTP Methods

LocalMart APIs use standard HTTP methods according to the operation being performed.

Common methods include:

| Method   | Typical purpose                |
| -------- | ------------------------------ |
| `GET`    | Retrieve data                  |
| `POST`   | Create or execute an operation |
| `PUT`    | Update existing data           |
| `DELETE` | Delete data                    |

For example:

```text
GET
  → Retrieve products

POST
  → Create an order

PUT
  → Update profile/address/product information

DELETE
  → Delete an address/cart item/resource
```

The exact method for each endpoint is defined by its controller mapping.

---

# 6. JSON Communication

The API communicates using JSON for request and response bodies.

Conceptually:

```text
Frontend
   |
   | JSON Request
   v
Spring Controller
   |
   v
Java DTO
```

and:

```text
Java DTO
   |
   v
Jackson
   |
   v
JSON Response
   |
   v
Frontend
```

Jackson handles JSON serialization and deserialization as part of the Spring Boot web stack.

---

# 7. DTO Architecture

LocalMart uses Data Transfer Objects instead of exposing entity objects directly for many API operations.

The DTO package contains:

```text
dto/
├── AddCartItemRequest.java
├── AdminLoginOtpRequest.java
├── AdminVerifyOtpRequest.java
├── CartItemResponse.java
├── CartResponse.java
├── CreateOrderRequest.java
├── CustomerAddressRequest.java
├── CustomerProfileRequest.java
├── CustomerProfileResponse.java
├── DeliveryFeeRequest.java
├── DeliveryOrderResponse.java
├── DeliveryPartnerAvailabilityRequest.java
├── DeliveryPartnerLocationRequest.java
├── DeliveryPartnerProfileResponse.java
├── GoogleAuthRequest.java
├── LocationSearchRequest.java
├── LocationSearchResponse.java
├── LoginOtpRequest.java
├── OrderItemRequest.java
├── RegistrationOtpRequest.java
├── StoreOwnerDetailsRequest.java
├── StoreOwnerDetailsResponse.java
├── UserRegistrationRequest.java
├── VerifyOtpRequest.java
├── XRegistrationData.java
└── XUserInfo.java
```

DTOs provide an API-facing representation of application data.

---

# 8. Why DTOs Are Used

An entity represents the persistence model.

A DTO represents information exchanged through the API.

Conceptually:

```text
Database Entity
      |
      v
Service
      |
      v
Response DTO
      |
      v
JSON
```

This prevents the REST API from being tightly coupled to the database representation.

DTOs can also be used for:

* Input validation
* Controlling exposed fields
* Structuring API requests
* Structuring API responses
* Separating frontend contracts from persistence models

---

# 9. Authentication API

The authentication endpoints are grouped under:

```text
/api/users
```

The main controller is:

```text
UserController.java
```

---

# 10. User Registration

### Endpoint

```text
POST /api/users/register
```

This endpoint performs normal LocalMart user registration.

The controller receives:

```text
UserRegistrationRequest
```

and delegates registration to:

```text
UserService.registerUser(...)
```

The response is represented using the application's user response model.

The high-level flow is:

```text
Frontend
   |
   | POST /api/users/register
   v
UserController
   |
   v
UserService
   |
   +---- Validate registration
   +---- Validate registration token
   +---- Check duplicate identity
   +---- Hash password
   +---- Create User
   +---- Create Role
   +---- Create role-specific data
   |
   v
Database
```

---

# 11. Registration OTP

### Endpoint

```text
POST /api/users/register/send-otp
```

This endpoint starts identifier verification for registration.

The controller delegates to:

```text
RegistrationVerificationService.sendOtp(...)
```

A successful operation returns a success response indicating that the OTP was sent.

---

# 12. Registration OTP Verification

### Endpoint

```text
POST /api/users/register/verify-otp
```

This endpoint verifies the registration OTP.

The controller delegates to:

```text
RegistrationVerificationService.verifyOtp(...)
```

A successful verification produces a temporary registration authorization/token.

The response includes information such as:

```text
success
message
registrationToken
identifier
identifierType
```

The resulting token is then used during the final registration process.

---

# 13. Login API

### Endpoint

```text
POST /api/users/login
```

This endpoint handles the normal login operation.

The controller delegates to:

```text
UserService.loginUser(...)
```

The login process verifies the supplied credentials and checks account status before establishing an authenticated session.

---

# 14. Login OTP Request

### Endpoint

```text
POST /api/users/login/send-otp
```

The request uses:

```text
LoginOtpRequest
```

The application can determine whether the login identifier represents an email address or mobile number and use the corresponding OTP delivery mechanism.

Conceptually:

```text
Login Identifier
       |
       +---- Email
       |       |
       |       v
       |   Email OTP
       |
       +---- Mobile
               |
               v
            SMS OTP
```

---

# 15. Login OTP Verification

### Endpoint

```text
POST /api/users/login/verify
```

The endpoint verifies the submitted login OTP.

The controller delegates to:

```text
UserService.verifyLoginOtp(...)
```

After successful verification, the application can establish the authenticated LocalMart session and return the authenticated user response containing the JWT.

---

# 16. Google Login

### Endpoint

```text
POST /api/users/google/login
```

The request uses:

```text
GoogleAuthRequest
```

The request contains the Google credential obtained from the frontend.

The backend delegates the operation to:

```text
UserService.googleLogin(...)
```

The Google identity token is verified by:

```text
GoogleTokenVerificationService
```

The flow is:

```text
Google
   |
   v
Google Identity Services
   |
   v
Frontend
   |
   | credential
   v
POST /api/users/google/login
   |
   v
UserService
   |
   v
GoogleTokenVerificationService
   |
   v
Verified identity
   |
   v
LocalMart session + JWT
```

---

# 17. Google Registration

### Endpoint

```text
POST /api/users/google/register
```

This endpoint handles registration using Google authentication.

The frontend sends the Google credential.

The backend verifies the credential before creating the LocalMart account.

---

# 18. Logout

### Endpoint

```text
POST /api/users/logout
```

Logout can receive the user's Bearer token.

The controller:

1. Reads the Authorization header.
2. Validates the JWT.
3. Extracts the session identifier.
4. Delegates logout to `UserSessionService`.

Conceptually:

```text
POST /logout
     |
     v
JWT
     |
     v
Session ID
     |
     v
UserSessionService
     |
     v
Session invalidated
```

---

# 19. SMS OTP API

A dedicated SMS OTP controller exists:

```text
SmsOtpController.java
```

The related DTOs are:

```text
SmsOtpSendRequest.java
SmsOtpVerifyRequest.java
```

The SMS flow is handled through:

```text
SmsOtpFlowService
```

and:

```text
MessageCentralOtpService
```

Conceptually:

```text
Client
   |
   v
SmsOtpController
   |
   v
SmsOtpFlowService
   |
   v
MessageCentralOtpService
   |
   v
Message Central
```

---

# 20. Customer API

Customer-specific endpoints are handled by:

```text
CustomerController.java
```

The customer API provides operations associated with the authenticated customer's profile and customer functionality.

Customer profile request/response models include:

```text
CustomerProfileRequest
CustomerProfileResponse
```

The general architecture is:

```text
Customer
   |
   v
CustomerController
   |
   v
CustomerService
   |
   v
Repository
```

---

# 21. Customer Address API

Customer address operations are handled by:

```text
CustomerAddressController.java
```

and:

```text
CustomerAddressService.java
```

The request DTO is:

```text
CustomerAddressRequest
```

The customer address API supports operations including:

```text
GET
  → Retrieve customer addresses

POST
  → Add address

PUT
  → Update address

DELETE
  → Delete address
```

The exact endpoint paths are determined by the controller mappings.

Address data includes geographic coordinates used by LocalMart's location and delivery functionality.

---

# 22. Store API

Store operations are handled by:

```text
StoreController.java
```

The store API supports store-related operations such as retrieving store information and store-associated products.

The general request flow is:

```text
Frontend
   |
   v
StoreController
   |
   v
StoreService
   |
   v
StoreDetailsRepository
   |
   v
PostgreSQL
```

Store information is retrieved from the database rather than being treated as static frontend data.

---

# 23. Product API

Product operations are handled by:

```text
ProductController.java
```

and:

```text
ProductService.java
```

The persistence layer uses:

```text
ProductRepository.java
```

The product flow is:

```text
ProductController
       |
       v
ProductService
       |
       v
ProductRepository
       |
       v
PostgreSQL
```

Product APIs support the product-browsing and store-owner product-management portions of LocalMart.

---

# 24. Cart API

Cart operations are handled by:

```text
CartController.java
```

and:

```text
CartService.java
```

The relevant persistence components are:

```text
CartRepository
CartItemRepository
```

The cart API uses DTOs including:

```text
AddCartItemRequest
CartItemResponse
CartResponse
```

The architecture is:

```text
Customer
   |
   v
CartController
   |
   v
CartService
   |
   +---- CartRepository
   |
   +---- CartItemRepository
   |
   +---- ProductRepository
   |
   v
PostgreSQL
```

The cart is therefore managed by the backend rather than being only browser-local state.

---

# 25. Cart Endpoints

The frontend currently communicates with the cart API through:

```text
/api/cart
```

Typical cart operations include:

```text
Add item
Update item
Remove item
Retrieve cart
```

The exact HTTP method and sub-path for each operation are defined by `CartController`.

The frontend should use the backend cart state as the authoritative cart state.

---

# 26. Order API

Order operations are handled by:

```text
OrderController.java
```

and:

```text
OrderService.java
```

The order API uses DTOs including:

```text
CreateOrderRequest
OrderItemRequest
DeliveryFeeRequest
```

The general architecture is:

```text
Customer
   |
   v
OrderController
   |
   v
OrderService
   |
   +---- Cart
   +---- Products
   +---- Address
   +---- Store
   +---- Order
   +---- Order Items
   |
   v
PostgreSQL
```

---

# 27. Delivery Fee API

The frontend currently uses:

```text
/api/orders/calculate-delivery-fee
```

with a request containing:

```json
{
  "storeId": "...",
  "addressId": "..."
}
```

The request is represented by:

```text
DeliveryFeeRequest
```

The calculation can use store and customer location information.

Conceptually:

```text
Store
  |
  | coordinates
  v
Distance calculation
  ^
  |
Customer Address
  |
  | coordinates
  v
Delivery fee calculation
```

The backend remains responsible for the final calculation rather than trusting a client-supplied fee.

---

# 28. Store Owner API

Store-owner operations are handled by:

```text
StoreOwnerController.java
```

The store-owner domain includes operations related to:

* Store management
* Store-owner profile/details
* Store products
* Store orders

Store-owner details use DTOs such as:

```text
StoreOwnerDetailsRequest
StoreOwnerDetailsResponse
```

The backend must associate store-owner operations with the authenticated store owner.

---

# 29. Store Owner Order API

Store-owner order operations are separated into:

```text
StoreOwnerOrderController.java
```

This separation allows the store-owner order workflow to have its own API boundary.

Conceptually:

```text
Store Owner
    |
    v
StoreOwnerOrderController
    |
    v
Store-owner order service logic
    |
    v
Order data
```

Authorization must ensure that store owners can access only the order information relevant to their store.

---

# 30. Delivery Partner API

Delivery-partner functionality is divided into profile and location APIs.

Relevant controllers include:

```text
DeliveryPartnerProfileController.java
DeliveryPartnerLocationController.java
```

The related DTOs include:

```text
DeliveryOrderResponse
DeliveryPartnerAvailabilityRequest
DeliveryPartnerLocationRequest
DeliveryPartnerProfileResponse
```

The delivery subsystem uses authenticated delivery-partner operations.

---

# 31. Delivery Partner Orders

The delivery API provides functionality for delivery partners to work with delivery orders.

The lifecycle is:

```text
READY_FOR_PICKUP
       ↓
ACCEPTED
       ↓
PICKED_UP
       ↓
OUT_FOR_DELIVERY
       ↓
DELIVERED
```

The frontend communicates with delivery-related endpoints under:

```text
/api/orders/delivery-partner
```

and related sub-paths for:

```text
Available deliveries
Accepting deliveries
Updating delivery status
```

The backend determines whether the authenticated delivery partner is allowed to perform the requested operation.

---

# 32. Delivery Partner Location API

Delivery-partner location operations are handled by:

```text
DeliveryPartnerLocationController
```

The request DTO is:

```text
DeliveryPartnerLocationRequest
```

The flow is:

```text
Browser
   |
   | navigator.geolocation
   v
Current coordinates
   |
   v
Frontend
   |
   | HTTP request
   v
DeliveryPartnerLocationController
   |
   v
DeliveryPartnerLocationService
   |
   v
DeliveryPartnerLocationRepository
   |
   v
PostgreSQL
```

The browser Geolocation API provides the device's current location; LocalMart's backend stores and manages the application-level location data.

---

# 33. Location API

Location operations are handled by:

```text
LocationController.java
```

The associated DTOs are:

```text
LocationSearchRequest
LocationSearchResponse
```

Location functionality is supported by:

```text
GeocodingService
```

The general flow is:

```text
Frontend
   |
   v
LocationController
   |
   v
GeocodingService
   |
   v
External geocoding service
   |
   v
Location result
```

The exact external provider depends on the current configuration of `GeocodingService`.

---

# 34. Admin API

Administrative functionality is divided among:

```text
AdminController.java
AdminDataController.java
AdminRequestController.java
```

and services:

```text
AdminService.java
AdminDataService.java
AdminRequestService.java
```

The admin APIs provide privileged operations.

These can include areas such as:

* Administrative data
* User/application management
* Store-owner applications
* Delivery-partner applications
* Approval/rejection operations

Admin endpoints must be protected by administrative authorization.

---

# 35. Application Approval API

Application requests are represented using:

```text
ApplicationRequest.java
```

and processed through:

```text
AdminRequestController
AdminRequestService
```

The relevant application states are:

```text
PENDING
APPROVED
REJECTED
```

The flow is:

```text
Store Owner / Delivery Partner
              |
              v
        Registration
              |
              v
      Application Request
              |
              v
            ADMIN
              |
        +-----+-----+
        |           |
     APPROVE      REJECT
```

The resulting state is persisted in the database.

---

# 36. X Authentication API

X authentication is handled by:

```text
XOAuthController.java
```

and:

```text
XOAuthService.java
```

The backend also contains:

```text
XAuthProperties.java
```

and X-related DTOs:

```text
XRegistrationData
XUserInfo
```

The X authentication flow validates the external identity before creating or authenticating the corresponding LocalMart account.

---

# 37. Authentication Headers

Protected LocalMart APIs use Bearer-token authentication.

The standard header is:

```text
Authorization: Bearer <JWT>
```

The request enters the backend security filter chain.

Conceptually:

```text
HTTP Request
     |
     v
Authorization Header
     |
     v
JwtAuthenticationFilter
     |
     v
JWT validation
     |
     v
Authenticated request
```

---

# 38. Public vs Protected APIs

Not every endpoint needs an authenticated user.

Authentication-related endpoints must be reachable before the user has a JWT.

Examples include operations such as:

```text
Registration
Registration OTP
Login
Login OTP
Google authentication
```

Protected business APIs require authentication.

Examples include:

```text
Cart
Customer addresses
Orders
Delivery operations
Store-owner operations
Administrative operations
```

The exact endpoint authorization rules are configured in:

```text
SecurityConfig.java
```

---

# 39. API Authorization

Authentication establishes the user's identity.

Authorization determines whether that identity can perform the requested operation.

The general flow is:

```text
JWT
 |
 v
Authenticated User
 |
 v
Role
 |
 v
Authorization
 |
 +---- CUSTOMER
 +---- STORE_OWNER
 +---- DELIVERY_PARTNER
 +---- ADMIN
```

Business ownership checks can provide an additional layer.

For example:

```text
STORE_OWNER
    |
    v
Is this their store?
    |
    +---- Yes → Continue
    |
    +---- No → Reject
```

---

# 40. API Validation

API requests are validated before being used by business logic.

Examples include:

```text
Required fields
Email format
Phone format
Password requirements
PIN-code format
Latitude range
Longitude range
Quantity
Identifiers
```

DTOs provide a structured boundary for incoming data.

The service layer can then perform business-level validation.

---

# 41. API Error Handling

LocalMart has centralized exception handling through:

```text
GlobalExceptionHandler.java
```

This provides a common place to translate application exceptions into HTTP responses.

The general flow is:

```text
Controller
   |
   v
Service
   |
   X
Exception
   |
   v
GlobalExceptionHandler
   |
   v
HTTP Error Response
```

This avoids placing repetitive exception-handling logic in every controller.

---

# 42. Common API Error Categories

An API request can fail for different reasons.

Typical categories include:

```text
400 Bad Request
```

Invalid request data or business input.

```text
401 Unauthorized
```

Authentication is missing or invalid.

```text
403 Forbidden
```

The user is authenticated but is not authorized to perform the operation.

```text
404 Not Found
```

The requested resource does not exist.

```text
409 Conflict
```

The requested operation conflicts with existing application state, such as duplicate data.

```text
500 Internal Server Error
```

Unexpected server-side failure.

The exact HTTP status returned for each exception is determined by the current exception-handling implementation.

---

# 43. API Security Flow

A protected request follows:

```text
Client
  |
  | HTTP request
  | Authorization: Bearer JWT
  v
RateLimitFilter
  |
  v
Spring Security
  |
  v
JwtAuthenticationFilter
  |
  v
JwtService
  |
  v
UserSessionService
  |
  v
Authorization
  |
  v
Controller
  |
  v
Service
  |
  v
Repository
  |
  v
PostgreSQL
```

This makes security part of the API request pipeline rather than something implemented separately in every endpoint.

---

# 44. API Data Flow Example — Login

```text
POST /api/users/login
        |
        v
UserController
        |
        v
UserService
        |
        +---- UserRepository
        |
        +---- BCrypt
        |
        +---- Account status
        |
        v
UserSessionService
        |
        v
JwtService
        |
        v
UserResponse
        |
        v
JSON
        |
        v
Frontend
```

---

# 45. API Data Flow Example — Add Cart Item

```text
POST /api/cart/...
        |
        v
CartController
        |
        v
CartService
        |
        +---- Validate customer
        +---- Find product
        +---- Find/create cart
        +---- Update cart item
        |
        v
CartRepository
CartItemRepository
        |
        v
PostgreSQL
        |
        v
CartResponse
```

The exact cart sub-path is determined by `CartController`.

---

# 46. API Data Flow Example — Calculate Delivery Fee

```text
POST /api/orders/calculate-delivery-fee
        |
        v
OrderController
        |
        v
OrderService
        |
        +---- Store
        |
        +---- Customer Address
        |
        +---- Coordinates
        |
        v
RoadDistanceService
        |
        v
OSRM
        |
        v
Road distance
        |
        v
Delivery fee calculation
        |
        v
JSON response
```

The backend performs the calculation rather than trusting a fee supplied by the frontend.

---

# 47. API Data Flow Example — Delivery Partner

```text
Delivery Partner
       |
       v
GET /api/orders/delivery-partner/available
       |
       v
OrderController
       |
       v
OrderService
       |
       v
OrderRepository
       |
       v
Available orders
```

After accepting an order:

```text
Delivery Partner
       |
       v
POST /api/orders/delivery-partner/{id}/accept
       |
       v
Backend authorization
       |
       v
Order state update
       |
       v
Database
```

The backend controls the delivery-order state transition.

---

# 48. API Design Principles

LocalMart's API architecture follows several principles.

## 48.1 Controllers Remain Thin

Controllers primarily:

* Receive HTTP requests
* Convert request data into DTOs
* Call services
* Return responses

Business logic belongs primarily in services.

---

## 48.2 Services Contain Business Logic

Services handle operations such as:

```text
Validation
Authentication
Authorization-related business rules
Calculations
Database coordination
External API interaction
```

---

## 48.3 Repositories Handle Persistence

Repositories provide the database-access boundary.

```text
Service
   |
   v
Repository
   |
   v
Database
```

---

## 48.4 DTOs Define API Data Contracts

DTOs prevent the API from being unnecessarily coupled to entity structures.

---

## 48.5 Backend Is Authoritative

The frontend requests operations, but the backend decides whether those operations are valid.

---

# 49. API Module Map

The LocalMart API can be grouped as follows:

| Module             | Main Controller(s)                  | Purpose                                                 |
| ------------------ | ----------------------------------- | ------------------------------------------------------- |
| Authentication     | `UserController`                    | Registration, login, OTP, social authentication, logout |
| SMS OTP            | `SmsOtpController`                  | SMS OTP operations                                      |
| Customer           | `CustomerController`                | Customer functionality                                  |
| Addresses          | `CustomerAddressController`         | Customer address management                             |
| Stores             | `StoreController`                   | Store browsing/management API                           |
| Products           | `ProductController`                 | Product operations                                      |
| Cart               | `CartController`                    | Shopping cart                                           |
| Orders             | `OrderController`                   | Orders and delivery-fee operations                      |
| Store Owner        | `StoreOwnerController`              | Store-owner functionality                               |
| Store Owner Orders | `StoreOwnerOrderController`         | Store-owner order operations                            |
| Delivery Profile   | `DeliveryPartnerProfileController`  | Delivery-partner profile                                |
| Delivery Location  | `DeliveryPartnerLocationController` | Delivery-partner location                               |
| Location           | `LocationController`                | Location/geocoding operations                           |
| Admin              | `AdminController`                   | Administrative operations                               |
| Admin Data         | `AdminDataController`               | Administrative data                                     |
| Admin Requests     | `AdminRequestController`            | Application approvals                                   |
| X OAuth            | `XOAuthController`                  | X authentication                                        |

---

# 50. API Request Lifecycle

The complete LocalMart API lifecycle can be summarized as:

```text
                    HTTP Request
                         |
                         v
                Security Filters
                         |
                         v
                     Controller
                         |
                         v
                     Request DTO
                         |
                         v
                       Service
                         |
              +----------+----------+
              |                     |
              v                     v
         Repository          External Service
              |                     |
              v                     v
          PostgreSQL           API Provider
              |                     |
              +----------+----------+
                         |
                         v
                   Business Result
                         |
                         v
                   Response DTO
                         |
                         v
                      Jackson
                         |
                         v
                    JSON Response
                         |
                         v
                      Frontend
```

---

# 51. API Documentation and Source of Truth

The API documentation should always be kept synchronized with the controller implementation.

The most authoritative locations are:

```text
controller/*.java
dto/*.java
service/*.java
security/SecurityConfig.java
```

The controller mappings determine:

* HTTP method
* URL path
* Request body
* Path variables
* Query parameters
* Response type

The DTO classes determine the API data structure.

The services determine the business behavior behind the endpoint.

---

# 52. API Evolution

As LocalMart grows, the API can be extended without changing the fundamental architecture.

For example:

```text
New Feature
    |
    +---- Controller endpoint
    |
    +---- Request/Response DTO
    |
    +---- Service logic
    |
    +---- Repository operations
    |
    +---- Entity/database changes if required
```

This separation makes the application easier to maintain.

---

# 53. API Architecture Summary

LocalMart exposes a modular REST API built using Spring Boot.

The architecture is:

```text
                 LOCALMART API
                       |
        +--------------+--------------+
        |              |              |
   Authentication   Commerce      Fulfillment
        |              |              |
        v              v              v
      Users         Cart/Order      Delivery
      OTP           Products        Location
      Google        Stores
      X             Payment
        |
        v
     Security
        |
        v
 Controllers
        |
        v
 Services
        |
        v
 Repositories
        |
        v
 PostgreSQL
```

The central API principle is:

> **Controllers expose HTTP endpoints, DTOs define the data exchanged through those endpoints, services implement business logic, repositories handle persistence, and the security layer protects the request before it reaches protected business operations.**

This structure keeps LocalMart's API modular and allows authentication, commerce, store management, payment, order processing, delivery, location services, and administration to evolve as separate but connected modules.
