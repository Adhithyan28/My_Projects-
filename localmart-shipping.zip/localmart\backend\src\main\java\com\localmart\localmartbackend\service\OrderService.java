package com.localmart.localmartbackend.service;

import com.localmart.localmartbackend.dto.CreateOrderRequest;
import com.localmart.localmartbackend.dto.DeliveryOrderResponse;
import com.localmart.localmartbackend.dto.OrderItemRequest;
import com.localmart.localmartbackend.entity.Address;
import com.localmart.localmartbackend.entity.Cart;
import com.localmart.localmartbackend.entity.DeliveryPartnerLocation;
import com.localmart.localmartbackend.entity.Order;
import com.localmart.localmartbackend.entity.OrderItem;
import com.localmart.localmartbackend.entity.Payment;
import com.localmart.localmartbackend.entity.Product;
import com.localmart.localmartbackend.entity.StoreDetails;
import com.localmart.localmartbackend.entity.User;
import com.localmart.localmartbackend.repository.AddressRepository;
import com.localmart.localmartbackend.repository.CartItemRepository;
import com.localmart.localmartbackend.repository.CartRepository;
import com.localmart.localmartbackend.repository.DeliveryPartnerLocationRepository;
import com.localmart.localmartbackend.repository.OrderItemRepository;
import com.localmart.localmartbackend.repository.OrderRepository;
import com.localmart.localmartbackend.repository.PaymentRepository;
import com.localmart.localmartbackend.repository.ProductRepository;
import com.localmart.localmartbackend.repository.StoreDetailsRepository;
import com.localmart.localmartbackend.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class OrderService {

    private final OrderRepository orderRepository;
    private final OrderItemRepository orderItemRepository;
    private final ProductRepository productRepository;
    private final AddressRepository addressRepository;
    private final PaymentRepository paymentRepository;
    private final CartRepository cartRepository;
    private final CartItemRepository cartItemRepository;
    private final StoreDetailsRepository storeDetailsRepository;
    private final UserRepository userRepository;
    private final DeliveryPartnerLocationRepository deliveryPartnerLocationRepository;
    private final RoadDistanceService roadDistanceService;
    private final RazorpayService razorpayService;

    private static final BigDecimal BASE_DELIVERY_FEE =
            new BigDecimal("30.00");

    /*
     * =============================================================
     * DELIVERY PARTNER EARNINGS CONFIGURATION
     * =============================================================
     */

    private static final BigDecimal DELIVERY_PARTNER_EARNINGS_PERCENTAGE =
            new BigDecimal("80.00");

    /*
     * A delivery partner's GPS location is considered fresh
     * only if it was updated within the last 2 minutes.
     */
    private static final long LOCATION_FRESHNESS_MINUTES = 2;

    public OrderService(
            OrderRepository orderRepository,
            OrderItemRepository orderItemRepository,
            ProductRepository productRepository,
            AddressRepository addressRepository,
            PaymentRepository paymentRepository,
            CartRepository cartRepository,
            CartItemRepository cartItemRepository,
            StoreDetailsRepository storeDetailsRepository,
            UserRepository userRepository,
            DeliveryPartnerLocationRepository deliveryPartnerLocationRepository,
            RoadDistanceService roadDistanceService,
            RazorpayService razorpayService
    ) {
        this.orderRepository = orderRepository;
        this.orderItemRepository = orderItemRepository;
        this.productRepository = productRepository;
        this.addressRepository = addressRepository;
        this.paymentRepository = paymentRepository;
        this.cartRepository = cartRepository;
        this.cartItemRepository = cartItemRepository;
        this.storeDetailsRepository = storeDetailsRepository;
        this.userRepository = userRepository;
        this.deliveryPartnerLocationRepository =
                deliveryPartnerLocationRepository;
        this.roadDistanceService = roadDistanceService;
        this.razorpayService = razorpayService;
    }

    /*
     * =============================================================
     * COD ORDER
     * =============================================================
     */

    @Transactional
    public Order createOrder(
            Long customerId,
            CreateOrderRequest request
    ) {

        validateBasicOrderRequest(customerId, request);

        String paymentMethod =
                request.getPaymentMethod()
                        .trim()
                        .toUpperCase();

        if (!"COD".equals(paymentMethod)) {

            throw new RuntimeException(
                    "This endpoint is only for COD orders"
            );
        }

        Address deliveryAddress =
                getCustomerAddress(
                        customerId,
                        request.getAddressId()
                );

        BigDecimal deliveryDistanceKm =
                calculateStoreToCustomerDistance(
                        request.getStoreId(),
                        deliveryAddress
                );

        BigDecimal deliveryFee =
                calculateDeliveryFee(
                        deliveryDistanceKm
                );

        List<OrderItem> orderItems =
                new ArrayList<>();

        BigDecimal subtotal =
                calculateOrderItems(
                        request,
                        orderItems,
                        true
                );

        BigDecimal total =
                subtotal.add(deliveryFee);

        Order order =
                buildOrder(
                        customerId,
                        request,
                        deliveryAddress,
                        subtotal,
                        deliveryFee,
                        total,
                        "COD",
                        "PENDING",
                        "PLACED"
                );

        order.setDeliveryDistanceKm(
                deliveryDistanceKm
        );

        Order savedOrder =
                orderRepository.save(order);

        attachOrderIdAndSaveItems(
                savedOrder,
                orderItems
        );

        Payment payment =
                new Payment();

        payment.setOrderId(
                savedOrder.getOrderId()
        );

        payment.setProvider(
                "LOCALMART"
        );

        payment.setAmount(
                total
        );

        payment.setCurrency(
                "INR"
        );

        payment.setPaymentMethod(
                "COD"
        );

        payment.setPaymentStatus(
                "PENDING"
        );

        paymentRepository.save(payment);

        clearCustomerCart(customerId);

        System.out.println("SAVED ORDER = " + savedOrder);

        return savedOrder;
    }

    /*
     * =============================================================
     * CREATE RAZORPAY UPI PAYMENT
     * =============================================================
     *
     * Flow:
     *
     * Customer
     *      ↓
     * LocalMart creates local order
     *      ↓
     * LocalMart creates Razorpay TEST order
     *      ↓
     * Razorpay order ID stored in Payment
     *      ↓
     * Frontend opens Razorpay Checkout
     */

    @Transactional
    public Map<String, Object> createUpiPayment(
            Long customerId,
            CreateOrderRequest request
    ) {

        validateBasicOrderRequest(customerId, request);

        String paymentMethod =
                request.getPaymentMethod()
                        .trim()
                        .toUpperCase();

        if (!"UPI".equals(paymentMethod)) {

            throw new RuntimeException(
                    "This endpoint is only for UPI payments"
            );
        }

        Address deliveryAddress =
                getCustomerAddress(
                        customerId,
                        request.getAddressId()
                );

        BigDecimal deliveryDistanceKm =
                calculateStoreToCustomerDistance(
                        request.getStoreId(),
                        deliveryAddress
                );

        BigDecimal deliveryFee =
                calculateDeliveryFee(
                        deliveryDistanceKm
                );

        List<OrderItem> orderItems =
                new ArrayList<>();

        /*
         * IMPORTANT:
         *
         * Stock is NOT deducted here.
         *
         * Stock is deducted only after Razorpay payment
         * has been successfully verified.
         */
        BigDecimal subtotal =
                calculateOrderItems(
                        request,
                        orderItems,
                        false
                );

        BigDecimal total =
                subtotal.add(deliveryFee);

        Order order =
                buildOrder(
                        customerId,
                        request,
                        deliveryAddress,
                        subtotal,
                        deliveryFee,
                        total,
                        "UPI",
                        "PENDING",
                        "PAYMENT_PENDING"
                );

        order.setDeliveryDistanceKm(
                deliveryDistanceKm
        );

        /*
         * Save LocalMart order first.
         *
         * We need the generated order ID for the Razorpay
         * receipt and for linking the payment.
         */
        Order savedOrder =
                orderRepository.save(order);

        attachOrderIdAndSaveItems(
                savedOrder,
                orderItems
        );

        /*
         * =========================================================
         * CONVERT INR TO PAISE
         * =========================================================
         */

        long amountInPaise =
                total
                        .movePointRight(2)
                        .setScale(
                                0,
                                RoundingMode.HALF_UP
                        )
                        .longValueExact();

        /*
         * =========================================================
         * CREATE RAZORPAY TEST ORDER
         * =========================================================
         */

        com.razorpay.Order razorpayOrder =
                razorpayService.createOrder(
                        amountInPaise,
                        "INR",
                        savedOrder.getOrderNumber()
                );

        String razorpayOrderId =
                razorpayOrder.get("id");

        if (razorpayOrderId == null ||
                razorpayOrderId.isBlank()) {

            throw new RuntimeException(
                    "Razorpay did not return an order ID"
            );
        }

        /*
         * =========================================================
         * SAVE LOCAL PAYMENT
         * =========================================================
         */

        Payment payment =
                new Payment();

        payment.setOrderId(
                savedOrder.getOrderId()
        );

        payment.setProvider(
                "RAZORPAY"
        );

        payment.setProviderOrderId(
                razorpayOrderId
        );

        payment.setAmount(
                total
        );

        payment.setCurrency(
                "INR"
        );

        payment.setPaymentMethod(
                "UPI"
        );

        payment.setPaymentStatus(
                "PENDING"
        );

        Payment savedPayment =
                paymentRepository.save(payment);

        /*
         * =========================================================
         * RESPONSE TO FRONTEND
         * =========================================================
         */

        Map<String, Object> response =
                new HashMap<>();

        response.put(
                "order",
                savedOrder
        );

        response.put(
                "paymentId",
                savedPayment.getPaymentId()
        );

        response.put(
                "paymentStatus",
                savedPayment.getPaymentStatus()
        );

        response.put(
                "paymentMethod",
                "UPI"
        );

        response.put(
                "amount",
                total
        );

        response.put(
                "currency",
                "INR"
        );

        response.put(
                "razorpayKeyId",
                razorpayService.getKeyId()
        );

        response.put(
                "razorpayOrderId",
                razorpayOrderId
        );

        return response;
    }

    /*
     * =============================================================
     * VERIFY RAZORPAY UPI PAYMENT
     * =============================================================
     *
     * IMPORTANT:
     *
     * The method name matches OrderController:
     *
     * orderService.verifyRazorpayUpiPayment(...)
     */

    @Transactional
    public Order verifyRazorpayUpiPayment(
            Long customerId,
            Long orderId,
            String razorpayOrderId,
            String razorpayPaymentId,
            String razorpaySignature
    ) {

        if (customerId == null) {

            throw new RuntimeException(
                    "Customer is not authenticated"
            );
        }

        if (orderId == null) {

            throw new RuntimeException(
                    "Order ID is required"
            );
        }

        if (razorpayOrderId == null ||
                razorpayOrderId.isBlank()) {

            throw new RuntimeException(
                    "Razorpay order ID is required"
            );
        }

        if (razorpayPaymentId == null ||
                razorpayPaymentId.isBlank()) {

            throw new RuntimeException(
                    "Razorpay payment ID is required"
            );
        }

        if (razorpaySignature == null ||
                razorpaySignature.isBlank()) {

            throw new RuntimeException(
                    "Razorpay payment signature is required"
            );
        }

        Order order =
                orderRepository.findById(orderId)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Order not found"
                                )
                        );

        if (!customerId.equals(
                order.getCustomerId())) {

            throw new RuntimeException(
                    "You are not authorized to verify this order"
            );
        }

        if (!"UPI".equals(
                order.getPaymentMethod())) {

            throw new RuntimeException(
                    "This order is not a UPI order"
            );
        }

        /*
         * =========================================================
         * IDEMPOTENCY
         * =========================================================
         *
         * If the browser sends the same successful payment
         * confirmation more than once, do not deduct stock again.
         */

        if ("PLACED".equals(
                order.getOrderStatus()) &&
                "SUCCESS".equals(
                        order.getPaymentStatus())) {

            return order;
        }

        Payment payment =
                paymentRepository
                        .findByOrderId(orderId)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Payment record not found"
                                )
                        );

        /*
         * Make sure this is actually a Razorpay payment.
         */
        if (!"RAZORPAY".equals(
                payment.getProvider())) {

            throw new RuntimeException(
                    "Invalid payment provider"
            );
        }

        /*
         * =========================================================
         * VERIFY RAZORPAY ORDER ID
         * =========================================================
         */

        if (!razorpayOrderId.equals(
                payment.getProviderOrderId())) {

            throw new RuntimeException(
                    "Razorpay order ID does not match payment record"
            );
        }

        /*
         * =========================================================
         * VERIFY PAYMENT SIGNATURE
         * =========================================================
         *
         * IMPORTANT:
         *
         * We use the Razorpay order ID stored in our database.
         *
         * We do NOT blindly trust the order ID sent by the
         * frontend.
         */

        boolean signatureValid =
                razorpayService.verifyPaymentSignature(
                        payment.getProviderOrderId(),
                        razorpayPaymentId,
                        razorpaySignature
                );

        if (!signatureValid) {

            throw new RuntimeException(
                    "Invalid Razorpay payment signature"
            );
        }

        /*
         * =========================================================
         * DEDUCT STOCK
         * =========================================================
         *
         * Stock was intentionally NOT deducted when the
         * Razorpay order was created.
         *
         * It is deducted only after payment verification.
         */

        List<OrderItem> orderItems =
                orderItemRepository
                        .findByOrderId(orderId);

        for (OrderItem orderItem :
                orderItems) {

            Product product =
                    productRepository
                            .findById(
                                    orderItem.getProductId()
                            )
                            .orElseThrow(() ->
                                    new RuntimeException(
                                            "Product no longer exists: "
                                                    + orderItem.getProductId()
                                    )
                            );

            if (!Boolean.TRUE.equals(
                    product.getIsAvailable())) {

                throw new RuntimeException(
                        "Product is no longer available: "
                                + product.getProductName()
                );
            }

            if (product.getStockQuantity() <
                    orderItem.getQuantity()) {

                throw new RuntimeException(
                        "Insufficient stock for: "
                                + product.getProductName()
                );
            }

            product.setStockQuantity(
                    product.getStockQuantity()
                            - orderItem.getQuantity()
            );

            if (product.getStockQuantity() == 0) {

                product.setIsAvailable(false);
            }

            productRepository.save(product);
        }

        /*
         * =========================================================
         * MARK PAYMENT SUCCESSFUL
         * =========================================================
         */

        payment.setProviderPaymentId(
                razorpayPaymentId
        );

        payment.setPaymentStatus(
                "SUCCESS"
        );

        paymentRepository.save(
                payment
        );

        /*
         * =========================================================
         * MARK LOCALMART ORDER SUCCESSFUL
         * =========================================================
         */

        order.setPaymentStatus(
                "SUCCESS"
        );

        order.setOrderStatus(
                "PLACED"
        );

        Order savedOrder =
                orderRepository.save(order);

        /*
         * =========================================================
         * CLEAR CUSTOMER CART
         * =========================================================
         */

        clearCustomerCart(customerId);

        return savedOrder;
    }

    /*
     * =============================================================
     * VALIDATION
     * =============================================================
     */

    private void validateBasicOrderRequest(
            Long customerId,
            CreateOrderRequest request
    ) {

        if (customerId == null) {

            throw new RuntimeException(
                    "Customer is not authenticated"
            );
        }

        if (request == null) {

            throw new RuntimeException(
                    "Order request is required"
            );
        }

        if (request.getStoreId() == null) {

            throw new RuntimeException(
                    "Store ID is required"
            );
        }

        if (request.getAddressId() == null) {

            throw new RuntimeException(
                    "Delivery address is required"
            );
        }

        if (request.getItems() == null ||
                request.getItems().isEmpty()) {

            throw new RuntimeException(
                    "Order must contain at least one item"
            );
        }

        if (request.getFullName() == null ||
                request.getFullName().isBlank()) {

            throw new RuntimeException(
                    "Delivery name is required"
            );
        }

        if (request.getPhone() == null ||
                request.getPhone().isBlank()) {

            throw new RuntimeException(
                    "Delivery phone is required"
            );
        }

        if (request.getPaymentMethod() == null ||
                request.getPaymentMethod().isBlank()) {

            throw new RuntimeException(
                    "Payment method is required"
            );
        }

        String paymentMethod =
                request.getPaymentMethod()
                        .trim()
                        .toUpperCase();

        if (!"COD".equals(paymentMethod) &&
                !"UPI".equals(paymentMethod)) {

            throw new RuntimeException(
                    "Invalid payment method. Only COD and UPI are supported."
            );
        }
    }

    /*
     * =============================================================
     * CUSTOMER ADDRESS
     * =============================================================
     */

    private Address getCustomerAddress(
            Long customerId,
            Long addressId
    ) {

        Address deliveryAddress =
                addressRepository.findById(addressId)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Delivery address not found"
                                )
                        );

        if (!customerId.equals(
                deliveryAddress.getUserId())) {

            throw new RuntimeException(
                    "You are not allowed to use this delivery address"
            );
        }

        return deliveryAddress;
    }

    /*
     * =============================================================
     * STORE → CUSTOMER ROAD DISTANCE
     * =============================================================
     */

    private BigDecimal calculateStoreToCustomerDistance(
            Long storeId,
            Address customerAddress
    ) {

        StoreDetails store =
                storeDetailsRepository.findById(storeId)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Store not found"
                                )
                        );

        Address storeAddress =
                addressRepository
                        .findByUserIdAndIsDefaultTrue(
                                store.getUserId()
                        )
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Store does not have a default address"
                                )
                        );

        if (storeAddress.getLatitude() == null ||
                storeAddress.getLongitude() == null) {

            throw new RuntimeException(
                    "Store GPS location is not available"
            );
        }

        if (customerAddress.getLatitude() == null ||
                customerAddress.getLongitude() == null) {

            throw new RuntimeException(
                    "Customer GPS location is not available"
            );
        }

        RoadDistanceService.RoadRoute route =
                roadDistanceService.calculateRoute(
                        storeAddress.getLatitude(),
                        storeAddress.getLongitude(),
                        customerAddress.getLatitude(),
                        customerAddress.getLongitude()
                );

        return route.getDistanceKm();
    }

    /*
     * =============================================================
     * DELIVERY FARE
     * =============================================================
     */

    private BigDecimal calculateDeliveryFee(
            BigDecimal distanceKm
    ) {

        if (distanceKm == null) {

            throw new RuntimeException(
                    "Delivery distance is required"
            );
        }

        distanceKm =
                distanceKm.setScale(
                        2,
                        RoundingMode.HALF_UP
                );

        if (distanceKm.compareTo(
                new BigDecimal("2.00")) <= 0) {

            return BASE_DELIVERY_FEE;
        }

        if (distanceKm.compareTo(
                new BigDecimal("5.00")) <= 0) {

            BigDecimal extraDistance =
                    distanceKm.subtract(
                            new BigDecimal("2.00")
                    );

            return BASE_DELIVERY_FEE
                    .add(
                            extraDistance.multiply(
                                    new BigDecimal("10.00")
                            )
                    )
                    .setScale(
                            2,
                            RoundingMode.HALF_UP
                    );
        }

        if (distanceKm.compareTo(
                new BigDecimal("10.00")) <= 0) {

            BigDecimal extraDistance =
                    distanceKm.subtract(
                            new BigDecimal("5.00")
                    );

            return new BigDecimal("60.00")
                    .add(
                            extraDistance.multiply(
                                    new BigDecimal("12.00")
                            )
                    )
                    .setScale(
                            2,
                            RoundingMode.HALF_UP
                    );
        }

        BigDecimal extraDistance =
                distanceKm.subtract(
                        new BigDecimal("10.00")
                );

        return new BigDecimal("120.00")
                .add(
                        extraDistance.multiply(
                                new BigDecimal("15.00")
                        )
                )
                .setScale(
                        2,
                        RoundingMode.HALF_UP
                );
    }

    /*
     * =============================================================
     * CALCULATE ORDER ITEMS
     * =============================================================
     */

    private BigDecimal calculateOrderItems(
            CreateOrderRequest request,
            List<OrderItem> orderItems,
            boolean deductStock
    ) {

        BigDecimal subtotal =
                BigDecimal.ZERO;

        for (OrderItemRequest itemRequest :
                request.getItems()) {

            if (itemRequest.getProductId() == null) {

                throw new RuntimeException(
                        "Product ID is required"
                );
            }

            if (itemRequest.getQuantity() == null ||
                    itemRequest.getQuantity() <= 0) {

                throw new RuntimeException(
                        "Product quantity must be greater than zero"
                );
            }

            Product product =
                    productRepository
                            .findById(
                                    itemRequest.getProductId()
                            )
                            .orElseThrow(() ->
                                    new RuntimeException(
                                            "Product not found: "
                                                    + itemRequest.getProductId()
                                    )
                            );

            if (!product.getStoreId().equals(
                    request.getStoreId())) {

                throw new RuntimeException(
                        "Product does not belong to the selected store"
                );
            }

            if (!Boolean.TRUE.equals(
                    product.getIsAvailable())) {

                throw new RuntimeException(
                        "Product is not available: "
                                + product.getProductName()
                );
            }

            if (product.getStockQuantity() <
                    itemRequest.getQuantity()) {

                throw new RuntimeException(
                        "Insufficient stock for: "
                                + product.getProductName()
                );
            }

            BigDecimal itemTotal =
                    product.getPrice()
                            .multiply(
                                    BigDecimal.valueOf(
                                            itemRequest.getQuantity()
                                    )
                            );

            subtotal =
                    subtotal.add(itemTotal);

            OrderItem orderItem =
                    new OrderItem();

            orderItem.setProductId(
                    product.getProductId()
            );

            orderItem.setProductName(
                    product.getProductName()
            );

            orderItem.setUnit(
                    product.getUnit()
            );

            orderItem.setQuantity(
                    itemRequest.getQuantity()
            );

            orderItem.setUnitPrice(
                    product.getPrice()
            );

            orderItem.setTotalPrice(
                    itemTotal
            );

            orderItems.add(orderItem);

            if (deductStock) {

                product.setStockQuantity(
                        product.getStockQuantity()
                                - itemRequest.getQuantity()
                );

                if (product.getStockQuantity() == 0) {

                    product.setIsAvailable(false);
                }

                productRepository.save(product);
            }
        }

        return subtotal;
    }

    /*
     * =============================================================
     * BUILD ORDER
     * =============================================================
     */

    private Order buildOrder(
            Long customerId,
            CreateOrderRequest request,
            Address deliveryAddress,
            BigDecimal subtotal,
            BigDecimal deliveryFee,
            BigDecimal total,
            String paymentMethod,
            String paymentStatus,
            String orderStatus
    ) {

        Order order =
                new Order();

        order.setOrderNumber(
                generateOrderNumber()
        );

        order.setCustomerId(
                customerId
        );

        order.setStoreId(
                request.getStoreId()
        );

        order.setSubtotal(
                subtotal
        );

        order.setDeliveryFee(
                deliveryFee
        );

        order.setTotal(
                total
        );

        order.setPaymentMethod(
                paymentMethod
        );

        order.setPaymentStatus(
                paymentStatus
        );

        order.setOrderStatus(
                orderStatus
        );

        order.setDeliveryName(
                request.getFullName().trim()
        );

        order.setDeliveryPhone(
                request.getPhone().trim()
        );

        order.setDeliveryAddress(
                deliveryAddress.getAddressLine()
        );

        order.setDeliveryCity(
                deliveryAddress.getCity()
        );

        order.setDeliveryPincode(
                deliveryAddress.getPincode()
        );

        return order;
    }

    /*
     * =============================================================
     * SAVE ORDER ITEMS
     * =============================================================
     */

    private void attachOrderIdAndSaveItems(
            Order savedOrder,
            List<OrderItem> orderItems
    ) {

        for (OrderItem orderItem :
                orderItems) {

            orderItem.setOrderId(
                    savedOrder.getOrderId()
            );
        }

        orderItemRepository.saveAll(
                orderItems
        );
    }

    /*
     * =============================================================
     * CLEAR CUSTOMER CART
     * =============================================================
     */

    private void clearCustomerCart(
            Long customerId
    ) {

        Cart cart =
                cartRepository
                        .findByCustomerId(customerId)
                        .orElse(null);

        if (cart == null) {
            return;
        }

        cartItemRepository.deleteByCartId(
                cart.getCartId()
        );
    }

    /*
     * =============================================================
     * CUSTOMER ORDERS
     * =============================================================
     */

    public List<Order> getCustomerOrders(
            Long customerId
    ) {

        return orderRepository
                .findByCustomerIdOrderByCreatedAtDesc(
                        customerId
                );
    }

    /*
     * =============================================================
     * STORE OWNER ORDERS
     * =============================================================
     */

    public List<Order> getStoreOrders(
            Long storeId
    ) {

        return orderRepository
                .findByStoreIdOrderByCreatedAtDesc(
                        storeId
                );
    }

    /*
     * =============================================================
     * GET ORDER
     * =============================================================
     */

    public Order getOrderById(
            Long orderId
    ) {

        return orderRepository
                .findById(orderId)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Order not found"
                        )
                );
    }

    /*
     * =============================================================
     * STORE OWNER ORDER STATUS
     * =============================================================
     */

    @Transactional
    public Order updateStoreOrderStatus(
            Long orderId,
            Long storeId,
            String newStatus
    ) {

        Order order =
                getOrderById(orderId);

        if (!order.getStoreId().equals(
                storeId)) {

            throw new RuntimeException(
                    "You are not authorized to update this order"
            );
        }

        if (newStatus == null ||
                newStatus.isBlank()) {

            throw new RuntimeException(
                    "Order status is required"
            );
        }

        newStatus =
                newStatus.trim().toUpperCase();

        String currentStatus =
                order.getOrderStatus();

        if ("CONFIRMED".equals(newStatus)) {

            if (!"PLACED".equals(currentStatus)) {

                throw new RuntimeException(
                        "Order can only be confirmed when it is placed"
                );
            }

        } else if ("PREPARING".equals(newStatus)) {

            if (!"CONFIRMED".equals(currentStatus)) {

                throw new RuntimeException(
                        "Order must be confirmed before preparing"
                );
            }

        } else if ("READY_FOR_PICKUP".equals(newStatus)) {

            if (!"PREPARING".equals(currentStatus)) {

                throw new RuntimeException(
                        "Order must be preparing before it is ready for pickup"
                );
            }

        } else if ("CANCELLED".equals(newStatus)) {

            if ("DELIVERED".equals(currentStatus) ||
                    "CANCELLED".equals(currentStatus)) {

                throw new RuntimeException(
                        "This order cannot be cancelled"
                );
            }

        } else {

            throw new RuntimeException(
                    "Invalid store order status"
            );
        }

        order.setOrderStatus(
                newStatus
        );

        return orderRepository.save(order);
    }

    /*
     * =============================================================
     * ORDER ITEMS
     * =============================================================
     */

    public List<OrderItem> getOrderItems(
            Long orderId
    ) {

        return orderItemRepository
                .findByOrderId(orderId);
    }

    /*
     * =============================================================
     * ORDER NUMBER
     * =============================================================
     */

    private String generateOrderNumber() {

        String datePart =
                LocalDate.now()
                        .format(
                                DateTimeFormatter.ofPattern(
                                        "yyyyMMdd"
                                )
                        );

        long sequence =
                orderRepository.count() + 1;

        return String.format(
                "LM-%s-%03d",
                datePart,
                sequence
        );
    }

    /*
     * =============================================================
     * DELIVERY PARTNER ORDERS
     * =============================================================
     */

    @Transactional(readOnly = true)
    public List<DeliveryOrderResponse> getDeliveryPartnerOrders(
            Long deliveryPartnerId
    ) {

        List<Order> orders =
                orderRepository
                        .findByDeliveryPartnerIdOrderByCreatedAtDesc(
                                deliveryPartnerId
                        );

        return buildDeliveryOrderResponses(
                orders
        );
    }

    /*
     * =============================================================
     * AVAILABLE DELIVERY ORDERS
     * =============================================================
     */

    @Transactional(readOnly = true)
    public List<DeliveryOrderResponse> getAvailableDeliveryOrders() {

        List<Order> orders =
                orderRepository
                        .findByOrderStatusAndDeliveryPartnerIdIsNullOrderByCreatedAtAsc(
                                "READY_FOR_PICKUP"
                        );

        return buildDeliveryOrderResponses(
                orders
        );
    }

    /*
     * =============================================================
     * BUILD DELIVERY ORDER RESPONSES
     * =============================================================
     */

    private List<DeliveryOrderResponse> buildDeliveryOrderResponses(
            List<Order> orders
    ) {

        List<DeliveryOrderResponse> responses =
                new ArrayList<>();

        for (Order order :
                orders) {

            responses.add(
                    buildDeliveryOrderResponse(
                            order
                    )
            );
        }

        return responses;
    }

    /*
     * =============================================================
     * DELIVERY PARTNER EARNINGS
     * =============================================================
     */

    private BigDecimal calculateDeliveryPartnerEarnings(
            BigDecimal deliveryFee
    ) {

        if (deliveryFee == null) {

            throw new RuntimeException(
                    "Delivery fee is required to calculate delivery partner earnings"
            );
        }

        return deliveryFee
                .multiply(
                        DELIVERY_PARTNER_EARNINGS_PERCENTAGE
                                .divide(
                                        new BigDecimal("100")
                                )
                )
                .setScale(
                        2,
                        RoundingMode.HALF_UP
                );
    }

    /*
     * =============================================================
     * BUILD SINGLE DELIVERY ORDER RESPONSE
     * =============================================================
     */

    private DeliveryOrderResponse buildDeliveryOrderResponse(
            Order order
    ) {

        DeliveryOrderResponse response =
                new DeliveryOrderResponse();

        response.setOrderId(
                order.getOrderId()
        );

        response.setOrderNumber(
                order.getOrderNumber()
        );

        response.setCustomerId(
                order.getCustomerId()
        );

        response.setStoreId(
                order.getStoreId()
        );

        response.setDeliveryPartnerId(
                order.getDeliveryPartnerId()
        );

        response.setOrderStatus(
                order.getOrderStatus()
        );

        response.setCreatedAt(
                order.getCreatedAt()
        );

        response.setUpdatedAt(
                order.getUpdatedAt()
        );

        response.setSubtotal(
                order.getSubtotal()
        );

        response.setDeliveryFee(
                order.getDeliveryFee()
        );

        response.setTotal(
                order.getTotal()
        );

        response.setPaymentMethod(
                order.getPaymentMethod()
        );

        response.setPaymentStatus(
                order.getPaymentStatus()
        );

        response.setPickupDistanceKm(
                order.getPickupDistanceKm()
        );

        response.setDeliveryDistanceKm(
                order.getDeliveryDistanceKm()
        );

        response.setTotalDistanceKm(
                order.getTotalDistanceKm()
        );

        BigDecimal estimatedEarnings =
                calculateDeliveryPartnerEarnings(
                        order.getDeliveryFee()
                );

        response.setEstimatedEarnings(
                estimatedEarnings
        );

        DeliveryOrderResponse.PickupLocation pickup =
                new DeliveryOrderResponse.PickupLocation();

        StoreDetails store =
                storeDetailsRepository
                        .findById(
                                order.getStoreId()
                        )
                        .orElse(null);

        if (store != null) {

            pickup.setStoreName(
                    store.getStoreName()
            );

            User storeUser =
                    userRepository
                            .findById(
                                    store.getUserId()
                            )
                            .orElse(null);

            if (storeUser != null) {

                pickup.setStorePhone(
                        storeUser.getPhone()
                );
            }

            Address storeAddress =
                    addressRepository
                            .findByUserIdAndIsDefaultTrue(
                                    store.getUserId()
                            )
                            .orElse(null);

            if (storeAddress != null) {

                pickup.setAddress(
                        storeAddress.getAddressLine()
                );

                pickup.setCity(
                        storeAddress.getCity()
                );

                pickup.setState(
                        storeAddress.getState()
                );

                pickup.setPincode(
                        storeAddress.getPincode()
                );

                pickup.setLatitude(
                        storeAddress.getLatitude()
                );

                pickup.setLongitude(
                        storeAddress.getLongitude()
                );
            }
        }

        response.setPickupLocation(
                pickup
        );

        DeliveryOrderResponse.DeliveryLocation delivery =
                new DeliveryOrderResponse.DeliveryLocation();

        delivery.setCustomerName(
                order.getDeliveryName()
        );

        delivery.setPhone(
                order.getDeliveryPhone()
        );

        delivery.setAddress(
                order.getDeliveryAddress()
        );

        delivery.setCity(
                order.getDeliveryCity()
        );

        delivery.setPincode(
                order.getDeliveryPincode()
        );

        response.setDeliveryLocation(
                delivery
        );

        List<OrderItem> orderItems =
                orderItemRepository
                        .findByOrderId(
                                order.getOrderId()
                        );

        List<DeliveryOrderResponse.Item> items =
                new ArrayList<>();

        for (OrderItem orderItem :
                orderItems) {

            DeliveryOrderResponse.Item item =
                    new DeliveryOrderResponse.Item();

            item.setProductId(
                    orderItem.getProductId()
            );

            item.setProductName(
                    orderItem.getProductName()
            );

            item.setUnit(
                    orderItem.getUnit()
            );

            item.setQuantity(
                    orderItem.getQuantity()
            );

            item.setUnitPrice(
                    orderItem.getUnitPrice()
            );

            item.setTotalPrice(
                    orderItem.getTotalPrice()
            );

            items.add(
                    item
            );
        }

        response.setItems(
                items
        );

        return response;
    }

    /*
     * =============================================================
     * ACCEPT DELIVERY ORDER
     * =============================================================
     */

    @Transactional
    public Order acceptDeliveryOrder(
            Long orderId,
            Long deliveryPartnerId
    ) {

        if (orderId == null) {

            throw new RuntimeException(
                    "Order ID is required"
            );
        }

        if (deliveryPartnerId == null) {

            throw new RuntimeException(
                    "Delivery partner is not authenticated"
            );
        }

        Order order =
                orderRepository
                        .findByIdForUpdate(orderId)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Order not found"
                                )
                        );

        if (!"READY_FOR_PICKUP".equals(
                order.getOrderStatus())) {

            throw new RuntimeException(
                    "This order is no longer available for acceptance"
            );
        }

        if (order.getDeliveryPartnerId() != null) {

            throw new RuntimeException(
                    "This order has already been accepted by another delivery partner"
            );
        }

        DeliveryPartnerLocation partner =
                deliveryPartnerLocationRepository
                        .findById(deliveryPartnerId)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Delivery partner location not found"
                                )
                        );

        if (!"AVAILABLE".equals(
                partner.getAvailabilityStatus())) {

            throw new RuntimeException(
                    "You are not currently available for deliveries"
            );
        }

        LocalDateTime freshnessLimit =
                LocalDateTime.now()
                        .minusMinutes(
                                LOCATION_FRESHNESS_MINUTES
                        );

        if (partner.getUpdatedAt() == null ||
                partner.getUpdatedAt().isBefore(
                        freshnessLimit
                )) {

            throw new RuntimeException(
                    "Your GPS location is stale. Please update your location and try again"
            );
        }

        if (partner.getLatitude() == null ||
                partner.getLongitude() == null) {

            throw new RuntimeException(
                    "Your GPS location is not available"
            );
        }

        StoreDetails store =
                storeDetailsRepository
                        .findById(
                                order.getStoreId()
                        )
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Store not found"
                                )
                        );

        Address storeAddress =
                addressRepository
                        .findByUserIdAndIsDefaultTrue(
                                store.getUserId()
                        )
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Store does not have a default address"
                                )
                        );

        if (storeAddress.getLatitude() == null ||
                storeAddress.getLongitude() == null) {

            throw new RuntimeException(
                    "Store GPS location is not available"
            );
        }

        RoadDistanceService.RoadRoute route =
                roadDistanceService.calculateRoute(
                        partner.getLatitude(),
                        partner.getLongitude(),
                        storeAddress.getLatitude(),
                        storeAddress.getLongitude()
                );

        BigDecimal pickupDistance =
                route.getDistanceKm();

        order.setDeliveryPartnerId(
                deliveryPartnerId
        );

        order.setPickupDistanceKm(
                pickupDistance
        );

        if (order.getDeliveryDistanceKm() != null) {

            order.setTotalDistanceKm(
                    pickupDistance
                            .add(
                                    order.getDeliveryDistanceKm()
                            )
                            .setScale(
                                    2,
                                    RoundingMode.HALF_UP
                            )
            );
        }

        order.setOrderStatus(
                "ACCEPTED"
        );

        partner.setAvailabilityStatus(
                "BUSY"
        );

        partner.setUpdatedAt(
                LocalDateTime.now()
        );

        deliveryPartnerLocationRepository.save(
                partner
        );

        return orderRepository.save(
                order
        );
    }

    /*
     * =============================================================
     * DELIVERY PARTNER ORDER STATUS
     * =============================================================
     */

    @Transactional
    public Order updateDeliveryPartnerOrderStatus(
            Long orderId,
            Long deliveryPartnerId,
            String newStatus
    ) {

        Order order =
                getOrderById(orderId);

        if (!deliveryPartnerId.equals(
                order.getDeliveryPartnerId())) {

            throw new RuntimeException(
                    "You are not assigned to this order"
            );
        }

        if (newStatus == null ||
                newStatus.isBlank()) {

            throw new RuntimeException(
                    "Order status is required"
            );
        }

        newStatus =
                newStatus.trim().toUpperCase();

        String currentStatus =
                order.getOrderStatus();

        if ("PICKED_UP".equals(newStatus)) {

            if (!"ACCEPTED".equals(
                    currentStatus)) {

                throw new RuntimeException(
                        "Order must be accepted before pickup"
                );
            }

        } else if ("OUT_FOR_DELIVERY".equals(newStatus)) {

            if (!"PICKED_UP".equals(
                    currentStatus)) {

                throw new RuntimeException(
                        "Order must be picked up before starting delivery"
                );
            }

        } else if ("DELIVERED".equals(newStatus)) {

            if (!"OUT_FOR_DELIVERY".equals(
                    currentStatus)) {

                throw new RuntimeException(
                        "Order must be out for delivery before completing"
                );
            }

        } else {

            throw new RuntimeException(
                    "Invalid delivery order status"
            );
        }

        order.setOrderStatus(
                newStatus
        );

        if ("DELIVERED".equals(newStatus)) {

            DeliveryPartnerLocation partner =
                    deliveryPartnerLocationRepository
                            .findById(
                                    deliveryPartnerId
                            )
                            .orElse(null);

            if (partner != null) {

                partner.setAvailabilityStatus(
                        "AVAILABLE"
                );

                partner.setUpdatedAt(
                        LocalDateTime.now()
                );

                deliveryPartnerLocationRepository.save(
                        partner
                );
            }
        }

        return orderRepository.save(
                order
        );
    }

    /*
     * =============================================================
     * CHECKOUT DELIVERY FEE CALCULATION
     * =============================================================
     */

    @Transactional(readOnly = true)
    public BigDecimal calculateDeliveryDistanceForCheckout(
            Long storeId,
            Address customerAddress
    ) {

        return calculateStoreToCustomerDistance(
                storeId,
                customerAddress
        );
    }

    @Transactional(readOnly = true)
    public BigDecimal calculateDeliveryFeeForCheckout(
            BigDecimal distanceKm
    ) {

        return calculateDeliveryFee(
                distanceKm
        );
    }
}