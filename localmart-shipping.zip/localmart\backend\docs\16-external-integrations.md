# LocalMart — External Integrations

## 1. Overview

LocalMart integrates with several external services to provide functionality that would otherwise require implementing and maintaining complex infrastructure internally.

The main external integrations are:

```text id="4l0xq9"
Google Identity Services
        ↓
Google Authentication

X OAuth
        ↓
X Authentication

Message Central
        ↓
SMS OTP

Gmail SMTP
        ↓
Email OTP

Razorpay
        ↓
Payment Processing

OSRM
        ↓
Road Distance / Duration

Geocoding Service
        ↓
Address / Location Conversion
```

These integrations are accessed primarily from the LocalMart backend.

The important architectural principle is:

> **External services provide specialized capabilities, while LocalMart remains responsible for its own users, business rules, orders, sessions, and application state.**

---

# 2. Integration Architecture

The overall architecture can be represented as:

```text id="wq7qf1"
                         LocalMart
                            |
             +--------------+--------------+
             |              |              |
             v              v              v
       Authentication    Messaging      Commerce
             |              |              |
       +-----+-----+    +---+---+         |
       |           |    |       |         |
     Google       X   SMS     Email     Razorpay
       |           |    |       |         |
       +-----------+----+-------+---------+
                            |
                            v
                       LocalMart
                            |
                 +----------+----------+
                 |                     |
                 v                     v
              Location              Database
                 |
             +---+---+
             |       |
           OSRM  Geocoding
```

Each external service has a specific responsibility.

---

# 3. External Integration Categories

LocalMart's integrations can be divided into four categories.

## Authentication

```text id="8j7v3a"
Google
X
```

Used to verify external identities.

## Messaging

```text id="r7n4hx"
Message Central
Gmail SMTP
```

Used to deliver OTPs and verification messages.

## Payments

```text id="w5k1sp"
Razorpay
```

Used for payment processing.

## Location

```text id="z2z6xn"
Geocoding Service
OSRM
```

Used for address/location conversion and road-distance calculations.

---

# 4. Integration Design Principle

LocalMart does not place external API communication directly inside controllers.

Instead, external communication is separated into service classes.

Examples include:

```text id="f9x4p0"
GoogleTokenVerificationService
MessageCentralOtpService
EmailService
RazorpayService
RoadDistanceService
GeocodingService
XOAuthService
```

The architecture is:

```text id="w2v5ha"
Controller
    |
    v
Application Service
    |
    v
Integration Service
    |
    v
External Provider
```

This separation prevents controllers from becoming tightly coupled to third-party APIs.

---

# 5. Google Identity Services

Google authentication is used to allow users to authenticate or register through their Google identity.

The backend contains:

```text id="qj6u9h"
GoogleTokenVerificationService.java
GoogleAuthProperties.java
```

The user API exposes:

```text id="2q6h7x"
POST /api/users/google/login
POST /api/users/google/register
```

---

# 6. Google Authentication Flow

The high-level flow is:

```text id="c5p4ne"
User
 |
 v
Google Identity Services
 |
 v
Frontend
 |
 | Google credential
 v
LocalMart Backend
 |
 v
UserService
 |
 v
GoogleTokenVerificationService
 |
 v
Google token verification
 |
 v
Verified Google identity
 |
 v
LocalMart User
 |
 v
UserSession
 |
 v
JWT
 |
 v
Frontend
```

The backend therefore does not simply trust user information supplied by the frontend.

It verifies the Google credential before using the identity.

---

# 7. Google Token Verification

The backend uses Google's token-verification libraries to validate the received credential.

The verification process checks that the token corresponds to an expected Google client/application identity.

Conceptually:

```text id="x9j5ar"
Google Credential
       |
       v
Token Verifier
       |
       +---- Invalid → Reject
       |
       +---- Valid
              |
              v
        Google Identity
```

The verified identity can then be associated with the LocalMart account.

---

# 8. Google Integration Configuration

Google-related configuration is represented by:

```text id="2m0w1c"
GoogleAuthProperties.java
```

The frontend also uses a Google client identifier through its environment configuration.

Sensitive or environment-specific credentials should not be hardcoded into the repository.

---

# 9. X Authentication

LocalMart also supports authentication through X.

The backend components include:

```text id="h5g8u3"
XOAuthController.java
XOAuthService.java
XAuthProperties.java
```

Related DTOs include:

```text id="xq2k4z"
XRegistrationData.java
XUserInfo.java
```

X authentication provides another external identity provider.

---

# 10. X Authentication Architecture

The conceptual flow is:

```text id="k2n7dr"
User
 |
 v
X
 |
 v
X OAuth Flow
 |
 v
LocalMart Backend
 |
 v
XOAuthService
 |
 v
External identity verification
 |
 v
LocalMart User
 |
 v
Session + JWT
```

The external identity is verified before LocalMart uses it to authenticate or register the user.

---

# 11. Why Social Login Is Verified by the Backend

The frontend is an untrusted client.

Therefore this is not sufficient:

```text id="qf0m3s"
Frontend says:
"Google/X says this user is John."
```

Instead:

```text id="v7u1qa"
Frontend
   |
   | Credential
   v
Backend
   |
   v
External provider verification
   |
   v
Verified identity
```

The backend makes the authentication decision.

---

# 12. Message Central

LocalMart uses Message Central for SMS OTP functionality.

The integration is represented by:

```text id="2d5xq6"
MessageCentralOtpService.java
```

There is also a dedicated SMS OTP module:

```text id="r0f4b9"
smsotp/
├── controller/
│   └── SmsOtpController.java
├── dto/
│   ├── SmsOtpSendRequest.java
│   └── SmsOtpVerifyRequest.java
├── model/
│   └── SmsOtpSession.java
└── service/
    └── SmsOtpFlowService.java
```

---

# 13. SMS OTP Flow

The SMS flow is:

```text id="1d6kz8"
User
 |
 | Request OTP
 v
LocalMart Frontend
 |
 v
LocalMart Backend
 |
 v
SmsOtpFlowService
 |
 v
MessageCentralOtpService
 |
 v
Message Central
 |
 v
SMS Network
 |
 v
User's Phone
```

When the user submits the OTP:

```text id="z6q7j4"
User
 |
 | OTP
 v
LocalMart Backend
 |
 v
OTP Verification
 |
 +---- Valid → Continue
 |
 +---- Invalid → Reject
```

---

# 14. Responsibility Split for SMS

The responsibilities are separated.

### LocalMart

Responsible for:

* Authentication flow
* User identity
* OTP verification logic
* Session creation
* JWT creation
* Account status
* Application business rules

### Message Central

Responsible for:

* External SMS delivery

Conceptually:

```text id="5c5o1q"
LocalMart
   |
   | "Send OTP"
   v
Message Central
   |
   | SMS
   v
User
```

---

# 15. Email SMTP

LocalMart also supports email-based OTP delivery.

The relevant backend component is:

```text id="v8h2sz"
EmailService.java
```

Email is delivered through SMTP.

The architecture is:

```text id="0v6z5c"
LocalMart Backend
       |
       v
EmailService
       |
       v
SMTP Server
       |
       v
User's Email
```

---

# 16. Email OTP Flow

The general email OTP flow is:

```text id="f2u7gk"
User
 |
 | Request OTP
 v
UserService / OTP Logic
 |
 v
EmailService
 |
 v
SMTP
 |
 v
Email Provider
 |
 v
User Inbox
```

The user then submits the received OTP back to LocalMart.

```text id="d1x6gc"
User
 |
 | OTP
 v
LocalMart Backend
 |
 v
OTP Verification
```

---

# 17. SMTP vs Email Provider

SMTP is a communication protocol rather than a single email provider.

LocalMart's `EmailService` communicates through SMTP configuration.

Conceptually:

```text id="0m5jpp"
LocalMart
   |
   | SMTP
   v
Configured mail server
   |
   v
Recipient
```

The exact SMTP server and credentials belong to the environment configuration.

---

# 18. TOTP

LocalMart also contains a TOTP implementation.

The relevant service is:

```text id="j0n8vw"
TotpService.java
```

TOTP is different from an SMS/email-delivered OTP.

It does not require sending a new code through a messaging provider for every authentication event.

Instead:

```text id="n4z6m2"
Shared Secret
      +
Current Time
      |
      v
TOTP Algorithm
      |
      v
Temporary Code
```

Both the authenticator and backend use the shared secret and current time to derive the expected code.

---

# 19. TOTP Library

The backend uses a TOTP library from the `dev.samstevens.totp` package.

The dependency provides the cryptographic TOTP implementation used by LocalMart.

The application-specific responsibility remains in:

```text id="k3q9fr"
TotpService.java
```

This service separates LocalMart's business flow from the underlying TOTP library.

---

# 20. Razorpay

LocalMart integrates Razorpay for payment processing.

The backend contains:

```text id="y5r0nd"
RazorpayService.java
```

and the payment domain contains:

```text id="x4j8s2"
Payment.java
PaymentRepository.java
```

Razorpay is used as the external payment-processing system.

---

# 21. Razorpay Payment Architecture

The conceptual flow is:

```text id="b5r1e6"
Customer
   |
   v
LocalMart Checkout
   |
   v
LocalMart Backend
   |
   v
RazorpayService
   |
   v
Razorpay
   |
   v
Payment Processing
```

The result is then handled by the LocalMart backend and associated with the relevant business transaction.

---

# 22. Responsibility Split for Payments

### LocalMart

Responsible for:

* Cart
* Order creation
* Order business rules
* Payment state associated with the order
* Customer identity
* Application-level authorization

### Razorpay

Responsible for:

* Payment processing infrastructure
* Supported payment methods
* Payment transaction processing

The exact payment flow depends on the current Razorpay implementation in `RazorpayService`.

---

# 23. Payment Data Boundary

Payment-related data crosses an external-service boundary.

Conceptually:

```text id="o4p6ws"
LocalMart
    |
    | Payment information
    v
Razorpay
    |
    v
Payment result
    |
    v
LocalMart
```

Sensitive payment credentials and API secrets must remain server-side and must not be exposed through frontend source code.

---

# 24. OSRM

LocalMart uses OSRM for road-distance and routing-related calculations.

The application contains:

```text id="0k8m5e"
RoadDistanceService.java
```

OSRM is used to calculate road-based distance/duration rather than simply calculating straight-line distance.

---

# 25. OSRM Architecture

The general flow is:

```text id="9c0v5a"
Store Coordinates
       |
       |
       +------------+
                    |
                    v
             RoadDistanceService
                    |
                    v
                   OSRM
                    |
                    v
             Road Distance
             Road Duration
                    |
                    v
             LocalMart Logic
```

The customer location is another input to the route calculation.

---

# 26. Why Road Distance Is Different From Coordinate Distance

Two coordinates can be geographically close while the road route between them is considerably longer.

For example:

```text id="y4p6q8"
Straight-line distance
        ≠
Road distance
```

OSRM considers road-network routing.

This makes it more appropriate for delivery-related calculations.

---

# 27. OSRM and Delivery Fee

The delivery-fee flow can use:

```text id="v9g5t1"
Store Location
       +
Customer Address Location
       |
       v
RoadDistanceService
       |
       v
OSRM
       |
       v
Road Distance / Duration
       |
       v
LocalMart Delivery Fee Logic
```

The external routing service provides geographic calculation; LocalMart remains responsible for the application's delivery-fee rules.

---

# 28. Geocoding Service

LocalMart also contains:

```text id="8v4c7n"
GeocodingService.java
```

and:

```text id="m7q3x1"
LocationController.java
LocationSearchRequest.java
LocationSearchResponse.java
```

The geocoding integration provides location-related functionality such as converting between human-readable addresses and geographic coordinates, depending on the configured implementation.

---

# 29. Geocoding Architecture

The conceptual flow is:

```text id="4k7x2z"
User Location Input
       |
       v
LocationController
       |
       v
GeocodingService
       |
       v
External Geocoding Provider
       |
       v
Location Result
       |
       v
LocalMart
```

The exact external provider should be determined from the current `GeocodingService` implementation/configuration.

---

# 30. Geocoding vs Routing

These are separate responsibilities.

### Geocoding

Answers:

> "Where is this address?"

```text id="p2x8nd"
Address
   ↓
Coordinates
```

or potentially:

```text id="j8v4wq"
Coordinates
   ↓
Address
```

### Routing

Answers:

> "How far is it by road, and how long might the route take?"

```text id="a0y5ms"
Point A + Point B
       ↓
Road Network
       ↓
Distance + Duration
```

LocalMart separates these responsibilities using different services.

---

# 31. Browser Geolocation

Not every location-related capability comes from an external API.

The delivery-partner frontend uses the browser Web API:

```text id="f4k8v1"
navigator.geolocation.getCurrentPosition()
```

This is provided by the browser itself.

The flow is:

```text id="m5y2c8"
Delivery Partner Browser
        |
        v
Browser Geolocation API
        |
        v
Current Coordinates
        |
        v
LocalMart Frontend
        |
        v
LocalMart Backend
```

The browser API and external geocoding/routing services therefore have different responsibilities.

---

# 32. Location Responsibility Matrix

| Requirement                         | Provider / Component                     |
| ----------------------------------- | ---------------------------------------- |
| Device's current location           | Browser Geolocation API                  |
| Address/location conversion         | `GeocodingService` + configured provider |
| Road distance                       | `RoadDistanceService` + OSRM             |
| Road duration                       | `RoadDistanceService` + OSRM             |
| Persisted customer location         | LocalMart PostgreSQL                     |
| Persisted store location            | LocalMart PostgreSQL                     |
| Persisted delivery-partner location | LocalMart PostgreSQL                     |
| Delivery-fee business calculation   | LocalMart backend                        |

---

# 33. External Integration Service Layer

LocalMart's integration services form an abstraction layer between application logic and external providers.

```text id="z3r8hc"
                    LocalMart
                       |
                 Service Layer
                       |
       +---------------+---------------+
       |               |               |
       v               v               v
 Authentication    Messaging        Location
       |               |               |
   +---+---+       +---+---+       +---+---+
   |       |       |       |       |       |
 Google    X      SMS    Email    OSRM  Geocoder
```

This makes provider-specific code easier to isolate.

---

# 34. Why Integration Services Are Important

Without an integration service, a controller could become tightly coupled to an external API:

```text id="k0v3bd"
Controller
   |
   +---- Build external request
   +---- Handle API authentication
   +---- Send HTTP request
   +---- Parse response
   +---- Handle provider errors
   +---- Apply business logic
```

This creates a difficult-to-maintain controller.

Instead:

```text id="x9d2kp"
Controller
   |
   v
Service
   |
   v
Integration Service
   |
   v
External API
```

Each layer has a clearer responsibility.

---

# 35. External API Failure

External services can fail independently of LocalMart.

Examples:

```text id="v3q8s1"
Network failure
Timeout
Provider unavailable
Invalid credentials
Rate limit
Invalid external response
Service maintenance
```

Therefore LocalMart should not assume that an external API will always respond successfully.

The integration service should handle provider failures and allow the application to return an appropriate application-level error.

---

# 36. External Service Rate Limits

Third-party providers may impose their own request limits.

This creates two different rate-limiting boundaries:

```text id="r6y3q0"
Client
  |
  v
LocalMart Rate Limiting
  |
  v
LocalMart Backend
  |
  v
External Provider Rate Limiting
```

LocalMart's `RateLimitFilter` controls incoming application traffic.

External providers independently control how frequently LocalMart can call their APIs.

---

# 37. External Credentials

External integrations may require credentials such as:

```text id="w2m7sk"
API Keys
Client IDs
Client Secrets
SMTP Credentials
JWT / application secrets
Payment credentials
```

These values should be provided through secure environment configuration.

They should not be committed to the Git repository.

---

# 38. Configuration Separation

The architecture should separate:

```text id="q8h1c3"
Application Code
       |
       +
       v
Environment Configuration
       |
       +
       v
External Credentials
```

For example:

```text id="6m3s8j"
Development
    ↓
Development API configuration

Production
    ↓
Production API configuration
```

The same application code can therefore operate against different external-service environments.

---

# 39. External Integration Security

External integrations introduce additional security requirements.

### Authentication providers

The backend must verify external credentials/tokens.

### Messaging providers

API credentials must remain private.

### Payment providers

Secret payment credentials must remain server-side.

### Location providers

Requests should contain only the location information required for the operation.

### SMTP

Email credentials must remain server-side.

---

# 40. Data Flow Through External Integrations

A typical integration follows:

```text id="6c4x1r"
LocalMart Request
       |
       v
Controller
       |
       v
Business Service
       |
       v
Integration Service
       |
       v
External Provider
       |
       v
External Response
       |
       v
Integration Service
       |
       v
Business Service
       |
       v
LocalMart Response
```

This prevents external-provider details from leaking throughout the application.

---

# 41. External Integration Summary

| Integration        | LocalMart Component              | Main Responsibility             |
| ------------------ | -------------------------------- | ------------------------------- |
| Google             | `GoogleTokenVerificationService` | Google identity verification    |
| X                  | `XOAuthService`                  | X authentication                |
| Message Central    | `MessageCentralOtpService`       | SMS OTP delivery                |
| SMTP               | `EmailService`                   | Email delivery                  |
| TOTP library       | `TotpService`                    | Time-based authentication codes |
| Razorpay           | `RazorpayService`                | Payment processing              |
| OSRM               | `RoadDistanceService`            | Road distance/duration          |
| Geocoding provider | `GeocodingService`               | Location/address conversion     |
| Browser            | `navigator.geolocation`          | Device location                 |

---

# 42. Integration Dependency Map

The major application dependencies can be visualized as:

```text id="e7m2k4"
                         LocalMart
                            |
       +--------------------+--------------------+
       |                    |                    |
       v                    v                    v
 Authentication        Communication         Commerce
       |                    |                    |
   +---+---+            +---+---+             Razorpay
   |       |            |       |
 Google    X       Message Central  SMTP
       |
       v
      TOTP
       |
       +--------------------+
                            |
                            v
                         Location
                            |
                       +----+----+
                       |         |
                      OSRM   Geocoding
```

---

# 43. What External Providers Do Not Control

External services do not become the source of truth for LocalMart's entire application.

For example:

```text id="h5c0p3"
Google
   ≠
LocalMart User Database

Razorpay
   ≠
LocalMart Order Database

OSRM
   ≠
LocalMart Delivery Database

Message Central
   ≠
LocalMart Authentication Database
```

Instead, the providers perform specialized external operations while LocalMart maintains its own application state.

---

# 44. External Integration and Database

The external-service result is often transformed into LocalMart application data.

For example:

```text id="n4x8k0"
External Service
       |
       v
Integration Service
       |
       v
LocalMart Business Logic
       |
       v
Entity
       |
       v
PostgreSQL
```

This keeps the database model independent from the exact external provider response format.

---

# 45. Provider Abstraction

A useful architectural property of the integration layer is provider abstraction.

For example, the application-level logic can conceptually depend on:

```text id="d6s1y9"
"Send OTP"
```

rather than:

```text id="c3h8q2"
"Call this exact Message Central HTTP endpoint"
```

Similarly, delivery logic can depend on:

```text id="y1k5s7"
"Calculate road distance"
```

rather than embedding OSRM-specific request logic throughout the order service.

This reduces coupling between LocalMart's business logic and external providers.

---

# 46. Testing External Integrations

External integrations should be tested separately from core business logic where practical.

For example:

```text id="x4v8j0"
Core business logic
       |
       v
Mock / test integration
```

can allow business logic to be tested without requiring a live external service for every test.

The existing project already contains automated testing for the TOTP service:

```text id="u3m9b2"
src/test/java/.../service/TotpServiceTest.java
```

External API integration tests can similarly be isolated from ordinary unit tests.

---

# 47. External Integration Failure Strategy

A robust integration should distinguish between:

```text id="e8q2r4"
Invalid user input
        ≠
External provider failure
        ≠
Local application failure
```

For example:

```text id="j5t8w1"
Invalid address
    → validation error

Geocoding provider unavailable
    → external-service error

Database unavailable
    → infrastructure/application error
```

This distinction helps the frontend display appropriate messages and helps developers diagnose failures.

---

# 48. End-to-End Example — Delivery Fee

A complete delivery-fee calculation demonstrates several layers:

```text id="n7k2p4"
Customer Frontend
       |
       | storeId + addressId
       v
OrderController
       |
       v
OrderService
       |
       +---- Store data
       |
       +---- Customer address
       |
       v
RoadDistanceService
       |
       v
OSRM
       |
       v
Road distance
       |
       v
LocalMart delivery-fee logic
       |
       v
JSON Response
       |
       v
Frontend
```

OSRM provides the road calculation, but the final LocalMart business decision remains inside LocalMart.

---

# 49. End-to-End Example — Google Login

```text id="k6m0q3"
User
 |
 v
Google
 |
 v
Google Identity Services
 |
 v
Frontend
 |
 | Credential
 v
UserController
 |
 v
UserService
 |
 v
GoogleTokenVerificationService
 |
 v
Google verification
 |
 v
UserRepository
 |
 v
UserSessionService
 |
 v
JwtService
 |
 v
JSON Response
```

The external provider verifies the external identity; LocalMart creates and manages the LocalMart session.

---

# 50. End-to-End Example — SMS OTP

```text id="f1x9c7"
User
 |
 v
Frontend
 |
 | Request OTP
 v
SmsOtpController
 |
 v
SmsOtpFlowService
 |
 v
MessageCentralOtpService
 |
 v
Message Central
 |
 v
SMS
 |
 v
User
 |
 | OTP
 v
LocalMart
 |
 v
OTP verification
 |
 v
Authentication
```

---

# 51. End-to-End Example — Payment

```text id="r8w4z1"
Customer
 |
 v
Checkout
 |
 v
LocalMart Backend
 |
 v
RazorpayService
 |
 v
Razorpay
 |
 v
Payment Processing
 |
 v
Payment Result
 |
 v
LocalMart Backend
 |
 v
Order / Payment State
```

The exact payment-state transition is governed by the current implementation of the order and payment services.

---

# 52. External Integration Best Practices

The LocalMart architecture should follow these principles when working with external services:

### Keep credentials server-side

Never expose private API credentials in frontend code.

### Validate external responses

Do not blindly trust external response data.

### Handle failures

External services can become unavailable.

### Isolate provider-specific code

Keep API-specific implementation inside integration services.

### Keep business logic inside LocalMart

External providers should provide specialized capabilities, not determine LocalMart's entire business state.

### Avoid unnecessary external calls

Cache or reuse data where appropriate, especially for expensive or rate-limited services.

### Log safely

Logs should help diagnose integration failures without exposing secrets, tokens, passwords, or sensitive user data.

---

# 53. External Integration Architecture Summary

LocalMart's external integrations can be summarized as:

```text id="g7c2n5"
                         LOCALMART
                             |
       +---------------------+---------------------+
       |                     |                     |
 Authentication          Messaging             Business
       |                     |                     |
  +----+----+           +----+----+           Razorpay
  |         |           |         |
Google      X       Message     SMTP
  |                     |
  +--------+------------+
           |
          TOTP

                             |
                             v
                         Location
                             |
                       +-----+-----+
                       |           |
                      OSRM    Geocoding
```

The central design principle is:

> **External services provide specialized capabilities, while LocalMart's backend remains responsible for authentication decisions, business rules, application state, persistence, authorization, and the final interpretation of external results.**

This architecture keeps third-party dependencies isolated and makes the application easier to maintain, test, and evolve.

---

# 54. External Integration Component Map

The primary integration-related source files are:

```text id="n5w3a9"
src/main/java/com/localmart/localmartbackend/
│
├── config/
│   ├── GoogleAuthProperties.java
│   └── XAuthProperties.java
│
├── service/
│   ├── EmailService.java
│   ├── GeocodingService.java
│   ├── GoogleTokenVerificationService.java
│   ├── MessageCentralOtpService.java
│   ├── RazorpayService.java
│   ├── RoadDistanceService.java
│   ├── TotpService.java
│   └── XOAuthService.java
│
└── smsotp/
    └── service/
        └── SmsOtpFlowService.java
```

These components form the integration boundary between LocalMart and its external services.
