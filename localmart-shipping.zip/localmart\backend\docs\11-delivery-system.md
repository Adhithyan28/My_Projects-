# LocalMart — Delivery System

## 1. Overview

The Delivery System manages the final fulfillment stage of a LocalMart order.

After a store prepares an order, the delivery workflow connects the store with an available delivery partner and ultimately delivers the order to the customer.

The high-level flow is:

```text
Customer
   |
   v
Order
   |
   v
Store
   |
   v
READY_FOR_PICKUP
   |
   v
Delivery Partner
   |
   v
Customer
```

The delivery system integrates with:

* Order Management
* Store Management
* Customer Address Management
* Location Services
* Road Distance Services
* Delivery Partner Management
* Authentication and Authorization

---

# 2. Purpose of the Delivery System

The Delivery System is responsible for managing the delivery lifecycle of an order.

Its responsibilities include:

* Making eligible deliveries available to delivery partners
* Allowing delivery partners to accept deliveries
* Managing delivery status progression
* Associating deliveries with delivery partners
* Tracking delivery-partner location
* Providing delivery-related order information
* Supporting road-distance calculations
* Supporting delivery-fee calculations
* Moving orders through the delivery lifecycle
* Completing delivery when the customer receives the order

---

# 3. Delivery Architecture

The overall architecture can be represented as:

```text
                     CUSTOMER
                         |
                         v
                       ORDER
                         |
                         v
                       STORE
                         |
                         v
                 READY_FOR_PICKUP
                         |
                         v
                DELIVERY PARTNER
                         |
             +-----------+-----------+
             |                       |
             v                       v
       Location Tracking       Order Status
             |                       |
             v                       v
        Browser GPS             PostgreSQL
             |
             v
        Backend API
```

---

# 4. Delivery and Order

Delivery is a stage within the order lifecycle.

The relationship is:

```text
Order
  |
  v
Store Fulfillment
  |
  v
READY_FOR_PICKUP
  |
  v
Delivery
  |
  v
DELIVERED
```

The delivery system therefore does not replace the Order Management Module.

Instead, it operates on orders after they reach the appropriate fulfillment stage.

---

# 5. Delivery Status Lifecycle

The delivery-partner workflow uses the following progression:

```text
READY_FOR_PICKUP
        |
        v
    ACCEPTED
        |
        v
    PICKED_UP
        |
        v
 OUT_FOR_DELIVERY
        |
        v
    DELIVERED
```

Each state represents a different operational stage.

---

# 6. READY_FOR_PICKUP

`READY_FOR_PICKUP` means that the store has prepared the order and it is ready to be collected.

```text
Store
  |
  v
Order Preparation
  |
  v
READY_FOR_PICKUP
```

At this stage, the delivery order can become available to an eligible delivery partner.

---

# 7. ACCEPTED

When a delivery partner accepts an available delivery:

```text
READY_FOR_PICKUP
        |
        v
Delivery Partner
        |
        v
ACCEPTED
```

The delivery is now associated with the accepting delivery partner according to the backend workflow.

---

# 8. PICKED_UP

After the delivery partner collects the order from the store:

```text
Store
  |
  v
Delivery Partner
  |
  v
PICKED_UP
```

This indicates that the physical order has moved from the store to the delivery partner.

---

# 9. OUT_FOR_DELIVERY

After pickup, the delivery partner travels toward the customer's delivery address.

```text
Store
  |
  v
Delivery Partner
  |
  v
Customer Address
```

The order enters:

```text
OUT_FOR_DELIVERY
```

during this stage.

---

# 10. DELIVERED

When the delivery is completed:

```text
OUT_FOR_DELIVERY
        |
        v
Customer
        |
        v
DELIVERED
```

This represents the completion of the delivery workflow.

---

# 11. Delivery Partner

The delivery system revolves around the `DeliveryPartner` entity.

Conceptually:

```text
DeliveryPartner
       |
       +--> User
       |
       +--> Vehicle
       |
       +--> Availability
       |
       +--> Location
       |
       +--> Deliveries
```

The delivery partner is therefore more than simply a user account.

The application maintains delivery-specific information separately from the common `User` entity.

---

# 12. Delivery Partner Profile

LocalMart contains:

```text
DeliveryPartnerProfileController
DeliveryPartnerProfileService
DeliveryPartnerProfileResponse
```

These components manage delivery-partner-specific profile information.

The general architecture is:

```text
React
  |
  v
DeliveryPartnerProfileController
  |
  v
DeliveryPartnerProfileService
  |
  v
DeliveryPartner
  |
  v
PostgreSQL
```

---

# 13. Delivery Partner Registration

Delivery partners require an application/approval process.

The high-level lifecycle is:

```text
Registration
    |
    v
Application Request
    |
    v
Admin Review
    |
    +------> REJECTED
    |
    v
APPROVED
    |
    v
Delivery Partner Account
```

This prevents an unapproved delivery partner from immediately participating in delivery operations.

---

# 14. Vehicle Information

LocalMart contains:

```text
VehicleDetails
VehicleDetailsRepository
```

Delivery partners can therefore have vehicle-related information associated with their delivery profile.

Conceptually:

```text
Delivery Partner
      |
      v
Vehicle Details
      |
      +--> Vehicle Information
```

Vehicle information can support delivery-partner operational management.

---

# 15. Delivery Partner Availability

LocalMart contains:

```text
DeliveryPartnerAvailabilityRequest
```

This represents availability-related information supplied by the delivery partner.

Conceptually:

```text
Delivery Partner
       |
       v
Availability
       |
       +--> Available
       |
       +--> Not Available
```

Availability is important when determining which delivery partners can participate in delivery operations.

---

# 16. Available Deliveries

The delivery-partner interface provides an available-delivery workflow.

The conceptual flow is:

```text
Order
  |
  v
READY_FOR_PICKUP
  |
  v
Available Deliveries
  |
  v
Delivery Partner
```

A delivery partner can review eligible available deliveries and accept one through the appropriate backend endpoint.

---

# 17. Accepting a Delivery

The backend provides an acceptance operation for delivery partners.

The flow is:

```text
Delivery Partner
      |
      | Accept
      v
Backend
      |
      v
Order / Delivery Validation
      |
      v
ACCEPTED
```

The backend should verify that the delivery is still eligible for acceptance before assigning it.

This is important because multiple delivery partners could potentially attempt to accept the same available delivery.

---

# 18. Current Deliveries

After accepting a delivery, it moves into the delivery partner's current-work area.

Conceptually:

```text
AVAILABLE
    |
    v
ACCEPTED
    |
    v
CURRENT
```

The delivery partner can then continue through the pickup and delivery workflow.

---

# 19. Completed Deliveries

Once delivery reaches:

```text
DELIVERED
```

it becomes part of the delivery partner's completed delivery history.

The UI therefore separates delivery work into concepts such as:

```text
AVAILABLE
CURRENT
COMPLETED
```

This makes it easier for a delivery partner to distinguish pending and completed work.

---

# 20. Delivery Status Update

The backend exposes status-update functionality for delivery partners.

The general flow is:

```text
Delivery Partner
      |
      v
Status Update Request
      |
      v
Backend
      |
      v
Validate Current Status
      |
      v
Update Order
      |
      v
Database
```

The important concept is that status changes are controlled by the backend rather than simply being a frontend-only state.

---

# 21. Status Transition Model

The delivery workflow can be viewed as a state machine:

```text
             +-------------------+
             |                   |
             v                   |
READY_FOR_PICKUP                 |
             |                   |
             v                   |
         ACCEPTED                |
             |                   |
             v                   |
         PICKED_UP               |
             |                   |
             v                   |
      OUT_FOR_DELIVERY           |
             |                   |
             v                   |
         DELIVERED  <------------+
```

In practice, the backend should only permit valid transitions defined by the business rules.

---

# 22. Why Status Is Backend Controlled

The frontend should not be the authority for delivery state.

For example, a browser should not simply decide:

```text
status = DELIVERED
```

and have the backend blindly accept it.

Instead:

```text
React
  |
  v
Status Request
  |
  v
Backend
  |
  +--> Authenticate Partner
  |
  +--> Verify Order
  |
  +--> Verify Ownership / Assignment
  |
  +--> Validate Transition
  |
  v
Database
```

This protects the integrity of the delivery workflow.

---

# 23. Delivery Partner Location

LocalMart supports delivery-partner location functionality.

The backend contains:

```text
DeliveryPartnerLocationController
DeliveryPartnerLocationService
DeliveryPartnerLocation
DeliveryPartnerLocationRepository
DeliveryPartnerLocationRequest
```

This creates a dedicated location subsystem for delivery partners.

---

# 24. Delivery Partner Location Architecture

The architecture is:

```text
Delivery Partner Browser
        |
        v
Browser Geolocation API
        |
        v
Latitude / Longitude
        |
        v
React
        |
        | HTTP
        v
DeliveryPartnerLocationController
        |
        v
DeliveryPartnerLocationService
        |
        v
DeliveryPartnerLocationRepository
        |
        v
PostgreSQL
```

---

# 25. Browser Geolocation

The frontend uses the browser's built-in:

```text
navigator.geolocation.getCurrentPosition()
```

This is not a LocalMart library.

It is a browser Web API provided by the browser environment.

The browser obtains the device's current geographic position using the available device/browser location mechanisms.

Conceptually:

```text
Device
  |
  v
Browser
  |
  v
Geolocation API
  |
  v
Latitude + Longitude
```

---

# 26. Location Request

The frontend sends location information to the backend.

Conceptually:

```text
React
 |
 | latitude
 | longitude
 v
DeliveryPartnerLocationRequest
 |
 v
DeliveryPartnerLocationController
 |
 v
DeliveryPartnerLocationService
```

The backend can then persist the location information.

---

# 27. Delivery Partner Location Entity

The backend contains:

```text
DeliveryPartnerLocation
```

This represents delivery-partner location information stored by the application.

The conceptual relationship is:

```text
DeliveryPartner
       |
       v
DeliveryPartnerLocation
       |
       +--> Latitude
       +--> Longitude
       +--> Location metadata
```

The exact fields and persistence behavior follow the current entity implementation.

---

# 28. Why Location Tracking Is Separate

Location tracking is a separate concern from order status.

For example:

```text
Order Status
-------------
PICKED_UP
OUT_FOR_DELIVERY

Location
-------------
Latitude
Longitude
```

The order tells the system **what stage the delivery is in**.

The location tells the system **where the delivery partner currently is**.

These are different types of information.

---

# 29. Location During Delivery

The relationship can be visualized as:

```text
                 ORDER
                   |
                   v
             OUT_FOR_DELIVERY
                   |
                   v
          Delivery Partner
                   |
                   v
          Current Location
                   |
                   v
            Customer Address
```

This allows location information to complement order status.

---

# 30. Store Location

A delivery requires a starting location.

The store has an address/location associated with it.

Conceptually:

```text
Store
  |
  v
Store Address
  |
  v
Latitude / Longitude
```

This provides the origin for delivery-distance calculations.

---

# 31. Customer Location

The customer's selected delivery address can contain geographic coordinates.

Conceptually:

```text
Customer
   |
   v
Saved Address
   |
   +--> Latitude
   +--> Longitude
```

These coordinates can be used for delivery calculations.

---

# 32. Road Distance

LocalMart contains:

```text
RoadDistanceService
```

which supports road-distance calculation.

The application integrates with **OSRM** for routing information.

The conceptual flow is:

```text
Store Coordinates
       |
       +
       |
Customer Coordinates
       |
       v
RoadDistanceService
       |
       v
OSRM
       |
       v
Road Distance / Duration
```

---

# 33. Why Road Distance Is Used

Straight-line geographic distance is not necessarily the actual distance travelled by a delivery partner.

For example:

```text
Store ---------------- Customer
       Straight line
```

may differ from:

```text
Store
  |
  +---- Road ----+
                |
                +------ Customer
```

OSRM can provide road-based routing information.

This makes road distance more appropriate for delivery-related calculations.

---

# 34. Delivery Fee

The delivery fee can depend on delivery distance.

The conceptual calculation is:

```text
Store
  |
  v
Road Distance
  |
  v
Delivery Fee Calculation
  |
  v
Customer Checkout
```

The frontend sends the relevant:

```text
storeId
addressId
```

to the delivery-fee endpoint.

The backend then uses the relevant store and customer address information to calculate the delivery-related amount.

---

# 35. Delivery Fee Flow

The complete flow is:

```text
Customer
   |
   v
Checkout
   |
   v
Selected Address
   |
   v
storeId + addressId
   |
   v
OrderController
   |
   v
OrderService
   |
   v
RoadDistanceService
   |
   v
OSRM
   |
   v
Road Distance
   |
   v
Delivery Fee
   |
   v
Checkout
```

The delivery-fee functionality is therefore shared between the Order and Location subsystems.

---

# 36. Delivery Partner Earnings

Delivery-related information can also be used by the delivery-partner interface to display delivery-related earning information.

Conceptually:

```text
Delivery
   |
   +--> Delivery Fee
   |
   v
Delivery Partner
   |
   v
Estimated Earnings
```

The exact earnings calculation and persistence rules should follow the current implementation.

---

# 37. Delivery Partner Location During an Active Delivery

An active delivery can combine order state and location state:

```text
Order
 |
 v
ACCEPTED
 |
 v
Delivery Partner
 |
 v
PICKED_UP
 |
 v
OUT_FOR_DELIVERY
 |
 +----------------------+
 |                      |
 v                      v
Location Updates    Customer Address
 |                      |
 +----------+-----------+
            |
            v
         DELIVERED
```

This provides the foundation for delivery tracking.

---

# 38. Delivery Tracking Architecture

The conceptual tracking architecture is:

```text
+-------------------+
| Delivery Partner  |
| Browser           |
+---------+---------+
          |
          | GPS position
          v
+-------------------+
| React Frontend    |
+---------+---------+
          |
          | HTTP
          v
+-------------------+
| Spring Boot       |
| Location API      |
+---------+---------+
          |
          v
+-------------------+
| PostgreSQL        |
+-------------------+
```

The stored location can then be associated with the delivery-partner record.

---

# 39. Delivery Controller Layer

Delivery-related operations are exposed through controllers such as:

```text
DeliveryPartnerLocationController
DeliveryPartnerProfileController
```

and order-related delivery operations are exposed through the order controller functionality.

The controller layer handles HTTP communication.

---

# 40. Delivery Service Layer

The main delivery-related services include:

```text
DeliveryPartnerLocationService
DeliveryPartnerProfileService
RoadDistanceService
OrderService
```

These services divide responsibilities between:

```text
Profile Management
Location Management
Distance Calculation
Order / Delivery Workflow
```

---

# 41. Delivery Repository Layer

The persistence layer contains:

```text
DeliveryPartnerRepository
DeliveryPartnerLocationRepository
VehicleDetailsRepository
OrderRepository
```

The general architecture is:

```text
Service
   |
   v
Repository
   |
   v
PostgreSQL
```

---

# 42. Delivery Database Relationships

The conceptual relationships are:

```text
users
  |
  v
delivery_partner
  |
  +------> vehicle_details
  |
  +------> delivery_partner_location
  |
  v
orders
```

The exact foreign-key mappings are determined by the current JPA entities and database schema.

---

# 43. Delivery and Authentication

Delivery operations are protected by the application's authentication system.

The request flow is:

```text
Delivery Partner
      |
      | Bearer JWT
      v
JwtAuthenticationFilter
      |
      v
Spring Security
      |
      v
Authenticated User
      |
      v
Delivery API
```

This allows the backend to identify which delivery partner is making the request.

---

# 44. Delivery Authorization

Authentication answers:

```text
"Who is making the request?"
```

Authorization answers:

```text
"Is this user allowed to perform this delivery operation?"
```

For example:

```text
JWT
 |
 v
User
 |
 v
DELIVERY_PARTNER
 |
 v
Delivery Operation
```

The backend can then apply delivery-specific authorization rules.

---

# 45. Delivery Partner Ownership

A delivery partner should only be able to manipulate deliveries associated with them or available to them according to the workflow.

Conceptually:

```text
Authenticated Delivery Partner
            |
            v
       Delivery Request
            |
            v
       Authorization
            |
            v
    Allowed Delivery
```

This prevents one delivery partner from arbitrarily modifying another delivery partner's active deliveries.

---

# 46. Concurrent Delivery Acceptance

A delivery may be visible to multiple eligible delivery partners.

For example:

```text
             READY_FOR_PICKUP
                    |
          +---------+---------+
          |         |         |
          v         v         v
        DP-A      DP-B      DP-C
```

If two partners attempt to accept the same delivery simultaneously, the backend must ensure that only a valid assignment succeeds.

This is a concurrency/data-integrity concern.

The exact locking or transactional strategy should follow the current implementation.

---

# 47. Delivery Status and Database

A status change is persisted through the backend.

For example:

```text
ACCEPTED
   |
   v
Order Entity
   |
   v
OrderRepository
   |
   v
PostgreSQL
```

The database therefore becomes the persistent source of the order's delivery state.

---

# 48. Customer Visibility

The customer can observe order progress through the customer order interface.

Conceptually:

```text
Backend Order State
       |
       v
Order API
       |
       v
Customer React UI
       |
       v
Delivery Status
```

For example, the customer can see progression such as:

```text
Preparing
   |
   v
Ready for Pickup
   |
   v
Accepted
   |
   v
Picked Up
   |
   v
Out for Delivery
   |
   v
Delivered
```

The exact customer-facing labels may differ from backend enum/status values.

---

# 49. Delivery Module and Store Module

The store is the origin of the delivery.

```text
Store
  |
  v
Order Preparation
  |
  v
READY_FOR_PICKUP
  |
  v
Delivery Partner
```

The delivery system therefore depends on valid store information and store location.

---

# 50. Delivery Module and Customer Module

The customer provides the delivery destination.

```text
Customer
  |
  v
Saved Address
  |
  v
Latitude / Longitude
  |
  v
Delivery
```

The address subsystem therefore supplies critical delivery information.

---

# 51. Delivery Module and Location Module

Location services provide two different types of information.

### Customer/store coordinates

Used for:

```text
Distance calculation
Delivery fee
Routing
```

### Delivery partner location

Used for:

```text
Current delivery-partner position
Delivery tracking
```

These should not be confused.

```text
Store Location
      |
      +------+
             |
             v
          Routing
             ^
             |
Customer Location


Delivery Partner Location
             |
             v
       Live/Current Position
```

---

# 52. Delivery Module and Payment

Payment occurs before or as part of the order's fulfillment process.

The high-level relationship is:

```text
Payment
   |
   v
Order
   |
   v
Store Fulfillment
   |
   v
Delivery
```

The delivery partner does not process the customer's payment.

Payment and delivery therefore remain separate concerns.

---

# 53. Delivery Error Handling

Possible delivery-related failures include:

```text
Delivery not found
Delivery already accepted
Invalid delivery status
Unauthorized delivery access
Delivery partner unavailable
Invalid location
Invalid coordinates
Invalid order state
Location update failure
Distance calculation failure
Routing service failure
```

The backend's global exception-handling mechanism can provide consistent API responses for applicable failures.

---

# 54. Location Failure

The browser may not always provide a location.

For example:

```text
Browser
   |
   v
Geolocation Request
   |
   +----> Success
   |
   +----> Permission Denied
   |
   +----> Position Unavailable
   |
   +----> Timeout
```

The frontend therefore needs to handle location failures without assuming that a GPS position is always available.

---

# 55. External Routing Failure

OSRM is an external dependency.

Therefore:

```text
LocalMart
   |
   v
RoadDistanceService
   |
   v
OSRM
   |
   +----> Success
   |
   +----> Error / Timeout
```

The application must account for external-service failures when performing routing or distance-dependent operations.

---

# 56. Complete Delivery Flow

The complete delivery lifecycle is:

```text
Customer Places Order
        |
        v
Store Receives Order
        |
        v
Store Prepares Order
        |
        v
READY_FOR_PICKUP
        |
        v
Available Delivery
        |
        v
Delivery Partner Accepts
        |
        v
ACCEPTED
        |
        v
Delivery Partner Travels to Store
        |
        v
PICKED_UP
        |
        v
Delivery Partner Travels to Customer
        |
        v
OUT_FOR_DELIVERY
        |
        v
Customer Receives Order
        |
        v
DELIVERED
```

---

# 57. Delivery Location Flow

The location side can operate alongside the delivery lifecycle:

```text
Delivery Partner
       |
       v
Browser Geolocation
       |
       v
Latitude / Longitude
       |
       v
React
       |
       v
DeliveryPartnerLocationController
       |
       v
DeliveryPartnerLocationService
       |
       v
DeliveryPartnerLocationRepository
       |
       v
PostgreSQL
```

During an active delivery:

```text
Order Status
     +
Partner Location
     |
     v
Delivery Tracking Context
```

---

# 58. Complete Delivery Architecture

The complete architecture can be visualized as:

```text
                         CUSTOMER
                            |
                            v
                          ORDER
                            |
                            v
                           STORE
                            |
                            v
                    READY_FOR_PICKUP
                            |
                            v
                   AVAILABLE DELIVERY
                            |
                            v
                   DELIVERY PARTNER
                            |
               +------------+------------+
               |                         |
               v                         v
          ORDER STATUS              LOCATION
               |                         |
               v                         v
        PostgreSQL               Browser GPS
                                         |
                                         v
                                      React
                                         |
                                         v
                               Location Controller
                                         |
                                         v
                                      Service
                                         |
                                         v
                                    PostgreSQL
                            |
                            v
                     OUT_FOR_DELIVERY
                            |
                            v
                         CUSTOMER
                            |
                            v
                         DELIVERED
```

---

# 59. Delivery Backend Components

The major delivery-related backend components currently include:

## Controllers

```text
DeliveryPartnerLocationController
DeliveryPartnerProfileController
OrderController
```

## Services

```text
DeliveryPartnerLocationService
DeliveryPartnerProfileService
OrderService
RoadDistanceService
```

## Entities

```text
DeliveryPartner
DeliveryPartnerLocation
VehicleDetails
Order
```

## Repositories

```text
DeliveryPartnerRepository
DeliveryPartnerLocationRepository
VehicleDetailsRepository
OrderRepository
```

## DTOs

```text
DeliveryPartnerAvailabilityRequest
DeliveryPartnerLocationRequest
DeliveryPartnerProfileResponse
DeliveryOrderResponse
```

---

# 60. External Services

The delivery subsystem interacts with external and browser-provided services.

### Browser Geolocation API

Provides the delivery partner's device location to the frontend.

```text
navigator.geolocation
```

### OSRM

Provides road-routing information used for road distance/duration calculations.

```text
LocalMart
   |
   v
RoadDistanceService
   |
   v
OSRM
```

### Geocoding Service

Location/address conversion functionality can provide geographic information needed by the application.

```text
Address
   |
   v
Geocoding Service
   |
   v
Coordinates / Location Information
```

---

# 61. Delivery Security Model

The security model is:

```text
Delivery Partner
       |
       v
JWT
       |
       v
Spring Security
       |
       v
Role Verification
       |
       v
Delivery Authorization
       |
       v
Delivery Operation
```

The backend remains responsible for determining whether the operation is permitted.

---

# 62. Delivery State vs Location State

An important architectural distinction is:

```text
ORDER STATE
-----------
READY_FOR_PICKUP
ACCEPTED
PICKED_UP
OUT_FOR_DELIVERY
DELIVERED


LOCATION STATE
--------------
Latitude
Longitude
Timestamp / location metadata
```

The two systems complement each other but represent different information.

---

# 63. Delivery System Design Principles

### Backend-controlled status

The backend controls the persistent delivery state.

### Role-based access

Only authorized delivery partners can perform delivery operations.

### Persistent state

Delivery status and relevant delivery information are stored in the backend/database.

### Location separation

Delivery-partner location is handled separately from order status.

### External-service isolation

Routing logic is isolated through `RoadDistanceService`.

### Store/customer separation

The store provides the origin; the customer provides the destination.

### Concurrency awareness

Delivery acceptance must account for multiple partners potentially attempting to accept the same delivery.

---

# 64. End-to-End Delivery Example

A simplified LocalMart delivery can be represented as:

```text
1. Customer
      |
      v
   Places Order
      |
      v

2. Store
      |
      v
   Prepares Order
      |
      v

3. Order
      |
      v
READY_FOR_PICKUP
      |
      v

4. Delivery Partner
      |
      v
   Sees Available Delivery
      |
      v
   Accepts
      |
      v

5. Order
      |
      v
ACCEPTED
      |
      v

6. Delivery Partner
      |
      v
   Travels to Store
      |
      v
   Picks Up
      |
      v

7. Order
      |
      v
PICKED_UP
      |
      v

8. Delivery Partner
      |
      v
   Travels to Customer
      |
      v

9. Order
      |
      v
OUT_FOR_DELIVERY
      |
      v

10. Customer
       |
       v
    Receives Order
       |
       v

11. Order
       |
       v
    DELIVERED
```

---

# 65. Summary

The LocalMart Delivery System connects the store, delivery partner, customer, order, and location services into one fulfillment workflow.

The core lifecycle is:

```text
READY_FOR_PICKUP
        |
        v
    ACCEPTED
        |
        v
    PICKED_UP
        |
        v
 OUT_FOR_DELIVERY
        |
        v
    DELIVERED
```

The delivery architecture is:

```text
                    ORDER
                      |
                      v
                   STORE
                      |
                      v
              READY_FOR_PICKUP
                      |
                      v
              DELIVERY PARTNER
                      |
             +--------+--------+
             |                 |
             v                 v
        STATUS FLOW         LOCATION
                               |
                               v
                         Browser GPS
                               |
                               v
                            React
                               |
                               v
                         Backend API
                               |
                               v
                          PostgreSQL
                      |
                      v
                CUSTOMER
                      |
                      v
                  DELIVERED
```

The major LocalMart components involved are:

```text
DeliveryPartner
DeliveryPartnerLocation
VehicleDetails
DeliveryPartnerRepository
DeliveryPartnerLocationRepository
VehicleDetailsRepository
DeliveryPartnerLocationController
DeliveryPartnerProfileController
DeliveryPartnerLocationService
DeliveryPartnerProfileService
RoadDistanceService
OrderService
```

The Delivery System therefore forms the bridge between **store fulfillment and final customer delivery**, while location services provide the geographic information needed to support delivery operations and road-distance calculations.
