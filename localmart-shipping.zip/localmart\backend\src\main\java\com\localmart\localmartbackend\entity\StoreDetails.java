
            package com.localmart.localmartbackend.entity;

    import jakarta.persistence.*;

    @Entity
    @Table(name = "store_details")
    public class StoreDetails {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Column(name = "store_id")
        private Long storeId;

        @Column(name = "user_id", nullable = false, unique = true)
        private Long userId;

        @Column(name = "store_name", nullable = false, length = 255)
        private String storeName;

        @Column(name = "business_type", nullable = false, length = 100)
        private String businessType;

        @Column(name = "gst_number", unique = true, length = 50)
        private String gstNumber;

        public StoreDetails() {
        }

        public Long getStoreId() {
            return storeId;
        }

        public void setStoreId(Long storeId) {
            this.storeId = storeId;
        }

        public Long getUserId() {
            return userId;
        }

        public void setUserId(Long userId) {
            this.userId = userId;
        }

        public String getStoreName() {
            return storeName;
        }

        public void setStoreName(String storeName) {
            this.storeName = storeName;
        }

        public String getBusinessType() {
            return businessType;
        }

        public void setBusinessType(String businessType) {
            this.businessType = businessType;
        }

        public String getGstNumber() {
            return gstNumber;
        }

        public void setGstNumber(String gstNumber) {
            this.gstNumber = gstNumber;
        }
    }

