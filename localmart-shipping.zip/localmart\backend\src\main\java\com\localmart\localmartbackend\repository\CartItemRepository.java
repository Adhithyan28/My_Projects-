package com.localmart.localmartbackend.repository;

import com.localmart.localmartbackend.entity.CartItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CartItemRepository extends JpaRepository<CartItem, Long> {

    List<CartItem> findByCartId(Long cartId);

    Optional<CartItem> findByCartIdAndProductId(
            Long cartId,
            Long productId
    );

    Optional<CartItem> findByCartItemIdAndCartId(
            Long cartItemId,
            Long cartId
    );

    void deleteByCartId(Long cartId);

    boolean existsByCartIdAndProductId(
            Long cartId,
            Long productId
    );
}