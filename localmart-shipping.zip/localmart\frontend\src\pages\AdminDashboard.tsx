
import { useEffect, useState } from "react"
import { useAuth } from "../context/AuthContext"
import "./AdminDashboard.css"

interface Application {
    userId: number
    email: string
    role: string
    accountStatus: string
    createdAt: string
    updatedAt: string
}

interface Customer {
    userId: number
    firstName: string
    lastName: string
    email: string
    phone: string
    accountStatus: number
    createdAt: string
}

interface Store {
    storeId: number
    userId: number
    storeName: string
    businessType: string
    city: string | null
    state: string | null
    latitude: number | null
    longitude: number | null
    accountStatus: number
}

interface DeliveryPartner {
    userId: number
    firstName: string
    lastName: string
    email: string
    phone: string
    accountStatus: number
    createdAt: string
    drivingLicenceNumber: string
    vehicleId: number
    vehicleType: string | null
    vehicleNumber: string | null
}

type AdminSection =
    | "overview"
    | "stores"
    | "delivery-partners"
    | "users"


function AdminDashboard() {

    const { user, logout } = useAuth()

    const [activeSection, setActiveSection] =
        useState<AdminSection>("overview")

    const [storeOwnerRequests, setStoreOwnerRequests] =
        useState<Application[]>([])

    const [deliveryPartnerRequests, setDeliveryPartnerRequests] =
        useState<Application[]>([])

    const [customers, setCustomers] =
        useState<Customer[]>([])

    const [stores, setStores] =
        useState<Store[]>([])

    const [deliveryPartners, setDeliveryPartners] =
        useState<DeliveryPartner[]>([])

    const [loadingStores, setLoadingStores] =
        useState(true)

    const [loadingDrivers, setLoadingDrivers] =
        useState(true)

    const [loadingCustomers, setLoadingCustomers] =
        useState(false)

    const [loadingAvailableStores, setLoadingAvailableStores] =
        useState(false)

    const [loadingDeliveryPartners, setLoadingDeliveryPartners] =
        useState(false)

    const [processingUserId, setProcessingUserId] =
        useState<number | null>(null)

    const [message, setMessage] =
        useState("")


    /* =====================================================
       LOAD ADMIN APPLICATION DATA
       ===================================================== */

    useEffect(() => {

        if (!user?.token) {

            setLoadingStores(false)
            setLoadingDrivers(false)

            setMessage(
                "You are not authorized to access admin data."
            )

            return
        }

        fetchStoreOwnerRequests()
        fetchDeliveryPartnerRequests()

    }, [user?.token])


    /* =====================================================
       STORE OWNER REQUESTS
       ===================================================== */

    const fetchStoreOwnerRequests =
        async () => {

            if (!user?.token) {
                return
            }

            try {

                setLoadingStores(true)

                const response =
                    await fetch(
                        "/api/admin/store-owner-requests",
                        {
                            method: "GET",

                            headers: {
                                "Authorization":
                                    `Bearer ${user.token}`,
                            },
                        }
                    )

                if (!response.ok) {

                    if (
                        response.status === 401 ||
                        response.status === 403
                    ) {

                        throw new Error(
                            "You are not authorized to access admin data."
                        )
                    }

                    throw new Error(
                        `Request failed: ${response.status}`
                    )
                }

                const data:
                    Application[] =
                    await response.json()

                setStoreOwnerRequests(data)

            } catch (error) {

                console.error(
                    "Failed to load store owner requests:",
                    error
                )

                setMessage(
                    error instanceof Error
                        ? error.message
                        : "Cannot load store owner applications."
                )

            } finally {

                setLoadingStores(false)
            }
        }


    /* =====================================================
       DELIVERY PARTNER REQUESTS
       ===================================================== */

    const fetchDeliveryPartnerRequests =
        async () => {

            if (!user?.token) {
                return
            }

            try {

                setLoadingDrivers(true)

                const response =
                    await fetch(
                        "/api/admin/delivery-partner-requests",
                        {
                            method: "GET",

                            headers: {
                                "Authorization":
                                    `Bearer ${user.token}`,
                            },
                        }
                    )

                if (!response.ok) {

                    if (
                        response.status === 401 ||
                        response.status === 403
                    ) {

                        throw new Error(
                            "You are not authorized to access admin data."
                        )
                    }

                    throw new Error(
                        `Request failed: ${response.status}`
                    )
                }

                const data:
                    Application[] =
                    await response.json()

                setDeliveryPartnerRequests(
                    data
                )

            } catch (error) {

                console.error(
                    "Failed to load delivery partner requests:",
                    error
                )

                setMessage(
                    error instanceof Error
                        ? error.message
                        : "Cannot load delivery partner applications."
                )

            } finally {

                setLoadingDrivers(false)
            }
        }


    /* =====================================================
       CUSTOMERS
       ===================================================== */

    const fetchCustomers =
        async () => {

            if (!user?.token) {
                return
            }

            try {

                setLoadingCustomers(true)
                setMessage("")

                const response =
                    await fetch(
                        "/api/admin/data/customers",
                        {
                            method: "GET",

                            headers: {
                                "Authorization":
                                    `Bearer ${user.token}`,
                            },
                        }
                    )

                if (!response.ok) {

                    if (
                        response.status === 401 ||
                        response.status === 403
                    ) {

                        throw new Error(
                            "You are not authorized to access customer data."
                        )
                    }

                    throw new Error(
                        `Customer request failed: ${response.status}`
                    )
                }

                const data:
                    Customer[] =
                    await response.json()

                setCustomers(data)

            } catch (error) {

                console.error(
                    "Failed to load customers:",
                    error
                )

                setMessage(
                    error instanceof Error
                        ? error.message
                        : "Cannot load customers."
                )

            } finally {

                setLoadingCustomers(false)
            }
        }


    /* =====================================================
       STORES
       ===================================================== */

    const fetchStores =
        async () => {

            if (!user?.token) {
                return
            }

            try {

                setLoadingAvailableStores(true)
                setMessage("")

                const response =
                    await fetch(
                        "/api/admin/data/stores",
                        {
                            method: "GET",

                            headers: {
                                "Authorization":
                                    `Bearer ${user.token}`,
                            },
                        }
                    )

                if (!response.ok) {

                    if (
                        response.status === 401 ||
                                               response.status === 403
                    ) {

                        throw new Error(
                            "You are not authorized to access store data."
                        )
                    }

                    throw new Error(
                        `Store request failed: ${response.status}`
                    )
                }

                const data:
                    Store[] =
                    await response.json()

                setStores(data)

            } catch (error) {

                console.error(
                    "Failed to load stores:",
                    error
                )

                setMessage(
                    error instanceof Error
                        ? error.message
                        : "Cannot load stores."
                )

            } finally {

                setLoadingAvailableStores(false)
            }
        }


    /* =====================================================
       DELIVERY PARTNERS
       ===================================================== */

    const fetchDeliveryPartners =
        async () => {

            if (!user?.token) {
                return
            }

            try {

                setLoadingDeliveryPartners(true)
                setMessage("")

                const response =
                    await fetch(
                        "/api/admin/data/delivery-partners",
                        {
                            method: "GET",

                            headers: {
                                "Authorization":
                                    `Bearer ${user.token}`,
                            },
                        }
                    )

                if (!response.ok) {

                    if (
                        response.status === 401 ||
                        response.status === 403
                    ) {

                        throw new Error(
                            "You are not authorized to access delivery partner data."
                        )
                    }

                    throw new Error(
                        `Delivery partner request failed: ${response.status}`
                    )
                }

                const data:
                    DeliveryPartner[] =
                    await response.json()

                setDeliveryPartners(data)

            } catch (error) {

                console.error(
                    "Failed to load delivery partners:",
                    error
                )

                setMessage(
                    error instanceof Error
                        ? error.message
                        : "Cannot load delivery partners."
                )

            } finally {

                setLoadingDeliveryPartners(false)
            }
        }


    /* =====================================================
       LOAD SECTION DATA WHEN SELECTED
       ===================================================== */

    useEffect(() => {

        if (!user?.token) {
            return
        }

        if (activeSection === "users") {
            fetchCustomers()
        }

        if (activeSection === "stores") {
            fetchStores()
        }

        if (activeSection === "delivery-partners") {
            fetchDeliveryPartners()
        }

    }, [activeSection, user?.token])


    /* =====================================================
       APPROVE REQUEST
       ===================================================== */

    const approveRequest =
        async (userId: number) => {

            if (!user?.token) {
                return
            }

            try {

                setProcessingUserId(userId)
                setMessage("")

                const response =
                    await fetch(
                        `/api/admin/requests/${userId}/approve`,
{
    method: "PUT",

        headers: {
    "Authorization":
    `Bearer ${user.token}`,
},
}
)

if (!response.ok) {

    const text =
        await response.text()

    throw new Error(
        text ||
        `Approve failed (${response.status})`
    )
}

setStoreOwnerRequests(
    previous =>
        previous.filter(
            application =>
                application.userId !==
                userId
        )
)

setDeliveryPartnerRequests(
    previous =>
        previous.filter(
            application =>
                application.userId !==
                userId
        )
)

setMessage(
    "Application approved successfully."
)

} catch (error) {

    console.error(error)

    setMessage(
        error instanceof Error
            ? error.message
            : "Failed to approve the application."
    )

} finally {

    setProcessingUserId(null)
}
}


/* =====================================================
   REJECT REQUEST
   ===================================================== */

const rejectRequest =
    async (userId: number) => {

        if (!user?.token) {
            return
        }

        try {

            setProcessingUserId(userId)
            setMessage("")

            const response =
                await fetch(
                    `/api/admin/requests/${userId}/reject`,
                    {
                        method: "PUT",

                        headers: {
                            "Authorization":
                                `Bearer ${user.token}`,
                        },
                    }
                )

            if (!response.ok) {

                const text =
                    await response.text()

                throw new Error(
                    text ||
                    `Reject failed (${response.status})`
                )
            }

            setStoreOwnerRequests(
                previous =>
                    previous.filter(
                        application =>
                            application.userId !==
                            userId
                    )
            )

            setDeliveryPartnerRequests(
                previous =>
                    previous.filter(
                        application =>
                            application.userId !==
                            userId
                    )
            )

            setMessage(
                "Application rejected successfully."
            )

        } catch (error) {

            console.error(error)

            setMessage(
                error instanceof Error
                    ? error.message
                    : "Failed to reject the application."
            )

        } finally {

            setProcessingUserId(null)
        }
    }


/* =====================================================
   BLOCK CUSTOMER
   ===================================================== */

const handleBlockUser =
    async (userId: number) => {

        if (!user?.token) {
            return
        }

        try {

            setProcessingUserId(userId)
            setMessage("")

            const response =
                await fetch(
                    `/api/admin/data/users/${userId}/block`,
                    {
                        method: "PUT",

                        headers: {
                            "Authorization":
                                `Bearer ${user.token}`,
                        },
                    }
                )

            if (!response.ok) {

                const text =
                    await response.text()

                throw new Error(
                    text ||
                    `Block user failed (${response.status})`
                )
            }

            setCustomers(
                previous =>
                    previous.map(
                        customer =>
                            customer.userId === userId
                                ? {
                                    ...customer,
                                    accountStatus: 3
                                }
                                : customer
                    )
            )

            setMessage(
                "Customer blocked successfully."
            )

        } catch (error) {

            console.error(
                "Failed to block customer:",
                error
            )

            setMessage(
                error instanceof Error
                    ? error.message
                    : "Failed to block customer."
            )

        } finally {

            setProcessingUserId(null)
        }
    }


/* =====================================================
   UNBLOCK CUSTOMER
   ===================================================== */

const handleUnblockUser =
    async (userId: number) => {

        if (!user?.token) {
            return
        }

        try {

            setProcessingUserId(userId)
            setMessage("")

            const response =
                await fetch(
                    `/api/admin/data/users/${userId}/unblock`,
                    {
                        method: "PUT",

                        headers: {
                            "Authorization":
                                `Bearer ${user.token}`,
                        },
                    }
                )

            if (!response.ok) {

                const text =
                    await response.text()

                throw new Error(
                    text ||
                    `Unblock user failed (${response.status})`
                )
            }

            setCustomers(
                previous =>
                    previous.map(
                        customer =>
                            customer.userId === userId
                                ? {
                                    ...customer,
                                    accountStatus: 1
                                }
                                : customer
                    )
            )

            setMessage(
                "Customer unblocked successfully."
            )

        } catch (error) {

            console.error(
                "Failed to unblock customer:",
                error
            )

            setMessage(
                error instanceof Error
                    ? error.message
                    : "Failed to unblock customer."
            )

        } finally {

            setProcessingUserId(null)
        }
    }


/* =====================================================
   BLOCK STORE
   ===================================================== */

const handleBlockStore =
    async (userId: number) => {

        if (!user?.token) {
            return
        }

        try {

            setProcessingUserId(userId)
            setMessage("")

            const response =
                await fetch(
                    `/api/admin/data/users/${userId}/block`,
                    {
                        method: "PUT",

                        headers: {
                            "Authorization":
                                `Bearer ${user.token}`,
                        },
                    }
                )

            if (!response.ok) {

                const text =
                    await response.text()

                throw new Error(
                    text ||
                    `Block store failed (${response.status})`
                )
            }

            setStores(
                previous =>
                    previous.map(
                        store =>
                            store.userId === userId
                                ? {
                                    ...store,
                                    accountStatus: 3
                                }
                                : store
                    )
            )

            setMessage(
                "Store blocked successfully."
            )

        } catch (error) {

            console.error(
                "Failed to block store:",
                error
            )

            setMessage(
                error instanceof Error
                    ? error.message
                    : "Failed to block store."
            )

        } finally {

            setProcessingUserId(null)
        }
    }


/* =====================================================
   UNBLOCK STORE
   ===================================================== */

const handleUnblockStore =
    async (userId: number) => {

        if (!user?.token) {
            return
        }

        try {

            setProcessingUserId(userId)
            setMessage("")

            const response =
                await fetch(
                    `/api/admin/data/users/${userId}/unblock`,
                    {
                        method: "PUT",

                        headers: {
                            "Authorization":
                                `Bearer ${user.token}`,
                        },
                    }
                )

            if (!response.ok) {

                const text =
                    await response.text()

                throw new Error(
                    text ||
                    `Unblock store failed (${response.status})`
                )
            }

            setStores(
                previous =>
                    previous.map(
                        store =>
                            store.userId === userId
                                ? {
                                    ...store,
                                    accountStatus: 1
                                }
                                : store
                    )
            )

            setMessage(
                "Store unblocked successfully."
            )

        } catch (error) {

            console.error(
                "Failed to unblock store:",
                error
            )

            setMessage(
                error instanceof Error
                    ? error.message
                    : "Failed to unblock store."
            )

        } finally {

            setProcessingUserId(null)
        }
    }


/* =====================================================
   BLOCK DELIVERY PARTNER
   ===================================================== */

const handleBlockDeliveryPartner =
    async (userId: number) => {

        if (!user?.token) {
            return
        }

        try {

            setProcessingUserId(userId)
            setMessage("")

            const response =
                await fetch(
                    `/api/admin/data/users/${userId}/block`,
                    {
                        method: "PUT",

                        headers: {
                            "Authorization":
                                `Bearer ${user.token}`,
                        },
                    }
                )

            if (!response.ok) {

                const text =
                    await response.text()

                throw new Error(
                    text ||
                    `Block delivery partner failed (${response.status})`
                )
            }

            setDeliveryPartners(
                previous =>
                    previous.map(
                        partner =>
                            partner.userId === userId
                                ? {
                                    ...partner,
                                    accountStatus: 3
                                }
                                : partner
                    )
            )

            setMessage(
                "Delivery partner blocked successfully."
            )

        } catch (error) {

            console.error(
                "Failed to block delivery partner:",
                error
            )

            setMessage(
                error instanceof Error
                    ? error.message
                    : "Failed to block delivery partner."
            )

        } finally {

            setProcessingUserId(null)
        }
    }


/* =====================================================
   UNBLOCK DELIVERY PARTNER
   ===================================================== */

const handleUnblockDeliveryPartner =
    async (userId: number) => {

        if (!user?.token) {
            return
        }

        try {

            setProcessingUserId(userId)
            setMessage("")

            const response =
                await fetch(
                    `/api/admin/data/users/${userId}/unblock`,
                    {
                        method: "PUT",

                        headers: {
                            "Authorization":
                                `Bearer ${user.token}`,
                        },
                    }
                )

            if (!response.ok) {

                const text =
                    await response.text()

                throw new Error(
                    text ||
                    `Unblock delivery partner failed (${response.status})`
                )
            }

            setDeliveryPartners(
                previous =>
                    previous.map(
                        partner =>
                            partner.userId === userId
                                ? {
                                    ...partner,
                                    accountStatus: 1
                                }
                                : partner
                    )
            )

            setMessage(
                "Delivery partner unblocked successfully."
            )

        } catch (error) {

            console.error(
                "Failed to unblock delivery partner:",
                error
            )

            setMessage(
                error instanceof Error
                    ? error.message
                    : "Failed to unblock delivery partner."
            )

        } finally {

            setProcessingUserId(null)
        }
    }


/* =====================================================
   SIDEBAR ITEM CLASS
   ===================================================== */

const sidebarClass =
    (section: AdminSection) =>
        activeSection === section
            ? "sidebar-item active"
            : "sidebar-item"


return (

    <div className="admin-dashboard">


        {/* =================================================
               HEADER
               ================================================= */}

        <header className="admin-header">

            <div className="admin-logo">
                Local<span>Mart</span>
            </div>


            <div className="admin-header-right">

                <div className="admin-profile">

                    <div className="admin-avatar">
                        A
                    </div>


                    <div className="admin-profile-info">

                        <strong>
                            Admin
                        </strong>

                        <span>
                                {user?.email}
                            </span>

                    </div>

                </div>


                <button
                    className="admin-logout"
                    onClick={logout}
                >
                    Logout
                </button>

            </div>

        </header>


        {/* =================================================
               BODY
               ================================================= */}

        <div className="admin-body">


            {/* =================================================
                   SIDEBAR
                   ================================================= */}

            <aside className="admin-sidebar">


                <div className="sidebar-section">

                    <p className="sidebar-title">
                        DASHBOARD
                    </p>


                    <button
                        className={sidebarClass("overview")}
                        onClick={() =>
                            setActiveSection("overview")
                        }
                    >

                            <span className="sidebar-icon">
                                ▣
                            </span>

                        Overview

                    </button>

                </div>


                <div className="sidebar-section">

                    <p className="sidebar-title">
                        MANAGEMENT
                    </p>


                    <button
                        className={sidebarClass("stores")}
                        onClick={() =>
                            setActiveSection("stores")
                        }
                    >

                            <span className="sidebar-icon">
                                ▤
                            </span>

                        Stores

                    </button>


                    <button
                        className={sidebarClass(
                            "delivery-partners"
                        )}
                        onClick={() =>
                            setActiveSection(
                                "delivery-partners"
                            )
                        }
                    >

                            <span className="sidebar-icon">
                                ▰
                            </span>

                        Delivery Partners

                    </button>


                    <button
                        className={sidebarClass("users")}
                        onClick={() =>
                            setActiveSection("users")
                        }
                    >

                            <span className="sidebar-icon">
                                ♙
                            </span>

                        Customer

                    </button>

                </div>


            </aside>


            {/* =================================================
                   MAIN CONTENT
                   ================================================= */}

            <main className="admin-content">


                {/* =================================================
                       OVERVIEW
                       ================================================= */}

                {activeSection === "overview" && (

                    <>

                        <section className="dashboard-intro">

                            <p className="dashboard-eyebrow">
                                ADMINISTRATION
                            </p>


                            <h1>
                                Dashboard
                            </h1>


                            <p>
                                Welcome back, Admin. Manage LocalMart
                                applications and users from here.
                            </p>

                        </section>


                        {/* SUMMARY */}

                        <section className="summary-grid">


                            <div className="summary-card">

                                <div className="summary-card-top">

                                        <span>
                                            Pending Stores
                                        </span>

                                    <div className="summary-icon">
                                        ▤
                                    </div>

                                </div>


                                <strong>

                                    {loadingStores
                                        ? "--"
                                        : storeOwnerRequests.length
                                            .toString()
                                            .padStart(2, "0")}

                                </strong>


                                <p>
                                    Awaiting verification
                                </p>

                            </div>


                            <div className="summary-card">

                                <div className="summary-card-top">

                                        <span>
                                            Pending Drivers
                                        </span>

                                    <div className="summary-icon">
                                        🚚
                                    </div>

                                </div>


                                <strong>

                                    {loadingDrivers
                                        ? "--"
                                        : deliveryPartnerRequests.length
                                            .toString()
                                            .padStart(2, "0")}

                                </strong>


                                <p>
                                    Awaiting verification
                                </p>

                            </div>

                        </section>


                        {/* APPLICATIONS */}

                        <section className="applications-section">

                            <div className="applications-heading">

                                <div>

                                    <p className="dashboard-eyebrow">
                                        VERIFICATION
                                    </p>

                                    <h2>
                                        Application Requests
                                    </h2>

                                </div>

                            </div>


                            <div className="applications-grid">


                                {/* STORE OWNER APPLICATIONS */}

                                <div className="application-panel">

                                    <div className="application-panel-header">

                                        <div>

                                            <h3>
                                                Store Owner Applications
                                            </h3>

                                            <p>
                                                Businesses waiting for approval
                                            </p>

                                        </div>


                                        <span className="pending-badge">

                                                {storeOwnerRequests.length}
                                            {" "}Pending

                                            </span>

                                    </div>


                                    <div className="application-list">

                                        {loadingStores && (

                                            <div className="application-item">

                                                <div className="application-info">

                                                    <strong>
                                                        Loading applications...
                                                    </strong>

                                                </div>

                                            </div>

                                        )}


                                        {!loadingStores &&
                                            storeOwnerRequests.length === 0 && (

                                                <div className="application-item">

                                                    <div className="application-info">

                                                        <strong>
                                                            No pending applications
                                                        </strong>

                                                        <span>
                                                                All store owner requests
                                                                have been processed.
                                                            </span>

                                                    </div>

                                                </div>

                                            )}


                                        {!loadingStores &&

                                            storeOwnerRequests.map(
                                                application => (

                                                    <div
                                                        className="application-item"
                                                        key={application.userId}
                                                    >

                                                        <div className="application-icon store-icon">

                                                            {application.email
                                                                .charAt(0)
                                                                .toUpperCase()}

                                                        </div>


                                                        <div className="application-info">

                                                            <strong>
                                                                Store Owner
                                                            </strong>

                                                            <span>
                                                                    {application.email}
                                                                </span>

                                                            <small>
                                                                Submitted{" "}
                                                                {new Date(
                                                                    application.createdAt
                                                                ).toLocaleDateString()}
                                                            </small>

                                                        </div>


                                                        <div className="application-actions">

                                                            <button
                                                                className="view-button"
                                                                disabled
                                                            >
                                                                View
                                                            </button>


                                                            <button
                                                                className="reject-button"
                                                                disabled={
                                                                    processingUserId !== null
                                                                }
                                                                onClick={() =>
                                                                    rejectRequest(
                                                                        application.userId
                                                                    )
                                                                }
                                                            >
                                                                {processingUserId ===
                                                                application.userId
                                                                    ? "Processing..."
                                                                    : "Reject"}
                                                            </button>


                                                            <button
                                                                className="approve-button"
                                                                disabled={
                                                                    processingUserId !== null
                                                                }
                                                                onClick={() =>
                                                                    approveRequest(
                                                                        application.userId
                                                                    )
                                                                }
                                                            >
                                                                {processingUserId ===
                                                                application.userId
                                                                    ? "Processing..."
                                                                    : "Approve"}
                                                            </button>

                                                        </div>

                                                    </div>

                                                )
                                            )}

                                    </div>

                                </div>


                                {/* DELIVERY PARTNER APPLICATIONS */}

                                <div className="application-panel">

                                    <div className="application-panel-header">

                                        <div>

                                            <h3>
                                                Delivery Partner Applications
                                            </h3>

                                            <p>
                                                Partners waiting for approval
                                            </p>

                                        </div>


                                        <span className="pending-badge">

                                                {deliveryPartnerRequests.length}
                                            {" "}Pending

                                            </span>

                                    </div>


                                    <div className="application-list">

                                        {loadingDrivers && (

                                            <div className="application-item">

                                                <div className="application-info">

                                                    <strong>
                                                        Loading applications...
                                                    </strong>

                                                </div>

                                            </div>

                                        )}


                                        {!loadingDrivers &&
                                            deliveryPartnerRequests.length === 0 && (

                                                <div className="application-item">

                                                    <div className="application-info">

                                                        <strong>
                                                            No pending applications
                                                        </strong>

                                                        <span>
                                                                All delivery partner requests
                                                                have been processed.
                                                            </span>

                                                    </div>

                                                </div>

                                            )}


                                        {!loadingDrivers &&

                                            deliveryPartnerRequests.map(
                                                application => (

                                                    <div
                                                        className="application-item"
                                                        key={application.userId}
                                                    >

                                                        <div className="application-icon">

                                                            {application.email
                                                                .charAt(0)
                                                                .toUpperCase()}

                                                        </div>


                                                        <div className="application-info">

                                                            <strong>
                                                                Delivery Partner
                                                            </strong>

                                                            <span>
                                                                    {application.email}
                                                                </span>

                                                            <small>
                                                                Submitted{" "}
                                                                {new Date(
                                                                    application.createdAt
                                                                ).toLocaleDateString()}
                                                            </small>

                                                        </div>


                                                        <div className="application-actions">

                                                            <button
                                                                className="view-button"
                                                                disabled
                                                            >
                                                                View
                                                            </button>


                                                            <button
                                                                className="reject-button"
                                                                disabled={
                                                                    processingUserId !== null
                                                                }
                                                                onClick={() =>
                                                                    rejectRequest(
                                                                        application.userId
                                                                    )
                                                                }
                                                            >
                                                                {processingUserId ===
                                                                application.userId
                                                                    ? "Processing..."
                                                                    : "Reject"}
                                                            </button>


                                                            <button
                                                                className="approve-button"
                                                                disabled={
                                                                    processingUserId !== null
                                                                }
                                                                onClick={() =>
                                                                    approveRequest(
                                                                        application.userId
                                                                    )
                                                                }
                                                            >
                                                                {processingUserId ===
                                                                application.userId
                                                                    ? "Processing..."
                                                                    : "Approve"}
                                                            </button>

                                                        </div>

                                                    </div>

                                                )
                                            )}

                                    </div>

                                </div>

                            </div>

                        </section>

                    </>

                )}


                {/* =================================================
                       STORES
                       ================================================= */}

                {activeSection === "stores" && (

                    <section>

                        <section className="dashboard-intro">

                            <p className="dashboard-eyebrow">
                                MANAGEMENT
                            </p>

                            <h1>
                                Stores
                            </h1>

                            <p>
                                Available LocalMart stores from the database.
                            </p>

                        </section>


                        {loadingAvailableStores && (

                            <div className="application-panel">

                                <div className="application-item">

                                    <div className="application-info">

                                        <strong>
                                            Loading stores...
                                        </strong>

                                    </div>

                                </div>

                            </div>

                        )}


                        {!loadingAvailableStores &&
                            stores.length === 0 && (

                                <div className="application-panel">

                                    <div className="application-item">

                                        <div className="application-info">

                                            <strong>
                                                No stores available
                                            </strong>

                                            <span>
                                                    There are currently no stores in the database.
                                                </span>

                                        </div>

                                    </div>

                                </div>

                            )}


                        {!loadingAvailableStores &&
                            stores.length > 0 && (

                                <div className="applications-grid">

                                    {stores.map(store => (

                                        <div
                                            className="application-panel"
                                            key={store.storeId}
                                        >

                                            <div className="application-panel-header">

                                                <div>

                                                    <h3>
                                                        {store.storeName}
                                                    </h3>

                                                    <p>
                                                        {store.businessType ||
                                                            "Business"}
                                                    </p>

                                                </div>


                                                <span
                                                    className={`pending-badge ${
                                                        store.accountStatus === 3
                                                            ? "blocked"
                                                            : ""
                                                    }`}
                                                >

                                                        {store.accountStatus === 3
                                                            ? "Blocked"
                                                            : "Active"}

                                                    </span>

                                            </div>


                                            <div className="application-list">

                                                <div className="application-item">

                                                    <div className="application-icon store-icon">

                                                        {store.storeName
                                                            .charAt(0)
                                                            .toUpperCase()}

                                                    </div>


                                                    <div className="application-info">

                                                        <strong>
                                                            {store.city ||
                                                                "City not available"}
                                                        </strong>

                                                        <span>
                                                                {store.state ||
                                                                    "State not available"}
                                                            </span>

                                                        <small>
                                                            Store ID:{" "}
                                                            {store.storeId}
                                                        </small>

                                                    </div>

                                                </div>


                                                <div className="application-item">

                                                    <div className="application-info">

                                                        <strong>
                                                            Store Owner
                                                        </strong>

                                                        <span>
                                                                User ID:{" "}
                                                            {store.userId}
                                                            </span>

                                                        <small>
                                                            Account status is controlled
                                                            by the admin.
                                                        </small>

                                                    </div>

                                                </div>


                                                {/* BLOCK / UNBLOCK */}

                                                <div className="customer-status-area">

                                                    {store.accountStatus === 3 ? (

                                                        <button
                                                            className="user-action-button unblock"
                                                            disabled={
                                                                processingUserId !== null
                                                            }
                                                            onClick={() =>
                                                                handleUnblockStore(
                                                                    store.userId
                                                                )
                                                            }
                                                        >

                                                            {processingUserId ===
                                                            store.userId
                                                                ? "Processing..."
                                                                : "Unblock"}

                                                        </button>

                                                    ) : (

                                                        <button
                                                            className="user-action-button block"
                                                            disabled={
                                                                processingUserId !== null
                                                            }
                                                            onClick={() =>
                                                                handleBlockStore(
                                                                    store.userId
                                                                )
                                                            }
                                                        >

                                                            {processingUserId ===
                                                            store.userId
                                                                ? "Processing..."
                                                                : "Block"}

                                                        </button>

                                                    )}

                                                </div>

                                            </div>

                                        </div>

                                    ))}

                                </div>

                            )}

                    </section>

                )}


                {/* =================================================
                       DELIVERY PARTNERS
                       ================================================= */}

                {activeSection === "delivery-partners" && (

                    <section>

                        <section className="dashboard-intro">

                            <p className="dashboard-eyebrow">
                                MANAGEMENT
                            </p>

                            <h1>
                                Delivery Partners
                            </h1>

                            <p>
                                Available delivery partners from the database.
                            </p>

                        </section>


                        {loadingDeliveryPartners && (

                            <div className="application-panel">

                                <div className="application-item">

                                    <div className="application-info">

                                        <strong>
                                            Loading delivery partners...
                                        </strong>

                                    </div>

                                </div>

                            </div>

                        )}


                        {!loadingDeliveryPartners &&
                            deliveryPartners.length === 0 && (

                                <div className="application-panel">

                                    <div className="application-item">

                                        <div className="application-info">

                                            <strong>
                                                No delivery partners available
                                            </strong>

                                            <span>
                                                    There are currently no approved active
                                                    delivery partners.
                                                </span>

                                        </div>

                                    </div>

                                </div>

                            )}


                        {!loadingDeliveryPartners &&
                            deliveryPartners.length > 0 && (

                                <div className="applications-grid">

                                    {deliveryPartners.map(partner => (

                                        <div
                                            className="application-panel"
                                            key={partner.userId}
                                        >

                                            <div className="application-panel-header">

                                                <div>

                                                    <h3>
                                                        {partner.firstName}{" "}
                                                        {partner.lastName}
                                                    </h3>

                                                    <p>
                                                        {partner.email}
                                                    </p>

                                                </div>


                                                <span
                                                    className={`pending-badge ${
                                                        partner.accountStatus === 3
                                                            ? "blocked"
                                                            : ""
                                                    }`}
                                                >

                                                        {partner.accountStatus === 3
                                                            ? "Blocked"
                                                            : "Active"}

                                                    </span>

                                            </div>


                                            <div className="application-list">

                                                <div className="application-item">

                                                    <div className="application-icon">

                                                        {partner.firstName
                                                            .charAt(0)
                                                            .toUpperCase()}

                                                    </div>


                                                    <div className="application-info">

                                                        <strong>
                                                            {partner.phone}
                                                        </strong>

                                                        <span>
                                                                {partner.vehicleType ||
                                                                    "Vehicle type not available"}
                                                            </span>

                                                        <small>
                                                            Vehicle:{" "}
                                                            {partner.vehicleNumber ||
                                                                "Not available"}
                                                        </small>

                                                    </div>

                                                </div>


                                                <div className="application-item">

                                                    <div className="application-info">

                                                        <strong>
                                                            Driving Licence
                                                        </strong>

                                                        <span>
                                                                {partner.drivingLicenceNumber}
                                                            </span>

                                                        <small>
                                                            User ID:{" "}
                                                            {partner.userId}
                                                        </small>

                                                    </div>

                                                </div>


                                                {/* BLOCK / UNBLOCK */}

                                                <div className="customer-status-area">

                                                    {partner.accountStatus === 3 ? (

                                                        <button
                                                            className="user-action-button unblock"
                                                            disabled={
                                                                processingUserId !== null
                                                            }
                                                            onClick={() =>
                                                                handleUnblockDeliveryPartner(
                                                                    partner.userId
                                                                )
                                                            }
                                                        >

                                                            {processingUserId ===
                                                            partner.userId
                                                                ? "Processing..."
                                                                : "Unblock"}

                                                        </button>

                                                    ) : (

                                                        <button
                                                            className="user-action-button block"
                                                            disabled={
                                                                processingUserId !== null
                                                            }
                                                            onClick={() =>
                                                                handleBlockDeliveryPartner(
                                                                    partner.userId
                                                                )
                                                            }
                                                        >

                                                            {processingUserId ===
                                                            partner.userId
                                                                ? "Processing..."
                                                                : "Block"}

                                                        </button>

                                                    )}

                                                </div>

                                            </div>

                                        </div>

                                    ))}

                                </div>

                            )}

                    </section>

                )}


                {/* =================================================
                       CUSTOMERS
                       ================================================= */}

                {activeSection === "users" && (

                    <section>

                        <section className="dashboard-intro">

                            <p className="dashboard-eyebrow">
                                MANAGEMENT
                            </p>

                            <h1>
                                Customers
                            </h1>

                            <p>
                                Customers registered in the LocalMart database.
                            </p>

                        </section>


                        {loadingCustomers && (

                            <div className="application-panel">

                                <div className="application-item">

                                    <div className="application-info">

                                        <strong>
                                            Loading customers...
                                        </strong>

                                    </div>

                                </div>

                            </div>

                        )}


                        {!loadingCustomers &&
                            customers.length === 0 && (

                                <div className="application-panel">

                                    <div className="application-item">

                                        <div className="application-info">

                                            <strong>
                                                No customers available
                                            </strong>

                                            <span>
                                                    There are currently no customers in the database.
                                                </span>

                                        </div>

                                    </div>

                                </div>

                            )}


                        {!loadingCustomers &&
                            customers.length > 0 && (

                                <div className="applications-grid">

                                    {customers.map(customer => (

                                        <div
                                            className="application-panel"
                                            key={customer.userId}
                                        >

                                            <div className="application-panel-header">

                                                <div>

                                                    <h3>
                                                        {customer.firstName}{" "}
                                                        {customer.lastName}
                                                    </h3>

                                                    <p>
                                                        {customer.email}
                                                    </p>

                                                </div>


                                                <span
                                                    className={`pending-badge ${
                                                        customer.accountStatus === 3
                                                            ? "blocked"
                                                            : ""
                                                    }`}
                                                >

                                                        {customer.accountStatus === 3
                                                            ? "Blocked"
                                                            : "Active"}

                                                    </span>

                                            </div>


                                            <div className="application-list">

                                                <div className="application-item">

                                                    <div className="application-icon">

                                                        {customer.firstName
                                                            .charAt(0)
                                                            .toUpperCase()}

                                                    </div>


                                                    <div className="application-info">

                                                        <strong>
                                                            {customer.phone}
                                                        </strong>

                                                        <span>
                                                                Customer
                                                            </span>

                                                        <small>
                                                            User ID:{" "}
                                                            {customer.userId}
                                                        </small>

                                                    </div>

                                                </div>


                                                <div className="application-item">

                                                    <div className="application-info">

                                                        <strong>
                                                            Registered
                                                        </strong>

                                                        <span>
                                                                {new Date(
                                                                    customer.createdAt
                                                                ).toLocaleDateString()}
                                                            </span>

                                                    </div>

                                                </div>


                                                {/* BLOCK / UNBLOCK */}

                                                <div className="customer-status-area">

                                                    {customer.accountStatus === 3 ? (

                                                        <button
                                                            className="user-action-button unblock"
                                                            disabled={
                                                                processingUserId !== null
                                                            }
                                                            onClick={() =>
                                                                handleUnblockUser(
                                                                    customer.userId
                                                                )
                                                            }
                                                        >

                                                            {processingUserId ===
                                                            customer.userId
                                                                ? "Processing..."
                                                                : "Unblock"}

                                                        </button>

                                                    ) : (

                                                        <button
                                                            className="user-action-button block"
                                                            disabled={
                                                                processingUserId !== null
                                                            }
                                                            onClick={() =>
                                                                handleBlockUser(
                                                                    customer.userId
                                                                )
                                                            }
                                                        >

                                                            {processingUserId ===
                                                            customer.userId
                                                                ? "Processing..."
                                                                : "Block"}

                                                        </button>

                                                    )}

                                                </div>

                                            </div>

                                        </div>

                                    ))}

                                </div>

                            )}

                    </section>

                )}


                {/* =================================================
                       GLOBAL MESSAGE
                       ================================================= */}

                {message && (

                    <p className="message">
                        {message}
                    </p>

                )}

            </main>

        </div>

    </div>
)
}

export default AdminDashboard

