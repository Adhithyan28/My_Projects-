package com.localmart.localmartbackend.repository;

import com.localmart.localmartbackend.entity.UserPasswordHistory;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserPasswordHistoryRepository
        extends JpaRepository<UserPasswordHistory, Long> {

    Optional<UserPasswordHistory> findTopByUserIdOrderByChangedAtDesc(Long userId);
}