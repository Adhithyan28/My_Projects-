import { useEffect, useState } from "react"
import { useAuth } from "../../context/AuthContext"
import "./DeliveryPartnerProfile.css"

interface DeliveryPartnerProfileData {
    firstName: string
    lastName: string
    email: string
    emergencyContactPhone: string | null
    vehicleType: string
    vehicleNumber: string
    drivingLicenceNumber: string
}

function DeliveryPartnerProfile() {

    const { user } = useAuth()

    const [profile, setProfile] =
        useState<DeliveryPartnerProfileData | null>(null)

    const [firstName, setFirstName] = useState("")
    const [lastName, setLastName] = useState("")
    const [emergencyPhone, setEmergencyPhone] = useState("")

    const [loading, setLoading] = useState(true)
    const [saving, setSaving] = useState(false)

    const [error, setError] = useState("")
    const [message, setMessage] = useState("")

    /*
     * ============================================================
     * LOAD PROFILE
     * ============================================================
     */

    useEffect(() => {

        const loadProfile = async () => {

            if (!user?.token) {
                setError("You are not logged in.")
                setLoading(false)
                return
            }

            try {

                setLoading(true)
                setError("")
                setMessage("")

                const response = await fetch(
                    "http://localhost:8080/api/delivery-partner/profile",
                    {
                        method: "GET",
                        headers: {
                            Authorization:
                                `Bearer ${user.token}`
                        }
                    }
                )

                if (!response.ok) {

                    if (response.status === 401) {
                        throw new Error(
                            "Your session has expired. Please log in again."
                        )
                    }

                    if (response.status === 403) {
                        throw new Error(
                            "You are not authorized to view this profile."
                        )
                    }

                    const errorData =
                        await response.text()

                    throw new Error(
                        errorData ||
                        "Failed to load profile."
                    )
                }

                const data:
                    DeliveryPartnerProfileData =
                    await response.json()

                setProfile(data)

                setFirstName(
                    data.firstName || ""
                )

                setLastName(
                    data.lastName || ""
                )

                setEmergencyPhone(
                    data.emergencyContactPhone || ""
                )

            } catch (err) {

                console.error(
                    "Profile loading error:",
                    err
                )

                if (err instanceof Error) {
                    setError(err.message)
                } else {
                    setError(
                        "Failed to load profile."
                    )
                }

            } finally {

                setLoading(false)
            }
        }

        loadProfile()

    }, [user])


    /*
     * ============================================================
     * SAVE PROFILE
     * ============================================================
     */

    const handleSave = async () => {

        if (!user?.token) {
            setError("You are not logged in.")
            return
        }

        setError("")
        setMessage("")

        const trimmedFirstName =
            firstName.trim()

        const trimmedLastName =
            lastName.trim()

        const trimmedEmergencyPhone =
            emergencyPhone.trim()

        if (!trimmedFirstName) {
            setError("First name is required.")
            return
        }

        if (!trimmedLastName) {
            setError("Last name is required.")
            return
        }

        if (
            trimmedEmergencyPhone &&
            !/^\d{10,15}$/.test(
                trimmedEmergencyPhone
            )
        ) {
            setError(
                "Emergency contact phone must contain 10 to 15 digits."
            )
            return
        }

        try {

            setSaving(true)

            const response = await fetch(
                "http://localhost:8080/api/delivery-partner/profile",
                {
                    method: "PUT",
                    headers: {
                        "Content-Type":
                            "application/json",

                        Authorization:
                            `Bearer ${user.token}`
                    },
                    body: JSON.stringify({
                        firstName:
                        trimmedFirstName,

                        lastName:
                        trimmedLastName,

                        emergencyContactPhone:
                        trimmedEmergencyPhone
                    })
                }
            )

            if (!response.ok) {

                if (response.status === 401) {
                    throw new Error(
                        "Your session has expired. Please log in again."
                    )
                }

                if (response.status === 403) {
                    throw new Error(
                        "You are not authorized to update this profile."
                    )
                }

                const errorData =
                    await response.text()

                throw new Error(
                    errorData ||
                    "Failed to save profile."
                )
            }

            const updatedProfile:
                DeliveryPartnerProfileData =
                await response.json()

            /*
             * Update the displayed profile with the
             * exact data returned by the backend.
             */

            setProfile(updatedProfile)

            setFirstName(
                updatedProfile.firstName || ""
            )

            setLastName(
                updatedProfile.lastName || ""
            )

            setEmergencyPhone(
                updatedProfile.emergencyContactPhone || ""
            )

            setMessage(
                "Profile updated successfully."
            )

        } catch (err) {

            console.error(
                "Profile update error:",
                err
            )

            if (err instanceof Error) {
                setError(err.message)
            } else {
                setError(
                    "Failed to save profile."
                )
            }

        } finally {

            setSaving(false)
        }
    }


    /*
     * ============================================================
     * CANCEL CHANGES
     * ============================================================
     */

    const handleCancel = () => {

        if (!profile) {
            return
        }

        setFirstName(
            profile.firstName || ""
        )

        setLastName(
            profile.lastName || ""
        )

        setEmergencyPhone(
            profile.emergencyContactPhone || ""
        )

        setError("")
        setMessage("")
    }


    /*
     * ============================================================
     * LOADING
     * ============================================================
     */

    if (loading) {

        return (

            <div className="delivery-profile-page">

                <div className="delivery-profile-card">

                    <div className="delivery-profile-section">

                        <h3>
                            Loading Profile...
                        </h3>

                        <p>
                            Please wait while we load your
                            delivery partner information.
                        </p>

                    </div>

                </div>

            </div>
        )
    }


    /*
     * ============================================================
     * PROFILE UI
     * ============================================================
     */

    return (

        <div className="delivery-profile-page">

            {/* =====================================================
                PROFILE HEADER
            ===================================================== */}

            <div className="delivery-profile-header">

                <div>

                    <p className="delivery-profile-label">
                        DELIVERY PARTNER
                    </p>

                    <h1>
                        Profile
                    </h1>

                    <p className="delivery-profile-description">
                        Manage your personal information and registered
                        delivery details.
                    </p>

                </div>

                <div className="delivery-profile-status">

                    <span className="delivery-profile-status-dot"></span>

                    Active

                </div>

            </div>


            {/* =====================================================
                SUCCESS / ERROR MESSAGE
            ===================================================== */}

            {message && (

                <div className="delivery-message">
                    {message}
                </div>

            )}

            {error && (

                <div className="delivery-error">
                    {error}
                </div>

            )}


            {/* =====================================================
                PROFILE CARD
            ===================================================== */}

            <div className="delivery-profile-card">


                {/* =================================================
                    PROFILE IDENTITY
                ================================================= */}

                <div className="delivery-profile-identity">

                    <div className="delivery-profile-avatar">
                        👤
                    </div>

                    <div className="delivery-profile-identity-info">

                        <h2>
                            {firstName} {lastName}
                        </h2>

                        <p>
                            Your LocalMart delivery account
                        </p>

                    </div>

                </div>


                {/* =================================================
                    PERSONAL INFORMATION
                ================================================= */}

                <section className="delivery-profile-section">

                    <div className="delivery-profile-section-header">

                        <div>

                            <h3>
                                Personal Information
                            </h3>

                            <p>
                                Update the personal details associated
                                with your delivery account.
                            </p>

                        </div>

                    </div>


                    <div className="delivery-profile-form-grid">


                        {/* FIRST NAME */}

                        <div className="delivery-profile-field">

                            <label htmlFor="profile-first-name">
                                First Name
                            </label>

                            <input
                                id="profile-first-name"
                                type="text"
                                value={firstName}
                                onChange={(event) =>
                                    setFirstName(
                                        event.target.value
                                    )
                                }
                                placeholder="Enter first name"
                            />

                        </div>


                        {/* LAST NAME */}

                        <div className="delivery-profile-field">

                            <label htmlFor="profile-last-name">
                                Last Name
                            </label>

                            <input
                                id="profile-last-name"
                                type="text"
                                value={lastName}
                                onChange={(event) =>
                                    setLastName(
                                        event.target.value
                                    )
                                }
                                placeholder="Enter last name"
                            />

                        </div>


                        {/* EMAIL */}

                        <div className="delivery-profile-field">

                            <label htmlFor="profile-email">
                                Email

                                <span className="delivery-profile-lock">
                                    🔒
                                </span>
                            </label>

                            <div className="delivery-profile-locked-field">

                                <input
                                    id="profile-email"
                                    type="email"
                                    value={
                                        profile?.email || ""
                                    }
                                    readOnly
                                    placeholder="Registered email"
                                />

                                <span>
                                    🔒
                                </span>

                            </div>

                            <small>
                                Email is linked to your LocalMart account.
                            </small>

                        </div>


                        {/* EMERGENCY CONTACT */}

                        <div className="delivery-profile-field">

                            <label htmlFor="profile-emergency-phone">
                                Emergency Contact Phone
                            </label>

                            <input
                                id="profile-emergency-phone"
                                type="tel"
                                value={emergencyPhone}
                                onChange={(event) =>
                                    setEmergencyPhone(
                                        event.target.value
                                    )
                                }
                                placeholder="Enter emergency contact number"
                            />

                        </div>

                    </div>

                </section>


                {/* =================================================
                    VEHICLE INFORMATION
                ================================================= */}

                <section className="delivery-profile-section">

                    <div className="delivery-profile-section-header">

                        <div>

                            <h3>
                                Vehicle Information
                            </h3>

                            <p>
                                Registered vehicle and licence information
                                cannot be changed from your profile.
                            </p>

                        </div>

                        <span className="delivery-profile-verified">
                            ✓ Verified Details
                        </span>

                    </div>


                    <div className="delivery-profile-form-grid">


                        {/* VEHICLE TYPE */}

                        <div className="delivery-profile-field">

                            <label htmlFor="profile-vehicle-type">

                                Vehicle Type

                                <span className="delivery-profile-lock">
                                    🔒
                                </span>

                            </label>

                            <div className="delivery-profile-locked-field">

                                <input
                                    id="profile-vehicle-type"
                                    type="text"
                                    value={
                                        profile?.vehicleType || ""
                                    }
                                    readOnly
                                    placeholder="Registered vehicle type"
                                />

                                <span>
                                    🔒
                                </span>

                            </div>

                        </div>


                        {/* VEHICLE NUMBER */}

                        <div className="delivery-profile-field">

                            <label htmlFor="profile-vehicle-number">

                                Vehicle Number

                                <span className="delivery-profile-lock">
                                    🔒
                                </span>

                            </label>

                            <div className="delivery-profile-locked-field">

                                <input
                                    id="profile-vehicle-number"
                                    type="text"
                                    value={
                                        profile?.vehicleNumber || ""
                                    }
                                    readOnly
                                    placeholder="Registered vehicle number"
                                />

                                <span>
                                    🔒
                                </span>

                            </div>

                        </div>


                        {/* LICENCE */}

                        <div className="delivery-profile-field delivery-profile-field-full">

                            <label htmlFor="profile-driving-licence">

                                Driving Licence Number

                                <span className="delivery-profile-lock">
                                    🔒
                                </span>

                            </label>

                            <div className="delivery-profile-locked-field">

                                <input
                                    id="profile-driving-licence"
                                    type="text"
                                    value={
                                        profile?.drivingLicenceNumber || ""
                                    }
                                    readOnly
                                    placeholder="Registered driving licence number"
                                />

                                <span>
                                    🔒
                                </span>

                            </div>

                        </div>

                    </div>

                </section>


                {/* =================================================
                    INFORMATION NOTE
                ================================================= */}

                <div className="delivery-profile-note">

                    <span>
                        🔒
                    </span>

                    <p>
                        Your email, vehicle information and driving licence
                        details are verified account information. These
                        details cannot be changed from the profile page.
                    </p>

                </div>


                {/* =================================================
                    ACTIONS
                ================================================= */}

                <div className="delivery-profile-actions">

                    <button
                        type="button"
                        className="delivery-profile-cancel"
                        onClick={handleCancel}
                        disabled={saving}
                    >
                        Cancel
                    </button>

                    <button
                        type="button"
                        className="delivery-profile-save"
                        onClick={handleSave}
                        disabled={saving}
                    >
                        {saving
                            ? "Saving..."
                            : "Save Changes"}
                    </button>

                </div>

            </div>

        </div>
    )
}

export default DeliveryPartnerProfile