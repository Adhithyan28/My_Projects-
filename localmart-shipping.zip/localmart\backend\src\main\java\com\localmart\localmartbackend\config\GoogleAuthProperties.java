package com.localmart.localmartbackend.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GoogleAuthProperties {

    @Value("${google.client-id}")
    private String clientId;

    public String getClientId() {
        return clientId;
    }
}