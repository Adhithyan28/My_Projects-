
package com.localmart.localmartbackend.smsotp.dto;

public class SmsOtpSendRequest {

    private String mobileNumber;

    public SmsOtpSendRequest() {
    }

    public SmsOtpSendRequest(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }
}
