package com.localmart.localmartbackend.dto;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;

import java.math.BigDecimal;

public class DeliveryPartnerAvailabilityRequest {

    @NotBlank(message = "Availability status is required")
    private String status;

    @DecimalMin(
            value = "-90.0",
            message = "Invalid latitude"
    )
    @DecimalMax(
            value = "90.0",
            message = "Invalid latitude"
    )
    private BigDecimal latitude;

    @DecimalMin(
            value = "-180.0",
            message = "Invalid longitude"
    )
    @DecimalMax(
            value = "180.0",
            message = "Invalid longitude"
    )
    private BigDecimal longitude;

    public DeliveryPartnerAvailabilityRequest() {
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public BigDecimal getLatitude() {
        return latitude;
    }

    public void setLatitude(BigDecimal latitude) {
        this.latitude = latitude;
    }

    public BigDecimal getLongitude() {
        return longitude;
    }

    public void setLongitude(BigDecimal longitude) {
        this.longitude = longitude;
    }
}