package com.localmart.localmartbackend.config;

import com.localmart.localmartbackend.entity.Role;
import com.localmart.localmartbackend.entity.User;
import com.localmart.localmartbackend.repository.RoleRepository;
import com.localmart.localmartbackend.repository.UserRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class AdminInitializer implements CommandLineRunner {

    /*
     * ADMIN role
     */
    private static final int ROLE_ADMIN = 4;

    /*
     * ACTIVE account
     */
    private static final int ACCOUNT_ACTIVE = 1;

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;

    @Value("${localmart.admin.email}")
    private String adminEmail;

    @Value("${localmart.admin.password:LocalMartDevOnly123!}")
    private String adminPassword;

    public AdminInitializer(
            UserRepository userRepository,
            RoleRepository roleRepository,
            PasswordEncoder passwordEncoder) {

        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {

        /*
         * Don't create duplicate admin.
         */
        if (userRepository.existsByEmail(adminEmail)) {
            return;
        }

        User user = new User();

        user.setFirstName("LocalMart");
        user.setLastName("Admin");

        user.setEmail(adminEmail);

        /*
         * Keep the existing test password.
         */
        user.setPassword(
                passwordEncoder.encode(
                        adminPassword
                )
        );

        /*
         * Phone is NOT nullable in the new DB.
         *
         * This is only the default development admin.
         */
        user.setPhone("9999999999");

        user.setAccountStatus(
                ACCOUNT_ACTIVE
        );

        User savedUser =
                userRepository.save(user);

        /*
         * Create ADMIN role.
         *
         * roles.user_id is itself the primary key
         * and foreign key to users.user_id.
         */
        Role role = new Role();

        role.setUserId(
                savedUser.getUserId()
        );

        role.setRole(
                ROLE_ADMIN
        );

        roleRepository.save(role);

        System.out.println(
                "================================="
        );

        System.out.println(
                "Default admin account created"
        );

        System.out.println(
                "Email: " + adminEmail
        );

        System.out.println(
                "Password: Admin@123"
        );

        System.out.println(
                "Role: ADMIN"
        );

        System.out.println(
                "================================="
        );
    }
}