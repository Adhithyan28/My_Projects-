
        package com.localmart.localmartbackend.controller;

import com.localmart.localmartbackend.dto.StoreOwnerDetailsRequest;
import com.localmart.localmartbackend.dto.StoreOwnerDetailsResponse;
import com.localmart.localmartbackend.service.StoreOwnerService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/store-owner")
@CrossOrigin(origins = "http://localhost:5175")
public class StoreOwnerController {

    private final StoreOwnerService storeOwnerService;

    public StoreOwnerController(
            StoreOwnerService storeOwnerService) {

        this.storeOwnerService = storeOwnerService;
    }

    // ============================================================
    // GET STORE DETAILS
    // ============================================================

    @GetMapping("/store")
    public ResponseEntity<StoreOwnerDetailsResponse>
    getStoreDetails(
            Authentication authentication) {

        Long userId =
                getAuthenticatedUserId(
                        authentication
                );

        return ResponseEntity.ok(
                storeOwnerService.getStoreDetails(
                        userId
                )
        );
    }

    // ============================================================
    // UPDATE STORE DETAILS
    // ============================================================

    @PutMapping("/store")
    public ResponseEntity<StoreOwnerDetailsResponse>
    updateStoreDetails(
            Authentication authentication,
            @RequestBody StoreOwnerDetailsRequest request) {

        Long userId =
                getAuthenticatedUserId(
                        authentication
                );

        return ResponseEntity.ok(
                storeOwnerService.updateStoreDetails(
                        userId,
                        request
                )
        );
    }

    // ============================================================
    // GET AUTHENTICATED USER ID
    // ============================================================

    private Long getAuthenticatedUserId(
            Authentication authentication) {

        if (authentication == null
                || authentication.getPrincipal() == null) {

            throw new RuntimeException(
                    "User is not authenticated"
            );
        }

        Object principal =
                authentication.getPrincipal();

        if (principal instanceof Long userId) {
            return userId;
        }

        if (principal instanceof String userId) {

            try {
                return Long.valueOf(userId);

            } catch (NumberFormatException exception) {

                throw new RuntimeException(
                        "Invalid authenticated user ID"
                );
            }
        }

        throw new RuntimeException(
                "Invalid authenticated user"
        );
    }
}
