# LocalMart — Location Services

## 1. Overview

Location Services provide the geographic information required by different parts of the LocalMart application.

LocalMart uses location information for several purposes:

* Customer address management
* Store location management
* Address-to-coordinate and coordinate-to-address operations
* Delivery-fee calculation
* Road-distance calculation
* Delivery-partner location tracking
* Delivery-related routing information

The location architecture combines:

```text id="l2x7q4"
Browser Location APIs
        +
Geocoding Service
        +
OSRM
        +
LocalMart Database
```

These components work together while maintaining clear boundaries between application data and external location services.

---

# 2. Purpose of Location Services

The Location Services subsystem is responsible for handling geographic information used by LocalMart.

Its responsibilities include:

* Obtaining geographic coordinates
* Storing latitude and longitude
* Converting addresses into geographic information
* Using coordinates for road-distance calculations
* Supporting delivery-fee calculation
* Supporting delivery-partner location tracking
* Providing location information to other LocalMart modules

Location functionality is therefore shared by multiple business modules.

---

# 3. Location Architecture

The high-level architecture is:

```text id="p7m3x8"
                         LOCATION SERVICES
                                |
             +------------------+------------------+
             |                  |                  |
             v                  v                  v
       Customer Address      Store Address    Delivery Partner
             |                  |                  |
             v                  v                  v
        Coordinates        Coordinates         Current Location
             |                  |                  |
             +------------------+------------------+
                                |
                                v
                       RoadDistanceService
                                |
                                v
                              OSRM
```

---

# 4. Location Sources

LocalMart can receive location information from different sources.

```text id="x4n8q2"
Location Information
       |
       +--> Customer-provided address
       |
       +--> Geocoding service
       |
       +--> Browser Geolocation API
       |
       +--> Existing database coordinates
```

These sources serve different purposes.

---

# 5. Latitude and Longitude

The basic geographic representation used by LocalMart is:

```text id="m6p2v9"
Latitude
Longitude
```

A location can therefore be represented as:

```text id="w8c3x5"
{
    latitude,
    longitude
}
```

Latitude represents the north/south geographic position.

Longitude represents the east/west geographic position.

Together they identify a geographic coordinate.

---

# 6. Coordinates in LocalMart

Coordinates are important because addresses represented only as text are difficult for routing services to process reliably.

For example:

```text id="r3x7m2"
Address
   |
   v
Latitude + Longitude
```

Once coordinates are available, LocalMart can use them for:

```text id="j5q8p4"
Distance
Routing
Delivery Fee
Location Tracking
```

---

# 7. Customer Address

Customer addresses are managed through the customer-address subsystem.

The address can contain geographic coordinates:

```text id="v2m9x6"
Customer
   |
   v
Address
   |
   +--> Address Information
   |
   +--> Latitude
   |
   +--> Longitude
```

The coordinates are stored as part of the address information used by LocalMart.

---

# 8. Address Validation

The customer-address service validates geographic coordinates.

Latitude must be within:

```text id="a8p3k5"
-90  <= latitude <= 90
```

Longitude must be within:

```text id="n4x7q2"
-180 <= longitude <= 180
```

This prevents obviously invalid coordinate values from being stored.

---

# 9. Address and Coordinates

The relationship can be represented as:

```text id="c7m2v8"
Human-readable Address
        |
        v
Geographic Coordinates
        |
        +--> Latitude
        +--> Longitude
```

This allows the same address to participate in geographic operations.

---

# 10. Geocoding

Geocoding is the process of converting an address or place description into geographic coordinates.

Conceptually:

```text id="q5x8m3"
Address
   |
   v
Geocoding Service
   |
   v
Latitude + Longitude
```

For example:

```text id="p2v7n4"
"Some address"
      |
      v
Geocoding
      |
      v
13.xxxxxx, 80.xxxxxx
```

The exact external geocoding provider used by the current implementation should follow `GeocodingService.java` and its configuration.

---

# 11. Reverse Geocoding

The opposite operation is reverse geocoding.

```text id="m8q3x7"
Latitude + Longitude
        |
        v
Geocoding Service
        |
        v
Address / Location Information
```

This can be useful when the application starts with geographic coordinates rather than a textual address.

---

# 12. Geocoding Service

LocalMart contains:

```text id="j4p8w2"
GeocodingService
```

This service isolates geocoding-related logic from the rest of the application.

Conceptually:

```text id="x9m3v6"
Controller / Business Service
          |
          v
GeocodingService
          |
          v
External Geocoding Provider
          |
          v
Location Information
```

This follows the same service-isolation principle used by other external integrations in LocalMart.

---

# 13. Why Geocoding Is a Separate Service

Without a dedicated service, external geocoding logic could become scattered across controllers and business services.

Instead:

```text id="w5q2n8"
OrderService
     |
     v
GeocodingService
```

or:

```text id="f7m3x9"
LocationController
     |
     v
GeocodingService
```

The application-specific business logic does not need to know every detail of the external provider.

---

# 14. Location Controller

LocalMart contains:

```text id="r8v2m5"
LocationController
```

This provides an API boundary for location-related operations.

The general flow is:

```text id="q3x7n9"
React
  |
  | HTTP
  v
LocationController
  |
  v
GeocodingService
  |
  v
External Location Service
```

The exact endpoints and request/response structures should follow the current `LocationController` implementation.

---

# 15. Location Search DTOs

The backend contains:

```text id="m4p8x2"
LocationSearchRequest
LocationSearchResponse
```

These DTOs represent location-search request and response data.

The architecture is:

```text id="t6n3v7"
React
  |
  v
LocationSearchRequest
  |
  v
LocationController
  |
  v
GeocodingService
  |
  v
LocationSearchResponse
  |
  v
React
```

---

# 16. Location Search

A location search can conceptually work as:

```text id="c2m8q5"
User enters location
        |
        v
Search Request
        |
        v
Backend
        |
        v
Geocoding / Location Provider
        |
        v
Search Results
        |
        v
Frontend
```

The frontend can then use the selected result to obtain geographic coordinates.

---

# 17. Browser Geolocation

The frontend also uses the browser's built-in Geolocation API.

The relevant browser API is:

```text id="u7x4m2"
navigator.geolocation
```

For example, LocalMart uses:

```text id="e9p3v8"
navigator.geolocation.getCurrentPosition()
```

This is provided by the browser itself.

It is **not imported from React**, LocalMart, or an npm package.

---

# 18. Browser Geolocation Flow

The browser location flow is:

```text id="k5q8m3"
Delivery Partner
       |
       v
React
       |
       v
Browser Geolocation API
       |
       v
Device Location
       |
       v
Latitude + Longitude
       |
       v
React
```

The browser may request permission from the user before providing the location.

---

# 19. Browser Location Permission

The browser controls access to the device's location.

Conceptually:

```text id="n3v7x2"
React
 |
 v
navigator.geolocation
 |
 v
Browser Permission
 |
 +------> Allowed
 |
 +------> Denied
```

If permission is denied, the frontend cannot simply assume that a location exists.

---

# 20. Delivery Partner Location

Delivery partners are a major consumer of browser location functionality.

The flow is:

```text id="q8m2v5"
Delivery Partner
       |
       v
Browser
       |
       v
navigator.geolocation
       |
       v
Latitude + Longitude
       |
       v
DeliveryPartnerLocationRequest
       |
       v
Backend
```

---

# 21. Delivery Partner Location Controller

The backend contains:

```text id="x6p3n8"
DeliveryPartnerLocationController
```

This provides the HTTP boundary for delivery-partner location operations.

The general flow is:

```text id="w2m7q4"
React
 |
 | latitude / longitude
 v
DeliveryPartnerLocationController
 |
 v
DeliveryPartnerLocationService
 |
 v
DeliveryPartnerLocationRepository
 |
 v
PostgreSQL
```

---

# 22. Delivery Partner Location Service

LocalMart contains:

```text id="v9q3m6"
DeliveryPartnerLocationService
```

Its purpose is to isolate business logic related to delivery-partner location.

Conceptually:

```text id="p5x8k2"
Location Controller
      |
      v
Location Service
      |
      v
Location Repository
      |
      v
Database
```

---

# 23. Delivery Partner Location Entity

The backend contains:

```text id="f3m7v9"
DeliveryPartnerLocation
```

This represents stored delivery-partner location information.

Conceptually:

```text id="r8q2x5"
DeliveryPartner
      |
      v
DeliveryPartnerLocation
      |
      +--> Latitude
      +--> Longitude
```

The exact additional fields depend on the current entity implementation.

---

# 24. Delivery Partner Location Repository

LocalMart contains:

```text id="m6v3p8"
DeliveryPartnerLocationRepository
```

which provides database access for delivery-partner location records.

The architecture is:

```text id="j2q7x4"
DeliveryPartnerLocationService
          |
          v
DeliveryPartnerLocationRepository
          |
          v
PostgreSQL
```

---

# 25. Store Coordinates

Stores also require geographic information for delivery calculations.

Conceptually:

```text id="c9x5m2"
Store
  |
  v
Store Address
  |
  v
Latitude + Longitude
```

These coordinates represent the delivery origin.

---

# 26. Customer Coordinates

The customer's selected address provides the delivery destination.

```text id="v7m3q8"
Customer
   |
   v
Selected Address
   |
   v
Latitude + Longitude
```

Therefore:

```text id="p2x6n9"
Store Coordinates
        +
Customer Coordinates
        |
        v
Delivery Route
```

---

# 27. Road Distance

LocalMart contains:

```text id="b8q3m5"
RoadDistanceService
```

This service is responsible for road-based distance/routing calculations.

The application integrates with **OSRM** for this purpose.

---

# 28. Why OSRM Is Used

A simple geographic calculation measures the direct distance between two coordinates.

But delivery partners travel using roads.

Therefore:

```text id="x5m8v2"
Coordinate A
      |
      | straight-line distance
      v
Coordinate B
```

does not necessarily equal:

```text id="n7q3p6"
Coordinate A
      |
      +---- Road ----+
                    |
                    +---- Coordinate B
```

OSRM provides road-routing information that is more appropriate for delivery-related calculations.

---

# 29. RoadDistanceService Architecture

The flow is:

```text id="f2v8m4"
OrderService
     |
     v
RoadDistanceService
     |
     v
OSRM
     |
     v
Road Distance / Duration
```

The application therefore isolates OSRM-specific communication inside its service layer.

---

# 30. OSRM Integration

The conceptual external integration is:

```text id="g6m3x9"
+--------------------------+
|       LocalMart          |
|                          |
| RoadDistanceService      |
|                          |
+------------+-------------+
             |
             | HTTP
             v
+--------------------------+
|          OSRM            |
|                          |
| Routing / Road Distance  |
|                          |
+--------------------------+
```

The exact OSRM endpoint and request format should follow the current `RoadDistanceService.java` implementation.

---

# 31. Road Distance Flow

The complete flow is:

```text id="q4p7m2"
Store
  |
  v
Store Coordinates
  |
  +--------------------+
                       |
                       v
                 RoadDistanceService
                       |
Customer Coordinates --+
                       |
                       v
                      OSRM
                       |
                       v
              Road Distance
              Road Duration
```

---

# 32. Delivery Fee Calculation

Location information participates in delivery-fee calculation.

The high-level flow is:

```text id="w9m3x6"
Customer Checkout
       |
       v
storeId + addressId
       |
       v
OrderService
       |
       v
Store Coordinates
       +
Customer Coordinates
       |
       v
RoadDistanceService
       |
       v
OSRM
       |
       v
Road Distance
       |
       v
Delivery Fee
```

The exact fee formula is determined by the current implementation.

---

# 33. Location and Checkout

Location services therefore participate in checkout even though checkout itself belongs to the order workflow.

```text id="n2x7v5"
Customer
   |
   v
Cart
   |
   v
Checkout
   |
   v
Select Address
   |
   v
Calculate Delivery Fee
   |
   v
Location Services
```

This demonstrates why location functionality is a cross-cutting application service.

---

# 34. Location and Delivery

Delivery uses location information in multiple ways.

```text id="m8q4p2"
Store Location
       |
       v
Delivery Origin

Customer Location
       |
       v
Delivery Destination

Delivery Partner Location
       |
       v
Current Position
```

These three locations have different meanings.

---

# 35. Three Important Location Types

LocalMart's delivery architecture can be understood using three geographic points:

```text id="x3v8m6"
1. Store
   |
   | Origin
   v

2. Delivery Partner
   |
   | Current Position
   v

3. Customer
   |
   | Destination
```

This distinction is important when designing delivery tracking.

---

# 36. Store → Customer Route

The route used for delivery-distance calculation is primarily:

```text id="p7m2q9"
Store
  |
  v
Customer
```

The delivery partner physically travels along that route after pickup.

---

# 37. Delivery Partner Current Location

The delivery partner's current location is different:

```text id="v4x8m3"
Delivery Partner
       |
       v
Current GPS Coordinates
```

It represents where the delivery partner is currently located.

It does not replace the store or customer coordinates.

---

# 38. Location Data Flow

The complete location ecosystem can be represented as:

```text id="q6m3x8"
                  LOCATION
                     |
        +------------+------------+
        |            |            |
        v            v            v
      STORE       CUSTOMER     DELIVERY
       GPS          GPS        PARTNER GPS
        |            |            |
        +------------+------------+
                     |
                     v
             LocalMart Backend
                     |
          +----------+----------+
          |                     |
          v                     v
   PostgreSQL              OSRM
                                |
                                v
                         Road Information
```

---

# 39. Geocoding vs Routing

Geocoding and routing solve different problems.

### Geocoding

```text id="k7p3x5"
Address
   |
   v
Coordinates
```

### Reverse Geocoding

```text id="m2v8q4"
Coordinates
   |
   v
Address
```

### Routing

```text id="n6x3p9"
Coordinate A
     +
Coordinate B
     |
     v
Road Route
Distance
Duration
```

They should not be treated as the same service.

---

# 40. Location Service Boundaries

LocalMart separates these responsibilities:

```text id="w8m2q5"
GeocodingService
        |
        +--> Address / location conversion

RoadDistanceService
        |
        +--> Road distance / routing

DeliveryPartnerLocationService
        |
        +--> Delivery partner location persistence
```

This separation follows the Single Responsibility Principle.

---

# 41. Database as LocalMart's Location Store

External services provide geographic information, but LocalMart maintains relevant application data in PostgreSQL.

Conceptually:

```text id="x5q8m3"
External Location Service
        |
        v
Location Information
        |
        v
LocalMart
        |
        v
PostgreSQL
```

This means the application does not need to query an external provider for every operation if the required location data is already stored.

---

# 42. Location and Address Lifecycle

A customer's address can follow this lifecycle:

```text id="f9m3v7"
Customer enters address
        |
        v
Location information obtained
        |
        v
Latitude + Longitude
        |
        v
Address Validation
        |
        v
PostgreSQL
        |
        v
Available for Checkout
```

The exact point at which geocoding occurs depends on the current frontend/backend implementation.

---

# 43. Location Search Lifecycle

A location-search operation can follow:

```text id="r2x7m5"
User enters location
        |
        v
LocationSearchRequest
        |
        v
LocationController
        |
        v
GeocodingService
        |
        v
External Provider
        |
        v
LocationSearchResponse
        |
        v
React
```

The user can then select the appropriate location.

---

# 44. Delivery Partner Location Lifecycle

A delivery partner's location follows a different lifecycle:

```text id="v6m2q8"
Delivery Partner
       |
       v
Browser Geolocation
       |
       v
Latitude + Longitude
       |
       v
React
       |
       v
Backend API
       |
       v
DeliveryPartnerLocation
       |
       v
PostgreSQL
```

This is a tracking-oriented flow rather than an address-conversion flow.

---

# 45. Location Data Validation

Coordinates received by the backend should be validated before persistence.

The valid geographic ranges are:

```text id="c3x8m6"
Latitude
-90 to +90

Longitude
-180 to +180
```

This prevents malformed location values from entering the database.

---

# 46. Location Security

Location information can be sensitive from a privacy perspective.

The application should therefore protect location APIs using the same authentication and authorization architecture where required.

For delivery-partner location:

```text id="m7q3v8"
Delivery Partner
       |
       v
JWT
       |
       v
Spring Security
       |
       v
Location API
```

The backend should associate location updates with the authenticated delivery partner rather than trusting an arbitrary partner identifier supplied by the client.

---

# 47. Location and JWT

The general protected-request flow is:

```text id="x2p8m5"
React
 |
 | Bearer JWT
 v
JwtAuthenticationFilter
 |
 v
SecurityContext
 |
 v
Authenticated Delivery Partner
 |
 v
DeliveryPartnerLocationService
```

This establishes the identity behind a location update.

---

# 48. Location Failure Handling

Location operations can fail.

Possible failures include:

```text id="n4m7x2"
Invalid address
Invalid coordinates
Geocoding failure
Location provider unavailable
Browser location permission denied
Browser location unavailable
Location timeout
OSRM failure
OSRM timeout
Database failure
Unauthorized location access
```

The frontend and backend should handle these failures appropriately.

---

# 49. Browser Location Failure

The browser Geolocation API may not always provide a position.

Conceptually:

```text id="q8x3m6"
getCurrentPosition()
        |
        +------> Success
        |
        +------> Permission Denied
        |
        +------> Position Unavailable
        |
        +------> Timeout
```

The application must not assume that the browser always returns a valid coordinate.

---

# 50. External Routing Failure

OSRM is an external dependency.

Therefore:

```text id="v3m7p9"
RoadDistanceService
       |
       v
OSRM
       |
       +----> Success
       |
       +----> Error
       |
       +----> Timeout
```

The application needs an appropriate failure path when routing information cannot be obtained.

---

# 51. Location and Order Management

Order management uses location information primarily for delivery-related operations.

```text id="j6q2x8"
Order
 |
 +--> Store
 |
 +--> Customer Address
 |
 v
Location Services
 |
 v
Delivery Information
```

This creates the connection between geographic data and order fulfillment.

---

# 52. Location and Payment

Location services do not process payments.

Their connection to payment is indirect:

```text id="m8x3q5"
Location
   |
   v
Delivery Fee
   |
   v
Order Total
   |
   v
Payment
```

Thus, location information can influence the amount being paid without becoming part of the payment-processing responsibility itself.

---

# 53. Location and Cart

Location can also affect the customer's checkout experience.

```text id="w4m9v2"
Cart
 |
 v
Checkout
 |
 v
Customer Address
 |
 v
Delivery Fee
 |
 v
Final Total
```

The cart itself remains responsible for the customer's selected products.

Location services provide geographic information needed by checkout.

---

# 54. Location and Store Browsing

Store location can also be used when displaying stores relevant to customers.

Conceptually:

```text id="x7p3m8"
Customer Location
       |
       v
Store Locations
       |
       v
Distance / Availability Logic
       |
       v
Store Results
```

The exact nearby-store filtering logic depends on the current Store implementation.

---

# 55. Location Module Backend Components

The major location-related backend components currently include:

## Controllers

```text id="q2v8m5"
LocationController
DeliveryPartnerLocationController
```

## Services

```text id="m7x3p9"
GeocodingService
RoadDistanceService
DeliveryPartnerLocationService
```

## DTOs

```text id="v4q8n2"
LocationSearchRequest
LocationSearchResponse
DeliveryPartnerLocationRequest
```

## Entities

```text id="x5m2p7"
Address
DeliveryPartnerLocation
```

## Repositories

```text id="j8v3q6"
AddressRepository
DeliveryPartnerLocationRepository
```

---

# 56. External and Browser Components

Location functionality also depends on components outside the Spring Boot application.

```text id="r3m7x9"
Browser
   |
   +--> Geolocation API
   |
   v
React

Spring Boot
   |
   +--> Geocoding Provider
   |
   +--> OSRM
```

This makes location functionality a combination of local application logic and external services.

---

# 57. Complete Location Architecture

The complete architecture can be represented as:

```text id="c8x2m7"
                         USER
                          |
             +------------+------------+
             |                         |
             v                         v
       Address Search            Browser GPS
             |                         |
             v                         v
      LocationController           React
             |                         |
             v                         v
      GeocodingService       Location Request
             |                         |
             v                         v
      External Provider       Backend Location API
             |                         |
             v                         v
        Coordinates       DeliveryPartnerLocationService
             |                         |
             +------------+------------+
                          |
                          v
                     PostgreSQL
                          |
                          v
                 LocalMart Location Data
```

For routing:

```text id="m5v8q3"
Store Coordinates
       +
Customer Coordinates
       |
       v
RoadDistanceService
       |
       v
OSRM
       |
       v
Road Distance / Duration
```

---

# 58. Complete Checkout Location Flow

```text id="n7x3m8"
Customer
   |
   v
Cart
   |
   v
Checkout
   |
   v
Select Address
   |
   v
Customer Coordinates
   |
   +
Store Coordinates
   |
   v
RoadDistanceService
   |
   v
OSRM
   |
   v
Road Distance
   |
   v
Delivery Fee
   |
   v
Order Total
   |
   v
Payment
```

---

# 59. Complete Delivery Location Flow

```text id="p4m8x2"
Store
  |
  | Store Coordinates
  v
Delivery Route
  ^
  |
  | Customer Coordinates
  |
Customer


Delivery Partner
       |
       v
Browser Geolocation
       |
       v
Current Coordinates
       |
       v
React
       |
       v
Backend
       |
       v
PostgreSQL
```

The route information and current delivery-partner location serve different purposes.

---

# 60. Complete Location Data Flow

The overall location-data flow is:

```text id="q9v3m7"
                    LOCATION DATA
                         |
       +-----------------+-----------------+
       |                 |                 |
       v                 v                 v
    ADDRESS          STORE LOCATION    PARTNER GPS
       |                 |                 |
       v                 v                 v
  Geocoding          Database          Browser GPS
       |                                   |
       v                                   v
 Coordinates                         Backend API
       |                                   |
       +----------------+------------------+
                        |
                        v
                 LocalMart Database
                        |
                        v
               Location Consumers
                        |
          +-------------+-------------+
          |             |             |
          v             v             v
       Checkout       Delivery      Tracking
```

---

# 61. Design Principles

### Separate location responsibilities

Geocoding, routing, and delivery-partner tracking are separate concerns.

### Store important coordinates

Relevant geographic information is maintained as part of LocalMart's own data model.

### Validate coordinates

Latitude and longitude are validated before persistence.

### Use road distance for delivery

Delivery-related distance calculations use road-routing information rather than assuming straight-line distance.

### Protect location APIs

Location updates should be associated with authenticated users where appropriate.

### Isolate external services

External providers are accessed through dedicated services such as `GeocodingService` and `RoadDistanceService`.

### Treat browser location separately

The browser's Geolocation API is a client-side capability and is different from backend geocoding or routing services.

---

# 62. Important Distinction: Who Provides What?

A key part of understanding LocalMart's location architecture is knowing which component provides each piece of information.

| Requirement                       | Provider                                           |
| --------------------------------- | -------------------------------------------------- |
| Device's current location         | Browser Geolocation API                            |
| Address/location conversion       | Geocoding service                                  |
| Road distance                     | OSRM through `RoadDistanceService`                 |
| Stored customer coordinates       | LocalMart PostgreSQL                               |
| Stored store coordinates          | LocalMart PostgreSQL                               |
| Stored delivery-partner locations | LocalMart PostgreSQL                               |
| Delivery-fee calculation          | LocalMart backend logic using location information |

The browser, external APIs, and LocalMart backend therefore each have different responsibilities.

---

# 63. Summary

The Location Services subsystem provides the geographic foundation for LocalMart.

The architecture can be summarized as:

```text id="v8m3q5"
                 LOCATION SERVICES
                        |
        +---------------+---------------+
        |               |               |
        v               v               v
     Geocoding       Browser GPS       Routing
        |               |               |
        v               v               v
 Coordinates       Partner Location     OSRM
        |               |               |
        +---------------+---------------+
                        |
                        v
                   LocalMart
                        |
                        v
                    PostgreSQL
```

The most important flows are:

### Address → Coordinates

```text id="x2q7m4"
Address
   |
   v
GeocodingService
   |
   v
Coordinates
   |
   v
LocalMart
```

### Delivery Partner → Current Location

```text id="m6v3p8"
Delivery Partner
   |
   v
Browser Geolocation API
   |
   v
Latitude + Longitude
   |
   v
React
   |
   v
Backend
   |
   v
PostgreSQL
```

### Store → Customer → Road Distance

```text id="p9x4m7"
Store Coordinates
       +
Customer Coordinates
       |
       v
RoadDistanceService
       |
       v
OSRM
       |
       v
Road Distance / Duration
```

### Location → Delivery Fee

```text id="q3m8x6"
Store
  +
Customer Address
  |
  v
Coordinates
  |
  v
Road Distance
  |
  v
Delivery Fee
  |
  v
Checkout
```

Location Services therefore act as a **shared infrastructure layer** connecting customer addresses, stores, checkout, delivery-fee calculation, and delivery-partner tracking without making any one business module responsible for all geographic operations.
