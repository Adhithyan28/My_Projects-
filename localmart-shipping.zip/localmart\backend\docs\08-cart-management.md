# LocalMart — Cart Management

## 1. Overview

The Cart Management Module is responsible for maintaining the products a customer has selected for purchase before checkout.

The cart acts as the bridge between product browsing and order creation:

```text
Customer
    |
    v
Products
    |
    v
Cart
    |
    v
Checkout
    |
    v
Order
```

The cart allows customers to:

* View their cart
* Add products
* Increase product quantity
* Decrease product quantity
* Remove products
* Review cart totals
* Continue to checkout

LocalMart uses a backend-managed cart architecture. The backend and database are the source of truth for cart information.

---

# 2. Cart Management Architecture

The cart module follows the standard LocalMart layered architecture:

```text
React Frontend
      |
      | HTTP
      v
CartController
      |
      v
CartService
      |
      +------------------+
      |                  |
      v                  v
CartRepository    CartItemRepository
      |                  |
      +---------+--------+
                |
                v
            PostgreSQL
```

The cart also interacts with products:

```text
Cart
 |
 +--> Cart Item
        |
        v
      Product
```

And eventually with orders:

```text
Cart
 |
 v
Checkout
 |
 v
Order
```

---

# 3. Purpose of the Cart

The cart represents the customer's current intended purchase.

For example:

```text
Customer Cart
 |
 +--> Product A × 2
 |
 +--> Product B × 1
 |
 +--> Product C × 3
```

The cart exists before the order.

Therefore:

```text
Cart != Order
```

A cart represents what the customer currently intends to purchase.

An order represents a purchase that has entered the order lifecycle.

---

# 4. Cart and Customer Relationship

A cart belongs to a customer.

Conceptually:

```text
Customer
   |
   v
 Cart
```

The customer's identity is determined through the authenticated LocalMart user.

The backend can therefore associate cart operations with the authenticated customer.

```text
JWT
 |
 v
Authenticated User
 |
 v
Customer
 |
 v
Cart
```

This prevents the cart from being treated as an anonymous browser-only object.

---

# 5. Backend-Managed Cart

The LocalMart cart is maintained by the backend.

The architecture is:

```text
React
  |
  | Request
  v
CartController
  |
  v
CartService
  |
  v
Database
```

The frontend displays and interacts with the cart, but the backend maintains the persistent cart state.

This makes the backend the authoritative source for cart contents.

---

# 6. Why the Cart Is Not Browser-Only

A browser-only cart would look like:

```text
Browser
   |
   v
localStorage
   |
   v
Cart
```

LocalMart instead follows:

```text
Browser
   |
   v
HTTP Request
   |
   v
Backend
   |
   v
PostgreSQL
   |
   v
Cart
```

This provides account-associated persistence.

The customer's cart is therefore not tied exclusively to one browser session.

---

# 7. Cart Entity

The backend contains a dedicated:

```text
Cart
```

entity.

Conceptually, a cart represents the customer's cart container.

```text
Cart
 |
 +--> Cart ID
 |
 +--> Customer / User
 |
 +--> Cart Items
```

The exact field mappings are determined by the current `Cart` entity.

---

# 8. Cart Item Entity

A cart contains individual cart items.

The backend contains:

```text
CartItem
```

An item represents a product selected by the customer and its quantity.

Conceptually:

```text
Cart
 |
 +--> CartItem
 |      |
 |      +--> Product
 |      +--> Quantity
 |
 +--> CartItem
        |
        +--> Product
        +--> Quantity
```

This allows one cart to contain multiple products.

---

# 9. Cart-to-Product Relationship

The fundamental relationship is:

```text
Cart
 |
 v
CartItem
 |
 v
Product
```

For example:

```text
Cart
 |
 +--> CartItem
 |      +--> Milk
 |      +--> Quantity: 2
 |
 +--> CartItem
        +--> Bread
        +--> Quantity: 1
```

The cart item provides the connection between the customer's selection and the product catalog.

---

# 10. Cart Controller

`CartController` acts as the HTTP/API boundary for cart operations.

Its responsibility is to:

* Receive cart requests
* Identify the relevant customer context
* Pass the operation to `CartService`
* Return the resulting response

The architecture is:

```text
HTTP Request
     |
     v
CartController
     |
     v
CartService
```

The controller should not be responsible for implementing the complete cart business workflow.

---

# 11. Cart Service

`CartService` contains the cart-related business logic.

It coordinates operations involving:

```text
Cart
CartItem
Product
```

The service sits between the controller and repositories:

```text
CartController
      |
      v
CartService
      |
      +--> CartRepository
      |
      +--> CartItemRepository
      |
      +--> ProductRepository
```

This keeps cart business logic separated from HTTP handling and persistence.

---

# 12. Cart Repository

`CartRepository` handles persistence-related operations for the cart.

Conceptually:

```text
CartService
     |
     v
CartRepository
     |
     v
PostgreSQL
```

The repository abstracts database operations from the service layer.

---

# 13. Cart Item Repository

`CartItemRepository` handles persistence-related operations for individual cart items.

The relationship is:

```text
CartService
     |
     v
CartItemRepository
     |
     v
PostgreSQL
```

Together, the cart and cart-item repositories allow the backend to manage the complete cart structure.

---

# 14. Adding a Product to Cart

When a customer selects a product and adds it to the cart, the request follows a backend flow.

```text
Customer
   |
   v
Product
   |
   v
Add to Cart
   |
   v
CartController
   |
   v
CartService
   |
   v
ProductRepository
   |
   v
Validate Product
   |
   v
Cart / CartItem
   |
   v
PostgreSQL
```

The backend then returns the updated cart information.

---

# 15. Add Cart Item Request

The backend contains:

```text
AddCartItemRequest
```

This DTO represents information supplied when adding an item to the cart.

The DTO acts as the boundary between the HTTP request and the service layer.

Conceptually:

```text
JSON Request
     |
     v
AddCartItemRequest
     |
     v
CartController
     |
     v
CartService
```

This prevents the controller from needing to directly expose persistence entities as request models.

---

# 16. Cart Response

The backend contains:

```text
CartResponse
CartItemResponse
```

These DTOs represent cart information returned to the frontend.

Conceptually:

```text
Database
   |
   v
Cart Entity
   |
   v
CartService
   |
   v
CartResponse
   |
   v
JSON
   |
   v
React
```

A cart response can contain the overall cart information and its individual cart items.

---

# 17. Adding the Same Product

When a product that already exists in the cart is selected again, the cart business logic needs to determine how to handle the existing cart item.

Conceptually:

```text
Add Product
     |
     v
Does CartItem Exist?
     |
   +---+---+
   |       |
  Yes      No
   |       |
   v       v
Update   Create
Quantity CartItem
```

The exact implementation determines whether the quantity is incremented or another business rule is applied.

---

# 18. Product Quantity

Quantity is a property of the cart item rather than the product itself.

```text
Product
   |
   v
CartItem
   |
   +--> Quantity
```

For example:

```text
Product: Rice
Cart Quantity: 3
```

The product's catalog information and the customer's selected quantity are therefore separate concepts.

---

# 19. Updating Cart Quantity

The customer can change the quantity of a cart item.

The conceptual flow is:

```text
Customer
   |
   v
Change Quantity
   |
   v
CartController
   |
   v
CartService
   |
   v
CartItem
   |
   v
Updated Quantity
   |
   v
PostgreSQL
```

The service layer should validate the requested quantity according to the application's business rules.

---

# 20. Removing a Cart Item

A customer can remove a selected product from the cart.

The flow is:

```text
Customer
   |
   v
Remove Product
   |
   v
CartController
   |
   v
CartService
   |
   v
CartItemRepository
   |
   v
Delete CartItem
```

The cart itself can remain associated with the customer after the item is removed.

---

# 21. Viewing the Cart

When the customer opens the Cart page:

```text
Customer
   |
   v
Cart Page
   |
   | HTTP Request
   v
CartController
   |
   v
CartService
   |
   +--> CartRepository
   |
   +--> CartItemRepository
   |
   +--> ProductRepository
   |
   v
CartResponse
   |
   v
React
```

The frontend then displays the current backend cart.

---

# 22. Cart Total

The cart contains multiple items, so the backend needs to calculate the monetary value of the selected products.

Conceptually:

```text
Product Price × Quantity
             |
             v
        Item Subtotal
             |
             v
     +-------+-------+
     |       |       |
    Item 1  Item 2  Item 3
     |       |       |
     +-------+-------+
             |
             v
       Cart Subtotal
```

The exact calculation and monetary handling are controlled by the application's service implementation.

---

# 23. Cart and Store

LocalMart is a multi-store commerce platform.

Products are associated with stores, which means cart contents can carry store context through their products.

```text
Cart
 |
 v
CartItem
 |
 v
Product
 |
 v
Store
```

For example:

```text
Cart
 |
 +--> Product A
 |       |
 |       +--> Store A
 |
 +--> Product B
         |
         +--> Store A
```

Store context becomes important during checkout and delivery-fee calculation.

---

# 24. Store Context During Checkout

The customer-side delivery-fee calculation uses:

```text
storeId
addressId
```

The conceptual relationship is:

```text
Cart
 |
 v
Store
 |
 +--> storeId
 |
 v
Customer Address
 |
 +--> addressId
 |
 v
Delivery Fee Calculation
```

This connects the cart to the location and delivery systems.

---

# 25. Cart and Customer Address

A cart does not represent a delivery address.

The address is selected during the checkout/delivery process.

```text
Cart
 |
 v
Checkout
 |
 v
Customer Address
 |
 v
Delivery Calculation
```

This distinction allows the customer to maintain multiple addresses while selecting the appropriate destination for a particular purchase.

---

# 26. Cart and Delivery Fee

The cart provides the purchase/store context required for delivery calculation.

A simplified flow is:

```text
Cart
 |
 v
Determine Store
 |
 v
Customer Selects Address
 |
 v
storeId + addressId
 |
 v
Delivery Fee Service
 |
 v
Distance Calculation
 |
 v
Delivery Fee
```

The delivery-fee system can use store and customer coordinates to calculate the appropriate delivery distance.

---

# 27. Cart and Location Services

The cart itself does not determine geographic distance.

Instead, location information is provided by the address/location subsystem.

```text
Customer Address
      |
      v
Latitude / Longitude
      |
      v
Location Services
      |
      v
Road Distance
      |
      v
Delivery Fee
```

This keeps location calculations separate from cart management.

---

# 28. Cart and Checkout

The cart is the starting point of checkout.

```text
Cart
 |
 v
Review Items
 |
 v
Select Address
 |
 v
Calculate Delivery Fee
 |
 v
Calculate Total
 |
 v
Payment
 |
 v
Order
```

Checkout combines information from multiple modules.

The cart module itself should not become responsible for payment processing or delivery management.

---

# 29. Cart and Payment

The cart contributes to the amount that eventually needs to be paid.

Conceptually:

```text
Cart
 |
 v
Cart Subtotal
 |
 +--> Delivery Fee
 |
 v
Order Total
 |
 v
Payment
```

The payment system is responsible for payment processing, while cart management remains responsible for maintaining the customer's selected products.

---

# 30. Cart to Order Transition

A cart and an order have different lifecycles.

```text
Cart
 |
 | Checkout
 v
Order Creation
 |
 v
Order
```

The cart represents the customer's current selection.

The order represents the purchase created from that selection.

Conceptually:

```text
Cart
 |
 +--> Product A × 2
 +--> Product B × 1
 |
 v
Checkout
 |
 v
Order
 |
 +--> OrderItem A × 2
 +--> OrderItem B × 1
```

---

# 31. Why Cart and Order Are Separate

The distinction is important.

### Cart

```text
Current intention
```

### Order

```text
Recorded purchase
```

A customer can modify a cart multiple times without creating an order.

Once checkout creates an order, the order enters its own lifecycle.

```text
Cart Lifecycle
      |
      v
Checkout
      |
      v
Order Lifecycle
```

---

# 32. Cart Persistence

The cart is persisted through the backend's database layer.

Conceptually:

```text
Customer
   |
   v
Cart
   |
   v
CartItem
   |
   v
PostgreSQL
```

The backend therefore maintains cart state independently of the React component's in-memory state.

The React application can retrieve the latest state from the backend whenever required.

---

# 33. Cart Synchronization

The frontend may maintain temporary UI state while displaying the cart, but the backend remains the source of truth for persistent cart information.

```text
Backend Cart
     |
     v
JSON Response
     |
     v
React State
     |
     v
Cart UI
```

When the customer changes the cart:

```text
React
   |
   v
HTTP Request
   |
   v
Backend
   |
   v
Database
   |
   v
Updated Cart
   |
   v
React
```

This provides a request/response synchronization model.

---

# 34. Cart Security

Cart operations are customer-specific.

A protected cart request should follow:

```text
HTTP Request
     |
     v
JWT
     |
     v
Spring Security
     |
     v
Authenticated User
     |
     v
Customer Cart
```

The backend should use the authenticated identity when determining which cart is being accessed.

---

# 35. Cart Ownership

A customer's cart should not be accessible merely because the client supplies another user's ID.

Conceptually:

```text
Authenticated User
        |
        v
User ID
        |
        v
Owned Cart
```

This is an important authorization and data-isolation rule.

---

# 36. Cart Validation

Cart operations should validate the relevant business data.

Possible validation concerns include:

* Product existence
* Product availability
* Valid quantity
* Cart ownership
* Store/product relationship
* Appropriate product state

The general flow is:

```text
Request
   |
   v
Validate
   |
   +---- Invalid ---> Error
   |
   v
Business Logic
   |
   v
Database
```

The exact validation rules are defined by the current `CartService` implementation.

---

# 37. Cart Error Handling

Cart operations can fail for business or request reasons.

Examples include:

```text
Product not found
Invalid quantity
Cart not found
Cart item not found
Product unavailable
Unauthorized access
```

The application uses centralized exception handling through:

```text
GlobalExceptionHandler
```

where applicable.

The purpose is to convert backend exceptions into appropriate HTTP responses instead of exposing internal implementation details.

---

# 38. Cart Module Backend Components

The main cart-related backend components are:

```text
Controller
    |
    +--> CartController

Service
    |
    +--> CartService

DTO
    |
    +--> AddCartItemRequest
    +--> CartItemResponse
    +--> CartResponse

Entity
    |
    +--> Cart
    +--> CartItem

Repository
    |
    +--> CartRepository
    +--> CartItemRepository
```

The cart also depends on product information through:

```text
ProductRepository
Product
ProductService
```

where required by the implementation.

---

# 39. Cart Module Frontend

The customer-facing cart interface is represented by:

```text
Cart
```

The page communicates with the backend cart API.

The conceptual flow is:

```text
React Cart Page
       |
       v
Cart API
       |
       v
CartController
       |
       v
CartService
       |
       v
Database
```

The frontend then renders the returned cart information.

---

# 40. Cart Request/Response Cycle

A typical cart request follows:

```text
React
  |
  | HTTP Request
  v
CartController
  |
  v
CartService
  |
  v
Repository
  |
  v
PostgreSQL
```

The response follows the reverse direction:

```text
PostgreSQL
   |
   v
Repository
   |
   v
CartService
   |
   v
CartResponse
   |
   v
CartController
   |
   v
JSON
   |
   v
React
```

---

# 41. Cart Module and Product Module

The relationship is:

```text
PRODUCT MODULE
      |
      v
   Product
      |
      v
CART MODULE
      |
      v
  Cart Item
```

The Product Module defines product information.

The Cart Module manages the customer's selection of those products.

---

# 42. Cart Module and Store Module

The relationship is:

```text
STORE MODULE
      |
      v
    Store
      |
      v
   Product
      |
      v
CART MODULE
```

The store provides the business context for products placed into the cart.

---

# 43. Cart Module and Order Module

The relationship is:

```text
CART MODULE
      |
      v
    Cart
      |
      v
   Checkout
      |
      v
ORDER MODULE
      |
      v
    Order
```

The cart therefore acts as an input to order creation.

---

# 44. Cart Module and Delivery Module

The relationship is:

```text
Cart
 |
 v
Store
 |
 +--> Store Location
 |
 v
Customer Address
 |
 v
Distance
 |
 v
Delivery Fee
 |
 v
Checkout
```

The cart itself does not perform delivery.

It supplies the shopping/store context needed by checkout and delivery-fee calculations.

---

# 45. Cart Module and Payment Module

The relationship is:

```text
Cart
 |
 v
Subtotal
 |
 v
Delivery Fee
 |
 v
Order Total
 |
 v
Payment
```

Payment processing remains the responsibility of the payment module.

---

# 46. Complete Cart Flow

The complete customer cart flow is:

```text
Customer
    |
    v
Browse Products
    |
    v
Select Product
    |
    v
Add to Cart
    |
    v
CartController
    |
    v
CartService
    |
    v
Cart / CartItem
    |
    v
PostgreSQL
    |
    v
Cart Response
    |
    v
Customer Reviews Cart
    |
    v
Update / Remove Items
    |
    v
Checkout
    |
    v
Select Address
    |
    v
Delivery Fee
    |
    v
Payment
    |
    v
Order
```

---

# 47. Complete Cart Architecture

The complete architecture can be summarized as:

```text
                         CUSTOMER
                             |
                             v
                        React UI
                             |
                             v
                       CartController
                             |
                             v
                        CartService
                             |
              +--------------+--------------+
              |              |              |
              v              v              v
       CartRepository  CartItemRepository ProductRepository
              |              |              |
              +--------------+--------------+
                             |
                             v
                         PostgreSQL
                             |
                             v
                       Cart / CartItems
```

The cart then connects to checkout:

```text
Cart
 |
 v
Checkout
 |
 +--> Customer Address
 |
 +--> Store
 |
 +--> Delivery Fee
 |
 +--> Payment
 |
 v
Order
```

---

# 48. Cart Lifecycle

A simplified lifecycle is:

```text
Cart Created / Retrieved
        |
        v
Add Items
        |
        v
Modify Quantities
        |
        v
Remove Items
        |
        v
Review Cart
        |
        v
Checkout
        |
        v
Order Created
```

The cart may continue to exist as an account-associated cart depending on the application's order/checkout implementation.

The exact post-order cart-clearing behavior is determined by the current implementation.

---

# 49. Important Design Principles

### Backend as the source of truth

Persistent cart information is maintained by the backend and database.

### Customer ownership

Cart data belongs to the authenticated customer.

### Product reference

Cart items refer to products rather than duplicating the entire product-management system.

### Store awareness

Products in the cart carry store context that becomes important during checkout.

### Separation from orders

A cart represents a pending selection; an order represents a purchase.

### Separation of concerns

Cart management does not directly own payment or delivery operations.

### Validation at the backend

Important cart rules must be validated server-side rather than relying exclusively on frontend validation.

---

# 50. Summary

The Cart Management Module is the bridge between product selection and checkout.

Its core structure is:

```text
Customer
   |
   v
Cart
   |
   +--> CartItem
           |
           v
        Product
           |
           v
         Store
```

The customer workflow is:

```text
Browse Product
      |
      v
Add to Cart
      |
      v
Update Cart
      |
      v
Review Cart
      |
      v
Select Address
      |
      v
Calculate Delivery
      |
      v
Checkout
      |
      v
Payment
      |
      v
Order
```

At the backend level:

```text
React
  |
  v
CartController
  |
  v
CartService
  |
  +--> CartRepository
  |
  +--> CartItemRepository
  |
  +--> ProductRepository
  |
  v
PostgreSQL
```

The Cart Module therefore provides the persistent shopping-selection layer that connects LocalMart's product catalog to its checkout and order-processing systems.
