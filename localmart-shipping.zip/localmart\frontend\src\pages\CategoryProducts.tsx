import { useEffect, useState } from "react"
import { useAuth } from "../context/AuthContext"


/* =========================================================
   TYPES
   ========================================================= */

interface Category {
    id: number
    name: string
    description: string
    icon: string
    productCount: number
}

interface Product {
    id: number
    name: string
    category: string
    description: string | null
    price: number
    unit: string
    icon: string | null
    storeId: number
    storeName: string
    stockQuantity: number
    isAvailable: boolean
}

interface Store {
    id: number
    name: string
    type: string
    city: string
    state: string
    latitude: number | null
    longitude: number | null
}

interface CategoryProductsProps {
    category: Category
    onHome: () => void
    onStores: () => void
    onCategories: () => void
    onProducts: () => void
    onOrders: () => void
    onCart: () => void
}


/* =========================================================
   COMPONENT
   ========================================================= */

function CategoryProducts({
                              category,
                              onHome,
                              onStores,
                              onCategories,
                              onProducts,
                              onOrders,
                              onCart,
                          }: CategoryProductsProps) {

    const { user, logout } = useAuth()

    const [search, setSearch] = useState("")

    const [products, setProducts] = useState<Product[]>([])

    const [loading, setLoading] = useState(true)
    const [error, setError] = useState("")


    /* =====================================================
       FETCH CATEGORY PRODUCTS + STORES
       ===================================================== */

    useEffect(() => {

        const fetchData = async () => {

            if (!user?.token) {

                setError(
                    "You must be logged in to view products."
                )

                setLoading(false)

                return
            }


            try {

                setLoading(true)
                setError("")


                const headers = {
                    Authorization:
                        `Bearer ${user.token}`,
                }


                /*
                 * The category name comes from the
                 * Categories page.
                 *
                 * Example:
                 *
                 * /api/products/category/food
                 */

                const encodedCategory =
                    encodeURIComponent(category.name)


                const [
                    productsResponse,
                    storesResponse,
                ] = await Promise.all([

                    fetch(
                        `/api/products/category/${encodedCategory}`,
                        {
                            headers,
                        }
                    ),

                    fetch(
                        "/api/stores",
                        {
                            headers,
                        }
                    ),

                ])


                if (!productsResponse.ok) {

                    throw new Error(
                        "Failed to load category products."
                    )

                }


                if (!storesResponse.ok) {

                    throw new Error(
                        "Failed to load stores."
                    )

                }


                const productsData =
                    await productsResponse.json()


                const storesData =
                    await storesResponse.json()


                /*
                 * Store API and Product API are separate.
                 *
                 * Product contains storeId.
                 * Store API contains the actual store name.
                 *
                 * Therefore create:
                 *
                 * storeId → storeName
                 */

                const storeMap =
                    new Map<number, string>()


                storesData.forEach(
                    (store: Store) => {

                        storeMap.set(
                            store.id,
                            store.name
                        )

                    }
                )


                /* =================================================
                   MAP PRODUCTS
                   ================================================= */

                const mappedProducts: Product[] =
                    productsData.map(
                        (product: any) => ({

                            id:
                            product.productId,

                            name:
                            product.productName,

                            category:
                            product.category,

                            description:
                                product.description ?? null,

                            price:
                                Number(product.price),

                            unit:
                            product.unit,

                            icon:
                                product.icon ?? null,

                            storeId:
                            product.storeId,

                            storeName:
                                storeMap.get(
                                    product.storeId
                                ) ??
                                `Store #${product.storeId}`,

                            stockQuantity:
                                Number(
                                    product.stockQuantity
                                ),

                            isAvailable:
                                Boolean(
                                    product.isAvailable
                                ),

                        })
                    )


                setProducts(mappedProducts)

            } catch (err) {

                console.error(
                    "Category products error:",
                    err
                )


                setError(
                    err instanceof Error
                        ? err.message
                        : "Unable to load products."
                )

            } finally {

                setLoading(false)

            }

        }


        fetchData()

    }, [user?.token, category.name])


    /* =====================================================
       SEARCH PRODUCTS
       ===================================================== */

    const filteredProducts =
        products.filter((product) => {

            const normalizedSearch =
                search
                    .toLowerCase()
                    .trim()


            return product.name
                .toLowerCase()
                .includes(normalizedSearch)

        })


    /* =====================================================
       ADD TO CART
       ===================================================== */

    const addToCart = async (
        product: Product
    ) => {

        if (!user?.token) {

            alert(
                "Please login to add products to your cart."
            )

            return
        }


        if (!product.isAvailable) {

            alert(
                `${product.name} is currently unavailable.`
            )

            return
        }


        if (product.stockQuantity <= 0) {

            alert(
                `${product.name} is out of stock.`
            )

            return
        }


        try {

            const response =
                await fetch(
                    "/api/cart/items",
                    {

                        method: "POST",

                        headers: {

                            "Content-Type":
                                "application/json",

                            Authorization:
                                `Bearer ${user.token}`,

                        },

                        body: JSON.stringify({

                            productId:
                            product.id,

                            quantity: 1,

                        }),

                    }
                )


            const data =
                await response.json()


            if (!response.ok) {

                throw new Error(
                    data.message ||
                    data.error ||
                    "Unable to add product to cart."
                )

            }


            alert(
                `${product.name} added to cart`
            )

        } catch (err) {

            console.error(
                "Add to cart error:",
                err
            )


            alert(
                err instanceof Error
                    ? err.message
                    : "Unable to add product to cart."
            )

        }

    }


    /* =====================================================
       PRODUCT ICON
       ===================================================== */

    const getProductIcon = (
        product: Product
    ) => {

        if (product.icon) {
            return product.icon
        }


        const categoryName =
            product.category
                ?.toLowerCase()


        if (
            categoryName?.includes("fruit") ||
            categoryName?.includes("vegetable")
        ) {
            return "🍎"
        }


        if (
            categoryName?.includes("dairy")
        ) {
            return "🥛"
        }


        if (
            categoryName?.includes("bakery")
        ) {
            return "🍞"
        }


        if (
            categoryName?.includes("beverage")
        ) {
            return "🥤"
        }


        if (
            categoryName?.includes("snack")
        ) {
            return "🍪"
        }


        if (
            categoryName?.includes("personal")
        ) {
            return "🧴"
        }


        if (
            categoryName?.includes("household")
        ) {
            return "🧺"
        }


        return "🛒"

    }


    /* =====================================================
       UI
       ===================================================== */

    return (

        <div className="customer-dashboard">


            {/* =================================================
                HEADER
            ================================================= */}

            <header className="customer-header">


                {/* LOGO */}

                <button
                    className="customer-logo"
                    type="button"
                    onClick={onHome}
                >

                    <span className="logo-icon">
                        🛒
                    </span>

                    <span>
                        LocalMart
                    </span>

                </button>


                {/* SEARCH */}

                <div className="customer-search">

                    <span className="search-icon">
                        ⌕
                    </span>

                    <input
                        type="text"
                        placeholder="Search products..."
                        value={search}
                        onChange={(e) =>
                            setSearch(e.target.value)
                        }
                    />

                </div>


                {/* LOCATION */}

                <div className="customer-location">

                    <span>
                        📍
                    </span>

                    <div>

                        <small>
                            Deliver to
                        </small>

                        <strong>
                            Chennai
                        </strong>

                    </div>

                </div>


                {/* CART */}

                <button
                    className="category-products-cart-button"
                    type="button"
                    onClick={onCart}
                >

                    🛒

                </button>


                {/* PROFILE */}

                <div className="customer-profile">

                    <div className="profile-avatar">

                        {user?.email
                            ?.charAt(0)
                            .toUpperCase() || "U"}

                    </div>

                    <div className="profile-info">

                        <span>
                            Customer
                        </span>

                        <strong>
                            {user?.email || "User"}
                        </strong>

                    </div>

                </div>


                {/* LOGOUT */}

                <button
                    className="customer-logout"
                    type="button"
                    onClick={logout}
                >
                    Logout
                </button>

            </header>


            {/* =================================================
                NAVIGATION
            ================================================= */}

            <nav className="customer-navigation">

                <div className="navigation-inner">

                    <button
                        type="button"
                        onClick={onHome}
                    >
                        Home
                    </button>

                    <button
                        type="button"
                        onClick={onStores}
                    >
                        Stores
                    </button>

                    <button
                        type="button"
                        className="nav-active"
                        onClick={onCategories}
                    >
                        Categories
                    </button>

                    <button
                        type="button"
                        onClick={onProducts}
                    >
                        Products
                    </button>

                    <button
                        type="button"
                        onClick={onOrders}
                    >
                        Orders
                    </button>

                </div>

            </nav>


            {/* =================================================
                MAIN
            ================================================= */}

            <main className="customer-main">

                <div className="category-products-container">


                    {/* BACK */}

                    <button
                        className="category-products-back"
                        type="button"
                        onClick={onCategories}
                    >
                        ← Back to Categories
                    </button>


                    {/* CATEGORY HEADING */}

                    <section className="category-products-heading">

                        <div className="category-products-icon">

                            {category.icon}

                        </div>


                        <div>

                            <p className="section-eyebrow">
                                SHOP LOCAL
                            </p>

                            <h1>
                                {category.name}
                            </h1>

                            <p>
                                {category.description}
                            </p>

                        </div>

                    </section>


                    {/* SEARCH */}

                    <section className="category-products-search">

                        <div className="category-products-search-box">

                            <span>
                                🔍
                            </span>

                            <input
                                type="text"
                                placeholder={
                                    `Search ${category.name.toLowerCase()}...`
                                }
                                value={search}
                                onChange={(e) =>
                                    setSearch(e.target.value)
                                }
                            />

                        </div>

                    </section>


                    {/* ERROR */}

                    {error && (

                        <section className="category-products-empty">

                            <div>
                                ⚠️
                            </div>

                            <h2>
                                Unable to load products
                            </h2>

                            <p>
                                {error}
                            </p>

                        </section>

                    )}


                    {/* LOADING */}

                    {loading && !error && (

                        <section className="category-products-empty">

                            <div>
                                🛒
                            </div>

                            <h2>
                                Loading products...
                            </h2>

                            <p>
                                Getting products from local stores.
                            </p>

                        </section>

                    )}


                    {/* TITLE */}

                    {!loading && !error && (

                        <div className="category-products-title">

                            <div>

                                <h2>
                                    {category.name}
                                </h2>

                                <p>
                                    {filteredProducts.length} products available
                                </p>

                            </div>

                        </div>

                    )}


                    {/* NO PRODUCTS */}

                    {!loading &&
                        !error &&
                        filteredProducts.length === 0 && (

                            <section className="category-products-empty">

                                <div>
                                    🔍
                                </div>

                                <h2>
                                    No products found
                                </h2>

                                <p>
                                    Try searching with another
                                    product name.
                                </p>

                            </section>

                        )}


                    {/* PRODUCTS */}

                    {!loading &&
                        !error &&
                        filteredProducts.length > 0 && (

                            <section className="category-products-grid">

                                {filteredProducts.map(
                                    (product) => (

                                        <article
                                            className="category-product-card"
                                            key={product.id}
                                        >


                                            {/* PRODUCT IMAGE */}

                                            <div className="category-product-image">

                                                {getProductIcon(
                                                    product
                                                )}

                                            </div>


                                            {/* PRODUCT BODY */}

                                            <div className="category-product-body">


                                                <span className="category-product-category">

                                                    {product.category}

                                                </span>


                                                <h3>
                                                    {product.name}
                                                </h3>


                                                <p className="category-product-unit">

                                                    {product.unit}

                                                </p>


                                                {/* STORE */}

                                                <div className="category-product-store">

                                                    <span>
                                                        🏪
                                                    </span>

                                                    {product.storeName}

                                                </div>


                                                {/* STOCK */}

                                                <div className="category-product-rating">

                                                    {product.stockQuantity > 0
                                                        ? `${product.stockQuantity} in stock`
                                                        : "Out of stock"}

                                                </div>


                                                {/* PRICE + CART */}

                                                <div className="category-product-bottom">

                                                    <strong>
                                                        ₹{product.price}
                                                    </strong>

                                                    <button
                                                        type="button"
                                                        disabled={
                                                            !product.isAvailable ||
                                                            product.stockQuantity <= 0
                                                        }
                                                        onClick={() =>
                                                            addToCart(
                                                                product
                                                            )
                                                        }
                                                    >

                                                        {!product.isAvailable
                                                            ? "Unavailable"
                                                            : product.stockQuantity <= 0
                                                                ? "Out of Stock"
                                                                : "Add to Cart"}

                                                    </button>

                                                </div>

                                            </div>

                                        </article>

                                    )
                                )}

                            </section>

                        )}

                </div>

            </main>


            {/* =================================================
                FOOTER
            ================================================= */}

            <footer className="customer-footer">

                <div className="footer-content">


                    {/* FOOTER BRAND */}

                    <div className="footer-brand">

                        <div className="footer-logo">
                            🛒 LocalMart
                        </div>

                        <p>
                            Your local stores,
                            delivered to your door.
                        </p>

                    </div>


                    {/* FOOTER LINKS */}

                    <div className="footer-links">

                        <button
                            type="button"
                            onClick={onHome}
                        >
                            Home
                        </button>

                        <button
                            type="button"
                            onClick={onStores}
                        >
                            Stores
                        </button>

                        <button
                            type="button"
                            onClick={onCategories}
                        >
                            Categories
                        </button>

                        <button
                            type="button"
                            onClick={onProducts}
                        >
                            Products
                        </button>

                        <button
                            type="button"
                            onClick={onOrders}
                        >
                            Orders
                        </button>

                        <button
                            type="button"
                            onClick={onCart}
                        >
                            Cart
                        </button>

                    </div>

                </div>


                {/* FOOTER BOTTOM */}

                <div className="footer-bottom">

                    <span>
                        © 2026 LocalMart
                    </span>

                    <span>
                        Shop local. Live local.
                    </span>

                </div>

            </footer>

        </div>
    )
}


export default CategoryProducts