# LocalMart — Validation and Business Rules

## 1. Overview

Validation is one of the mechanisms that protects LocalMart from invalid, incomplete, inconsistent, or unauthorized data.

LocalMart performs validation at multiple layers:

```text
Frontend
   |
   v
Controller / Request DTO
   |
   v
Service
   |
   v
Repository / Database
```

These layers have different responsibilities.

The two most important concepts are:

* **Input validation** — Is the supplied data correctly formatted and complete?
* **Business-rule validation** — Is the requested operation actually allowed according to LocalMart's rules?

For example:

```text
"Is this a valid Indian PIN code?"
        ↓
Input validation

"Does this address belong to this customer?"
        ↓
Business-rule validation
```

---

# 2. Why Validation Is Required

A web application receives data from clients that cannot automatically be trusted.

For example:

```text
Frontend
   |
   | email = "abc"
   | phone = "123"
   | quantity = -5
   | latitude = 500
   |
   v
Backend
```

The backend must validate the data before using it.

The fundamental rule is:

> **Frontend validation improves user experience; backend validation protects application correctness and security.**

---

# 3. Validation Layers

LocalMart's validation can be viewed as:

```text
                 User Request
                      |
                      v
              Frontend Validation
                      |
                      v
              HTTP Request / DTO
                      |
                      v
             Backend Validation
                      |
             +--------+--------+
             |                 |
             v                 v
       Input Validation   Business Rules
             |                 |
             +--------+--------+
                      |
                      v
                  Repository
                      |
                      v
                   Database
```

Validation closer to the database provides an additional protection layer against inconsistent persistent data.

---

# 4. Input Validation

Input validation checks whether the supplied value has an acceptable format.

Examples include:

```text
Required fields
Email format
Phone format
Password requirements
PIN code format
Coordinate ranges
Positive quantities
Valid identifiers
```

For example:

```text
Email:
    user@example.com  → valid format

    userexample.com   → invalid format
```

Input validation does not necessarily determine whether an operation is allowed.

---

# 5. Business-Rule Validation

Business validation determines whether an operation makes sense according to LocalMart's application rules.

Examples:

```text
Customer can modify their own address
Store owner can manage their own store
Customer cannot access another customer's cart
Blocked account cannot authenticate
Inactive store-owner application cannot perform owner operations
Order status must follow valid transitions
```

The difference is:

```text
Input validation
    ↓
"Is the data valid?"

Business validation
    ↓
"Is this operation allowed?"
```

---

# 6. Frontend vs Backend Validation

LocalMart can validate data on the frontend before sending it.

For example:

```text
User enters phone number
        |
        v
Frontend validation
        |
   +----+----+
   |         |
Invalid    Valid
   |         |
Show error  Send request
```

However, the backend must validate the same critical information again.

The reason is that a client can be bypassed.

For example, a user could directly send:

```text
POST /api/users/register
```

without using the LocalMart frontend.

Therefore:

```text
Frontend validation
       +
Backend validation
       =
Defense in depth
```

---

# 7. Required Fields

Many LocalMart requests require mandatory fields.

Examples include:

```text
Registration
    first name
    last name
    email / phone
    password
    role

Address
    address line
    city
    state
    PIN
    latitude
    longitude

Cart
    product ID
    quantity

Order
    address ID
    store ID
    order items
```

Missing required information should be rejected before the operation proceeds.

---

# 8. Email Validation

Email addresses are validated before they are used for operations such as:

```text
Registration
Login
OTP delivery
Google account association
```

The purpose is to prevent malformed email values from entering the application.

However, syntactic validity does not prove that the user owns the email address.

That is why OTP verification provides an additional ownership check.

```text
Email format validation
        +
Email OTP verification
        ↓
Stronger email verification
```

---

# 9. Phone Number Validation

LocalMart supports Indian mobile-number based authentication.

The frontend login flow identifies an Indian mobile number using:

```text
[6-9]\d{9}
```

This represents:

```text
6–9
+
nine additional digits
```

giving a 10-digit Indian mobile number.

Backend validation should remain the authoritative validation boundary.

---

# 10. OTP Validation

OTP-based operations require validation of:

```text
OTP value
OTP expiration
OTP session/context
Associated login or registration identifier
```

Conceptually:

```text
User
 |
 | OTP
 v
Backend
 |
 +---- Correct?
 |
 +---- Expired?
 |
 +---- Correct user/session?
 |
 v
Verification result
```

An invalid OTP must not result in successful authentication or registration.

---

# 11. OTP Expiration

LocalMart's user authentication flow uses a five-minute OTP validity period.

Conceptually:

```text
OTP generated
      |
      v
5-minute validity window
      |
      +---- OTP submitted in time → verify
      |
      +---- OTP submitted after expiry → reject
```

Expiration prevents an old OTP from remaining valid indefinitely.

---

# 12. Registration Verification

LocalMart uses a verification step before completing registration.

The registration flow is:

```text
User
 |
 | registration data
 v
Request OTP
 |
 v
OTP Verification
 |
 v
Registration Token
 |
 v
User Registration
```

The registration token acts as proof that the required verification step was completed.

The backend validates that token before completing the registration.

---

# 13. Registration Token Validation

The registration process can be represented as:

```text
Registration request
        |
        v
OTP verification
        |
        v
Registration token
        |
        v
Register user
```

If the registration token is:

```text
missing
invalid
expired
already consumed
```

registration should not proceed.

This prevents a user from bypassing the verification stage.

---

# 14. Duplicate User Validation

LocalMart prevents duplicate identities.

During registration, the backend checks for existing users using identifiers such as:

```text
Email
Phone
External identity
```

Conceptually:

```text
New registration
      |
      v
Check existing user
      |
   +--+--+
   |     |
 Exists  Doesn't exist
   |          |
 Reject      Continue
```

This maintains identity uniqueness.

---

# 15. Password Validation

Passwords are validated before being stored.

LocalMart does not store the user's raw password.

The flow is:

```text
Plain Password
      |
      v
Validation
      |
      v
BCrypt
      |
      v
Password Hash
      |
      v
Database
```

During login:

```text
Entered Password
      |
      v
BCrypt verification
      |
      v
Stored Hash
```

The original password is not reconstructed from the hash.

---

# 16. Role Validation

LocalMart defines four primary roles:

```text
CUSTOMER
STORE_OWNER
DELIVERY_PARTNER
ADMIN
```

The backend validates the requested role during registration.

The application prevents ordinary registration from creating an administrator account.

Conceptually:

```text
Registration
     |
     v
Requested Role
     |
     +---- CUSTOMER → allowed
     |
     +---- STORE_OWNER → application process
     |
     +---- DELIVERY_PARTNER → application process
     |
     +---- ADMIN → not allowed through ordinary registration
```

---

# 17. Account Status Rules

LocalMart uses account status values including:

```text
ACTIVE
INACTIVE
BLOCKED
```

The account status affects authentication and access.

Conceptually:

```text
Account
   |
   +---- ACTIVE
   |       ↓
   |    Continue
   |
   +---- BLOCKED
   |       ↓
   |    Reject
   |
   +---- INACTIVE
           ↓
      Check application state
```

This means authentication is not determined solely by whether credentials are correct.

---

# 18. Store Owner Registration Rule

Store-owner registration requires an administrative approval process.

The general flow is:

```text
Store Owner
     |
     v
Registration
     |
     v
Application Request
     |
     v
Admin Review
     |
 +---+---+
 |       |
Approve Reject
 |       |
 v       v
Continue Stop
```

The store owner cannot simply create an approved business account without the application process.

---

# 19. Delivery Partner Registration Rule

Delivery partners follow a similar approval concept.

```text
Delivery Partner
       |
       v
Registration
       |
       v
Application Request
       |
       v
Admin Review
       |
   +---+---+
   |       |
Approved Rejected
```

Additional delivery-partner information can include vehicle-related information.

---

# 20. Application Status

LocalMart defines application statuses:

```text
PENDING
APPROVED
REJECTED
```

The application state determines what can happen next.

Conceptually:

```text
PENDING
   |
   +---- Admin approves → APPROVED
   |
   +---- Admin rejects  → REJECTED
```

The application status is separate from ordinary account status.

This distinction is important.

```text
Application status
        ≠
Account status
```

---

# 21. Store Validation

Store-related operations must validate that the relevant store exists.

For example:

```text
Customer
   |
   v
Request products for Store 10
   |
   v
Store lookup
   |
   +---- Store exists → Continue
   |
   +---- Store missing → Error
```

This prevents operations from referencing nonexistent stores.

---

# 22. Store Ownership Validation

Store owners must not be able to modify arbitrary stores.

Conceptually:

```text
Authenticated Store Owner
          |
          v
Requested Store
          |
          v
Ownership Check
       /     \
    Owner   Not Owner
      |         |
   Continue    Reject
```

The authenticated user's identity must be associated with the store being modified.

This is a business authorization rule.

---

# 23. Product Validation

Product operations must validate information such as:

```text
Product identity
Product name
Price
Quantity
Store association
Availability
```

A product must belong to a valid store.

Conceptually:

```text
Product
   |
   v
Store
   |
   +---- Exists → Continue
   |
   +---- Missing → Reject
```

---

# 24. Product Price Validation

Product prices should represent valid monetary values.

A negative product price should not be accepted.

```text
Price
  |
  +---- valid positive value → Continue
  |
  +---- negative / invalid → Reject
```

Payment and order calculations must use trusted backend values rather than prices supplied by the client.

---

# 25. Cart Validation

The cart belongs to a customer.

Therefore:

```text
Authenticated User
       |
       v
Customer Cart
```

The backend must ensure that the cart being accessed belongs to the authenticated customer.

A customer should not be able to manipulate another customer's cart by changing an ID in the request.

---

# 26. Cart Item Validation

When adding a product to the cart, the backend needs to validate:

```text
Product exists
Product belongs to a valid store
Quantity is valid
Customer exists
```

Conceptually:

```text
Add Cart Item
      |
      +---- Customer valid?
      |
      +---- Product valid?
      |
      +---- Quantity valid?
      |
      +---- Store valid?
      |
      v
Add item
```

---

# 27. Quantity Validation

Cart and order quantities must be meaningful.

For example:

```text
quantity = 0
quantity = -1
```

should not represent a normal purchasable quantity.

The backend should reject invalid quantities rather than relying solely on frontend controls.

---

# 28. Address Validation

LocalMart's `CustomerAddressService` validates address information.

Required information includes:

```text
Address line
City
State
PIN code
Latitude
Longitude
```

The service validates the Indian PIN format and geographic coordinates.

---

# 29. PIN Code Validation

The customer address service validates the PIN code using an Indian PIN-code pattern.

Conceptually:

```text
PIN
 |
 +---- Valid format → Continue
 |
 +---- Invalid format → Reject
```

This prevents malformed postal codes from being stored as valid customer addresses.

---

# 30. Coordinate Validation

Coordinates are validated using geographic boundaries.

Latitude must be within:

```text
-90 to +90
```

Longitude must be within:

```text
-180 to +180
```

Therefore:

```text
latitude = 91
```

is invalid.

Likewise:

```text
longitude = 181
```

is invalid.

The validation can be represented as:

```text
Coordinates
     |
     +---- Latitude: -90 ≤ lat ≤ 90
     |
     +---- Longitude: -180 ≤ lon ≤ 180
     |
     v
Valid location
```

---

# 31. Default Address Rule

Customers can have multiple addresses.

LocalMart supports a default-address concept.

When an address becomes the default:

```text
Address A
Address B
Address C
```

the application ensures that the default state is managed across the customer's addresses.

Conceptually:

```text
Before:
A → Default
B → Normal
C → Normal

Set B as default:

A → Normal
B → Default
C → Normal
```

This prevents multiple addresses from unintentionally remaining marked as the default.

---

# 32. Address Ownership Rule

An address belongs to a customer.

Therefore:

```text
Customer A
   |
   +---- Address 1
   +---- Address 2

Customer B
   |
   +---- Address 3
```

Customer A must not be able to update or delete Address 3.

The backend must validate ownership.

This is especially important because IDs can be manually changed in HTTP requests.

---

# 33. Address Deletion Rule

When a default address is deleted, LocalMart's address service selects another remaining address as the default when appropriate.

Conceptually:

```text
A → Default
B → Normal
C → Normal

Delete A

B → Default
C → Normal
```

This keeps the customer's address state consistent.

---

# 34. Order Validation

Order creation is subject to multiple business rules.

Before creating an order, the backend needs to validate relevant information such as:

```text
Customer
Store
Address
Cart
Products
Quantities
Prices
Order state
Payment requirements
```

Conceptually:

```text
Checkout
   |
   +---- Customer valid?
   |
   +---- Store valid?
   |
   +---- Address valid?
   |
   +---- Cart valid?
   |
   +---- Items valid?
   |
   v
Create Order
```

---

# 35. Customer Ownership During Checkout

The authenticated customer must be the owner of the cart and the relevant address.

```text
JWT User ID
     |
     +---- Cart owner?
     |
     +---- Address owner?
     |
     v
Checkout allowed
```

This prevents users from using another customer's resources.

---

# 36. Store Consistency Rule

LocalMart is designed around store-based shopping.

Therefore order items must be consistent with the selected store.

Conceptually:

```text
Selected Store
      |
      v
Cart Items
      |
      +---- Product belongs to selected store → valid
      |
      +---- Product belongs to another store → invalid
```

This prevents an order from incorrectly combining products from unrelated stores when the application's business model expects one store per order.

---

# 37. Delivery Fee Validation

The delivery-fee calculation uses information such as:

```text
Store
Customer Address
Store Coordinates
Customer Coordinates
```

The backend validates that the referenced store and address are valid before performing the calculation.

Conceptually:

```text
storeId + addressId
        |
        v
Validate resources
        |
        v
Obtain coordinates
        |
        v
RoadDistanceService
        |
        v
Delivery fee calculation
```

---

# 38. Delivery Partner Validation

Delivery-partner operations must verify that the authenticated user is actually a delivery partner.

```text
Authenticated User
       |
       v
Role Check
       |
       +---- DELIVERY_PARTNER → Continue
       |
       +---- Other role → Reject
```

The same principle applies to other role-specific endpoints.

---

# 39. Delivery Order Ownership

A delivery partner should only be able to manipulate deliveries assigned to them or perform actions explicitly allowed by the delivery workflow.

Conceptually:

```text
Delivery Partner
       |
       v
Delivery
       |
       v
Ownership / Assignment Check
       |
   +---+---+
   |       |
Allowed  Not Allowed
   |       |
Continue  Reject
```

This prevents one delivery partner from modifying another partner's delivery.

---

# 40. Delivery Status Rules

LocalMart uses a defined delivery lifecycle:

```text
READY_FOR_PICKUP
        ↓
ACCEPTED
        ↓
PICKED_UP
        ↓
OUT_FOR_DELIVERY
        ↓
DELIVERED
```

The status represents the state of the delivery.

---

# 41. Delivery Status Transition Validation

A delivery should not arbitrarily jump between states.

For example:

```text
READY_FOR_PICKUP
        ↓
ACCEPTED
```

is a valid transition in the defined workflow.

But:

```text
READY_FOR_PICKUP
        ↓
DELIVERED
```

would bypass intermediate states and should not be treated as a normal transition unless explicitly supported by the application.

The general rule is:

```text
Current State
      +
Requested Action
      |
      v
Transition validation
      |
      +---- Allowed → Update state
      |
      +---- Not allowed → Reject
```

---

# 42. Delivery Acceptance

When a delivery partner accepts a delivery, the backend must ensure that the delivery is still available for acceptance.

Conceptually:

```text
Delivery = READY_FOR_PICKUP
        |
        v
Partner accepts
        |
        v
Validate current state
        |
   +----+----+
   |         |
Available   Already accepted
   |             |
   v             v
Accept         Reject
```

This is important because multiple delivery partners could potentially attempt to accept the same delivery.

Concurrency control is therefore an important consideration for this operation.

---

# 43. Order Status Rules

Order status and delivery status are related but conceptually separate.

For example:

```text
Order
   |
   +---- Order lifecycle
   |
   v
Delivery
   |
   +---- Delivery lifecycle
```

The order represents the customer's purchase.

The delivery represents the physical delivery process.

---

# 44. Payment Validation

Payment-related operations must validate information such as:

```text
Order association
Payment amount
Payment status
Payment provider result
```

The server should not simply trust a payment amount supplied by the frontend.

For example:

```text
Frontend says:
amount = ₹10

Backend calculates:
amount = ₹750
```

The trusted amount should come from the server-side order/cart calculation.

---

# 45. Payment State

A payment should be associated with the correct order.

Conceptually:

```text
Payment
   |
   v
Order
```

The application should prevent payment information from being attached to an unrelated order.

---

# 46. External Authentication Validation

External login introduces another validation boundary.

For Google:

```text
Credential
    |
    v
Google token verification
    |
    +---- Invalid → Reject
    |
    +---- Valid → Continue
```

For X:

```text
External authentication data
    |
    v
X authentication service
    |
    +---- Invalid → Reject
    |
    +---- Valid → Continue
```

LocalMart should not trust an external identity solely because the frontend claims it is valid.

---

# 47. Session Validation

LocalMart maintains user sessions associated with JWT authentication.

The general process is:

```text
JWT
 |
 v
Validate token
 |
 v
Extract session information
 |
 v
Validate session
 |
 v
Authenticated request
```

A valid-looking token should not automatically grant access if the application's session rules indicate that the session is no longer valid.

---

# 48. Account Status Validation During Login

Credentials alone are not sufficient.

The login process also checks account status.

Conceptually:

```text
Credentials
     |
     v
User found
     |
     v
Account status
     |
 +---+---+---+
 |       |   |
ACTIVE BLOCKED INACTIVE
 |       |      |
 v       v      v
Login   Reject  Check application
```

This is a business rule in addition to credential verification.

---

# 49. Admin Validation

The ADMIN role has privileged access.

Administrative operations should therefore validate:

```text
Authenticated user
       |
       v
ADMIN role
       |
       +---- Yes → Continue
       |
       +---- No → Reject
```

Admin approval operations must not be exposed to ordinary customers or other roles.

---

# 50. Role-Based Access Rules

LocalMart's major role boundaries are:

| Role             | Primary responsibilities                  |
| ---------------- | ----------------------------------------- |
| CUSTOMER         | Shopping, cart, addresses, orders         |
| STORE_OWNER      | Store/product/order management            |
| DELIVERY_PARTNER | Delivery and delivery location operations |
| ADMIN            | Administrative management and approvals   |

The actual authorization is enforced server-side through the application's security configuration and service-level business checks.

---

# 51. ID Validation

Client requests frequently contain IDs:

```text
userId
storeId
productId
addressId
orderId
cartItemId
```

The backend should never assume that an ID supplied by the client is valid.

The general process is:

```text
ID
 |
 v
Repository lookup
 |
 +---- Found → Continue
 |
 +---- Missing → Error
```

Then, where required:

```text
Found resource
      |
      v
Ownership / authorization check
      |
      v
Continue
```

---

# 52. Validation Is Not Just "Checking the Database"

A resource can exist and still be invalid for the requested operation.

For example:

```text
Order 100 exists.
```

does not necessarily mean:

```text
Customer 5 can modify Order 100.
```

There are two separate questions:

```text
1. Does the resource exist?
2. Is this user allowed to operate on it?
```

Both may need to be checked.

---

# 53. Validation Order

A useful validation sequence is:

```text
Request received
      |
      v
Basic input validation
      |
      v
Authentication
      |
      v
Authorization
      |
      v
Resource existence
      |
      v
Ownership
      |
      v
Business rules
      |
      v
Database operation
```

The exact execution order depends on the endpoint and Spring Security configuration, but this provides the conceptual model.

---

# 54. Database Constraints as Final Protection

Application-level validation is not the only protection.

PostgreSQL constraints can provide an additional integrity boundary.

Conceptually:

```text
Application Validation
        |
        v
JPA / Hibernate
        |
        v
PostgreSQL Constraints
        |
        v
Persistent Data
```

Database constraints can protect against invalid state even if application code contains an unexpected path.

---

# 55. `ddl-auto=validate`

LocalMart is configured with:

```text
spring.jpa.hibernate.ddl-auto=validate
```

This means Hibernate validates the existing database schema against the entity mapping rather than automatically modifying the schema.

This is important because database structure is treated as something that must remain consistent with the application mappings.

---

# 56. Validation and DTOs

LocalMart uses DTOs to represent API input and output.

Examples include:

```text
UserRegistrationRequest
LoginOtpRequest
VerifyOtpRequest
CustomerAddressRequest
AddCartItemRequest
CreateOrderRequest
DeliveryFeeRequest
```

DTOs provide a boundary between:

```text
HTTP JSON
    |
    v
Application data
```

They prevent controllers from directly treating arbitrary request JSON as persistent entities.

---

# 57. DTO Validation Flow

The conceptual flow is:

```text
JSON
 |
 v
Jackson
 |
 v
DTO
 |
 v
Validation
 |
 v
Service
 |
 v
Entity
```

This separation allows API input to be validated before it becomes persistent domain data.

---

# 58. Business Rules vs Validation Rules

These terms are related but not identical.

### Validation rule

```text
Latitude must be between -90 and 90.
```

### Business rule

```text
A customer can only modify their own address.
```

### Validation rule

```text
Quantity must be positive.
```

### Business rule

```text
A product must belong to the store associated with the order.
```

This distinction is useful when designing services.

---

# 59. Error Handling Integration

When validation fails, the error is passed into LocalMart's error-handling architecture.

Conceptually:

```text
Invalid Input / Business Rule
          |
          v
Exception
          |
          v
GlobalExceptionHandler
          |
          v
HTTP Error Response
          |
          v
Frontend
```

The detailed exception-to-status mapping is documented in:

```text
17-error-handling.md
```

---

# 60. Validation Security Principles

Validation also contributes to application security.

Important principles include:

### Never trust the client

```text
Frontend ≠ trusted authority
```

### Validate ownership

```text
ID exists ≠ user can access it
```

### Validate server-side prices

```text
Client amount ≠ trusted amount
```

### Validate authentication

```text
Credential supplied ≠ identity verified
```

### Validate account status

```text
Valid password ≠ automatically allowed login
```

### Validate state transitions

```text
Current state + action → permitted transition
```

---

# 61. Validation and External Services

External services also require validation.

For example, before using a location service:

```text
Latitude
Longitude
   |
   v
Validate coordinate ranges
   |
   v
External routing/geocoding service
```

Similarly, before accepting an external authentication credential:

```text
External credential
       |
       v
Verification
       |
       v
LocalMart identity
```

LocalMart should not blindly pass or accept arbitrary external data.

---

# 62. Validation and Concurrency

Some business rules depend on the current state of the database.

Delivery acceptance is an example.

Two users could theoretically send:

```text
Accept Delivery 101
```

at nearly the same time.

Both requests could initially observe:

```text
READY_FOR_PICKUP
```

Therefore checking the state and updating it must be designed carefully to avoid two users successfully claiming the same delivery.

Conceptually:

```text
Partner A ──┐
             ├──> Delivery 101
Partner B ──┘

          Concurrent requests
                 |
                 v
        State / concurrency control
```

This is a business-integrity concern rather than simple input validation.

---

# 63. Validation Checklist

Before accepting an important operation, LocalMart should conceptually verify:

```text
[ ] Request structure is valid
[ ] Required fields exist
[ ] Data formats are valid
[ ] User is authenticated
[ ] User has required role
[ ] Resource exists
[ ] Resource belongs to the user when required
[ ] Account status permits operation
[ ] Business state permits operation
[ ] Related resources are consistent
[ ] External response is valid
[ ] Database constraints are satisfied
```

Not every endpoint requires every check, but the applicable rules must be enforced at the backend.

---

# 64. Validation Architecture Summary

The complete validation architecture is:

```text
                         Client
                           |
                           v
                    Frontend Validation
                           |
                           v
                       HTTP JSON
                           |
                           v
                         DTO
                           |
                           v
                  Backend Input Validation
                           |
                           v
                     Authentication
                           |
                           v
                     Authorization
                           |
                           v
                  Resource Validation
                           |
                           v
                  Business Rule Validation
                           |
                           v
                  External Service Calls
                           |
                           v
                       Repository
                           |
                           v
                       PostgreSQL
                           |
                           v
                   Persistent State
```

---

# 65. Core LocalMart Business Rules

The most important application rules can be summarized as follows:

| Area             | Rule                                                              |
| ---------------- | ----------------------------------------------------------------- |
| Registration     | Required identity and registration data must be valid             |
| Registration     | Duplicate identifiers must be rejected                            |
| Registration     | Admin cannot be created through ordinary registration             |
| OTP              | OTP must be valid and within its validity period                  |
| Account          | Blocked accounts cannot authenticate normally                     |
| Store Owner      | Store-owner registration requires application/approval flow       |
| Delivery Partner | Delivery-partner registration requires application/approval flow  |
| Customer         | Customer resources must belong to the authenticated customer      |
| Address          | Address requires valid geographic coordinates                     |
| Address          | Only one appropriate default address should be maintained         |
| Store            | Store must exist before store-dependent operations                |
| Product          | Product must be associated with a valid store                     |
| Cart             | Cart belongs to a customer                                        |
| Cart             | Product and quantity must be valid                                |
| Order            | Order resources must belong to the correct customer/store context |
| Payment          | Payment must correspond to the appropriate order                  |
| Delivery         | Delivery operations require the delivery-partner role             |
| Delivery         | Delivery status must follow the defined lifecycle                 |
| Delivery         | Delivery acceptance must account for concurrent claims            |
| Admin            | Administrative operations require appropriate authorization       |

---

# 66. Final Principle

Validation is not a single `if` statement or a frontend form feature.

In LocalMart, validation is a layered process:

```text
Input correctness
       ↓
Authentication
       ↓
Authorization
       ↓
Resource ownership
       ↓
Business-state validation
       ↓
External-service validation
       ↓
Database integrity
```

The fundamental principle is:

> **LocalMart should never rely on the client to enforce a rule that affects security, data integrity, money, ownership, or business state.**

Frontend validation helps users enter correct data, while backend validation is the authoritative boundary that protects the application.
