
        package com.localmart.localmartbackend.controller;

import com.localmart.localmartbackend.dto.LocationSearchRequest;
import com.localmart.localmartbackend.dto.LocationSearchResponse;
import com.localmart.localmartbackend.service.GeocodingService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/location")
@CrossOrigin(origins = "http://localhost:5175")
public class LocationController {

    private final GeocodingService geocodingService;

    public LocationController(
            GeocodingService geocodingService
    ) {
        this.geocodingService = geocodingService;
    }

    @PostMapping("/search")
    public ResponseEntity<LocationSearchResponse> searchLocation(
            @RequestBody LocationSearchRequest request
    ) {

        if (request == null) {
            throw new RuntimeException(
                    "Location search request cannot be empty."
            );
        }

        if (isBlank(request.getAddressLine())
                || isBlank(request.getCity())
                || isBlank(request.getState())
                || isBlank(request.getPincode())) {

            throw new RuntimeException(
                    "Complete address is required to find the location."
            );
        }

        GeocodingService.Coordinates coordinates =
                geocodingService.geocode(
                        request.getAddressLine().trim(),
                        request.getCity().trim(),
                        request.getState().trim(),
                        request.getPincode().trim()
                );

        LocationSearchResponse response =
                new LocationSearchResponse(
                        coordinates.latitude(),
                        coordinates.longitude()
                );

        return ResponseEntity.ok(response);
    }

    private boolean isBlank(String value) {

        return value == null
                || value.trim().isEmpty();
    }
}
