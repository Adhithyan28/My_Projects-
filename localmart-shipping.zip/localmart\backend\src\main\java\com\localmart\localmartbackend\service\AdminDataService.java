
        package com.localmart.localmartbackend.service;

import com.localmart.localmartbackend.entity.DeliveryPartner;
import com.localmart.localmartbackend.entity.Role;
import com.localmart.localmartbackend.entity.User;
import com.localmart.localmartbackend.entity.VehicleDetails;
import com.localmart.localmartbackend.repository.DeliveryPartnerRepository;
import com.localmart.localmartbackend.repository.RoleRepository;
import com.localmart.localmartbackend.repository.UserRepository;
import com.localmart.localmartbackend.repository.VehicleDetailsRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AdminDataService {

    private static final int ROLE_CUSTOMER = 1;
    private static final int ROLE_STORE_OWNER = 2;
    private static final int ROLE_DELIVERY_PARTNER = 3;

    private static final int ACCOUNT_ACTIVE = 1;
    private static final int ACCOUNT_BLOCKED = 3;

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final DeliveryPartnerRepository deliveryPartnerRepository;
    private final VehicleDetailsRepository vehicleDetailsRepository;

    public AdminDataService(
            UserRepository userRepository,
            RoleRepository roleRepository,
            DeliveryPartnerRepository deliveryPartnerRepository,
            VehicleDetailsRepository vehicleDetailsRepository
    ) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.deliveryPartnerRepository = deliveryPartnerRepository;
        this.vehicleDetailsRepository = vehicleDetailsRepository;
    }

    /* =====================================================
       CUSTOMERS
       ===================================================== */

    public List<User> getCustomers() {

        List<User> allUsers =
                userRepository.findAll();

        List<User> customers =
                new ArrayList<>();

        for (User user : allUsers) {

            Role role =
                    roleRepository.findByUserId(user.getUserId())
                            .orElse(null);

            if (role != null
                    && role.getRole() == ROLE_CUSTOMER) {

                customers.add(user);
            }
        }

        return customers;
    }


    /* =====================================================
       DELIVERY PARTNERS
       ===================================================== */

    public List<DeliveryPartner> getDeliveryPartners() {

        return deliveryPartnerRepository.findAll();
    }


    public List<User> getDeliveryPartnerUsers() {

        List<User> allUsers =
                userRepository.findAll();

        List<User> deliveryPartners =
                new ArrayList<>();

        for (User user : allUsers) {

            Role role =
                    roleRepository.findByUserId(user.getUserId())
                            .orElse(null);

            if (role != null
                    && role.getRole() == ROLE_DELIVERY_PARTNER) {

                deliveryPartners.add(user);
            }
        }

        return deliveryPartners;
    }


    /* =====================================================
       VEHICLE
       ===================================================== */

    public VehicleDetails getVehicle(Long vehicleId) {

        return vehicleDetailsRepository
                .findById(vehicleId)
                .orElse(null);
    }


    /* =====================================================
       BLOCK / UNBLOCK USER
       ===================================================== */

    public User updateUserAccountStatus(
            Long userId,
            Integer accountStatus
    ) {

        User user =
                userRepository.findById(userId)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "User not found"
                                )
                        );

        Role role =
                roleRepository.findByUserId(userId)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "User role not found"
                                )
                        );

        /*
         * Admin can manage:
         *
         * 1 = Customer
         * 2 = Store Owner
         * 3 = Delivery Partner
         *
         * Admin itself cannot be blocked through this method.
         */

        if (role.getRole() != ROLE_CUSTOMER
                && role.getRole() != ROLE_STORE_OWNER
                && role.getRole() != ROLE_DELIVERY_PARTNER) {

            throw new RuntimeException(
                    "This user type cannot be blocked or unblocked"
            );
        }

        if (accountStatus != ACCOUNT_ACTIVE
                && accountStatus != ACCOUNT_BLOCKED) {

            throw new RuntimeException(
                    "Invalid account status"
            );
        }

        user.setAccountStatus(accountStatus);

        return userRepository.save(user);
    }
    public Integer getUserAccountStatus(Long userId) {

        User user =
                userRepository.findById(userId)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "User not found"
                                )
                        );

        return user.getAccountStatus();
    }
}

