
import { useEffect, useState } from "react"
import { useAuth } from "../context/AuthContext"

interface Category {
    id: number
    name: string
    description: string
    icon: string
    productCount: number
}

interface Product {
    productId: number
    productName: string
    category: string
    description: string
    price: number
    unit: string
    stockQuantity: number
    icon: string
    isAvailable: boolean
    storeId: number
}

interface CategoriesProps {
    onHome: () => void
    onStores: () => void
    onCart: () => void
    onProducts: () => void
    onOrders: () => void
    onCategoryClick: (category: Category) => void
}


/* ==========================================
 * CATEGORY PRESENTATION
 *
 * Category name/count come from DB.
 * These are only UI descriptions/icons.
 * ========================================== */

const categoryPresentation: Record<
    string,
    {
        description: string
        icon: string
    }
> = {
    groceries: {
        description:
            "Fresh groceries and daily essentials",
        icon: "🛒",
    },

    "fruits & vegetables": {
        description:
            "Fresh fruits and vegetables",
        icon: "🥦",
    },

    "dairy & eggs": {
        description:
            "Milk, eggs, cheese and dairy products",
        icon: "🥛",
    },

    bakery: {
        description:
            "Bread, cakes and freshly baked items",
        icon: "🍞",
    },

    beverages: {
        description:
            "Drinks, juices and refreshments",
        icon: "🥤",
    },

    snacks: {
        description:
            "Chips, biscuits and quick snacks",
        icon: "🍿",
    },

    "personal care": {
        description:
            "Personal care and hygiene products",
        icon: "🧴",
    },

    household: {
        description:
            "Cleaning and household essentials",
        icon: "🏠",
    },
}


/* ==========================================
 * FALLBACK PRESENTATION
 * ========================================== */

const getCategoryPresentation = (
    categoryName: string
) => {

    const presentation =
        categoryPresentation[
            categoryName.toLowerCase()
        ]

    if (presentation) {
        return presentation
    }

    return {
        description:
            `Explore ${categoryName} products from local stores`,
        icon: "🛍️",
    }
}


function Categories({
    onHome,
    onStores,
    onCart,
    onProducts,
    onOrders,
    onCategoryClick,
}: CategoriesProps) {

    const { user, logout } = useAuth()

    const [categories, setCategories] =
        useState<Category[]>([])

    const [search, setSearch] =
        useState("")

    const [loading, setLoading] =
        useState(true)

    const [error, setError] =
        useState("")


    /* ==========================================
     * LOAD CATEGORIES FROM PRODUCTS
     * ========================================== */

    useEffect(() => {

        const loadCategories = async () => {

            if (!user?.token) {

                setError(
                    "Please login to view categories."
                )

                setLoading(false)

                return
            }

            try {

                setLoading(true)
                setError("")

                const response =
                    await fetch(
                        "/api/products",
                        {
                            method: "GET",
                            headers: {
                                Authorization:
                                    `Bearer ${user.token}`,
                            },
                        }
                    )

                if (!response.ok) {

                    if (
                        response.status === 401
                    ) {

                        throw new Error(
                            "Your session has expired. Please login again."
                        )
                    }

                    throw new Error(
                        "Unable to load categories."
                    )
                }

                const products: Product[] =
                    await response.json()


                /* ==================================
                 * GROUP PRODUCTS BY CATEGORY
                 * ================================== */

                const categoryMap =
                    new Map<
                        string,
                        number
                    >()


                products.forEach(
                    (product) => {

                        if (
                            !product.category ||
                            product.category.trim() === ""
                        ) {
                            return
                        }

                        const categoryName =
                            product.category.trim()

                        const categoryKey =
                            categoryName.toLowerCase()

                        categoryMap.set(
                            categoryKey,
                            (
                                categoryMap.get(
                                    categoryKey
                                ) || 0
                            ) + 1
                        )
                    }
                )


                /* ==================================
                 * CREATE CATEGORY OBJECTS
                 * ================================== */

                const dbCategories: Category[] =
                    Array.from(
                        categoryMap.entries()
                    )
                        .sort(
                            (
                                [, countA],
                                [, countB]
                            ) =>
                                countB - countA
                        )
                        .map(
                            (
                                [
                                    categoryKey,
                                    productCount,
                                ],
                                index
                            ) => {

                                /*
                                 * Find the original
                                 * category casing from
                                 * the products.
                                 */

                                const originalProduct =
                                    products.find(
                                        (product) =>
                                            product.category
                                                ?.trim()
                                                .toLowerCase() ===
                                            categoryKey
                                    )

                                const categoryName =
                                    originalProduct
                                        ?.category
                                        ?.trim() ||
                                    categoryKey

                                const presentation =
                                    getCategoryPresentation(
                                        categoryName
                                    )

                                return {
                                    id: index + 1,
                                    name: categoryName,
                                    description:
                                        presentation.description,
                                    icon:
                                        presentation.icon,
                                    productCount,
                                }
                            }
                        )


                setCategories(
                    dbCategories
                )

            } catch (err) {

                console.error(
                    "Failed to load categories:",
                    err
                )

                setError(
                    err instanceof Error
                        ? err.message
                        : "Unable to load categories."
                )

            } finally {

                setLoading(false)

            }
        }


        loadCategories()

    }, [user?.token])


    /* ==========================================
     * SEARCH
     * ========================================== */

    const filteredCategories =
        categories.filter(
            (category) =>
                category.name
                    .toLowerCase()
                    .includes(
                        search.toLowerCase()
                    )
        )


    return (
        <div className="customer-dashboard">

            {/* =================================================
                HEADER
            ================================================= */}

            <header className="customer-header">

                <div
                    className="customer-logo"
                    onClick={onHome}
                    role="button"
                    tabIndex={0}
                    onKeyDown={(e) => {

                        if (e.key === "Enter") {
                            onHome()
                        }

                    }}
                >
                    Local<span>Mart</span>
                </div>


                {/* SEARCH */}

                <div className="customer-search">

                    <span>🔍</span>

                    <input
                        type="text"
                        placeholder="Search categories..."
                        value={search}
                        onChange={(e) =>
                            setSearch(
                                e.target.value
                            )
                        }
                    />

                </div>


                {/* HEADER ACTIONS */}

                <div className="customer-header-actions">

                    <button
                        className="header-icon-button"
                        title="Cart"
                        type="button"
                        onClick={onCart}
                    >
                        🛒
                    </button>


                    <div className="customer-profile">

                        <div className="profile-avatar">

                            {user?.email
                                ?.charAt(0)
                                .toUpperCase() ||
                                "👤"}

                        </div>

                        <div className="profile-info">

                            <span>
                                Hello
                            </span>

                            <strong>
                                {user?.email ||
                                    "Customer"}
                            </strong>

                        </div>

                    </div>


                    <button
                        className="customer-logout"
                        type="button"
                        onClick={logout}
                    >
                        Logout
                    </button>

                </div>

            </header>


            {/* =================================================
                NAVIGATION
            ================================================= */}

            <nav className="customer-navigation">

                <div className="navigation-inner">

                    <button
                        type="button"
                        onClick={onHome}
                    >
                        Home
                    </button>

                    <button
                        type="button"
                        onClick={onStores}
                    >
                        Stores
                    </button>

                    <button
                        type="button"
                        className="nav-active"
                    >
                        Categories
                    </button>

                    <button
                        type="button"
                        onClick={onProducts}
                    >
                        Products
                    </button>

                    <button
                        type="button"
                        onClick={onOrders}
                    >
                        Orders
                    </button>

                </div>

            </nav>


            {/* =================================================
                MAIN CONTENT
            ================================================= */}

            <main className="customer-main">

                {/* PAGE HEADING */}

                <section className="page-heading">

                    <div>

                        <p className="section-eyebrow">
                            EXPLORE LOCALMART
                        </p>

                        <h1>
                            Shop by Category
                        </h1>

                        <p>
                            Find exactly what you need
                            from stores around you.
                        </p>

                    </div>

                </section>


                {/* CATEGORY SEARCH */}

                <section className="category-search-section">

                    <div className="category-search-box">

                        <span>
                            🔍
                        </span>

                        <input
                            type="text"
                            placeholder="Search for a category..."
                            value={search}
                            onChange={(e) =>
                                setSearch(
                                    e.target.value
                                )
                            }
                        />

                    </div>

                </section>


                {/* CATEGORIES */}

                <section className="categories-section">

                    <div className="section-title-row">

                        <div>

                            <h2>
                                Categories
                            </h2>

                            <p>

                                {loading
                                    ? "Loading categories..."
                                    : `${filteredCategories.length} ${
    filteredCategories.length === 1
        ? "category"
        : "categories"
} available`
                                }

                            </p>

                        </div>

                    </div>


                    {/* ==========================================
                     * LOADING
                     * ========================================== */}

                    {loading ? (

                        <div className="empty-state">

                            <div className="empty-icon">
                                🛍️
                            </div>

                            <h3>
                                Loading categories...
                            </h3>

                            <p>
                                Getting categories
                                from LocalMart.
                            </p>

                        </div>

                    ) : error ? (

                        /* ==========================================
                         * ERROR
                         * ========================================== */

                        <div className="empty-state">

                            <div className="empty-icon">
                                ⚠️
                            </div>

                            <h3>
                                Unable to load categories
                            </h3>

                            <p>
                                {error}
                            </p>

                            <button
                                type="button"
                                onClick={() =>
                                    window.location.reload()
                                }
                            >
                                Try Again
                            </button>

                        </div>

                    ) : filteredCategories.length === 0 ? (

                        /* ==========================================
                         * NO CATEGORIES
                         * ========================================== */

                        <div className="empty-state">

                            <div className="empty-icon">
                                🔍
                            </div>

                            <h3>
                                No categories found
                            </h3>

                            <p>
                                {categories.length === 0
                                    ? "There are no products with categories available yet."
                                    : "Try searching with a different category name."
                                }
                            </p>

                        </div>

                    ) : (

                        /* ==========================================
                         * CATEGORY GRID
                         * ========================================== */

                        <div className="categories-grid">

                            {filteredCategories.map(
                                (category) => (

                                    <button
                                        key={category.id}
                                        type="button"
                                        className="category-card"
                                        onClick={() =>
                                            onCategoryClick(
                                                category
                                            )
                                        }
                                    >

                                        <div className="category-icon">
                                            {category.icon}
                                        </div>


                                        <div className="category-details">

                                            <h3>
                                                {category.name}
                                            </h3>

                                            <p>
                                                {
                                                    category.description
                                                }
                                            </p>

                                            <span>
                                                {
                                                    category.productCount
                                                }{" "}
                                                {
                                                    category.productCount === 1
                                                        ? "product"
                                                        : "products"
                                                }
                                            </span>

                                        </div>


                                        <div className="category-arrow">
                                            →
                                        </div>

                                    </button>

                                )
                            )}

                        </div>

                    )}

                </section>

            </main>


            {/* =================================================
                FOOTER
            ================================================= */}

            <footer className="customer-footer">

                <div className="footer-content">

                    <div className="footer-brand">

                        <strong className="customer-logo">
                            Local<span>Mart</span>
                        </strong>

                        <p>
                            Your local marketplace
                        </p>

                    </div>


                    <div className="footer-links">

                        <button
                            type="button"
                            onClick={onHome}
                        >
                            Home
                        </button>

                        <button
                            type="button"
                            onClick={onStores}
                        >
                            Stores
                        </button>

                        <button
                            type="button"
                        >
                            Categories
                        </button>

                        <button
                            type="button"
                            onClick={onProducts}
                        >
                            Products
                        </button>

                        <button
                            type="button"
                            onClick={onOrders}
                        >
                            Orders
                        </button>

                        <button
                            type="button"
                            onClick={onCart}
                        >
                            Cart
                        </button>

                    </div>

                </div>

            </footer>

        </div>
    )
}

export default Categories
