package com.localmart.localmartbackend.service;

import com.localmart.localmartbackend.dto.AdminLoginOtpRequest;
import com.localmart.localmartbackend.dto.AdminVerifyOtpRequest;
import com.localmart.localmartbackend.dto.LoginRequest;
import com.localmart.localmartbackend.dto.UserResponse;
import com.localmart.localmartbackend.entity.Role;
import com.localmart.localmartbackend.entity.User;
import com.localmart.localmartbackend.entity.UserSession;
import com.localmart.localmartbackend.repository.RoleRepository;
import com.localmart.localmartbackend.repository.UserRepository;
import com.localmart.localmartbackend.security.JwtService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class AdminService {

    private static final int ROLE_ADMIN = 4;
    private static final int ACCOUNT_ACTIVE = 1;

    private static final int OTP_EXPIRY_MINUTES = 5;

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final OtpService otpService;
    private final MessageCentralOtpService messageCentralOtpService;
    private final UserSessionService userSessionService;

    /*
     * Stores pending Message Central verification IDs
     * for Admin mobile login.
     *
     * Key:
     * normalized phone + channel
     *
     * Value:
     * verification ID + expiry
     */
    private final Map<String, MobileOtpData> mobileOtpStore =
            new ConcurrentHashMap<>();

    public AdminService(
            UserRepository userRepository,
            RoleRepository roleRepository,
            PasswordEncoder passwordEncoder,
            JwtService jwtService,
            OtpService otpService,
            MessageCentralOtpService messageCentralOtpService,
            UserSessionService userSessionService) {

        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
        this.otpService = otpService;
        this.messageCentralOtpService =
                messageCentralOtpService;
        this.userSessionService = userSessionService;
    }

    /*
     * Existing direct Admin login method.
     *
     * Kept so existing Admin functionality is not
     * unnecessarily removed.
     */
    public UserResponse loginAdmin(LoginRequest request) {

        if (request == null
                || request.getEmail() == null
                || request.getEmail().isBlank()
                || request.getPassword() == null
                || request.getPassword().isBlank()) {

            throw new RuntimeException(
                    "Email and password are required"
            );
        }

        User user = userRepository
                .findByEmail(request.getEmail().trim())
                .orElseThrow(() ->
                        new RuntimeException(
                                "Invalid email or password"
                        )
                );

        validateAdminCredentials(user, request.getPassword());

        Role role = getUserRole(user.getUserId());

        return createUserResponse(
                user,
                role
        );
    }

    /*
     * ADMIN LOGIN - STEP 1
     *
     * Email:
     *     Email + password
     *          ↓
     *     Email OTP
     *
     * Mobile:
     *     Mobile + password
     *          ↓
     *     SMS / WhatsApp OTP
     */
    public String sendAdminLoginOtp(
            AdminLoginOtpRequest request) {

        if (request == null
                || request.getIdentifier() == null
                || request.getIdentifier().isBlank()
                || request.getPassword() == null
                || request.getPassword().isBlank()) {

            throw new RuntimeException(
                    "Identifier and password are required"
            );
        }

        String identifier =
                request.getIdentifier().trim();

        String channel =
                request.getChannel() == null
                        ? ""
                        : request.getChannel()
                        .trim()
                        .toUpperCase();

        User user =
                findAdminUser(identifier);

        validateAdminCredentials(
                user,
                request.getPassword()
        );

        /*
         * EMAIL OTP
         */
        if (isEmail(identifier)) {

            if (!"EMAIL".equals(channel)) {
                throw new RuntimeException(
                        "Email login must use EMAIL OTP"
                );
            }

            otpService.sendEmailOtp(
                    user.getEmail()
            );

            return "OTP sent successfully to admin email";
        }

        /*
         * MOBILE OTP
         */
        String phone =
                normalizePhone(identifier);

        if (phone == null) {
            throw new RuntimeException(
                    "Enter a valid admin email or mobile number"
            );
        }

        /*
         * Make sure the requested channel is valid.
         */
        if (!"SMS".equals(channel)
                && !"WHATSAPP".equals(channel)) {

            throw new RuntimeException(
                    "For mobile login, select SMS or WhatsApp"
            );
        }

        /*
         * Make sure the phone belongs to this Admin.
         */
        if (!phone.equals(
                normalizePhone(user.getPhone()))) {

            throw new RuntimeException(
                    "Admin mobile number not found"
            );
        }

        String verificationId;

        if ("SMS".equals(channel)) {

            verificationId =
                    messageCentralOtpService
                            .sendSmsOtp(phone);

        } else {

            verificationId =
                    messageCentralOtpService
                            .sendWhatsAppOtp(phone);
        }

        String key =
                buildMobileOtpKey(
                        phone,
                        channel
                );

        mobileOtpStore.put(
                key,
                new MobileOtpData(
                        verificationId,
                        LocalDateTime.now()
                                .plusMinutes(
                                        OTP_EXPIRY_MINUTES
                                )
                )
        );

        return "OTP sent successfully to admin mobile";
    }

    /*
     * ADMIN LOGIN - STEP 2
     *
     * Verify:
     *
     * EMAIL
     *     OtpService
     *
     * SMS / WHATSAPP
     *     Message Central verificationId
     *
     * Then:
     *     Create server session
     *     Generate JWT
     */
    public UserResponse verifyAdminLoginOtp(
            AdminVerifyOtpRequest request) {

        if (request == null
                || request.getIdentifier() == null
                || request.getIdentifier().isBlank()
                || request.getOtp() == null
                || request.getOtp().isBlank()) {

            throw new RuntimeException(
                    "Identifier and OTP are required"
            );
        }

        String identifier =
                request.getIdentifier().trim();

        String otp =
                request.getOtp().trim();

        String channel =
                request.getChannel() == null
                        ? ""
                        : request.getChannel()
                        .trim()
                        .toUpperCase();

        User user =
                findAdminUser(identifier);

        Role role =
                getUserRole(
                        user.getUserId()
                );

        if (!isAdmin(role)) {
            throw new RuntimeException(
                    "Access denied"
            );
        }

        if (!isActive(user)) {
            throw new RuntimeException(
                    "Admin account is not active"
            );
        }

        /*
         * EMAIL OTP
         */
        if (isEmail(identifier)) {

            if (!"EMAIL".equals(channel)) {
                throw new RuntimeException(
                        "Email login must use EMAIL OTP"
                );
            }

            otpService.verifyEmailOtp(
                    user.getEmail(),
                    otp
            );

            return createUserResponse(
                    user,
                    role
            );
        }

        /*
         * MOBILE OTP
         */
        String phone =
                normalizePhone(identifier);

        if (phone == null) {
            throw new RuntimeException(
                    "Enter a valid admin email or mobile number"
            );
        }

        if (!"SMS".equals(channel)
                && !"WHATSAPP".equals(channel)) {

            throw new RuntimeException(
                    "For mobile login, select SMS or WhatsApp"
            );
        }

        if (!phone.equals(
                normalizePhone(user.getPhone()))) {

            throw new RuntimeException(
                    "Admin mobile number not found"
            );
        }

        String key =
                buildMobileOtpKey(
                        phone,
                        channel
                );

        MobileOtpData otpData =
                mobileOtpStore.get(key);

        if (otpData == null) {

            throw new RuntimeException(
                    "No OTP found. Please request a new OTP"
            );
        }

        if (LocalDateTime.now()
                .isAfter(otpData.expiresAt())) {

            mobileOtpStore.remove(key);

            throw new RuntimeException(
                    "OTP has expired"
            );
        }

        boolean verified =
                messageCentralOtpService.verifyOtp(
                        otpData.verificationId(),
                        otp
                );

        if (!verified) {

            throw new RuntimeException(
                    "Invalid OTP"
            );
        }

        /*
         * OTP has been successfully consumed.
         */
        mobileOtpStore.remove(key);

        return createUserResponse(
                user,
                role
        );
    }

    /*
     * Finds a user using either:
     *
     * email
     * OR
     * mobile number
     */
    private User findAdminUser(
            String identifier) {

        if (isEmail(identifier)) {

            return userRepository
                    .findByEmail(
                            identifier.trim()
                    )
                    .orElseThrow(() ->
                            new RuntimeException(
                                    "Invalid email or password"
                            )
                    );
        }

        String phone =
                normalizePhone(identifier);

        if (phone == null) {

            throw new RuntimeException(
                    "Enter a valid admin email or mobile number"
            );
        }

        return userRepository
                .findByPhone(phone)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Invalid mobile number or password"
                        )
                );
    }

    /*
     * Validates:
     *
     * 1. Password
     * 2. Admin role
     * 3. Active account
     */
    private void validateAdminCredentials(
            User user,
            String password) {

        if (!passwordEncoder.matches(
                password,
                user.getPassword())) {

            throw new RuntimeException(
                    "Invalid email/mobile or password"
            );
        }

        Role role =
                getUserRole(
                        user.getUserId()
                );

        if (!isAdmin(role)) {

            throw new RuntimeException(
                    "Access denied"
            );
        }

        if (!isActive(user)) {

            throw new RuntimeException(
                    "Admin account is not active"
            );
        }
    }

    private Role getUserRole(Long userId) {

        return roleRepository
                .findByUserId(userId)
                .orElseThrow(() ->
                        new RuntimeException(
                                "User role not found"
                        )
                );
    }

    private boolean isAdmin(Role role) {

        return role.getRole() != null
                && role.getRole() == ROLE_ADMIN;
    }

    private boolean isActive(User user) {

        return user.getAccountStatus() != null
                && user.getAccountStatus()
                == ACCOUNT_ACTIVE;
    }

    private UserResponse createUserResponse(
            User user,
            Role role) {

        /*
         * IMPORTANT:
         *
         * We create the server-side session only
         * after successful OTP verification.
         *
         * Therefore failed password/OTP attempts
         * never create a login session.
         */
        UserSession session =
                userSessionService.createSession(
                        user.getUserId()
                );

        String roleName =
                roleName(role.getRole());

        String token =
                jwtService.generateToken(
                        user.getUserId(),
                        user.getEmail(),
                        roleName,
                        session.getSessionId()
                );

        UserResponse response =
                new UserResponse();

        response.setUserId(
                user.getUserId()
        );

        response.setEmail(
                user.getEmail()
        );

        response.setRole(
                roleName
        );

        response.setAccountStatus(
                accountStatusName(
                        user.getAccountStatus()
                )
        );

        response.setCreatedAt(
                user.getCreatedAt()
        );

        response.setUpdatedAt(
                user.getUpdatedAt()
        );

        response.setToken(token);

        return response;
    }

    private boolean isEmail(
            String identifier) {

        return identifier != null
                && identifier.contains("@");
    }

    /*
     * Converts:
     *
     * 9876543210
     * 919876543210
     * +919876543210
     *
     * into:
     *
     * 9876543210
     */
    private String normalizePhone(
            String phone) {

        if (phone == null) {
            return null;
        }

        String value =
                phone.trim()
                        .replaceAll(
                                "[\\s-]",
                                ""
                        );

        if (value.startsWith("+91")) {

            value =
                    value.substring(3);

        } else if (value.startsWith("91")
                && value.length() == 12) {

            value =
                    value.substring(2);
        }

        if (!value.matches(
                "^[6-9][0-9]{9}$"
        )) {

            return null;
        }

        return value;
    }

    private String buildMobileOtpKey(
            String phone,
            String channel) {

        return phone + ":" + channel;
    }

    private String roleName(Integer role) {

        if (role == null) {
            return "UNKNOWN";
        }

        return switch (role) {
            case 1 -> "CUSTOMER";
            case 2 -> "STORE_OWNER";
            case 3 -> "DELIVERY_PARTNER";
            case 4 -> "ADMIN";
            default -> "UNKNOWN";
        };
    }

    private String accountStatusName(
            Integer status) {

        if (status == null) {
            return "UNKNOWN";
        }

        return switch (status) {
            case 1 -> "ACTIVE";
            case 2 -> "INACTIVE";
            case 3 -> "BLOCKED";
            default -> "UNKNOWN";
        };
    }

    /*
     * Temporary data used only for Admin
     * SMS / WhatsApp login.
     */
    private record MobileOtpData(
            String verificationId,
            LocalDateTime expiresAt
    ) {
    }
}