package com.localmart.localmartbackend.service;

import com.localmart.localmartbackend.dto.UserResponse;
import com.localmart.localmartbackend.entity.ApplicationRequest;
import com.localmart.localmartbackend.entity.Role;
import com.localmart.localmartbackend.entity.User;
import com.localmart.localmartbackend.repository.ApplicationRequestRepository;
import com.localmart.localmartbackend.repository.RoleRepository;
import com.localmart.localmartbackend.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class AdminRequestService {

    /*
     * Application types
     */
    private static final int APPLICATION_STORE_OWNER = 1;
    private static final int APPLICATION_DELIVERY_PARTNER = 2;

    /*
     * Application statuses
     */
    private static final int STATUS_PENDING = 1;
    private static final int STATUS_APPROVED = 2;
    private static final int STATUS_REJECTED = 3;

    /*
     * Account statuses
     */
    private static final int ACCOUNT_ACTIVE = 1;
    private static final int ACCOUNT_INACTIVE = 2;

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final ApplicationRequestRepository applicationRequestRepository;

    public AdminRequestService(
            UserRepository userRepository,
            RoleRepository roleRepository,
            ApplicationRequestRepository applicationRequestRepository) {

        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.applicationRequestRepository =
                applicationRequestRepository;
    }

    /*
     * Get pending STORE_OWNER applications.
     */
    public List<UserResponse> getPendingStoreOwnerRequests() {

        List<ApplicationRequest> applications =
                applicationRequestRepository
                        .findByApplicationTypeAndApplicationStatus(
                                APPLICATION_STORE_OWNER,
                                STATUS_PENDING
                        );

        return applications.stream()
                .map(application ->
                        convertToResponse(
                                getUser(
                                        application.getUserId()
                                )
                        )
                )
                .toList();
    }

    /*
     * Get pending DELIVERY_PARTNER applications.
     */
    public List<UserResponse> getPendingDeliveryPartnerRequests() {

        List<ApplicationRequest> applications =
                applicationRequestRepository
                        .findByApplicationTypeAndApplicationStatus(
                                APPLICATION_DELIVERY_PARTNER,
                                STATUS_PENDING
                        );

        return applications.stream()
                .map(application ->
                        convertToResponse(
                                getUser(
                                        application.getUserId()
                                )
                        )
                )
                .toList();
    }

    /*
     * Approve an application.
     */
    public UserResponse approveRequest(Long userId) {

        ApplicationRequest application =
                getPendingApplication(userId);

        /*
         * Application becomes APPROVED.
         */
        application.setApplicationStatus(
                STATUS_APPROVED
        );

        /*
         * Record review time.
         */
        application.setReviewedAt(
                LocalDateTime.now()
        );

        applicationRequestRepository.save(
                application
        );

        /*
         * User becomes ACTIVE.
         */
        User user = getUser(userId);

        user.setAccountStatus(
                ACCOUNT_ACTIVE
        );

        User updatedUser =
                userRepository.save(user);

        return convertToResponse(
                updatedUser
        );
    }

    /*
     * Reject an application.
     */
    public UserResponse rejectRequest(Long userId) {

        ApplicationRequest application =
                getPendingApplication(userId);

        /*
         * Application becomes REJECTED.
         */
        application.setApplicationStatus(
                STATUS_REJECTED
        );

        /*
         * Record review time.
         */
        application.setReviewedAt(
                LocalDateTime.now()
        );

        applicationRequestRepository.save(
                application
        );

        /*
         * Rejected users are made INACTIVE.
         *
         * We don't use REJECTED as an account status
         * because our account_status mapping is:
         *
         * 1 ACTIVE
         * 2 INACTIVE
         * 3 BLOCKED
         */
        User user = getUser(userId);

        user.setAccountStatus(
                ACCOUNT_INACTIVE
        );

        User updatedUser =
                userRepository.save(user);

        return convertToResponse(
                updatedUser
        );
    }

    /*
     * Find the pending application belonging
     * to the user.
     */
    private ApplicationRequest getPendingApplication(
            Long userId) {

        List<ApplicationRequest> applications =
                applicationRequestRepository
                        .findByUserIdAndApplicationStatus(
                                userId,
                                STATUS_PENDING
                        );

        if (applications.isEmpty()) {

            throw new RuntimeException(
                    "No pending application found for this user"
            );
        }

        ApplicationRequest application =
                applications.get(0);

        /*
         * Only STORE_OWNER and DELIVERY_PARTNER
         * applications require admin approval.
         */
        Integer applicationType =
                application.getApplicationType();

        if (applicationType == null
                || (applicationType
                != APPLICATION_STORE_OWNER
                && applicationType
                != APPLICATION_DELIVERY_PARTNER)) {

            throw new RuntimeException(
                    "This application type cannot be approved"
            );
        }

        return application;
    }

    /*
     * Get User using central user_id.
     */
    private User getUser(Long userId) {

        return userRepository
                .findById(userId)
                .orElseThrow(() ->
                        new RuntimeException(
                                "User not found"
                        )
                );
    }

    /*
     * Convert User entity into API response.
     */
    private UserResponse convertToResponse(
            User user) {

        Role role =
                roleRepository
                        .findByUserId(
                                user.getUserId()
                        )
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "User role not found"
                                )
                        );

        UserResponse response =
                new UserResponse();

        response.setUserId(
                user.getUserId()
        );

        response.setEmail(
                user.getEmail()
        );

        response.setRole(
                roleName(role.getRole())
        );

        response.setAccountStatus(
                accountStatusName(
                        user.getAccountStatus()
                )
        );

        response.setCreatedAt(
                user.getCreatedAt()
        );

        response.setUpdatedAt(
                user.getUpdatedAt()
        );

        return response;
    }

    /*
     * Convert role integer to readable API value.
     */
    private String roleName(Integer role) {

        if (role == null) {
            return "UNKNOWN";
        }

        return switch (role) {

            case 1 -> "CUSTOMER";

            case 2 -> "STORE_OWNER";

            case 3 -> "DELIVERY_PARTNER";

            case 4 -> "ADMIN";

            default -> "UNKNOWN";
        };
    }

    /*
     * Convert account status integer to readable API value.
     */
    private String accountStatusName(
            Integer status) {

        if (status == null) {
            return "UNKNOWN";
        }

        return switch (status) {

            case 1 -> "ACTIVE";

            case 2 -> "INACTIVE";

            case 3 -> "BLOCKED";

            default -> "UNKNOWN";
        };
    }

    /*
     * Convert application type to readable value.
     */
    public static String applicationTypeName(
            Integer type) {

        if (type == null) {
            return "UNKNOWN";
        }

        return switch (type) {

            case APPLICATION_STORE_OWNER ->
                    "STORE_OWNER";

            case APPLICATION_DELIVERY_PARTNER ->
                    "DELIVERY_PARTNER";

            default ->
                    "UNKNOWN";
        };
    }

    /*
     * Convert application status to readable value.
     */
    public static String applicationStatusName(
            Integer status) {

        if (status == null) {
            return "UNKNOWN";
        }

        return switch (status) {

            case STATUS_PENDING ->
                    "PENDING";

            case STATUS_APPROVED ->
                    "APPROVED";

            case STATUS_REJECTED ->
                    "REJECTED";

            default ->
                    "UNKNOWN";
        };
    }
}