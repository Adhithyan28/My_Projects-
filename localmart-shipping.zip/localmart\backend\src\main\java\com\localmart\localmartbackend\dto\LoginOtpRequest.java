package com.localmart.localmartbackend.dto;

public class LoginOtpRequest {

    private String login;
    private String password;

    public LoginOtpRequest() {
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}