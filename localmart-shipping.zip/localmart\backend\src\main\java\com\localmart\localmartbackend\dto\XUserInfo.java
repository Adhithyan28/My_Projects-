package com.localmart.localmartbackend.dto;

public class XUserInfo {

    private String xId;
    private String email;
    private String name;
    private String givenName;
    private String familyName;
    private String username;

    public XUserInfo() {
    }

    public XUserInfo(
            String xId,
            String email,
            String name,
            String givenName,
            String familyName,
            String username) {

        this.xId = xId;
        this.email = email;
        this.name = name;
        this.givenName = givenName;
        this.familyName = familyName;
        this.username = username;
    }

    public String getXId() {
        return xId;
    }

    public void setXId(String xId) {
        this.xId = xId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGivenName() {
        return givenName;
    }

    public void setGivenName(String givenName) {
        this.givenName = givenName;
    }

    public String getFamilyName() {
        return familyName;
    }

    public void setFamilyName(String familyName) {
        this.familyName = familyName;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}