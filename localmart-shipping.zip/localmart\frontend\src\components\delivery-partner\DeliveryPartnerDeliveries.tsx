import { useCallback, useEffect, useState } from "react"
import { useAuth } from "../../context/AuthContext"

interface PickupLocation {
    storeName?: string
    storePhone?: string
    address?: string
    city?: string
    state?: string
    pincode?: string
    latitude?: number | null
    longitude?: number | null
}

interface DeliveryLocation {
    customerName?: string
    phone?: string
    address?: string
    city?: string
    state?: string
    pincode?: string
}

interface OrderItem {
    productId?: number
    productName?: string
    unit?: string
    quantity?: number
    unitPrice?: number
    totalPrice?: number
}

interface DeliveryOrder {
    orderId: number
    orderNumber: string

    customerId: number
    storeId: number
    deliveryPartnerId?: number | null

    subtotal: number
    deliveryFee: number
    total: number

    pickupDistanceKm?: number | null
    deliveryDistanceKm?: number | null
    totalDistanceKm?: number | null

    estimatedEarnings?: number | null

    paymentMethod?: string
    paymentStatus?: string
    orderStatus: string

    createdAt?: string
    updatedAt?: string

    pickupLocation?: PickupLocation
    deliveryLocation?: DeliveryLocation

    items?: OrderItem[]
}

type DeliveryTab =
    | "AVAILABLE"
    | "CURRENT"
    | "COMPLETED"


function DeliveryPartnerDeliveries() {

    const { user } = useAuth()

    const [orders, setOrders] =
        useState<DeliveryOrder[]>([])

    const [availableOrders, setAvailableOrders] =
        useState<DeliveryOrder[]>([])

    const [activeTab, setActiveTab] =
        useState<DeliveryTab>("AVAILABLE")

    const [selectedOrder, setSelectedOrder] =
        useState<DeliveryOrder | null>(null)

    const [loading, setLoading] =
        useState(true)

    const [updatingOrderId, setUpdatingOrderId] =
        useState<number | null>(null)

    const [message, setMessage] =
        useState("")

    const [error, setError] =
        useState("")


    /*
     * =============================================================
     * LOAD MY DELIVERIES
     * =============================================================
     */

    const loadOrders = useCallback(async () => {

        if (!user?.token) {
            return
        }

        try {

            const response =
                await fetch(
                    "http://localhost:8080/api/orders/delivery-partner",
                    {
                        method: "GET",
                        headers: {
                            Authorization:
                                `Bearer ${user.token}`
                        }
                    }
                )

            const result =
                await response.text()

            if (!response.ok) {

                let errorMessage =
                    "Unable to load deliveries"

                try {

                    const parsed =
                        JSON.parse(result)

                    errorMessage =
                        parsed.message ||
                        parsed.error ||
                        errorMessage

                } catch {

                    if (result) {
                        errorMessage = result
                    }
                }

                throw new Error(errorMessage)
            }

            const data =
                JSON.parse(result)

            setOrders(
                Array.isArray(data)
                    ? data
                    : []
            )

        } catch (err) {

            throw new Error(
                err instanceof Error
                    ? err.message
                    : "Unable to load deliveries"
            )
        }

    }, [user?.token])


    /*
     * =============================================================
     * LOAD AVAILABLE DELIVERIES
     * =============================================================
     */

    const loadAvailableOrders =
        useCallback(async () => {

            if (!user?.token) {
                return
            }

            try {

                const response =
                    await fetch(
                        "http://localhost:8080/api/orders/delivery-partner/available",
                        {
                            method: "GET",
                            headers: {
                                Authorization:
                                    `Bearer ${user.token}`
                            }
                        }
                    )

                const result =
                    await response.text()

                if (!response.ok) {

                    let errorMessage =
                        "Unable to load available deliveries"

                    try {

                        const parsed =
                            JSON.parse(result)

                        errorMessage =
                            parsed.message ||
                            parsed.error ||
                            errorMessage

                    } catch {

                        if (result) {
                            errorMessage = result
                        }
                    }

                    throw new Error(errorMessage)
                }

                const data =
                    JSON.parse(result)

                setAvailableOrders(
                    Array.isArray(data)
                        ? data
                        : []
                )

            } catch (err) {

                throw new Error(
                    err instanceof Error
                        ? err.message
                        : "Unable to load available deliveries"
                )
            }

        }, [user?.token])


    /*
     * =============================================================
     * LOAD EVERYTHING
     * =============================================================
     */

    const loadAllOrders =
        useCallback(async () => {

            if (!user?.token) {
                setLoading(false)
                return
            }

            try {

                setLoading(true)
                setError("")

                await Promise.all([
                    loadOrders(),
                    loadAvailableOrders()
                ])

            } catch (err) {

                setError(
                    err instanceof Error
                        ? err.message
                        : "Unable to load deliveries"
                )

            } finally {

                setLoading(false)
            }

        }, [
            user?.token,
            loadOrders,
            loadAvailableOrders
        ])


    /*
     * =============================================================
     * INITIAL LOAD
     * =============================================================
     */

    useEffect(() => {

        loadAllOrders()

    }, [loadAllOrders])


    /*
     * =============================================================
     * ACCEPT DELIVERY
     * =============================================================
     */

    const acceptDelivery =
        async (orderId: number) => {

            if (!user?.token) {
                return
            }

            try {

                setUpdatingOrderId(orderId)
                setMessage("")
                setError("")

                const response =
                    await fetch(
                        `http://localhost:8080/api/orders/delivery-partner/${orderId}/accept`,
                        {
                            method: "PUT",
                            headers: {
                                Authorization:
                                    `Bearer ${user.token}`
                            }
                        }
                    )

                const result =
                    await response.text()

                if (!response.ok) {

                    let errorMessage =
                        "Unable to accept delivery"

                    try {

                        const parsed =
                            JSON.parse(result)

                        errorMessage =
                            parsed.message ||
                            parsed.error ||
                            errorMessage

                    } catch {

                        if (result) {
                            errorMessage = result
                        }
                    }

                    throw new Error(errorMessage)
                }

                let acceptedOrder:
                    DeliveryOrder | null = null

                try {

                    acceptedOrder =
                        JSON.parse(result)

                } catch {

                    acceptedOrder = null
                }

                setAvailableOrders(
                    currentOrders =>
                        currentOrders.filter(
                            order =>
                                order.orderId !== orderId
                        )
                )

                if (acceptedOrder) {

                    setOrders(
                        currentOrders => {

                            const alreadyExists =
                                currentOrders.some(
                                    order =>
                                        order.orderId ===
                                        acceptedOrder!.orderId
                                )

                            if (alreadyExists) {

                                return currentOrders.map(
                                    order =>
                                        order.orderId ===
                                        acceptedOrder!.orderId
                                            ? acceptedOrder!
                                            : order
                                )
                            }

                            return [
                                acceptedOrder!,
                                ...currentOrders
                            ]
                        }
                    )

                    setSelectedOrder(
                        acceptedOrder
                    )

                } else {

                    await loadAllOrders()

                    setSelectedOrder(null)
                }

                setActiveTab("CURRENT")

                setMessage(
                    "Delivery accepted successfully"
                )

            } catch (err) {

                setError(
                    err instanceof Error
                        ? err.message
                        : "Unable to accept delivery"
                )

            } finally {

                setUpdatingOrderId(null)
            }
        }


    /*
     * =============================================================
     * UPDATE DELIVERY STATUS
     * =============================================================
     */

    const updateStatus = async (
        orderId: number,
        status: string
    ) => {

        if (!user?.token) {
            return
        }

        try {

            setUpdatingOrderId(orderId)
            setMessage("")
            setError("")

            const response =
                await fetch(
                    `http://localhost:8080/api/orders/delivery-partner/${orderId}/status`,
                    {
                        method: "PUT",
                        headers: {
                            "Content-Type":
                                "application/json",

                            Authorization:
                                `Bearer ${user.token}`
                        },
                        body: JSON.stringify({
                            status
                        })
                    }
                )

            const result =
                await response.text()

            if (!response.ok) {

                let errorMessage =
                    "Unable to update delivery status"

                try {

                    const parsed =
                        JSON.parse(result)

                    errorMessage =
                        parsed.message ||
                        parsed.error ||
                        errorMessage

                } catch {

                    if (result) {
                        errorMessage = result
                    }
                }

                throw new Error(errorMessage)
            }

            let updatedOrder:
                DeliveryOrder | null = null

            try {

                updatedOrder =
                    JSON.parse(result)

            } catch {

                updatedOrder = null
            }

            if (updatedOrder) {

                setOrders(
                    currentOrders =>
                        currentOrders.map(
                            order =>
                                order.orderId === orderId
                                    ? updatedOrder!
                                    : order
                        )
                )

                setSelectedOrder(
                    updatedOrder
                )

            } else {

                await loadOrders()
            }

            if (status === "DELIVERED") {

                await loadAvailableOrders()

                setSelectedOrder(null)
            }

            setMessage(
                `Order updated to ${status.replaceAll("_", " ")}`
            )

        } catch (err) {

            setError(
                err instanceof Error
                    ? err.message
                    : "Unable to update delivery status"
            )

        } finally {

            setUpdatingOrderId(null)
        }
    }


    /*
     * =============================================================
     * NAVIGATE TO PICKUP
     * =============================================================
     */

    const navigateToPickup =
        (order: DeliveryOrder) => {

            const latitude =
                order.pickupLocation?.latitude

            const longitude =
                order.pickupLocation?.longitude

            if (
                latitude === null ||
                latitude === undefined ||
                longitude === null ||
                longitude === undefined
            ) {

                setError(
                    "Pickup location is not available for this order."
                )

                return
            }

            const mapsUrl =
                `https://www.google.com/maps/dir/?api=1&destination=${latitude},${longitude}`

            window.open(
                mapsUrl,
                "_blank",
                "noopener,noreferrer"
            )
        }


    /*
     * =============================================================
     * NAVIGATE TO CUSTOMER
     * =============================================================
     */

    const navigateToCustomer =
        (order: DeliveryOrder) => {

            const delivery =
                order.deliveryLocation

            const destination =
                [
                    delivery?.address,
                    delivery?.city,
                    delivery?.state,
                    delivery?.pincode
                ]
                    .filter(Boolean)
                    .join(", ")

            if (!destination) {

                setError(
                    "Customer delivery address is not available."
                )

                return
            }

            const mapsUrl =
                `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(destination)}`

            window.open(
                mapsUrl,
                "_blank",
                "noopener,noreferrer"
            )
        }


    /*
     * =============================================================
     * NEXT ACTION
     * =============================================================
     */

    const getNextAction =
        (status: string) => {

            switch (status) {

                case "ACCEPTED":
                    return {
                        label: "Mark Picked Up",
                        nextStatus: "PICKED_UP"
                    }

                case "PICKED_UP":
                    return {
                        label: "Start Delivery",
                        nextStatus: "OUT_FOR_DELIVERY"
                    }

                case "OUT_FOR_DELIVERY":
                    return {
                        label: "Mark Delivered",
                        nextStatus: "DELIVERED"
                    }

                default:
                    return null
            }
        }


    /*
     * =============================================================
     * STATUS CLASS
     * =============================================================
     */

    const getStatusClass =
        (status: string) => {

            switch (status) {

                case "DELIVERED":
                    return "delivery-order-status delivered"

                case "OUT_FOR_DELIVERY":
                    return "delivery-order-status out-for-delivery"

                case "PICKED_UP":
                    return "delivery-order-status picked-up"

                case "ACCEPTED":
                    return "delivery-order-status accepted"

                case "READY_FOR_PICKUP":
                    return "delivery-order-status ready"

                default:
                    return "delivery-order-status"
            }
        }


    /*
     * =============================================================
     * FORMAT STATUS
     * =============================================================
     */

    const formatStatus =
        (status: string) => {

            return status
                .replaceAll("_", " ")
                .toLowerCase()
                .replace(/\b\w/g, char =>
                    char.toUpperCase()
                )
        }


    /*
     * =============================================================
     * FORMAT DISTANCE
     * =============================================================
     */

    const formatDistance =
        (distance?: number | null) => {

            if (
                distance === null ||
                distance === undefined
            ) {
                return "—"
            }

            return `${Number(distance).toFixed(2)} km`
        }


    /*
     * =============================================================
     * FORMAT CURRENCY
     * =============================================================
     */

    const formatCurrency =
        (amount?: number | null) => {

            if (
                amount === null ||
                amount === undefined
            ) {
                return "₹0.00"
            }

            return `₹${Number(amount).toFixed(2)}`
        }


    /*
     * =============================================================
     * FORMAT DATE
     * =============================================================
     */

    const formatDate =
        (date?: string) => {

            if (!date) {
                return "—"
            }

            const parsedDate =
                new Date(date)

            if (
                Number.isNaN(
                    parsedDate.getTime()
                )
            ) {
                return date
            }

            return parsedDate.toLocaleString(
                "en-IN",
                {
                    day: "2-digit",
                    month: "short",
                    year: "numeric",
                    hour: "2-digit",
                    minute: "2-digit"
                }
            )
        }


    /*
     * =============================================================
     * COMPLETED DATE
     * =============================================================
     */

    const formatCompletedDate =
        (date?: string) => {

            if (!date) {
                return "—"
            }

            const parsedDate =
                new Date(date)

            if (
                Number.isNaN(
                    parsedDate.getTime()
                )
            ) {
                return date
            }

            return parsedDate.toLocaleDateString(
                "en-IN",
                {
                    day: "2-digit",
                    month: "short",
                    year: "numeric"
                }
            )
        }


    /*
     * =============================================================
     * FULL ADDRESS
     * =============================================================
     */

    const getPickupAddress =
        (order: DeliveryOrder) => {

            return [
                order.pickupLocation?.address,
                order.pickupLocation?.city,
                order.pickupLocation?.state,
                order.pickupLocation?.pincode
            ]
                .filter(Boolean)
                .join(", ")
        }


    const getDeliveryAddress =
        (order: DeliveryOrder) => {

            return [
                order.deliveryLocation?.address,
                order.deliveryLocation?.city,
                order.deliveryLocation?.state,
                order.deliveryLocation?.pincode
            ]
                .filter(Boolean)
                .join(", ")
        }


    /*
     * =============================================================
     * FILTER ORDERS
     * =============================================================
     */

    const currentOrders =
        orders.filter(
            order =>
                order.orderStatus !== "DELIVERED"
        )

    const completedOrders =
        orders.filter(
            order =>
                order.orderStatus === "DELIVERED"
        )


    /*
     * =============================================================
     * LOADING
     * =============================================================
     */

    if (loading) {

        return (
            <div className="delivery-deliveries-page">

                <div className="delivery-page-header">

                    <div className="delivery-header-content">

                        <span className="delivery-header-eyebrow">
                            Deliveries
                        </span>

                        <h1>
                            My Deliveries
                        </h1>

                        <p>
                            Loading your deliveries...
                        </p>

                    </div>

                </div>

                <div className="delivery-loading-card">
                    Loading deliveries...
                </div>

            </div>
        )
    }


    /*
     * =============================================================
     * PAGE
     * =============================================================
     */

    return (

        <div className="delivery-deliveries-page">

            {/* HEADER */}

            <div className="delivery-page-header">

                <div className="delivery-header-content">

                    <span className="delivery-header-eyebrow">
                        Deliveries
                    </span>

                    <h1>
                        My Deliveries
                    </h1>

                    <p className="delivery-page-description">
                        Find available orders and manage your
                        deliveries from pickup to completion.
                    </p>

                </div>

                <button
                    className="delivery-refresh-button"
                    type="button"
                    onClick={loadAllOrders}
                    disabled={loading}
                >
                    ↻ Refresh
                </button>

            </div>


            {/* MESSAGE */}

            {message && (

                <div className="delivery-message">
                    {message}
                </div>

            )}

            {error && (

                <div className="delivery-error">
                    {error}
                </div>

            )}


            {/* =====================================================
                    DELIVERY TABS
                ===================================================== */}

            <div className="delivery-tabs">

                <button
                    type="button"
                    className={
                        activeTab === "AVAILABLE"
                            ? "delivery-tab active"
                            : "delivery-tab"
                    }
                    onClick={() => {
                        setActiveTab("AVAILABLE")
                        setSelectedOrder(null)
                    }}
                >
                    <span>
                        Available
                    </span>

                    <strong>
                        {availableOrders.length}
                    </strong>

                </button>


                <button
                    type="button"
                    className={
                        activeTab === "CURRENT"
                            ? "delivery-tab active"
                            : "delivery-tab"
                    }
                    onClick={() => {
                        setActiveTab("CURRENT")
                        setSelectedOrder(null)
                    }}
                >
                    <span>
                        Current
                    </span>

                    <strong>
                        {currentOrders.length}
                    </strong>

                </button>


                <button
                    type="button"
                    className={
                        activeTab === "COMPLETED"
                            ? "delivery-tab active"
                            : "delivery-tab"
                    }
                    onClick={() => {
                        setActiveTab("COMPLETED")
                        setSelectedOrder(null)
                    }}
                >
                    <span>
                        Completed
                    </span>

                    <strong>
                        {completedOrders.length}
                    </strong>

                </button>

            </div>


            {/* =====================================================
                    SELECTED ORDER DETAILS
                ===================================================== */}

            {selectedOrder && (

                <div className="delivery-order-card selected-note">

                    <div className="delivery-note-pin">
                        •
                    </div>


                    {/* ORDER HEADER */}

                    <div className="delivery-order-header">

                        <div>

                            <p className="delivery-order-label">
                                ORDER DETAILS
                            </p>

                            <h2>
                                #{selectedOrder.orderNumber}
                            </h2>

                            <p>
                                {formatDate(
                                    selectedOrder.createdAt
                                )}
                            </p>

                        </div>

                        <span
                            className={
                                getStatusClass(
                                    selectedOrder.orderStatus
                                )
                            }
                        >
                            {formatStatus(
                                selectedOrder.orderStatus
                            )}
                        </span>

                    </div>


                    {/* ROUTE */}

                    <div className="delivery-route">

                        <div className="delivery-route-point">

                            <div className="delivery-route-dot pickup">
                                P
                            </div>

                            <div>

                                <span>
                                    PICKUP
                                </span>

                                <strong>
                                    {selectedOrder.pickupLocation?.storeName ||
                                        `Store #${selectedOrder.storeId}`}
                                </strong>

                            </div>

                        </div>


                        <div className="delivery-route-line" />


                        <div className="delivery-route-point">

                            <div className="delivery-route-dot delivery">
                                D
                            </div>

                            <div>

                                <span>
                                    DELIVERY
                                </span>

                                <strong>
                                    {selectedOrder.deliveryLocation?.customerName ||
                                        "Customer"}
                                </strong>

                            </div>

                        </div>

                    </div>


                    {/* PICKUP */}

                    <div className="delivery-customer-section">

                        <div>

                            <span>
                                PICKUP ADDRESS
                            </span>

                            <strong>
                                {getPickupAddress(selectedOrder) ||
                                    "Address unavailable"}
                            </strong>

                            {activeTab === "CURRENT" &&
                                selectedOrder.pickupLocation?.storePhone && (

                                    <p>
                                        ☎ {selectedOrder.pickupLocation.storePhone}
                                    </p>

                                )}

                        </div>


                        {/* CONTACT / NAVIGATION
                            CURRENT ONLY */}

                        {activeTab === "CURRENT" && (

                            <div>

                                {selectedOrder.pickupLocation?.storePhone && (

                                    <a
                                        className="delivery-call-button"
                                        href={`tel:${selectedOrder.pickupLocation.storePhone}`}
                                    >
                                        ☎ Call Store
                                    </a>

                                )}


                                {selectedOrder.pickupLocation?.latitude !== null &&
                                    selectedOrder.pickupLocation?.latitude !== undefined &&
                                    selectedOrder.pickupLocation?.longitude !== null &&
                                    selectedOrder.pickupLocation?.longitude !== undefined && (

                                        <button
                                            type="button"
                                            className="delivery-refresh-button"
                                            onClick={() =>
                                                navigateToPickup(selectedOrder)
                                            }
                                        >
                                            Navigate to Pickup
                                        </button>

                                    )}

                            </div>

                        )}

                    </div>


                    {/* DELIVERY */}

                    <div className="delivery-customer-section">

                        <div>

                            <span>
                                DELIVERY ADDRESS
                            </span>

                            <strong>
                                {getDeliveryAddress(selectedOrder) ||
                                    "Address unavailable"}
                            </strong>

                            {activeTab === "CURRENT" &&
                                selectedOrder.deliveryLocation?.phone && (

                                    <p>
                                        ☎ {selectedOrder.deliveryLocation.phone}
                                    </p>

                                )}

                        </div>


                        {/* CONTACT / NAVIGATION
                            CURRENT ONLY */}

                        {activeTab === "CURRENT" && (

                            <div>

                                {selectedOrder.deliveryLocation?.phone && (

                                    <a
                                        className="delivery-call-button"
                                        href={`tel:${selectedOrder.deliveryLocation.phone}`}
                                    >
                                        ☎ Call Customer
                                    </a>

                                )}


                                <button
                                    type="button"
                                    className="delivery-refresh-button"
                                    onClick={() =>
                                        navigateToCustomer(selectedOrder)
                                    }
                                >
                                    Navigate to Customer
                                </button>

                            </div>

                        )}

                    </div>


                    {/* DISTANCE */}

                    <div className="delivery-distance-grid">

                        <div>

                            <span>
                                PARTNER → STORE
                            </span>

                            <strong>
                                {formatDistance(
                                    selectedOrder.pickupDistanceKm
                                )}
                            </strong>

                        </div>


                        <div>

                            <span>
                                STORE → CUSTOMER
                            </span>

                            <strong>
                                {formatDistance(
                                    selectedOrder.deliveryDistanceKm
                                )}
                            </strong>

                        </div>


                        <div>

                            <span>
                                TOTAL ROUTE
                            </span>

                            <strong>
                                {formatDistance(
                                    selectedOrder.totalDistanceKm
                                )}
                            </strong>

                        </div>

                    </div>


                    {/* =================================================
                            DELIVERY PARTNER EARNINGS
                        ================================================= */}

                    <div className="delivery-order-details">

                        <div>

                            <span>
                                DELIVERY PARTNER EARNINGS
                            </span>

                            <strong>
                                {formatCurrency(
                                    selectedOrder.estimatedEarnings
                                )}
                            </strong>

                        </div>

                    </div>


                    {/* PAYMENT */}

                    <div className="delivery-order-details">

                        <div>

                            <span>
                                PAYMENT
                            </span>

                            <strong>
                                {selectedOrder.paymentMethod ||
                                    "—"}
                            </strong>

                        </div>


                        <div>

                            <span>
                                PAYMENT STATUS
                            </span>

                            <strong>
                                {selectedOrder.paymentStatus ||
                                    "—"}
                            </strong>

                        </div>

                    </div>


                    {/* ITEMS */}

                    <div className="delivery-order-details">

                        <div>

                            <span>
                                ORDER ITEMS
                            </span>

                            {selectedOrder.items &&
                            selectedOrder.items.length > 0 ? (

                                <div>

                                    {selectedOrder.items.map(
                                        (item, index) => (

                                            <p
                                                key={
                                                    `${selectedOrder.orderId}-${item.productId ?? index}`
                                                }
                                            >
                                                {item.productName ||
                                                    "Product"}

                                                {" × "}

                                                {item.quantity ?? 0}

                                                {item.unit
                                                    ? ` ${item.unit}`
                                                    : ""}

                                                {" — "}

                                                {formatCurrency(
                                                    item.totalPrice
                                                )}

                                            </p>

                                        )
                                    )}

                                </div>

                            ) : (

                                <strong>
                                    No items available
                                </strong>

                            )}

                        </div>

                    </div>


                    {/* AVAILABLE ACTION */}

                    {activeTab === "AVAILABLE" && (

                        <div className="delivery-order-action">

                            <button
                                type="button"
                                className="delivery-action-button"
                                disabled={
                                    updatingOrderId ===
                                    selectedOrder.orderId
                                }
                                onClick={() =>
                                    acceptDelivery(
                                        selectedOrder.orderId
                                    )
                                }
                            >

                                {updatingOrderId ===
                                selectedOrder.orderId
                                    ? "Accepting..."
                                    : "Accept Order"}

                            </button>

                        </div>

                    )}


                    {/* CURRENT ACTION */}

                    {activeTab === "CURRENT" &&
                        getNextAction(
                            selectedOrder.orderStatus
                        ) && (

                            <div className="delivery-order-action">

                                <button
                                    type="button"
                                    className="delivery-action-button"
                                    disabled={
                                        updatingOrderId ===
                                        selectedOrder.orderId
                                    }
                                    onClick={() => {

                                        const nextAction =
                                            getNextAction(
                                                selectedOrder.orderStatus
                                            )

                                        if (nextAction) {

                                            updateStatus(
                                                selectedOrder.orderId,
                                                nextAction.nextStatus
                                            )

                                        }

                                    }}
                                >

                                    {updatingOrderId ===
                                    selectedOrder.orderId
                                        ? "Updating..."
                                        : getNextAction(
                                            selectedOrder.orderStatus
                                        )?.label}

                                </button>

                            </div>

                        )}


                    {/* CLOSE */}

                    <div className="delivery-order-action">

                        <button
                            type="button"
                            className="delivery-refresh-button"
                            onClick={() =>
                                setSelectedOrder(null)
                            }
                        >
                            Close Details
                        </button>

                    </div>

                </div>

            )}


            {/* =====================================================
                    AVAILABLE ORDERS
                ===================================================== */}

            {activeTab === "AVAILABLE" && !selectedOrder && (

                <div>

                    <div className="delivery-page-header delivery-section-header">

                        <div>

                            <h1>
                                Available Orders
                            </h1>

                            <p>
                                Choose an order you want to deliver.
                            </p>

                        </div>

                    </div>


                    {availableOrders.length === 0 ? (

                        <div className="delivery-empty-card">

                            <div className="delivery-empty-icon">
                                📦
                            </div>

                            <h2>
                                No available orders
                            </h2>

                            <p>
                                New deliveries will appear here when
                                stores mark orders as ready for pickup.
                            </p>

                            <button
                                type="button"
                                className="delivery-refresh-button"
                                onClick={loadAllOrders}
                            >
                                Check Again
                            </button>

                        </div>

                    ) : (

                        <div className="delivery-orders-list">

                            {availableOrders.map(order => {

                                const accepting =
                                    updatingOrderId ===
                                    order.orderId

                                return (

                                    <div
                                        className="delivery-order-card delivery-sticky-note delivery-sticky-note-available"
                                        key={order.orderId}
                                        onClick={() =>
                                            setSelectedOrder(order)
                                        }
                                        role="button"
                                        tabIndex={0}
                                        onKeyDown={event => {

                                            if (
                                                event.key === "Enter" ||
                                                event.key === " "
                                            ) {

                                                setSelectedOrder(order)
                                            }

                                        }}
                                    >

                                        <div className="delivery-note-pin">
                                            •
                                        </div>


                                        <div className="delivery-order-header">

                                            <div>

                                                <p className="delivery-order-label">
                                                    AVAILABLE ORDER
                                                </p>

                                                <h2>
                                                    #{order.orderNumber}
                                                </h2>

                                            </div>

                                            <span
                                                className={
                                                    getStatusClass(
                                                        order.orderStatus
                                                    )
                                                }
                                            >
                                                {formatStatus(
                                                    order.orderStatus
                                                )}
                                            </span>

                                        </div>


                                        <div className="delivery-route">

                                            <div className="delivery-route-point">

                                                <div className="delivery-route-dot pickup">
                                                    P
                                                </div>

                                                <div>

                                                    <span>
                                                        PICKUP
                                                    </span>

                                                    <strong>
                                                        {order.pickupLocation?.storeName ||
                                                            `Store #${order.storeId}`}
                                                    </strong>

                                                </div>

                                            </div>


                                            <div className="delivery-route-line" />


                                            <div className="delivery-route-point">

                                                <div className="delivery-route-dot delivery">
                                                    D
                                                </div>

                                                <div>

                                                    <span>
                                                        DELIVERY
                                                    </span>

                                                    <strong>
                                                        {order.deliveryLocation?.customerName ||
                                                            "Customer"}
                                                    </strong>

                                                </div>

                                            </div>

                                        </div>


                                        <div className="delivery-distance-grid">

                                            <div>

                                                <span>
                                                    DISTANCE
                                                </span>

                                                <strong>
                                                    {formatDistance(
                                                        order.deliveryDistanceKm
                                                    )}
                                                </strong>

                                            </div>


                                            <div>

                                                <span>
                                                    ESTIMATED EARNINGS
                                                </span>

                                                <strong>
                                                    {formatCurrency(
                                                        order.estimatedEarnings
                                                    )}
                                                </strong>

                                            </div>

                                        </div>


                                        <div className="delivery-order-action">

                                            <button
                                                type="button"
                                                className="delivery-action-button"
                                                disabled={accepting}
                                                onClick={event => {

                                                    event.stopPropagation()

                                                    acceptDelivery(
                                                        order.orderId
                                                    )

                                                }}
                                            >
                                                {accepting
                                                    ? "Accepting..."
                                                    : "Accept Order"}
                                            </button>

                                        </div>

                                    </div>

                                )
                            })}

                        </div>

                    )}

                </div>

            )}


            {/* =====================================================
                    CURRENT ORDERS
                ===================================================== */}

            {activeTab === "CURRENT" && !selectedOrder && (

                <div>

                    <div className="delivery-page-header delivery-section-header">

                        <div>

                            <h1>
                                Current Orders
                            </h1>

                            <p>
                                Manage the deliveries you are currently
                                handling.
                            </p>

                        </div>

                    </div>


                    {currentOrders.length === 0 ? (

                        <div className="delivery-empty-card">

                            <div className="delivery-empty-icon">
                                🚚
                            </div>

                            <h2>
                                No current orders
                            </h2>

                            <p>
                                Accepted deliveries will appear here.
                            </p>

                            <button
                                type="button"
                                className="delivery-refresh-button"
                                onClick={() =>
                                    setActiveTab("AVAILABLE")
                                }
                            >
                                View Available Orders
                            </button>

                        </div>

                    ) : (

                        <div className="delivery-orders-list">

                            {currentOrders.map(order => {

                                const nextAction =
                                    getNextAction(
                                        order.orderStatus
                                    )

                                return (

                                    <div
                                        className="delivery-order-card delivery-sticky-note delivery-sticky-note-current"
                                        key={order.orderId}
                                        onClick={() =>
                                            setSelectedOrder(order)
                                        }
                                        role="button"
                                        tabIndex={0}
                                        onKeyDown={event => {

                                            if (
                                                event.key === "Enter" ||
                                                event.key === " "
                                            ) {

                                                setSelectedOrder(order)
                                            }

                                        }}
                                    >

                                        <div className="delivery-note-pin">
                                            •
                                        </div>


                                        <div className="delivery-order-header">

                                            <div>

                                                <p className="delivery-order-label">
                                                    CURRENT ORDER
                                                </p>

                                                <h2>
                                                    #{order.orderNumber}
                                                </h2>

                                            </div>

                                            <span
                                                className={
                                                    getStatusClass(
                                                        order.orderStatus
                                                    )
                                                }
                                            >
                                                {formatStatus(
                                                    order.orderStatus
                                                )}
                                            </span>

                                        </div>


                                        <div className="delivery-route">

                                            <div className="delivery-route-point">

                                                <div className="delivery-route-dot pickup">
                                                    P
                                                </div>

                                                <div>

                                                    <span>
                                                        STORE
                                                    </span>

                                                    <strong>
                                                        {order.pickupLocation?.storeName ||
                                                            `Store #${order.storeId}`}
                                                    </strong>

                                                </div>

                                            </div>


                                            <div className="delivery-route-line" />


                                            <div className="delivery-route-point">

                                                <div className="delivery-route-dot delivery">
                                                    D
                                                </div>

                                                <div>

                                                    <span>
                                                        CUSTOMER
                                                    </span>

                                                    <strong>
                                                        {order.deliveryLocation?.customerName ||
                                                            "Customer"}
                                                    </strong>

                                                </div>

                                            </div>

                                        </div>


                                        <div className="delivery-distance-grid">

                                            <div>

                                                <span>
                                                    TOTAL ROUTE
                                                </span>

                                                <strong>
                                                    {formatDistance(
                                                        order.totalDistanceKm ??
                                                        order.deliveryDistanceKm
                                                    )}
                                                </strong>

                                            </div>


                                            <div>

                                                <span>
                                                    ESTIMATED EARNINGS
                                                </span>

                                                <strong>
                                                    {formatCurrency(
                                                        order.estimatedEarnings
                                                    )}
                                                </strong>

                                            </div>

                                        </div>


                                        <div className="delivery-order-details">

                                            <div>

                                                <span>
                                                    STATUS
                                                </span>

                                                <strong>
                                                    {formatStatus(
                                                        order.orderStatus
                                                    )}
                                                </strong>

                                            </div>

                                        </div>


                                        {nextAction && (

                                            <div className="delivery-order-action">

                                                <button
                                                    type="button"
                                                    className="delivery-action-button"
                                                    disabled={
                                                        updatingOrderId ===
                                                        order.orderId
                                                    }
                                                    onClick={event => {

                                                        event.stopPropagation()

                                                        updateStatus(
                                                            order.orderId,
                                                            nextAction.nextStatus
                                                        )

                                                    }}
                                                >

                                                    {updatingOrderId ===
                                                    order.orderId
                                                        ? "Updating..."
                                                        : nextAction.label}

                                                </button>

                                            </div>

                                        )}

                                    </div>
                                )
                            })}

                        </div>

                    )}

                </div>

            )}


            {/* =====================================================
                    COMPLETED ORDERS
                ===================================================== */}

            {activeTab === "COMPLETED" && !selectedOrder && (

                <div>

                    <div className="delivery-page-header delivery-section-header">

                        <div>

                            <h1>
                                Completed Orders
                            </h1>

                            <p>
                                View your successfully completed
                                deliveries.
                            </p>

                        </div>

                    </div>


                    {completedOrders.length === 0 ? (

                        <div className="delivery-empty-card">

                            <div className="delivery-empty-icon">
                                ✓
                            </div>

                            <h2>
                                No completed orders
                            </h2>

                            <p>
                                Completed deliveries will appear here.
                            </p>

                        </div>

                    ) : (

                        <div className="delivery-orders-list">

                            {completedOrders.map(order => (

                                <div
                                    className="delivery-order-card delivery-sticky-note delivery-sticky-note-completed"
                                    key={order.orderId}
                                    onClick={() =>
                                        setSelectedOrder(order)
                                    }
                                    role="button"
                                    tabIndex={0}
                                    onKeyDown={event => {

                                        if (
                                            event.key === "Enter" ||
                                            event.key === " "
                                        ) {

                                            setSelectedOrder(order)
                                        }

                                    }}
                                >

                                    <div className="delivery-note-pin">
                                        •
                                    </div>


                                    <div className="delivery-order-header">

                                        <div>

                                            <p className="delivery-order-label">
                                                COMPLETED ORDER
                                            </p>

                                            <h2>
                                                #{order.orderNumber}
                                            </h2>

                                        </div>

                                        <span
                                            className={
                                                getStatusClass(
                                                    order.orderStatus
                                                )
                                            }
                                        >
                                            ✓ Completed
                                        </span>

                                    </div>


                                    <div className="delivery-route">

                                        <div className="delivery-route-point">

                                            <div className="delivery-route-dot pickup">
                                                P
                                            </div>

                                            <div>

                                                <span>
                                                    STORE
                                                </span>

                                                <strong>
                                                    {order.pickupLocation?.storeName ||
                                                        `Store #${order.storeId}`}
                                                </strong>

                                            </div>

                                        </div>


                                        <div className="delivery-route-line" />


                                        <div className="delivery-route-point">

                                            <div className="delivery-route-dot delivery">
                                                D
                                            </div>

                                            <div>

                                                <span>
                                                    CUSTOMER
                                                </span>

                                                <strong>
                                                    {order.deliveryLocation?.customerName ||
                                                        "Customer"}
                                                </strong>

                                            </div>

                                        </div>

                                    </div>


                                    <div className="delivery-distance-grid">

                                        <div>

                                            <span>
                                                COMPLETED
                                            </span>

                                            <strong>
                                                {formatCompletedDate(
                                                    order.updatedAt ||
                                                    order.createdAt
                                                )}
                                            </strong>

                                        </div>


                                        <div>

                                            <span>
                                                TOTAL ROUTE
                                            </span>

                                            <strong>
                                                {formatDistance(
                                                    order.totalDistanceKm
                                                )}
                                            </strong>

                                        </div>

                                    </div>


                                    {/* =================================================
                                            COMPLETED EARNINGS
                                        ================================================= */}

                                    <div className="delivery-order-details">

                                        <div>

                                            <span>
                                                EARNED
                                            </span>

                                            <strong>
                                                {formatCurrency(
                                                    order.estimatedEarnings
                                                )}
                                            </strong>

                                        </div>

                                    </div>

                                </div>

                            ))}

                        </div>

                    )}

                </div>

            )}

        </div>
    )
}

export default DeliveryPartnerDeliveries