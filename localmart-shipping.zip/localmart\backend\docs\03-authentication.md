# LocalMart — Authentication Architecture

**Version:** 1.0
**Project:** LocalMart
**Document Type:** Authentication Architecture Documentation

---

# 1. Purpose

This document describes the authentication architecture of the LocalMart application.

Authentication is responsible for establishing the identity of a user before allowing the application to perform operations on behalf of that user.

LocalMart supports multiple authentication mechanisms:

* Password-based authentication with OTP verification.
* Email OTP.
* SMS OTP.
* TOTP-based authentication.
* Google authentication.
* X authentication.
* Password reset authentication flows.

After successful authentication, LocalMart creates an authenticated application session and issues a JWT that is used for subsequent protected API requests.

The detailed implementation flow for each authentication mechanism is documented separately under:

```text
docs/flows/
```

---

# 2. Authentication Goals

The authentication system is designed to provide:

* User identity verification.
* Secure password handling.
* OTP-based verification.
* Social authentication.
* JWT-based API authentication.
* Server-side user session tracking.
* Account-status validation.
* Role-aware access control.
* Protection against excessive authentication requests.
* Secure communication between the frontend and backend.

---

# 3. Authentication Components

The main authentication-related backend components are:

```text
com.localmart.localmartbackend
│
├── controller
│   ├── UserController.java
│   └── XOAuthController.java
│
├── dto
│   ├── LoginRequest.java
│   ├── LoginOtpRequest.java
│   ├── VerifyOtpRequest.java
│   ├── RegistrationOtpRequest.java
│   ├── UserRegistrationRequest.java
│   ├── GoogleAuthRequest.java
│   ├── UserResponse.java
│   ├── XRegistrationData.java
│   └── XUserInfo.java
│
├── service
│   ├── UserService.java
│   ├── OtpService.java
│   ├── OtpDeliveryService.java
│   ├── EmailService.java
│   ├── MessageCentralOtpService.java
│   ├── MockOtpDeliveryService.java
│   ├── RegistrationVerificationService.java
│   ├── GoogleTokenVerificationService.java
│   ├── XOAuthService.java
│   ├── TotpService.java
│   └── UserSessionService.java
│
├── security
│   ├── SecurityConfig.java
│   ├── JwtAuthenticationFilter.java
│   ├── JwtService.java
│   └── RateLimitFilter.java
│
└── entity
    ├── User.java
    ├── Role.java
    └── UserSession.java
```

These components work together rather than placing the entire authentication process inside a single class.

---

# 4. Authentication Architecture

The high-level authentication architecture is:

```text
┌──────────────────────────┐
│       React Frontend     │
└────────────┬─────────────┘
             │
             │ Authentication Request
             ▼
┌──────────────────────────┐
│     UserController       │
│     / XOAuthController   │
└────────────┬─────────────┘
             │
             ▼
┌──────────────────────────┐
│       UserService        │
└────────────┬─────────────┘
             │
       ┌─────┼─────────────┐
       │     │             │
       ▼     ▼             ▼
     OTP   Google         X OAuth
       │     │             │
       └─────┼─────────────┘
             │
             ▼
┌──────────────────────────┐
│     User / Role Data     │
│       PostgreSQL         │
└────────────┬─────────────┘
             │
             ▼
┌──────────────────────────┐
│       JwtService         │
└────────────┬─────────────┘
             │
             ▼
┌──────────────────────────┐
│   UserSessionService     │
└────────────┬─────────────┘
             │
             ▼
┌──────────────────────────┐
│           JWT            │
└────────────┬─────────────┘
             │
             ▼
┌──────────────────────────┐
│       React Frontend     │
└──────────────────────────┘
```

The important architectural principle is that **different authentication methods eventually converge into the same authenticated application identity**.

---

# 5. Authentication vs Authorization

Authentication and authorization are separate concepts.

### Authentication

Authentication answers:

> Who is this user?

Examples:

* Email/password + OTP.
* Mobile/password + OTP.
* Google identity.
* X identity.
* TOTP verification.

### Authorization

Authorization answers:

> What is this authenticated user allowed to do?

LocalMart has multiple roles:

```text
CUSTOMER
STORE_OWNER
DELIVERY_PARTNER
ADMIN
```

Therefore:

```text
Authentication
      │
      ▼
Identify User
      │
      ▼
Identify Role
      │
      ▼
Authorization
      │
      ▼
Allow / Reject Operation
```

---

# 6. User Identity

The central authentication identity is represented by:

```text
User.java
```

The user record contains the identity information required by the application.

Authentication operations ultimately need to associate the authenticated request with a LocalMart user.

The application also maintains role information through:

```text
Role.java
```

Therefore the authenticated identity can be conceptually represented as:

```text
User
 │
 └── Role
```

The user's account status is also considered during authentication.

The application uses the following status model:

```text
1 = ACTIVE
2 = BLOCKED
3 = SUSPENDED
4 = DEACTIVATED
```

An authenticated identity is therefore not determined only by whether credentials are valid. The account's current status must also be considered.

---

# 7. Local Authentication

Local authentication is handled primarily through:

```text
UserController.java
UserService.java
OtpService.java
OtpDeliveryService.java
```

The login process uses an authentication identifier that can represent:

* Email address.
* Mobile number.

The frontend determines whether the supplied identifier is an email address or an Indian mobile number and sends the login request to the backend.

The backend then performs the authentication workflow.

Conceptually:

```text
User enters
Email / Mobile
      │
      ▼
Password
      │
      ▼
Login Request
      │
      ▼
Backend
      │
      ▼
Verify User / Password
      │
      ▼
OTP Verification
      │
      ▼
Successful Authentication
```

The detailed implementation is documented in:

```text
docs/flows/02-login-flow.md
```

---

# 8. Password Verification

LocalMart uses BCrypt for password hashing.

The password stored by the application is not intended to be the original plaintext password.

Conceptually:

```text
Registration
     │
     ▼
Plain Password
     │
     ▼
BCrypt
     │
     ▼
Password Hash
     │
     ▼
Database
```

During login:

```text
Entered Password
       │
       ▼
BCrypt Verification
       │
       ▼
Stored Password Hash
       │
       ▼
Match / Reject
```

The backend therefore verifies the supplied password against the stored BCrypt hash rather than decrypting the stored value.

---

# 9. OTP Authentication

OTP authentication is used as an additional verification step in authentication-related flows.

Relevant components include:

```text
OtpService.java
OtpDeliveryService.java
EmailService.java
MessageCentralOtpService.java
MockOtpDeliveryService.java
```

The conceptual flow is:

```text
Authentication Request
        │
        ▼
Generate OTP
        │
        ▼
Select Delivery Channel
        │
     ┌──┴─────────────┐
     │                │
     ▼                ▼
   Email             SMS
     │                │
     ▼                ▼
   User enters OTP
        │
        ▼
OTP Verification
        │
        ▼
Authentication Success
```

Detailed OTP flows are documented separately.

---

# 10. Email OTP

Email-based OTP delivery is supported through the application's email service.

Relevant component:

```text
EmailService.java
```

The application communicates with an SMTP email provider to deliver OTP messages.

Conceptually:

```text
LocalMart Backend
       │
       ▼
EmailService
       │
       ▼
SMTP Server
       │
       ▼
User Email Inbox
```

The email delivery mechanism is different from the OTP generation and verification logic.

The architecture separates:

```text
OTP Generation
      +
OTP Delivery
      +
OTP Verification
```

This allows the delivery mechanism to change without redesigning the entire OTP system.

Detailed flow:

```text
docs/flows/03-email-otp-flow.md
```

---

# 11. SMS OTP

SMS OTP functionality uses the dedicated SMS OTP subsystem and Message Central integration.

Relevant components include:

```text
smsotp/
├── controller
│   └── SmsOtpController.java
├── dto
│   ├── SmsOtpSendRequest.java
│   └── SmsOtpVerifyRequest.java
├── model
│   └── SmsOtpSession.java
└── service
    └── SmsOtpFlowService.java
```

The backend also contains:

```text
MessageCentralOtpService.java
```

The high-level architecture is:

```text
Frontend
   │
   ▼
SmsOtpController
   │
   ▼
SmsOtpFlowService
   │
   ▼
MessageCentralOtpService
   │
   ▼
Message Central
   │
   ▼
User Mobile
```

Detailed flow:

```text
docs/flows/04-sms-otp-flow.md
```

---

# 12. TOTP

TOTP stands for:

**Time-Based One-Time Password**

LocalMart contains:

```text
TotpService.java
```

and a corresponding test:

```text
src/test/java/com/localmart/localmartbackend/service/TotpServiceTest.java
```

TOTP is different from SMS or email OTP.

The important distinction is:

```text
SMS / Email
     │
     └── Delivery Channel

TOTP
     │
     └── OTP Generation / Verification Mechanism
```

A TOTP system generates time-dependent codes based on a shared secret and the current time window.

The application can use TOTP as an authentication verification mechanism without requiring an SMS message to be sent for every generated code.

Detailed TOTP behavior should be documented in:

```text
docs/flows/05-totp-flow.md
```

---

# 13. Google Authentication

LocalMart supports Google authentication.

Relevant components:

```text
GoogleAuthRequest.java
GoogleTokenVerificationService.java
UserService.java
```

The frontend obtains a Google credential using Google's identity services.

The credential is sent to the LocalMart backend.

Conceptually:

```text
Google Identity Services
          │
          ▼
Google Credential
          │
          ▼
LocalMart Frontend
          │
          │ POST Google Credential
          ▼
UserController
          │
          ▼
UserService
          │
          ▼
GoogleTokenVerificationService
          │
          ▼
Google Token Verification
          │
          ▼
LocalMart User
          │
          ▼
JWT / Session
```

The backend therefore does not simply trust arbitrary user information supplied by the frontend. It verifies the Google credential before creating the LocalMart authenticated identity.

Detailed flow:

```text
docs/flows/06-google-login-flow.md
```

---

# 14. X Authentication

The project also contains X authentication components:

```text
XOAuthController.java
XOAuthService.java
XRegistrationData.java
XUserInfo.java
XAuthProperties.java
```

The X authentication architecture follows the OAuth-based integration implemented by the project.

Conceptually:

```text
User
 │
 ▼
LocalMart Frontend
 │
 ▼
X Authentication
 │
 ▼
X OAuth
 │
 ▼
XOAuthService
 │
 ▼
LocalMart User
 │
 ▼
JWT / Session
```

The exact OAuth request and callback behavior should be documented using the current implementation in:

```text
docs/flows/07-x-login-flow.md
```

---

# 15. Registration Verification

Registration-related verification is handled through:

```text
RegistrationVerificationService.java
```

Registration can involve verification before a user account becomes fully usable.

The exact verification sequence depends on the registration flow implemented by the current `UserController` and `UserService`.

The detailed process should be documented in:

```text
docs/flows/01-registration-flow.md
```

---

# 16. JWT Generation

Once authentication succeeds, LocalMart uses:

```text
JwtService.java
```

to create a JSON Web Token.

Conceptually:

```text
Successful Authentication
          │
          ▼
     User Identity
          │
          ▼
      JwtService
          │
          ▼
        JWT
```

The token represents the authenticated identity for subsequent API requests.

---

# 17. JWT-Based API Authentication

After receiving the JWT, the frontend sends it with protected API requests.

The standard request concept is:

```text
Authorization: Bearer <JWT>
```

The backend contains:

```text
JwtAuthenticationFilter.java
```

which processes incoming requests containing the token.

Conceptually:

```text
Frontend
    │
    │ Authorization: Bearer JWT
    ▼
JwtAuthenticationFilter
    │
    ▼
JwtService
    │
    ▼
Validate JWT
    │
    ▼
Extract Identity
    │
    ▼
SecurityContext
    │
    ▼
Controller
```

This allows Spring Security to associate the incoming request with an authenticated user.

---

# 18. Security Context

Spring Security maintains the authenticated request identity through the security context.

The conceptual process is:

```text
JWT
 │
 ▼
JwtAuthenticationFilter
 │
 ▼
Authentication Object
 │
 ▼
SecurityContext
 │
 ▼
Protected Controller
```

Controllers and services can therefore operate in the context of the authenticated user.

The exact implementation depends on the current `SecurityConfig` and `JwtAuthenticationFilter`.

---

# 19. User Session Management

LocalMart contains:

```text
UserSession.java
UserSessionRepository.java
UserSessionService.java
```

The application therefore has a server-side session-management component associated with authenticated users.

The conceptual relationship is:

```text
Authenticated User
       │
       ▼
UserSessionService
       │
       ▼
UserSession
       │
       ▼
Database
```

JWT authentication and server-side session tracking therefore serve different purposes:

```text
JWT
 │
 └── Carries authentication information with API requests

UserSession
 │
 └── Maintains server-side session information
```

The exact session lifecycle should be documented from the implementation in `UserSessionService.java`.

---

# 20. Rate Limiting and Authentication

Authentication endpoints can be targeted by excessive requests.

LocalMart contains:

```text
RateLimitFilter.java
```

The rate-limiting layer provides an additional protection mechanism.

Conceptually:

```text
Authentication Request
        │
        ▼
Rate Limit Check
        │
   ┌────┴─────┐
   │          │
Allowed     Rejected
   │
   ▼
Authentication Flow
```

This is particularly relevant to:

* Login.
* OTP generation.
* OTP verification.
* Authentication-related endpoints.

The exact rate limits are defined by the current implementation.

---

# 21. Authentication and Account Status

Successful credential verification does not necessarily mean the user should receive access.

The application also maintains account status.

```text
Credentials
     │
     ▼
Valid?
     │
     ▼
Account Status
     │
 ┌───┼───────────────┐
 │   │       │       │
 ▼   ▼       ▼       ▼
ACTIVE BLOCKED SUSPENDED DEACTIVATED
 │
 ▼
Continue Authentication
```

The application should prevent blocked, suspended, or deactivated accounts from being treated as normally active accounts according to the rules implemented in `UserService`.

---

# 22. Role-Based Access

After authentication, the user's role becomes important for authorization.

LocalMart supports:

```text
CUSTOMER
STORE_OWNER
DELIVERY_PARTNER
ADMIN
```

Conceptually:

```text
Authenticated User
       │
       ▼
      Role
       │
 ┌─────┼──────────────┬─────────────┐
 ▼     ▼              ▼             ▼
Customer Store Owner Delivery     Admin
                         Partner
```

Different backend endpoints can then apply role-based access rules through Spring Security configuration.

---

# 23. Complete Authentication Architecture

The complete high-level process can be represented as:

```text
                         USER
                          │
                          ▼
                  React Frontend
                          │
             ┌────────────┼─────────────┐
             │            │             │
             ▼            ▼             ▼
        Local Login     Google        X OAuth
             │            │             │
             ▼            ▼             ▼
            OTP       Google Verify   OAuth Verify
             │            │             │
             └────────────┼─────────────┘
                          │
                          ▼
                     UserService
                          │
                          ▼
                  Validate User
                          │
                          ▼
                   Check Account
                      Status
                          │
                          ▼
                    Identify Role
                          │
                          ▼
                    JwtService
                          │
                          ▼
                        JWT
                          │
                          ▼
                 UserSessionService
                          │
                          ▼
                  Authenticated User
                          │
                          ▼
              Protected API Requests
                          │
                          ▼
             JwtAuthenticationFilter
                          │
                          ▼
                  SecurityContext
                          │
                          ▼
                     Controller
```

---

# 24. Authentication Responsibility Model

| Component                        | Responsibility                                          |
| -------------------------------- | ------------------------------------------------------- |
| `UserController`                 | Handles authentication-related HTTP requests            |
| `UserService`                    | Coordinates user authentication and identity operations |
| `OtpService`                     | Handles OTP-related logic                               |
| `OtpDeliveryService`             | Provides OTP delivery abstraction                       |
| `EmailService`                   | Handles email delivery                                  |
| `MessageCentralOtpService`       | Handles Message Central OTP integration                 |
| `TotpService`                    | Handles TOTP operations                                 |
| `GoogleTokenVerificationService` | Verifies Google authentication credentials              |
| `XOAuthService`                  | Handles X OAuth integration                             |
| `UserSessionService`             | Handles server-side user session information            |
| `JwtService`                     | Creates and validates JWTs                              |
| `JwtAuthenticationFilter`        | Processes JWT authentication on incoming requests       |
| `SecurityConfig`                 | Configures Spring Security and authorization rules      |
| `RateLimitFilter`                | Restricts excessive requests                            |
| `User`                           | Represents application user identity                    |
| `Role`                           | Represents user role information                        |
| `UserSession`                    | Represents server-side session information              |

---

# 25. Authentication Security Principles

LocalMart's authentication architecture follows several security principles.

## Passwords are hashed

Passwords are protected using BCrypt rather than being stored as plaintext.

## Authentication is server-controlled

The frontend does not determine whether authentication succeeded. The backend validates authentication data.

## JWT is validated by the backend

Protected API requests must contain a valid authentication token.

## External identity credentials are verified

Social authentication credentials are processed and verified by backend services.

## Account status is checked

Authentication must consider whether an account is active or restricted.

## Role information is server-controlled

Authorization decisions are based on backend identity and role information.

## Authentication endpoints can be rate-limited

Rate limiting provides protection against excessive authentication requests.

---

# 26. Authentication Flow Documentation

Detailed authentication flows are maintained separately:

```text
docs/flows/
│
├── 01-registration-flow.md
├── 02-login-flow.md
├── 03-email-otp-flow.md
├── 04-sms-otp-flow.md
├── 05-totp-flow.md
├── 06-google-login-flow.md
├── 07-x-login-flow.md
└── 08-password-reset-flow.md
```

These documents should contain implementation-level traces.

For example:

```text
Frontend File
     ↓
HTTP Method + Endpoint
     ↓
Security Filter
     ↓
Controller Method
     ↓
Request DTO
     ↓
Service Method
     ↓
Repository
     ↓
Entity
     ↓
Database
     ↓
External Service
     ↓
Response DTO
     ↓
JSON Response
     ↓
Frontend
```

Only components that actually participate in a particular flow should be included in that flow's final diagram.

---

# 27. Source-of-Truth Rule

This document describes the authentication architecture based on the current LocalMart project structure.

Implementation-level details must always be verified against the current source code.

In particular:

* Exact endpoint paths must come from controller mappings.
* Exact JWT claims must come from `JwtService`.
* Exact session behavior must come from `UserSessionService`.
* Exact account-status rules must come from `UserService`.
* Exact OTP behavior must come from `OtpService` and related delivery services.
* Exact Google verification behavior must come from `GoogleTokenVerificationService`.
* Exact X OAuth behavior must come from `XOAuthService` and `XOAuthController`.
* Exact authorization rules must come from `SecurityConfig`.
* Exact rate-limit behavior must come from `RateLimitFilter`.

This prevents architectural documentation from becoming inconsistent with the implementation.

---

# 28. Summary

LocalMart uses a multi-mechanism authentication architecture in which different authentication methods eventually converge on a common LocalMart user identity.

The major authentication path is:

```text
Authentication Method
        │
        ▼
Verification
        │
        ▼
User Identity
        │
        ▼
Account Status
        │
        ▼
Role
        │
        ▼
JWT
        │
        ▼
User Session
        │
        ▼
Protected API Access
```

The architecture separates:

```text
Identity Verification
        +
OTP / OAuth / TOTP
        +
JWT Authentication
        +
Session Management
        +
Authorization
```

This separation allows LocalMart to support multiple authentication mechanisms while maintaining a common security model for protected backend APIs.
