import { useEffect, useState } from "react"
import { useAuth } from "../../context/AuthContext"

interface StoreDetails {
    storeId: number
    firstName: string
    lastName: string
    ownerName: string
    email: string
    phone: string
    storeName: string
    businessType: string
    gstNumber: string
    addressLine: string
    city: string
    state: string
    pincode: string
    latitude: number | null
    longitude: number | null
}

interface Product {
    productId: number
    storeId: number
    name?: string
    productName?: string
}

type BackendOrderStatus =
    | "PLACED"
    | "CONFIRMED"
    | "PREPARING"
    | "READY_FOR_PICKUP"
    | "CANCELLED"

interface BackendOrder {
    orderId: number
    orderNumber: string
    customerId: number
    storeId: number
    subtotal: number
    deliveryFee: number
    total: number
    paymentMethod: string
    paymentStatus: string
    orderStatus: BackendOrderStatus
    deliveryName: string
    deliveryPhone: string
    deliveryAddress: string
    deliveryCity: string
    deliveryPincode: string
    createdAt: string
    updatedAt: string
    items: unknown[]
}

interface Order {
    id: string
    customer: string
    amount: number
    status: string
    date: string
}

function StoreOwnerHome() {

    const { user } = useAuth()

    const token = user?.token

    const API_BASE_URL = "http://localhost:8080"

    const [store, setStore] =
        useState<StoreDetails | null>(null)

    const [products, setProducts] =
        useState<Product[]>([])

    const [orders, setOrders] =
        useState<BackendOrder[]>([])

    const [loading, setLoading] =
        useState(true)

    const [error, setError] =
        useState("")

    /*
     * ============================================================
     * STATUS CONVERSION
     * ============================================================
     */

    const getDisplayStatus = (
        status: BackendOrderStatus
    ) => {

        switch (status) {

            case "PLACED":
                return "New"

            case "CONFIRMED":
                return "Confirmed"

            case "PREPARING":
                return "Preparing"

            case "READY_FOR_PICKUP":
                return "Ready for Delivery"

            case "CANCELLED":
                return "Cancelled"

            default:
                return status
        }
    }

    /*
     * ============================================================
     * DATE FORMAT
     * ============================================================
     */

    const formatDate = (
        dateString: string
    ) => {

        if (!dateString) {
            return "-"
        }

        const date =
            new Date(dateString)

        if (Number.isNaN(date.getTime())) {
            return dateString
        }

        return date.toLocaleDateString(
            "en-IN",
            {
                day: "2-digit",
                month: "short",
                year: "numeric",
            }
        )
    }

    /*
     * ============================================================
     * FETCH DASHBOARD DATA
     * ============================================================
     */

    useEffect(() => {

        const fetchDashboardData =
            async () => {

                try {

                    setLoading(true)
                    setError("")

                    const headers: HeadersInit = {}

                    if (token) {
                        headers.Authorization =
                            `Bearer ${token}`
                    }

                    /*
                     * ------------------------------------------------
                     * GET STORE DETAILS
                     * ------------------------------------------------
                     */

                    const storeResponse =
                        await fetch(
                            `${API_BASE_URL}/api/store-owner/store`,
                            {
                                method: "GET",
                                headers,
                            }
                        )

                    if (!storeResponse.ok) {

                        const message =
                            await storeResponse.text()

                        throw new Error(
                            message ||
                            "Failed to load store details."
                        )
                    }

                    const storeData:
                        StoreDetails =
                        await storeResponse.json()

                    setStore(storeData)

                    /*
                     * ------------------------------------------------
                     * GET PRODUCTS
                     * ------------------------------------------------
                     */

                    const productResponse =
                        await fetch(
                            `${API_BASE_URL}/api/products/store/${storeData.storeId}`,
                            {
                                method: "GET",
                                headers,
                            }
                        )

                    if (!productResponse.ok) {

                        const message =
                            await productResponse.text()

                        throw new Error(
                            message ||
                            "Failed to load products."
                        )
                    }

                    const productData:
                        Product[] =
                        await productResponse.json()

                    setProducts(productData)

                    /*
                     * ------------------------------------------------
                     * GET ORDERS
                     * ------------------------------------------------
                     */

                    const orderResponse =
                        await fetch(
                            `${API_BASE_URL}/api/store-owner/orders`,
                            {
                                method: "GET",
                                headers,
                            }
                        )

                    if (!orderResponse.ok) {

                        const message =
                            await orderResponse.text()

                        throw new Error(
                            message ||
                            "Failed to load orders."
                        )
                    }

                    const orderData:
                        BackendOrder[] =
                        await orderResponse.json()

                    setOrders(orderData)

                } catch (error) {

                    console.error(
                        "Failed to load store owner dashboard:",
                        error
                    )

                    setError(
                        error instanceof Error
                            ? error.message
                            : "Failed to load dashboard."
                    )

                } finally {

                    setLoading(false)
                }
            }

        fetchDashboardData()

    }, [token])

    /*
     * ============================================================
     * KPI CALCULATIONS
     * ============================================================
     */

    const totalProducts =
        products.length

    const totalOrders =
        orders.length

    const totalSales =
        orders
            .filter(
                (order) =>
                    order.orderStatus !== "CANCELLED"
            )
            .reduce(
                (sum, order) =>
                    sum + Number(order.total || 0),
                0
            )

    /*
     * ============================================================
     * RECENT ORDERS
     * ============================================================
     */

    const recentOrders: Order[] =
        [...orders]
            .sort(
                (a, b) =>
                    new Date(b.createdAt).getTime() -
                    new Date(a.createdAt).getTime()
            )
            .slice(0, 4)
            .map(
                (order) => ({

                    id:
                        order.orderNumber ||
                        `#LM${order.orderId}`,

                    customer:
                        order.deliveryName ||
                        "Customer",

                    amount:
                        Number(order.total || 0),

                    status:
                        getDisplayStatus(
                            order.orderStatus
                        ),

                    date:
                        formatDate(
                            order.createdAt
                        ),
                })
            )

    /*
     * ============================================================
     * ADDRESS DISPLAY
     * ============================================================
     */

    const storeAddress =
        store
            ? [
                store.addressLine,
                store.city,
                store.state,
                store.pincode,
            ]
                .filter(Boolean)
                .join(", ")
            : "-"

    /*
     * ============================================================
     * RENDER
     * ============================================================
     */

    return (

        <div className="owner-page">

            {/* =====================================================
                PAGE HEADER
            ===================================================== */}

            <div className="owner-page-header">

                <div>

                    <span className="owner-section-label">

                    </span>

                    <h1>
                        Welcome back
                        {user?.email
                            ? `, ${user.email.split("@")[0]}`
                            : ""}
                    </h1>

                    <p>
                        Here's what's happening with your store today.
                    </p>

                </div>

            </div>

            {/* =====================================================
                ERROR
            ===================================================== */}

            {error && (

                <div className="owner-dashboard-alert">

                    <span className="owner-alert-icon">
                        !
                    </span>

                    <div>

                        <strong>
                            Unable to load dashboard
                        </strong>

                        <p>
                            {error}
                        </p>

                    </div>

                </div>

            )}

            {/* =====================================================
                KPI CARDS
            ===================================================== */}

            <section className="owner-kpi-grid">

                <div className="owner-kpi-card">

                    <div className="owner-kpi-icon">
                        📦
                    </div>

                    <div className="owner-kpi-content">

                        <span>
                            Total Products
                        </span>

                        <strong>
                            {loading
                                ? "..."
                                : totalProducts}
                        </strong>

                        <small>
                            Products in your store
                        </small>

                    </div>

                </div>

                <div className="owner-kpi-card">

                    <div className="owner-kpi-icon">
                        🛒
                    </div>

                    <div className="owner-kpi-content">

                        <span>
                            Total Orders
                        </span>

                        <strong>
                            {loading
                                ? "..."
                                : totalOrders}
                        </strong>

                        <small>
                            Orders received
                        </small>

                    </div>

                </div>

                <div className="owner-kpi-card">

                    <div className="owner-kpi-icon">
                        ₹
                    </div>

                    <div className="owner-kpi-content">

                        <span>
                            Total Sales
                        </span>

                        <strong>
                            {loading
                                ? "..."
                                : `₹${totalSales.toLocaleString(
                                    "en-IN",
                                    {
                                        minimumFractionDigits: 2,
                                        maximumFractionDigits: 2,
                                    }
                                )}`}
                        </strong>


                    </div>

                </div>

            </section>

            {/* =====================================================
                DASHBOARD CONTENT
            ===================================================== */}

            <div className="owner-dashboard-grid">

                {/* =================================================
                    STORE SUMMARY
                ================================================= */}

                <section className="owner-card store-summary-card">

                    <div className="owner-card-header">

                        <div>

                            <span className="owner-section-label">
                                MY STORE
                            </span>

                            <h2>
                                Store Summary
                            </h2>

                        </div>

                        <div className="owner-store-status">

                            <span></span>

                            Open

                        </div>

                    </div>

                    <div className="owner-store-summary">

                        <div className="owner-store-avatar">
                            🏪
                        </div>

                        <div className="owner-store-main-info">

                            <h3>
                                {loading
                                    ? "Loading..."
                                    : store?.storeName || "-"}
                            </h3>

                            <p>
                                {loading
                                    ? "Loading..."
                                    : store?.businessType || "-"}
                            </p>

                        </div>

                    </div>

                    <div className="owner-summary-details">

                        <div className="owner-summary-item">

                            <span>
                                BUSINESS TYPE
                            </span>

                            <strong>
                                {store?.businessType || "-"}
                            </strong>

                        </div>

                        <div className="owner-summary-item">

                            <span>
                                GST NUMBER
                            </span>

                            <strong>
                                {store?.gstNumber || "-"}
                            </strong>

                        </div>

                        <div className="owner-summary-item">

                            <span>
                                STORE ADDRESS
                            </span>

                            <strong>
                                {storeAddress}
                            </strong>

                        </div>

                    </div>

                </section>

                {/* =================================================
                    RECENT ORDERS
                ================================================= */}

                <section className="owner-card recent-orders-card">

                    <div className="owner-card-header">

                        <div>

                            <span className="owner-section-label">
                                ORDERS
                            </span>

                            <h2>
                                Recent Orders
                            </h2>

                        </div>

                        <span className="owner-card-count">
                            {recentOrders.length}
                        </span>

                    </div>

                    <div className="owner-orders-list">

                        {loading ? (

                            <div className="owner-dashboard-state">

                                <div className="owner-state-icon">
                                    ⏳
                                </div>

                                <strong>
                                    Loading orders
                                </strong>

                                <span>
                                    Please wait while we fetch your latest orders.
                                </span>

                            </div>

                        ) : recentOrders.length === 0 ? (

                            <div className="owner-dashboard-state">

                                <div className="owner-state-icon">
                                    🛒
                                </div>

                                <strong>
                                    No orders yet
                                </strong>

                                <span>
                                    Your recent orders will appear here.
                                </span>

                            </div>

                        ) : (

                            recentOrders.map(
                                (order) => (

                                    <div
                                        className="owner-order-row"
                                        key={order.id}
                                    >

                                        <div className="owner-order-info">

                                            <strong>
                                                {order.id}
                                            </strong>

                                            <span>
                                                {order.customer}
                                            </span>

                                        </div>

                                        <div className="owner-order-date">
                                            {order.date}
                                        </div>

                                        <div className="owner-order-amount">

                                            ₹{order.amount.toLocaleString(
                                            "en-IN",
                                            {
                                                minimumFractionDigits: 2,
                                                maximumFractionDigits: 2,
                                            }
                                        )}

                                        </div>

                                        <span
                                            className={`owner-order-status ${order.status
                                                .toLowerCase()
                                                .replaceAll(" ", "-")}`}
                                        >
                                            {order.status}
                                        </span>

                                    </div>

                                )
                            )

                        )}

                    </div>

                </section>

            </div>

        </div>
    )
}

export default StoreOwnerHome