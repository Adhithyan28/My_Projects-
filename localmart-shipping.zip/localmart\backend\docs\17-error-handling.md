# LocalMart — Error Handling

## 1. Overview

LocalMart uses centralized exception handling to prevent individual controllers from having to handle every possible error manually.

The primary component responsible for this is:

```text
GlobalExceptionHandler.java
```

located under:

```text
com.localmart.localmartbackend.exception
```

The main responsibility of the global exception handler is to intercept exceptions raised during request processing and convert them into appropriate HTTP responses.

The overall idea is:

```text
Client Request
      |
      v
Controller
      |
      v
Service
      |
      X
   Exception
      |
      v
GlobalExceptionHandler
      |
      v
HTTP Error Response
      |
      v
Client
```

This provides a consistent error-handling mechanism throughout the application.

---

# 2. Why Global Exception Handling Is Needed

Without centralized exception handling, every controller would potentially need code like:

```text
try {
    ...
} catch (...) {
    ...
}
```

For a large application, this quickly becomes repetitive.

For example:

```text
UserController
    → error handling

OrderController
    → error handling

CartController
    → error handling

ProductController
    → error handling

StoreController
    → error handling
```

This duplicates error-handling logic.

Instead, LocalMart follows:

```text
All Controllers
       |
       v
Business Services
       |
       v
Exception
       |
       v
GlobalExceptionHandler
```

The error-handling logic is therefore centralized.

---

# 3. Location of the Exception Handler

The exception handler belongs to:

```text
src/main/java/com/localmart/localmartbackend/exception/
```

with:

```text
GlobalExceptionHandler.java
```

This keeps exception-related code separate from:

```text
controller/
service/
repository/
entity/
security/
```

The project structure therefore has a dedicated exception layer.

---

# 4. Role of GlobalExceptionHandler

The `GlobalExceptionHandler` acts as a boundary between internal application failures and HTTP responses.

Internally, LocalMart may encounter:

```text
IllegalArgumentException
Authentication failures
Validation failures
Database-related exceptions
External-service failures
Business-rule violations
Unexpected runtime exceptions
```

The handler converts these into responses that the frontend can understand.

Conceptually:

```text
Java Exception
      |
      v
GlobalExceptionHandler
      |
      v
HTTP Status + Response Body
```

---

# 5. Spring's Exception Handling Mechanism

Spring MVC provides infrastructure for exception handling.

A global exception handler can intercept exceptions thrown while processing controller requests.

The important concept is that an exception does not necessarily have to be caught inside the controller.

For example:

```text
Controller
    |
    v
Service
    |
    X
throw exception
```

The exception can propagate back through the Spring request-processing infrastructure until the appropriate exception handler processes it.

Conceptually:

```text
Service
   |
   | exception
   v
Controller
   |
   v
Spring MVC
   |
   v
GlobalExceptionHandler
```

---

# 6. Normal Request Flow

A successful LocalMart request looks like:

```text
Frontend
   |
   | HTTP Request
   v
Controller
   |
   v
Service
   |
   v
Repository
   |
   v
PostgreSQL
   |
   v
Repository
   |
   v
Service
   |
   v
Controller
   |
   v
HTTP 200 / 201
```

---

# 7. Error Request Flow

When something fails:

```text
Frontend
   |
   | HTTP Request
   v
Controller
   |
   v
Service
   |
   X
Exception
   |
   v
GlobalExceptionHandler
   |
   v
HTTP Error Response
   |
   v
Frontend
```

The frontend therefore receives an HTTP response instead of the server simply terminating the request without a structured response.

---

# 8. Service-Layer Errors

Most application business logic lives inside services.

For example:

```text
UserService
OrderService
CartService
ProductService
StoreService
CustomerService
DeliveryPartnerLocationService
```

A service can detect a business-rule violation.

Examples:

```text
User does not exist
Product does not exist
Cart item does not exist
Invalid OTP
Invalid login credentials
Account is blocked
Address does not belong to customer
Invalid order state
Insufficient product availability
```

The service can throw an exception.

The exception can then be handled centrally.

---

# 9. Example — Invalid User

Conceptually:

```text
UserController
      |
      v
UserService
      |
      v
UserRepository
      |
      X
User not found
      |
      v
Exception
      |
      v
GlobalExceptionHandler
      |
      v
HTTP 4xx response
```

The controller does not need to know every detail about how the error should be converted into an HTTP response.

---

# 10. Example — Invalid OTP

An OTP verification request can follow:

```text
POST /api/users/login/verify
```

The request enters:

```text
UserController
```

which delegates to:

```text
UserService
```

The service verifies the OTP.

If the OTP is invalid:

```text
OTP
 |
 v
Verification
 |
 X
Invalid OTP
 |
 v
Exception
 |
 v
GlobalExceptionHandler
 |
 v
HTTP error response
```

This keeps the authentication logic inside the service while keeping HTTP error formatting centralized.

---

# 11. Authentication Errors

LocalMart contains several authentication mechanisms:

```text
Password login
Email OTP
SMS OTP
Google login
X login
TOTP
JWT
```

Authentication failures can therefore occur at different stages.

Examples:

```text
Invalid password
Invalid OTP
Expired OTP
Invalid Google credential
Invalid X authentication data
Invalid JWT
Expired JWT
Missing authentication
Blocked account
Inactive account
```

These should result in appropriate HTTP error responses rather than successful responses.

---

# 12. Authorization Errors

Authentication answers:

> "Who is the user?"

Authorization answers:

> "Is this user allowed to perform this operation?"

For example:

```text
CUSTOMER
    |
    X
Access admin endpoint
```

or:

```text
DELIVERY_PARTNER
    |
    X
Modify another user's account
```

Spring Security can reject unauthorized access before the controller executes.

Conceptually:

```text
Request
   |
   v
Security Filters
   |
   X
Unauthorized / Forbidden
```

Therefore not every security error necessarily reaches `GlobalExceptionHandler`.

Spring Security has its own authentication and authorization handling mechanisms.

---

# 13. Validation Errors

LocalMart uses Bean Validation and application-level validation.

Validation can occur at multiple levels.

### Request validation

For example:

```text
Email format
Phone number
Required fields
PIN code
Coordinates
Password requirements
```

### Business validation

For example:

```text
Customer must exist
Store must exist
Address must belong to customer
Order must be in valid state
```

These are different types of validation.

---

# 14. Input Validation Flow

A typical request can follow:

```text
Frontend
   |
   v
HTTP Request
   |
   v
Controller
   |
   v
Request Validation
   |
   X
Invalid input
   |
   v
Exception Handler
   |
   v
HTTP 400
```

The client should receive a response indicating that the request itself is invalid.

---

# 15. HTTP Status Codes

Error handling should use HTTP status codes to communicate the general class of failure.

Common categories include:

| Status                      | Meaning                                                               |
| --------------------------- | --------------------------------------------------------------------- |
| `200 OK`                    | Request succeeded                                                     |
| `201 Created`               | Resource created                                                      |
| `400 Bad Request`           | Invalid request/input                                                 |
| `401 Unauthorized`          | Authentication required/failed                                        |
| `403 Forbidden`             | Authenticated but not permitted                                       |
| `404 Not Found`             | Requested resource does not exist                                     |
| `409 Conflict`              | Request conflicts with current state/data                             |
| `500 Internal Server Error` | Unexpected server failure                                             |
| `502/503`                   | External/dependency or service availability problem, when appropriate |

The exact status returned by LocalMart depends on the exception handling implemented in `GlobalExceptionHandler` and the surrounding Spring Security configuration.

---

# 16. Client-Friendly Error Responses

An important purpose of centralized handling is to give the frontend a predictable response.

Instead of exposing an internal Java stack trace, the API should return an application-level error.

Conceptually:

```json
{
  "message": "Invalid OTP"
}
```

rather than:

```text
java.lang.IllegalArgumentException:
    at com.localmart...
    at org.springframework...
    at ...
```

The client needs the error information, not the server's internal implementation details.

---

# 17. Why Stack Traces Should Not Be Returned

A stack trace can expose internal information such as:

```text
Package names
Class names
Method names
Database implementation details
Framework internals
File paths
Internal processing logic
```

This information is useful to developers but unnecessary for normal clients.

Therefore:

```text
Developer logs
     ≠
Client response
```

The server can retain detailed diagnostic information internally while returning a safe message to the client.

---

# 18. Error Handling Layers

LocalMart's error handling can be viewed as several layers.

```text
                HTTP Request
                     |
                     v
             Spring Security
                     |
              +------+------+
              |             |
           Allowed        Rejected
              |             |
              v             v
         Controller     Security Error
              |
              v
           Service
              |
              v
         Repository
              |
              v
          Database
```

At each layer, different failures can occur.

---

# 19. Controller-Level Errors

Controllers primarily handle HTTP concerns.

For example:

```text
@RequestBody
@PathVariable
@RequestParam
HTTP method
HTTP response
```

Controllers should generally delegate business operations to services.

If a service throws an exception:

```text
Controller
    |
    v
Service
    |
    X
Exception
```

the global handler can process it.

This keeps controllers thin.

---

# 20. Service-Level Errors

Services contain LocalMart's business rules.

For example:

```text
UserService
```

may reject:

```text
Duplicate email
Duplicate phone
Invalid registration token
Invalid OTP
Blocked account
Invalid role
```

Similarly:

```text
OrderService
```

may reject:

```text
Invalid address
Invalid store
Invalid cart
Invalid order state
```

These are business-level errors rather than HTTP-specific concerns.

---

# 21. Repository / Database Errors

Repositories communicate with PostgreSQL through JPA/Hibernate.

Potential failures include:

```text
Database connection failure
Constraint violation
Transaction failure
Unexpected persistence error
```

The persistence layer can throw exceptions that propagate upward.

The global exception mechanism can then convert appropriate exceptions into HTTP responses.

Unexpected database failures should generally not expose raw database details to the client.

---

# 22. External-Service Errors

LocalMart communicates with external systems such as:

```text
Google
X
Message Central
SMTP
Razorpay
OSRM
Geocoding provider
```

These services can fail independently.

Examples:

```text
Timeout
Network failure
Invalid credentials
Provider unavailable
Rate limit
Invalid external response
```

The application should distinguish:

```text
Client error
      vs
LocalMart error
      vs
External-service error
```

This distinction is important for debugging and user feedback.

---

# 23. External-Service Failure Flow

For example:

```text
OrderService
     |
     v
RoadDistanceService
     |
     v
OSRM
     |
     X
Timeout
     |
     v
Integration exception
     |
     v
Application error handling
     |
     v
HTTP response
```

The user should not receive an OSRM-specific internal stack trace.

---

# 24. Security Filter Errors

LocalMart's request processing includes security components such as:

```text
JwtAuthenticationFilter
RateLimitFilter
SecurityConfig
```

The security chain executes before normal controller processing for protected requests.

Conceptually:

```text
HTTP Request
      |
      v
RateLimitFilter
      |
      v
JwtAuthenticationFilter
      |
      v
Spring Security
      |
      v
Controller
```

A request can therefore fail before reaching a controller.

---

# 25. JWT Errors

JWT-related problems can include:

```text
Missing token
Invalid token
Expired token
Malformed token
Invalid session
```

The authentication filter is responsible for processing JWT authentication.

A rejected authentication request can therefore be handled through Spring Security's security response mechanisms rather than the ordinary controller exception path.

---

# 26. Rate-Limit Errors

LocalMart also contains:

```text
RateLimitFilter.java
```

The purpose of the filter is to limit excessive requests.

Conceptually:

```text
Client
  |
  | Many requests
  v
RateLimitFilter
  |
  X
Limit exceeded
  |
  v
HTTP rate-limit response
```

This can happen before the request reaches a controller.

Therefore rate limiting belongs to the security/infrastructure boundary rather than normal service exception handling.

---

# 27. Global Exception Handler vs Security Filters

These mechanisms solve different problems.

| Component                 | Main responsibility                                |
| ------------------------- | -------------------------------------------------- |
| `GlobalExceptionHandler`  | Application/controller/service exception responses |
| `JwtAuthenticationFilter` | JWT authentication                                 |
| `RateLimitFilter`         | Request-rate control                               |
| `SecurityConfig`          | Security rules and authorization                   |
| Spring Security handlers  | Authentication/authorization failures              |

This separation prevents one component from becoming responsible for every type of failure.

---

# 28. Error Propagation

A useful way to understand LocalMart's error handling is to follow an exception backward through the call stack.

For example:

```text
OrderController
      |
      v
OrderService
      |
      v
ProductRepository
      |
      X
Exception
```

The exception propagates:

```text
ProductRepository
      ↑
OrderService
      ↑
OrderController
      ↑
Spring MVC
      ↑
GlobalExceptionHandler
```

The handler then creates the HTTP response.

---

# 29. Exception Handling Does Not Mean Ignoring Errors

Global exception handling does not mean that the application simply catches everything and continues.

Instead:

```text
Exception
   |
   v
Recognize failure
   |
   v
Choose appropriate HTTP response
   |
   v
Return failure to client
```

The failed operation does not silently become a successful operation.

---

# 30. Error Handling and Transactions

Database operations may involve multiple changes.

For example, order creation can involve:

```text
Create Order
Create Order Items
Create Payment information
Update Cart
```

If an operation fails partway through, transaction management becomes important.

Conceptually:

```text
Transaction
   |
   +---- Create Order
   |
   +---- Create Items
   |
   +---- Update Cart
   |
   X
Failure
   |
   v
Rollback
```

Exception handling and transaction management are related but different responsibilities.

The exception handler determines how the failure is communicated.

Transaction management determines whether database changes are committed or rolled back.

---

# 31. Error Handling and Logging

There are two different audiences for errors.

### Client

Needs:

```text
HTTP status
Safe error message
Possibly structured error information
```

### Developer

Needs:

```text
Exception type
Stack trace
Request context
Relevant identifiers
External-service failure details
```

Therefore:

```text
Client Response
       ≠
Developer Log
```

Detailed internal information should remain in server-side logs.

---

# 32. Error Handling Security Principle

Error messages should avoid revealing sensitive information.

For example, responses should not expose:

```text
Passwords
Password hashes
JWT secrets
API keys
OAuth client secrets
SMTP credentials
Payment credentials
Database credentials
Internal stack traces
```

Even when an operation fails.

---

# 33. Authentication Error Example

Consider a login request.

```text
Frontend
   |
   | email + password
   v
UserController
   |
   v
UserService
   |
   v
Password verification
   |
   X
Invalid password
   |
   v
Exception
   |
   v
GlobalExceptionHandler
   |
   v
HTTP error
```

The frontend can then display an appropriate authentication error.

---

# 34. Business Rule Error Example

Suppose a customer attempts to access an address belonging to another user.

```text
Customer
   |
   v
CustomerAddressController
   |
   v
CustomerAddressService
   |
   v
Ownership validation
   |
   X
Not authorized
   |
   v
Exception
   |
   v
GlobalExceptionHandler / Security handling
   |
   v
HTTP response
```

The important rule is that resource ownership must be validated server-side.

---

# 35. Error Handling and API Consistency

Centralized handling helps different endpoints behave consistently.

Without centralized handling:

```text
/cart
    → one error format

/orders
    → another format

/products
    → another format

/users
    → another format
```

With centralized handling:

```text
All application errors
        |
        v
GlobalExceptionHandler
        |
        v
Consistent API error structure
```

This makes frontend error handling simpler.

---

# 36. Frontend Error Handling

The LocalMart frontend communicates with the backend through HTTP.

Therefore it can distinguish:

```text
2xx → success
4xx → client/auth/business problem
5xx → server/infrastructure problem
```

For example:

```text
HTTP 400
   ↓
Show validation message

HTTP 401
   ↓
Authentication required

HTTP 403
   ↓
Access denied

HTTP 404
   ↓
Resource not found

HTTP 500
   ↓
Server-side failure
```

The exact UI behavior depends on the frontend implementation.

---

# 37. Error Handling Architecture

The complete LocalMart error architecture can be represented as:

```text
                         HTTP Request
                              |
                              v
                       Security Filters
                              |
                 +------------+------------+
                 |                         |
              Allowed                   Rejected
                 |                         |
                 v                         v
            Controller              Security Handler
                 |
                 v
              Service
                 |
        +--------+--------+
        |        |        |
        v        v        v
   Repository External  Business
              Service    Rules
        |        |        |
        +--------+--------+
                 |
                 X
              Exception
                 |
                 v
        GlobalExceptionHandler
                 |
                 v
          HTTP Error Response
                 |
                 v
             Frontend
```

---

# 38. Error Handling Responsibilities

| Layer                    | Responsibility                                    |
| ------------------------ | ------------------------------------------------- |
| Frontend                 | Display appropriate user-facing message           |
| Controller               | Receive HTTP requests and delegate                |
| Service                  | Enforce business rules                            |
| Repository               | Persistence operations                            |
| Integration services     | Communicate with external systems                 |
| Security filters         | Authentication/rate limiting                      |
| Spring Security          | Authorization/security failure handling           |
| `GlobalExceptionHandler` | Centralized application exception → HTTP response |
| Database                 | Persistence constraints and transaction storage   |

---

# 39. Important Architectural Distinction

LocalMart does not treat every failure as the same type of error.

A useful model is:

```text
                Failure
                   |
       +-----------+-----------+
       |           |           |
       v           v           v
    Client      Security    Infrastructure
    Error        Error          Error
       |           |              |
       v           v              v
      4xx      Security       5xx / suitable
               handling        response
                   |
                   |
            Application Error
                   |
                   v
        GlobalExceptionHandler
```

This makes the architecture easier to reason about and debug.

---

# 40. Error Handling Design Principles

LocalMart's error-handling architecture follows these principles:

### Centralize application exception handling

Use `GlobalExceptionHandler` rather than repeating the same handling logic in every controller.

### Keep business errors in services

Services should determine whether an operation is valid.

### Keep HTTP concerns in the web layer

Services should not need to construct complete HTTP responses for every business rule.

### Protect internal information

Do not expose stack traces, secrets, database details, or credentials.

### Distinguish authentication from authorization

A user can be authenticated but still not have permission to perform an operation.

### Handle external failures explicitly

External providers can fail independently of LocalMart.

### Preserve transaction consistency

A failed multi-step database operation should not leave invalid partial state.

### Provide predictable API responses

The frontend should be able to interpret error responses consistently.

---

# 41. Complete Error Lifecycle

A typical LocalMart error can therefore follow this lifecycle:

```text
1. Client sends request
          |
          v
2. Security filters process request
          |
          v
3. Controller receives request
          |
          v
4. Service executes business logic
          |
          v
5. Repository / external service is called
          |
          X
6. Failure occurs
          |
          v
7. Exception propagates
          |
          v
8. GlobalExceptionHandler processes it
          |
          v
9. HTTP status + safe error response created
          |
          v
10. Frontend receives response
          |
          v
11. Frontend displays appropriate message
```

---

# 42. Debugging an Error in LocalMart

When debugging a backend failure, the recommended path is to trace the request from the outside inward:

```text
Frontend request
      ↓
HTTP endpoint
      ↓
Controller
      ↓
Service
      ↓
Repository / external service
      ↓
Exception
      ↓
GlobalExceptionHandler
      ↓
HTTP response
```

For example, if:

```text
POST /api/orders/calculate-delivery-fee
```

returns `400`, investigate:

```text
Request body
      ↓
DeliveryFeeRequest
      ↓
OrderController
      ↓
OrderService
      ↓
Store/address lookup
      ↓
Distance calculation
      ↓
Validation/business rule
      ↓
Exception
      ↓
GlobalExceptionHandler
```

This is much more reliable than changing the frontend blindly.

---

# 43. Source Components

The primary error-handling component is:

```text
src/main/java/com/localmart/localmartbackend/exception/
└── GlobalExceptionHandler.java
```

It interacts conceptually with:

```text
controller/
service/
security/
repository/
```

and the Spring MVC/Security infrastructure.

---

# 44. Final Architecture

The LocalMart error-handling architecture can be summarized as:

```text
                       LOCALMART
                           |
                    Incoming HTTP Request
                           |
                           v
                  +-------------------+
                  | Security Filters  |
                  +-------------------+
                           |
                           v
                    +-------------+
                    | Controller  |
                    +-------------+
                           |
                           v
                    +-------------+
                    |   Service   |
                    +-------------+
                      /     |     \
                     /      |      \
                    v       v       v
              Database   External  Business
                          APIs      Rules
                    \       |       /
                     \      |      /
                      +-----+-----+
                            |
                       Exception
                            |
                            v
                +------------------------+
                | GlobalExceptionHandler |
                +------------------------+
                            |
                            v
                  HTTP Error Response
                            |
                            v
                       Frontend
```

The key architectural principle is:

> **LocalMart separates error detection from error presentation: business and infrastructure layers detect failures, while centralized web-layer handling converts application exceptions into safe, consistent HTTP responses.**
