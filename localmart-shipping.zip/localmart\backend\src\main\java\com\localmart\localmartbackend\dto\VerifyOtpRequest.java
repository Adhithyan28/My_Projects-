
package com.localmart.localmartbackend.dto;

public class VerifyOtpRequest {

    private String login;
    private String otp;
    private String channel;

    public VerifyOtpRequest() {
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getOtp() {
        return otp;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }
}

