package com.localmart.localmartbackend.controller;

import com.localmart.localmartbackend.dto.StoreResponse;
import com.localmart.localmartbackend.entity.DeliveryPartner;
import com.localmart.localmartbackend.entity.Role;
import com.localmart.localmartbackend.entity.StoreDetails;
import com.localmart.localmartbackend.entity.User;
import com.localmart.localmartbackend.entity.VehicleDetails;
import com.localmart.localmartbackend.repository.RoleRepository;
import com.localmart.localmartbackend.repository.StoreDetailsRepository;
import com.localmart.localmartbackend.service.AdminDataService;
import com.localmart.localmartbackend.service.StoreService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/admin/data")
@CrossOrigin(origins = {
        "http://localhost:5173",
        "http://localhost:5174",
        "http://localhost:5175"
})
public class AdminDataController {

    private final AdminDataService adminDataService;
    private final StoreService storeService;
    private final StoreDetailsRepository storeDetailsRepository;
    private final RoleRepository roleRepository;

    public AdminDataController(
            AdminDataService adminDataService,
            StoreService storeService,
            StoreDetailsRepository storeDetailsRepository,
            RoleRepository roleRepository
    ) {
        this.adminDataService = adminDataService;
        this.storeService = storeService;
        this.storeDetailsRepository = storeDetailsRepository;
        this.roleRepository = roleRepository;
    }


    /* =====================================================
       CUSTOMERS
       ===================================================== */

    @GetMapping("/customers")
    public ResponseEntity<List<Map<String, Object>>> getCustomers() {

        List<User> customers =
                adminDataService.getCustomers();

        List<Map<String, Object>> response =
                new ArrayList<>();

        for (User customer : customers) {

            Map<String, Object> data =
                    new HashMap<>();

            data.put("userId", customer.getUserId());
            data.put("firstName", customer.getFirstName());
            data.put("lastName", customer.getLastName());
            data.put("email", customer.getEmail());
            data.put("phone", customer.getPhone());
            data.put("accountStatus", customer.getAccountStatus());
            data.put("createdAt", customer.getCreatedAt());

            response.add(data);
        }

        return ResponseEntity.ok(response);
    }


    /* =====================================================
       BLOCK CUSTOMER / STORE OWNER / DELIVERY PARTNER
       ===================================================== */

    @PutMapping("/users/{userId}/block")
    public ResponseEntity<Map<String, Object>> blockUser(
            @PathVariable Long userId
    ) {

        User user =
                adminDataService.updateUserAccountStatus(
                        userId,
                        3
                );

        Map<String, Object> response =
                new HashMap<>();

        response.put(
                "userId",
                user.getUserId()
        );

        response.put(
                "accountStatus",
                user.getAccountStatus()
        );

        return ResponseEntity.ok(response);
    }


    /* =====================================================
       UNBLOCK CUSTOMER / STORE OWNER / DELIVERY PARTNER
       ===================================================== */

    @PutMapping("/users/{userId}/unblock")
    public ResponseEntity<Map<String, Object>> unblockUser(
            @PathVariable Long userId
    ) {

        User user =
                adminDataService.updateUserAccountStatus(
                        userId,
                        1
                );

        Map<String, Object> response =
                new HashMap<>();

        response.put(
                "userId",
                user.getUserId()
        );

        response.put(
                "accountStatus",
                user.getAccountStatus()
        );

        return ResponseEntity.ok(response);
    }


    /* =====================================================
       STORES
       ===================================================== */

    @GetMapping("/stores")
    public ResponseEntity<List<Map<String, Object>>> getStores() {

        List<StoreResponse> stores =
                storeService.getAllStores();

        List<Map<String, Object>> response =
                new ArrayList<>();

        for (StoreResponse store : stores) {

            StoreDetails storeDetails =
                    storeDetailsRepository
                            .findById(store.getStoreId())
                            .orElse(null);

            if (storeDetails == null) {
                continue;
            }

            Long userId =
                    storeDetails.getUserId();

            User owner =
                    null;

            try {

                owner =
                        adminDataService
                                .getCustomers()
                                .stream()
                                .filter(
                                        user ->
                                                user.getUserId()
                                                        .equals(userId)
                                )
                                .findFirst()
                                .orElse(null);

            } catch (Exception ignored) {
                // Store owner is not a customer.
            }

            /*
             * Store owner is role 2, so fetch directly
             * through the user repository is preferable.
             *
             * We therefore use the role to identify the
             * owner and retrieve status below.
             */

            Map<String, Object> data =
                    new HashMap<>();

            data.put(
                    "storeId",
                    store.getStoreId()
            );

            data.put(
                    "storeName",
                    store.getStoreName()
            );

            data.put(
                    "businessType",
                    store.getBusinessType()
            );

            data.put(
                    "city",
                    store.getCity()
            );

            data.put(
                    "state",
                    store.getState()
            );

            data.put(
                    "latitude",
                    store.getLatitude()
            );

            data.put(
                    "longitude",
                    store.getLongitude()
            );

            data.put(
                    "userId",
                    userId
            );

            /*
             * The status is retrieved from the user's
             * account through the store owner's user ID.
             */
            Role role =
                    roleRepository
                            .findByUserId(userId)
                            .orElse(null);

            if (role != null
                    && role.getRole() == 2) {

                /*
                 * The actual account status is supplied
                 * through the helper below.
                 */
                data.put(
                        "accountStatus",
                        getUserAccountStatus(userId)
                );

            } else {

                data.put(
                        "accountStatus",
                        1
                );
            }

            response.add(data);
        }

        return ResponseEntity.ok(response);
    }


    /* =====================================================
       DELIVERY PARTNERS
       ===================================================== */

    @GetMapping("/delivery-partners")
    public ResponseEntity<List<Map<String, Object>>>
    getDeliveryPartners() {

        List<DeliveryPartner> partners =
                adminDataService.getDeliveryPartners();

        List<User> deliveryPartnerUsers =
                adminDataService.getDeliveryPartnerUsers();

        List<Map<String, Object>> response =
                new ArrayList<>();

        for (DeliveryPartner partner : partners) {

            User user =
                    deliveryPartnerUsers
                            .stream()
                            .filter(
                                    item ->
                                            item.getUserId()
                                                    .equals(
                                                            partner.getUserId()
                                                    )
                            )
                            .findFirst()
                            .orElse(null);

            if (user == null) {
                continue;
            }

            VehicleDetails vehicle =
                    adminDataService.getVehicle(
                            partner.getVehicleId()
                    );

            Map<String, Object> data =
                    new HashMap<>();

            data.put(
                    "userId",
                    user.getUserId()
            );

            data.put(
                    "firstName",
                    user.getFirstName()
            );

            data.put(
                    "lastName",
                    user.getLastName()
            );

            data.put(
                    "email",
                    user.getEmail()
            );

            data.put(
                    "phone",
                    user.getPhone()
            );

            data.put(
                    "accountStatus",
                    user.getAccountStatus()
            );

            data.put(
                    "createdAt",
                    user.getCreatedAt()
            );

            data.put(
                    "drivingLicenceNumber",
                    partner.getDrivingLicenceNumber()
            );

            data.put(
                    "vehicleId",
                    partner.getVehicleId()
            );

            if (vehicle != null) {

                data.put(
                        "vehicleType",
                        vehicle.getVehicleType()
                );

                data.put(
                        "vehicleNumber",
                        vehicle.getVehicleNumber()
                );

            } else {

                data.put(
                        "vehicleType",
                        null
                );

                data.put(
                        "vehicleNumber",
                        null
                );
            }

            response.add(data);
        }

        return ResponseEntity.ok(response);
    }


    /* =====================================================
       GET USER ACCOUNT STATUS
       ===================================================== */

    private Integer getUserAccountStatus(
            Long userId
    ) {

        return adminDataService
                .getUserAccountStatus(userId);
    }
}
