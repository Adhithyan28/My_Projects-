
        package com.localmart.localmartbackend.smsotp.model;

import java.time.LocalDateTime;

public class SmsOtpSession {

    private final String mobileNumber;

    private final String verificationId;

    private final LocalDateTime createdAt;

    private final LocalDateTime expiresAt;

    private boolean verified;

    public SmsOtpSession(
            String mobileNumber,
            String verificationId,
            LocalDateTime createdAt,
            LocalDateTime expiresAt) {

        this.mobileNumber = mobileNumber;
        this.verificationId = verificationId;
        this.createdAt = createdAt;
        this.expiresAt = expiresAt;
        this.verified = false;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public String getVerificationId() {
        return verificationId;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public LocalDateTime getExpiresAt() {
        return expiresAt;
    }

    public boolean isVerified() {
        return verified;
    }

    public void setVerified(boolean verified) {
        this.verified = verified;
    }

    public boolean isExpired() {
        return LocalDateTime.now().isAfter(expiresAt);
    }
}

