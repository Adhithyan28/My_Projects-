package com.localmart.localmartbackend.service;

import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdTokenVerifier;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.gson.GsonFactory;
import com.localmart.localmartbackend.config.GoogleAuthProperties;
import org.springframework.stereotype.Service;

import java.util.Collections;

@Service
public class GoogleTokenVerificationService {

    private final GoogleAuthProperties googleAuthProperties;

    private final GoogleIdTokenVerifier verifier;

    public GoogleTokenVerificationService(
            GoogleAuthProperties googleAuthProperties) {

        this.googleAuthProperties = googleAuthProperties;

        this.verifier = new GoogleIdTokenVerifier.Builder(
                new NetHttpTransport(),
                GsonFactory.getDefaultInstance()
        )
                .setAudience(
                        Collections.singletonList(
                                googleAuthProperties.getClientId()
                        )
                )
                .build();
    }

    public GoogleUserInfo verify(String credential) {

        try {

            System.out.println();
            System.out.println("==================================================");
            System.out.println("              GOOGLE AUTHENTICATION");
            System.out.println("==================================================");

            // ==================================================
            // CHECK CREDENTIAL
            // ==================================================

            if (credential == null || credential.isBlank()) {

                System.out.println(
                        "ERROR: Google credential is NULL or EMPTY"
                );

                throw new RuntimeException(
                        "Google credential is missing"
                );
            }

            System.out.println(
                    "Google credential received: YES"
            );

            // ==================================================
            // VERIFY GOOGLE ID TOKEN
            // ==================================================

            System.out.println(
                    "Verifying Google ID token..."
            );

            GoogleIdToken idToken =
                    verifier.verify(credential);

            if (idToken == null) {

                System.out.println(
                        "ERROR: Google ID token verification failed"
                );

                throw new RuntimeException(
                        "Invalid Google ID token"
                );
            }

            System.out.println(
                    "Google ID token verified successfully."
            );

            // ==================================================
            // GET GOOGLE PAYLOAD
            // ==================================================

            GoogleIdToken.Payload payload =
                    idToken.getPayload();

            System.out.println(
                    "Google payload received successfully."
            );

            // ==================================================
            // GET GOOGLE ACCOUNT INFORMATION
            // ==================================================

            String googleId =
                    payload.getSubject();

            String email =
                    payload.getEmail();

            Boolean emailVerified =
                    payload.getEmailVerified();

            String name =
                    (String) payload.get("name");

            String givenName =
                    (String) payload.get("given_name");

            String familyName =
                    (String) payload.get("family_name");

            String picture =
                    (String) payload.get("picture");

            // ==================================================
            // DISPLAY GOOGLE ACCOUNT ID
            // ==================================================

            System.out.println();
            System.out.println("==================================================");
            System.out.println("           GOOGLE ACCOUNT INFORMATION");
            System.out.println("==================================================");

            System.out.println();
            System.out.println("GOOGLE ACCOUNT ID (SUB)");
            System.out.println("------------------------------------------");
            System.out.println(googleId);

            System.out.println();
            System.out.println("GOOGLE EMAIL");
            System.out.println("------------------------------------------");
            System.out.println(email);

            System.out.println();
            System.out.println("GOOGLE EMAIL VERIFIED");
            System.out.println("------------------------------------------");
            System.out.println(emailVerified);

            System.out.println();
            System.out.println("GOOGLE NAME");
            System.out.println("------------------------------------------");
            System.out.println(name);

            System.out.println();
            System.out.println("GOOGLE GIVEN NAME");
            System.out.println("------------------------------------------");
            System.out.println(givenName);

            System.out.println();
            System.out.println("GOOGLE FAMILY NAME");
            System.out.println("------------------------------------------");
            System.out.println(familyName);

            System.out.println();
            System.out.println("==================================================");

            // ==================================================
            // VALIDATE GOOGLE ID
            // ==================================================

            if (googleId == null || googleId.isBlank()) {

                System.out.println(
                        "ERROR: Google Account ID (SUB) is NULL or EMPTY"
                );

                throw new RuntimeException(
                        "Google account ID could not be obtained"
                );
            }

            // ==================================================
            // VALIDATE EMAIL
            // ==================================================

            if (email == null || email.isBlank()) {

                System.out.println(
                        "ERROR: Google email is NULL or EMPTY"
                );

                throw new RuntimeException(
                        "Google account does not contain an email"
                );
            }

            // ==================================================
            // VALIDATE EMAIL VERIFICATION
            // ==================================================

            if (!Boolean.TRUE.equals(emailVerified)) {

                System.out.println(
                        "ERROR: Google email is not verified"
                );

                throw new RuntimeException(
                        "Google email is not verified"
                );
            }

            // ==================================================
            // SUCCESS
            // ==================================================

            System.out.println();
            System.out.println("==================================================");
            System.out.println("      GOOGLE AUTHENTICATION SUCCESSFUL");
            System.out.println("==================================================");
            System.out.println();
            System.out.println(
                    "Google Account ID obtained successfully."
            );
            System.out.println();
            System.out.println("==================================================");
            System.out.println();

            return new GoogleUserInfo(
                    googleId,
                    email,
                    name,
                    givenName,
                    familyName,
                    picture
            );

        } catch (Exception e) {

            System.out.println();
            System.out.println("==================================================");
            System.out.println("       GOOGLE AUTHENTICATION ERROR");
            System.out.println("==================================================");

            System.out.println(
                    "ERROR: " + e.getMessage()
            );

            System.out.println("==================================================");
            System.out.println();

            throw new RuntimeException(
                    "Google authentication failed",
                    e
            );
        }
    }

    public static class GoogleUserInfo {

        private final String googleId;

        private final String email;

        private final String name;

        private final String givenName;

        private final String familyName;

        private final String picture;

        public GoogleUserInfo(
                String googleId,
                String email,
                String name,
                String givenName,
                String familyName,
                String picture) {

            this.googleId = googleId;
            this.email = email;
            this.name = name;
            this.givenName = givenName;
            this.familyName = familyName;
            this.picture = picture;
        }

        public String getGoogleId() {
            return googleId;
        }

        public String getEmail() {
            return email;
        }

        public String getName() {
            return name;
        }

        public String getGivenName() {
            return givenName;
        }

        public String getFamilyName() {
            return familyName;
        }

        public String getPicture() {
            return picture;
        }
    }
}