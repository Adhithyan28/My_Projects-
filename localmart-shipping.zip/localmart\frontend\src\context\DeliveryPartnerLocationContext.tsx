
import {
    createContext,
    useContext,
    useEffect,
    useRef,
    useState,
} from "react"

import type {
    ReactNode
} from "react"

import { useAuth } from "./AuthContext"


interface DeliveryPartnerLocationContextType {

    isTracking: boolean

    latitude: number | null

    longitude: number | null

    gpsStatus: string

    availabilityStatus:
        | "OFFLINE"
        | "AVAILABLE"

    startTracking: () => void

    stopTracking: () => void

    goOnline: () => Promise<boolean>

    goOffline: () => Promise<boolean>
}


const DeliveryPartnerLocationContext =
    createContext<
        DeliveryPartnerLocationContextType | undefined
    >(undefined)


interface ProviderProps {
    children: ReactNode
}


export function DeliveryPartnerLocationProvider({
                                                    children,
                                                }: ProviderProps) {

    const { user } = useAuth()


    const [isTracking, setIsTracking] =
        useState(false)


    const [latitude, setLatitude] =
        useState<number | null>(null)


    const [longitude, setLongitude] =
        useState<number | null>(null)


    const [gpsStatus, setGpsStatus] =
        useState(
            "GPS tracking is stopped"
        )


    const [availabilityStatus, setAvailabilityStatus] =
        useState<
            "OFFLINE" | "AVAILABLE"
        >("OFFLINE")


    const watchIdRef =
        useRef<number | null>(null)


    /*
     * Stores the interval used to periodically
     * refresh the GPS location.
     *
     * watchPosition() does not guarantee that
     * a location update will happen when the
     * delivery partner is standing still.
     */
    const refreshIntervalRef =
        useRef<number | null>(null)


    const userTokenRef =
        useRef<string | null>(null)


    useEffect(() => {

        userTokenRef.current =
            user?.token ?? null

    }, [user?.token])


    /*
     * Safely read backend response.
     */
    const readResponse = async (
        response: Response
    ) => {

        const text =
            await response.text()

        if (!text) {
            return {}
        }

        try {

            return JSON.parse(text)

        } catch {

            return {
                message: text,
            }
        }
    }


    /*
     * Send GPS location to backend.
     *
     * This updates:
     *
     * latitude
     * longitude
     * updatedAt
     */
    const sendLocation = async (
        currentLatitude: number,
        currentLongitude: number
    ) => {

        const token =
            userTokenRef.current

        if (!token) {
            return
        }


        try {

            const response =
                await fetch(
                    "http://localhost:8080/api/delivery-partner/location",
                    {
                        method: "POST",

                        headers: {

                            "Content-Type":
                                "application/json",

                            "Authorization":
                                `Bearer ${token}`,

                        },

                        body: JSON.stringify({

                            latitude:
                            currentLatitude,

                            longitude:
                            currentLongitude,

                        }),

                    }
                )


            const data =
                await readResponse(
                    response
                )


            if (!response.ok) {

                throw new Error(
                    data.message ||
                    "Failed to update location"
                )
            }


            setLatitude(
                currentLatitude
            )

            setLongitude(
                currentLongitude
            )


            setGpsStatus(
                "GPS location is being updated"
            )

        } catch (error) {

            console.error(
                "Location update error:",
                error
            )


            setGpsStatus(
                "Unable to update GPS location"
            )

        }

    }


    /*
     * Periodically refresh GPS location.
     *
     * IMPORTANT:
     *
     * navigator.geolocation.watchPosition()
     * may not fire when the delivery partner
     * remains stationary.
     *
     * The backend checks updatedAt and requires
     * the GPS location to be fresh.
     *
     * Therefore we manually request the
     * current position every 60 seconds.
     */
    const refreshLocation = () => {

        if (!userTokenRef.current) {
            return
        }


        if (!navigator.geolocation) {
            return
        }


        navigator.geolocation.getCurrentPosition(

            (position) => {

                const currentLatitude =
                    position.coords.latitude

                const currentLongitude =
                    position.coords.longitude


                sendLocation(
                    currentLatitude,
                    currentLongitude
                )

            },

            (error) => {

                console.error(
                    "Periodic GPS refresh error:",
                    error
                )

            },

            {

                enableHighAccuracy: true,

                maximumAge: 30000,

                timeout: 15000,

            }

        )

    }


    /*
     * Start browser GPS tracking.
     *
     * IMPORTANT:
     *
     * This watcher belongs to the CONTEXT,
     * not to Dashboard/Home/Location pages.
     *
     * Therefore changing sidebar pages will
     * NOT stop tracking.
     */
    const startTracking = () => {

        if (!userTokenRef.current) {

            setGpsStatus(
                "You are not authenticated"
            )

            return
        }


        if (!navigator.geolocation) {

            setGpsStatus(
                "Geolocation is not supported by this browser"
            )

            return
        }


        /*
         * Prevent creating multiple GPS watchers.
         */
        if (watchIdRef.current !== null) {

            return
        }


        setGpsStatus(
            "Starting GPS tracking..."
        )


        const watchId =
            navigator.geolocation.watchPosition(

                (position) => {

                    const currentLatitude =
                        position.coords.latitude

                    const currentLongitude =
                        position.coords.longitude


                    setLatitude(
                        currentLatitude
                    )

                    setLongitude(
                        currentLongitude
                    )


                    setGpsStatus(
                        "GPS location is being updated"
                    )


                    /*
                     * Send every location update
                     * received from the browser.
                     */
                    sendLocation(
                        currentLatitude,
                        currentLongitude
                    )

                },

                (error) => {

                    console.error(
                        "GPS error:",
                        error
                    )


                    setGpsStatus(
                        "Unable to access GPS location"
                    )

                },

                {

                    enableHighAccuracy: true,

                    maximumAge: 10000,

                    timeout: 15000,

                }

            )


        watchIdRef.current =
            watchId


        setIsTracking(true)


        /*
         * Start periodic GPS refresh.
         *
         * This guarantees that updatedAt on the
         * backend is refreshed even if the user
         * does not move.
         */
        if (refreshIntervalRef.current === null) {

            refreshIntervalRef.current =
                window.setInterval(

                    refreshLocation,

                    60 * 1000

                )

        }

    }


    /*
     * Stop browser GPS tracking.
     */
    const stopTracking = () => {

        /*
         * Stop browser GPS watcher.
         */
        if (watchIdRef.current !== null) {

            navigator.geolocation.clearWatch(
                watchIdRef.current
            )

            watchIdRef.current = null

        }


        /*
         * Stop periodic GPS refresh.
         */
        if (refreshIntervalRef.current !== null) {

            window.clearInterval(
                refreshIntervalRef.current
            )

            refreshIntervalRef.current = null

        }


        setIsTracking(false)


        setGpsStatus(
            "GPS tracking is stopped"
        )

    }


    /*
     * Go ONLINE.
     *
     * Backend receives:
     *
     * AVAILABLE + current GPS
     */
    const goOnline = async (): Promise<boolean> => {

        const token =
            userTokenRef.current

        if (!token) {

            setGpsStatus(
                "You are not authenticated"
            )

            return false
        }


        if (!navigator.geolocation) {

            setGpsStatus(
                "Geolocation is not supported by this browser"
            )

            return false
        }


        setGpsStatus(
            "Getting your current location..."
        )


        return new Promise(
            (resolve) => {

                navigator.geolocation.getCurrentPosition(

                    async (position) => {

                        const currentLatitude =
                            position.coords.latitude

                        const currentLongitude =
                            position.coords.longitude


                        setLatitude(
                            currentLatitude
                        )

                        setLongitude(
                            currentLongitude
                        )


                        try {

                            const response =
                                await fetch(
                                    "http://localhost:8080/api/delivery-partner/availability",
                                    {

                                        method: "POST",

                                        headers: {

                                            "Content-Type":
                                                "application/json",

                                            "Authorization":
                                                `Bearer ${token}`,

                                        },

                                        body: JSON.stringify({

                                            status:
                                                "AVAILABLE",

                                            latitude:
                                            currentLatitude,

                                            longitude:
                                            currentLongitude,

                                        }),

                                    }
                                )


                            const data =
                                await readResponse(
                                    response
                                )


                            if (!response.ok) {

                                throw new Error(
                                    data.message ||
                                    "Unable to go online"
                                )

                            }


                            setAvailabilityStatus(
                                "AVAILABLE"
                            )


                            setGpsStatus(
                                "GPS tracking is active"
                            )


                            /*
                             * Start the persistent GPS watcher
                             * and the 60-second refresh timer.
                             */
                            startTracking()


                            resolve(true)

                        } catch (error) {

                            console.error(
                                "Online status error:",
                                error
                            )


                            setGpsStatus(
                                error instanceof Error
                                    ? error.message
                                    : "Unable to go online"
                            )


                            resolve(false)

                        }

                    },

                    (error) => {

                        console.error(
                            "Initial GPS error:",
                            error
                        )


                        setGpsStatus(
                            "GPS permission/location unavailable"
                        )


                        resolve(false)

                    },

                    {

                        enableHighAccuracy: true,

                        timeout: 15000,

                        maximumAge: 0,

                    }

                )

            }
        )

    }


    /*
     * Go OFFLINE.
     */
    const goOffline = async (): Promise<boolean> => {

        const token =
            userTokenRef.current

        if (!token) {

            setGpsStatus(
                "You are not authenticated"
            )

            return false
        }


        try {

            const response =
                await fetch(
                    "http://localhost:8080/api/delivery-partner/availability",
                    {

                        method: "POST",

                        headers: {

                            "Content-Type":
                                "application/json",

                            "Authorization":
                                `Bearer ${token}`,

                        },

                        body: JSON.stringify({

                            status:
                                "OFFLINE",

                        }),

                    }
                )


            const data =
                await readResponse(
                    response
                )


            if (!response.ok) {

                throw new Error(
                    data.message ||
                    "Unable to go offline"
                )

            }


            /*
             * Only stop GPS after backend
             * successfully accepts OFFLINE.
             */
            stopTracking()


            setAvailabilityStatus(
                "OFFLINE"
            )


            setGpsStatus(
                "GPS tracking is stopped"
            )


            return true

        } catch (error) {

            console.error(
                "Offline status error:",
                error
            )


            setGpsStatus(
                error instanceof Error
                    ? error.message
                    : "Unable to go offline"
            )


            return false

        }

    }


    /*
     * Cleanup ONLY when the entire provider
     * is destroyed.
     *
     * Changing Dashboard pages will NOT
     * destroy this provider.
     */
    useEffect(() => {

        return () => {

            /*
             * Stop browser GPS watcher.
             */
            if (watchIdRef.current !== null) {

                navigator.geolocation.clearWatch(
                    watchIdRef.current
                )

                watchIdRef.current = null

            }


            /*
             * Stop periodic GPS refresh timer.
             */
            if (refreshIntervalRef.current !== null) {

                window.clearInterval(
                    refreshIntervalRef.current
                )

                refreshIntervalRef.current = null

            }

        }

    }, [])


    return (

        <DeliveryPartnerLocationContext.Provider
            value={{

                isTracking,

                latitude,

                longitude,

                gpsStatus,

                availabilityStatus,

                startTracking,

                stopTracking,

                goOnline,

                goOffline,

            }}
        >

            {children}

        </DeliveryPartnerLocationContext.Provider>

    )

}


export function useDeliveryPartnerLocation() {

    const context =
        useContext(
            DeliveryPartnerLocationContext
        )


    if (!context) {

        throw new Error(
            "useDeliveryPartnerLocation must be used inside DeliveryPartnerLocationProvider"
        )

    }


    return context

}
