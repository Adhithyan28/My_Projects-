
import { useEffect, useState } from "react"
import { useAuth } from "../../context/AuthContext"

type BackendOrderStatus =
    | "PLACED"
    | "CONFIRMED"
    | "PREPARING"
    | "READY_FOR_PICKUP"
    | "CANCELLED"

type OrderStatus =
    | "New"
    | "Confirmed"
    | "Preparing"
    | "Ready for Delivery"
    | "Cancelled"

interface BackendOrderItem {
    orderItemId?: number
    orderId?: number
    productId: number
    productName: string
    unit: string
    quantity: number
    unitPrice: number
    totalPrice: number
}

interface BackendOrder {
    orderId: number
    orderNumber: string
    customerId: number
    storeId: number
    subtotal: number
    deliveryFee: number
    total: number
    paymentMethod: string
    paymentStatus: string
    orderStatus: BackendOrderStatus
    deliveryName: string
    deliveryPhone: string
    deliveryAddress: string
    deliveryCity: string
    deliveryPincode: string
    createdAt: string
    updatedAt: string
    items: BackendOrderItem[]
}

interface Order {
    id: string
    orderId: number
    customer: string
    phone: string
    items: string
    amount: number
    subtotal: number
    deliveryFee: number
    date: string
    status: OrderStatus
    backendStatus: BackendOrderStatus
    paymentMethod: string
    paymentStatus: string
    deliveryAddress: string
    deliveryCity: string
    deliveryPincode: string
    orderItems: BackendOrderItem[]
}

function StoreOwnerOrders() {

    const { user } = useAuth()

    const token = user?.token

    const [orders, setOrders] = useState<Order[]>([])

    const [selectedOrder, setSelectedOrder] =
        useState<Order | null>(null)

    const [activeFilter, setActiveFilter] =
        useState<"All" | OrderStatus>("All")

    const [loading, setLoading] = useState(true)

    const [error, setError] = useState("")

    const [updatingOrderId, setUpdatingOrderId] =
        useState<number | null>(null)

    const API_BASE_URL = "http://localhost:8080"

    /*
     * ============================================================
     * STATUS CONVERSION
     * ============================================================
     */

    const getDisplayStatus = (
        status: BackendOrderStatus
    ): OrderStatus => {

        switch (status) {

            case "PLACED":
                return "New"

            case "CONFIRMED":
                return "Confirmed"

            case "PREPARING":
                return "Preparing"

            case "READY_FOR_PICKUP":
                return "Ready for Delivery"

            case "CANCELLED":
                return "Cancelled"

            default:
                return "New"
        }
    }

    /*
     * ============================================================
     * DATE FORMAT
     * ============================================================
     */

    const formatDate = (dateString: string) => {

        if (!dateString) {
            return "-"
        }

        const date = new Date(dateString)

        if (Number.isNaN(date.getTime())) {
            return dateString
        }

        return date.toLocaleDateString(
            "en-IN",
            {
                day: "2-digit",
                month: "short",
                year: "numeric",
            }
        )
    }

    /*
     * ============================================================
     * MAP BACKEND ORDER
     * ============================================================
     */

    const mapBackendOrder = (
        backendOrder: BackendOrder
    ): Order => {

        const itemSummary =
            backendOrder.items
                ?.map(
                    (item) =>
                        `${item.productName} × ${item.quantity}`
                )
                .join(", ") || "No items"

        return {
            id:
                backendOrder.orderNumber ||
                `#LM${backendOrder.orderId}`,

            orderId:
                backendOrder.orderId,

            customer:
                backendOrder.deliveryName ||
                "Customer",

            phone:
                backendOrder.deliveryPhone ||
                "-",

            items:
                itemSummary,

            amount:
                Number(backendOrder.total || 0),

            subtotal:
                Number(backendOrder.subtotal || 0),

            deliveryFee:
                Number(backendOrder.deliveryFee || 0),

            date:
                formatDate(
                    backendOrder.createdAt
                ),

            status:
                getDisplayStatus(
                    backendOrder.orderStatus
                ),

            backendStatus:
                backendOrder.orderStatus,

            paymentMethod:
                backendOrder.paymentMethod ||
                "-",

            paymentStatus:
                backendOrder.paymentStatus ||
                "-",

            deliveryAddress:
                backendOrder.deliveryAddress ||
                "-",

            deliveryCity:
                backendOrder.deliveryCity ||
                "-",

            deliveryPincode:
                backendOrder.deliveryPincode ||
                "-",

            orderItems:
                backendOrder.items || [],
        }
    }

    /*
     * ============================================================
     * FETCH STORE OWNER ORDERS
     * ============================================================
     */

    const fetchOrders = async () => {

        try {

            setLoading(true)
            setError("")

            const headers: HeadersInit = {}

            if (token) {
                headers.Authorization =
                    `Bearer ${token}`
            }

            const response =
                await fetch(
                    `${API_BASE_URL}/api/store-owner/orders`,
                    {
                        method: "GET",
                        headers,
                    }
                )

            if (!response.ok) {

                const message =
                    await response.text()

                throw new Error(
                    message ||
                    "Failed to load orders."
                )
            }

            const data: BackendOrder[] =
                await response.json()

            const mappedOrders =
                data.map(
                    mapBackendOrder
                )

            setOrders(
                mappedOrders
            )

        } catch (error) {

            console.error(
                "Failed to fetch store owner orders:",
                error
            )

            setError(
                error instanceof Error
                    ? error.message
                    : "Failed to load orders."
            )

        } finally {

            setLoading(false)
        }
    }

    useEffect(() => {

        fetchOrders()

    }, [token])

    /*
     * ============================================================
     * FILTER
     * ============================================================
     */

    const filteredOrders =
        activeFilter === "All"
            ? orders
            : orders.filter(
                (order) =>
                    order.status === activeFilter
            )

    /*
     * ============================================================
     * NEXT STATUS
     * ============================================================
     */

    const getNextStatus = (
        status: BackendOrderStatus
    ): BackendOrderStatus | null => {

        switch (status) {

            case "PLACED":
                return "CONFIRMED"

            case "CONFIRMED":
                return "PREPARING"

            case "PREPARING":
                return "READY_FOR_PICKUP"

            default:
                return null
        }
    }

    /*
     * ============================================================
     * UPDATE ORDER STATUS
     * ============================================================
     */

    const updateOrderStatus = async (
        order: Order
    ) => {

        const nextStatus =
            getNextStatus(
                order.backendStatus
            )

        if (!nextStatus) {
            return
        }

        try {

            setUpdatingOrderId(
                order.orderId
            )

            setError("")

            const headers: HeadersInit = {}

            if (token) {
                headers.Authorization =
                    `Bearer ${token}`
            }

            const response =
                await fetch(
                    `${API_BASE_URL}/api/store-owner/orders/${order.orderId}/status?status=${nextStatus}`,
{
    method: "PUT",
        headers,
}
)

if (!response.ok) {

    const message =
        await response.text()

    throw new Error(
        message ||
        "Failed to update order status."
    )
}

const updatedBackendOrder:
    BackendOrder =
    await response.json()

const updatedOrder =
    mapBackendOrder(
        updatedBackendOrder
    )

setOrders(
    (currentOrders) =>
        currentOrders.map(
            (currentOrder) =>
                currentOrder.orderId ===
                order.orderId
                    ? updatedOrder
                    : currentOrder
        )
)

setSelectedOrder(
    (currentOrder) =>
        currentOrder &&
        currentOrder.orderId ===
        order.orderId
            ? updatedOrder
            : currentOrder
)

} catch (error) {

    console.error(
        "Failed to update order status:",
        error
    )

    setError(
        error instanceof Error
            ? error.message
            : "Failed to update order status."
    )

} finally {

    setUpdatingOrderId(
        null
    )
}
}

/*
 * ============================================================
 * STATUS CSS CLASS
 * ============================================================
 */

const getStatusClass = (
    status: OrderStatus
) => {

    return status
        .toLowerCase()
        .replaceAll(" ", "-")
}

/*
 * ============================================================
 * PROGRESS
 * ============================================================
 */

const isProgressActive = (
    orderStatus: BackendOrderStatus,
    step: BackendOrderStatus
) => {

    const progressOrder:
        BackendOrderStatus[] = [
        "PLACED",
        "CONFIRMED",
        "PREPARING",
        "READY_FOR_PICKUP",
    ]

    const currentIndex =
        progressOrder.indexOf(
            orderStatus
        )

    const stepIndex =
        progressOrder.indexOf(
            step
        )

    if (orderStatus === "CANCELLED") {
        return false
    }

    return (
        currentIndex >= stepIndex
    )
}

/*
 * ============================================================
 * RENDER
 * ============================================================
 */

return (
    <div className="owner-page">

        <div className="owner-page-header">

            <div>

                <h1>
                    📋 Orders
                </h1>

                <p>
                    Manage customer orders and update their status.
                </p>

            </div>

        </div>

        {/* ERROR */}

        {error && (

            <div
                className="owner-card"
                style={{
                    marginBottom: "16px",
                    padding: "14px",
                }}
            >
                {error}
            </div>

        )}

        {/* ORDER FILTERS */}

        <section className="owner-card owner-order-filters">

            {[
                "All",
                "New",
                "Confirmed",
                "Preparing",
                "Ready for Delivery",
                "Cancelled",
            ].map((filter) => (

                <button
                    key={filter}
                    type="button"
                    className={
                        activeFilter === filter
                            ? "owner-filter active"
                            : "owner-filter"
                    }
                    onClick={() =>
                        setActiveFilter(
                            filter as
                                "All" |
                                OrderStatus
                        )
                    }
                >
                    {filter}
                </button>

            ))}

        </section>

        {/* ORDERS */}

        <section className="owner-card owner-orders-card">

            <div className="owner-table-wrapper">

                {loading ? (

                    <div
                        style={{
                            padding: "30px",
                            textAlign: "center",
                        }}
                    >
                        Loading orders...
                    </div>

                ) : filteredOrders.length === 0 ? (

                    <div
                        style={{
                            padding: "30px",
                            textAlign: "center",
                        }}
                    >
                        No orders found.
                    </div>

                ) : (

                    <table className="owner-orders-table">

                        <thead>

                        <tr>

                            <th>
                                Order ID
                            </th>

                            <th>
                                Customer
                            </th>

                            <th>
                                Items
                            </th>

                            <th>
                                Amount
                            </th>

                            <th>
                                Date
                            </th>

                            <th>
                                Status
                            </th>

                            <th>
                                Action
                            </th>

                        </tr>

                        </thead>

                        <tbody>

                        {filteredOrders.map(
                            (order) => (

                                <tr key={order.orderId}>

                                    <td>
                                        <strong>
                                            {order.id}
                                        </strong>
                                    </td>

                                    <td>
                                        {order.customer}
                                    </td>

                                    <td>
                                        {order.items}
                                    </td>

                                    <td>
                                        ₹{order.amount.toFixed(2)}
                                    </td>

                                    <td>
                                        {order.date}
                                    </td>

                                    <td>

                                            <span
                                                className={`owner-order-status ${getStatusClass(order.status)}`}
                                            >
                                                {order.status}
                                            </span>

                                    </td>

                                    <td>

                                        <button
                                            type="button"
                                            className="owner-view-button"
                                            onClick={() =>
                                                setSelectedOrder(
                                                    order
                                                )
                                            }
                                        >
                                            View
                                        </button>

                                    </td>

                                </tr>

                            )
                        )}

                        </tbody>

                    </table>

                )}

            </div>

        </section>

        {/* ORDER DETAILS */}

        {selectedOrder && (

            <div className="owner-modal-overlay">

                <div className="owner-modal">

                    <div className="owner-modal-header">

                        <div>

                            <h2>
                                {selectedOrder.id}
                            </h2>

                        </div>

                        <button
                            type="button"
                            className="owner-modal-close"
                            onClick={() =>
                                setSelectedOrder(null)
                            }
                        >
                            ✕
                        </button>

                    </div>

                    <div className="owner-modal-content">

                        <div className="owner-detail-row">

                                <span>
                                    Customer
                                </span>

                            <strong>
                                {selectedOrder.customer}
                            </strong>

                        </div>

                        <div className="owner-detail-row">

                                <span>
                                    Phone
                                </span>

                            <strong>
                                {selectedOrder.phone}
                            </strong>

                        </div>

                        <div className="owner-detail-row">

                                <span>
                                    Items
                                </span>

                            <strong>
                                {selectedOrder.items}
                            </strong>

                        </div>

                        <div className="owner-detail-row">

                                <span>
                                    Subtotal
                                </span>

                            <strong>
                                ₹{selectedOrder.subtotal.toFixed(2)}
                            </strong>

                        </div>

                        <div className="owner-detail-row">

                                <span>
                                    Delivery Fee
                                </span>

                            <strong>
                                ₹{selectedOrder.deliveryFee.toFixed(2)}
                            </strong>

                        </div>

                        <div className="owner-detail-row">

                                <span>
                                    Total
                                </span>

                            <strong>
                                ₹{selectedOrder.amount.toFixed(2)}
                            </strong>

                        </div>

                        <div className="owner-detail-row">

                                <span>
                                    Payment Method
                                </span>

                            <strong>
                                {selectedOrder.paymentMethod}
                            </strong>

                        </div>

                        <div className="owner-detail-row">

                                <span>
                                    Payment Status
                                </span>

                            <strong>
                                {selectedOrder.paymentStatus}
                            </strong>

                        </div>

                        <div className="owner-detail-row">

                                <span>
                                    Delivery Address
                                </span>

                            <strong>
                                {selectedOrder.deliveryAddress},{" "}
                                {selectedOrder.deliveryCity},{" "}
                                {selectedOrder.deliveryPincode}
                            </strong>

                        </div>

                        <div className="owner-detail-row">

                                <span>
                                    Current Status
                                </span>

                            <span
                                className={`owner-order-status ${getStatusClass(selectedOrder.status)}`}
                            >
                                    {selectedOrder.status}
                                </span>

                        </div>

                    </div>

                    {/* ORDER ITEMS */}

                    <div
                        className="owner-order-progress"
                        style={{
                            display: "block",
                        }}
                    >

                        <strong>
                            Order Items
                        </strong>

                        <div
                            style={{
                                marginTop: "12px",
                            }}
                        >

                            {selectedOrder.orderItems.map(
                                (item) => (

                                    <div
                                        key={
                                            `${selectedOrder.orderId}-${item.productId}`
                                        }
                                        className="owner-detail-row"
                                    >

                                            <span>
                                                {item.productName} ×{" "}
                                                {item.quantity}
                                            </span>

                                        <strong>
                                            ₹{Number(
                                            item.totalPrice
                                        ).toFixed(2)}
                                        </strong>

                                    </div>

                                )
                            )}

                        </div>

                    </div>

                    {/* ORDER PROGRESS */}

                    {selectedOrder.backendStatus !==
                        "CANCELLED" && (

                            <div className="owner-order-progress">

                                <div
                                    className={
                                        isProgressActive(
                                            selectedOrder.backendStatus,
                                            "PLACED"
                                        )
                                            ? "progress-step active"
                                            : "progress-step"
                                    }
                                >
                                    <span>
                                        1
                                    </span>
                                    New
                                </div>

                                <div
                                    className={
                                        isProgressActive(
                                            selectedOrder.backendStatus,
                                            "CONFIRMED"
                                        )
                                            ? "progress-step active"
                                            : "progress-step"
                                    }
                                >
                                    <span>
                                        2
                                    </span>
                                    Confirmed
                                </div>

                                <div
                                    className={
                                        isProgressActive(
                                            selectedOrder.backendStatus,
                                            "PREPARING"
                                        )
                                            ? "progress-step active"
                                            : "progress-step"
                                    }
                                >
                                    <span>
                                        3
                                    </span>
                                    Preparing
                                </div>

                                <div
                                    className={
                                        isProgressActive(
                                            selectedOrder.backendStatus,
                                            "READY_FOR_PICKUP"
                                        )
                                            ? "progress-step active"
                                            : "progress-step"
                                    }
                                >
                                    <span>
                                        4
                                    </span>
                                    Ready
                                </div>

                            </div>

                        )}

                    {/* ACTIONS */}

                    <div className="owner-modal-actions">

                        {getNextStatus(
                            selectedOrder.backendStatus
                        ) && (

                            <button
                                type="button"
                                className="owner-primary-button"
                                disabled={
                                    updatingOrderId ===
                                    selectedOrder.orderId
                                }
                                onClick={() =>
                                    updateOrderStatus(
                                        selectedOrder
                                    )
                                }
                            >

                                {updatingOrderId ===
                                selectedOrder.orderId
                                    ? "Updating..."
                                    : `Mark as ${getDisplayStatus(
                                        getNextStatus(
                                            selectedOrder.backendStatus
                                        )!
                                    )}`}

                            </button>

                        )}

                        <button
                            type="button"
                            className="owner-secondary-button"
                            onClick={() =>
                                setSelectedOrder(null)
                            }
                        >
                            Close
                        </button>

                    </div>

                </div>

            </div>

        )}

    </div>
)
}

export default StoreOwnerOrders
