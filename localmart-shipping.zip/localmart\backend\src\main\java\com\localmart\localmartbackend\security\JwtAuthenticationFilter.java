package com.localmart.localmartbackend.security;

import com.localmart.localmartbackend.service.UserSessionService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.List;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private final JwtService jwtService;
    private final UserSessionService userSessionService;

    public JwtAuthenticationFilter(
            JwtService jwtService,
            UserSessionService userSessionService) {

        this.jwtService = jwtService;
        this.userSessionService = userSessionService;
    }

    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain filterChain)
            throws ServletException, IOException {

        String authorizationHeader =
                request.getHeader("Authorization");

        System.out.println(
                "JWT FILTER -> "
                        + request.getMethod()
                        + " "
                        + request.getRequestURI()
        );

        System.out.println(
                "AUTHORIZATION HEADER PRESENT -> "
                        + (authorizationHeader != null)
        );

        /*
         * No Authorization header.
         *
         * This is allowed to continue because Spring Security
         * will decide whether the endpoint requires authentication.
         */
        if (authorizationHeader == null
                || !authorizationHeader.startsWith("Bearer ")) {

            System.out.println(
                    "JWT FILTER -> No Bearer token found"
            );

            filterChain.doFilter(request, response);
            return;
        }

        String token =
                authorizationHeader.substring(7);

        System.out.println(
                "JWT FILTER -> Bearer token received"
        );

        /*
         * --------------------------------------------------------
         * STEP 1: Validate JWT signature + expiration
         * --------------------------------------------------------
         */
        if (!jwtService.isTokenValid(token)) {

            System.out.println(
                    "JWT FILTER -> TOKEN INVALID"
            );

            filterChain.doFilter(request, response);
            return;
        }

        System.out.println(
                "JWT FILTER -> TOKEN VALID"
        );

        try {

            /*
             * ----------------------------------------------------
             * STEP 2: Extract user information from JWT
             * ----------------------------------------------------
             */

            Long userId =
                    jwtService.extractUserId(token);

            String role =
                    jwtService.extractRole(token);

            String sessionId =
                    jwtService.extractSessionId(token);

            System.out.println(
                    "JWT FILTER -> USER ID = "
                            + userId
            );

            System.out.println(
                    "JWT FILTER -> ROLE = "
                            + role
            );

            System.out.println(
                    "JWT FILTER -> SESSION ID PRESENT = "
                            + (sessionId != null
                            && !sessionId.isBlank())
            );

            /*
             * ----------------------------------------------------
             * LOGOUT REQUEST
             * ----------------------------------------------------
             *
             * Logout is special.
             *
             * We must allow the request to reach the logout
             * controller even if the server-side session has
             * already expired or has already been deleted.
             *
             * The logout controller will delete the session.
             */

            if (request.getRequestURI()
                    .equals("/api/users/logout")) {

                System.out.println(
                        "JWT FILTER -> LOGOUT REQUEST"
                );

                filterChain.doFilter(
                        request,
                        response
                );

                return;
            }

            /*
             * ----------------------------------------------------
             * STEP 3: Validate server-side session
             * ----------------------------------------------------
             *
             * JWT alone is NOT enough anymore.
             *
             * The JWT sessionId must match the active session
             * stored in the database.
             */

            boolean sessionValid =
                    userSessionService.isSessionValid(
                            userId,
                            sessionId
                    );

            if (!sessionValid) {

                System.out.println(
                        "JWT FILTER -> SESSION INVALID OR EXPIRED"
                );

                /*
                 * IMPORTANT:
                 *
                 * Do NOT create an authentication object.
                 *
                 * This means a logged-out or expired session
                 * cannot access protected endpoints even if
                 * the JWT itself has not expired yet.
                 */

                filterChain.doFilter(
                        request,
                        response
                );

                return;
            }

            System.out.println(
                    "JWT FILTER -> SESSION VALID"
            );

            /*
             * ----------------------------------------------------
             * STEP 4: Create Spring Security authentication
             * ----------------------------------------------------
             */

            UsernamePasswordAuthenticationToken authentication =
                    new UsernamePasswordAuthenticationToken(
                            userId,
                            null,
                            List.of(
                                    new SimpleGrantedAuthority(
                                            "ROLE_" + role
                                    )
                            )
                    );

            SecurityContextHolder
                    .getContext()
                    .setAuthentication(authentication);

            System.out.println(
                    "JWT FILTER -> AUTHENTICATION SET"
            );

            System.out.println(
                    "JWT AUTH SUCCESS -> userId="
                            + userId
                            + ", role="
                            + role
                            + ", authority=ROLE_"
                            + role
            );

        } catch (Exception e) {

            /*
             * JWT/session information could not be read.
             *
             * Do not authenticate the request.
             */

            SecurityContextHolder
                    .clearContext();

            System.out.println(
                    "JWT FILTER -> ERROR READING TOKEN: "
                            + e.getMessage()
            );
        }

        filterChain.doFilter(
                request,
                response
        );
    }
}