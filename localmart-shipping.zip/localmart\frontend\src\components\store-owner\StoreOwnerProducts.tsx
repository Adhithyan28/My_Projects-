import { useEffect, useState } from "react"
import { useAuth } from "../../context/AuthContext"

interface Product {
    id: number
    name: string
    category: string
    price: number
    stock: number
}

interface StoreDetails {
    storeName: string
    ownerName: string
    email: string
    mobile: string
    businessType: string
    gstNumber: string
    addressLine: string
    city: string
    state: string
    pincode: string
    storeId: number
}

interface BackendProduct {
    productId: number
    storeId: number
    productName: string
    category: string
    description: string | null
    price: number
    unit: string
    stockQuantity: number
    icon: string | null
    isAvailable: boolean
    createdAt: string
    updatedAt: string
}

interface StoreOwnerResponse {
    storeId: number
    firstName: string
    lastName: string
    ownerName: string
    email: string
    phone: string
    storeName: string
    businessType: string
    gstNumber: string | null
    addressLine: string
    city: string
    state: string
    pincode: string
    latitude: number
    longitude: number
}

const STORE_DETAILS_KEY = "localmart_store_owner_details"
const API_BASE_URL = "http://localhost:8080"

function StoreOwnerProducts() {

    const { user } = useAuth()

    const [products, setProducts] =
        useState<Product[]>([])

    const [storeDetails, setStoreDetails] =
        useState<StoreDetails | null>(null)

    const [search, setSearch] =
        useState("")

    const [showForm, setShowForm] =
        useState(false)

    const [editingProductId, setEditingProductId] =
        useState<number | null>(null)

    const [formData, setFormData] = useState({
        name: "",
        category: "",
        price: "",
        stock: ""
    })

    const [isLoading, setIsLoading] =
        useState(true)


    /* =========================================================
       LOCAL STORE DETAILS
    ========================================================= */

    const getLocalStoreDetails =
        (): StoreDetails | null => {

            const saved =
                localStorage.getItem(
                    STORE_DETAILS_KEY
                )

            if (!saved) {
                return null
            }

            try {
                return JSON.parse(saved)
            } catch {
                return null
            }
        }


    /* =========================================================
       STORE DETAILS VALIDATION
    ========================================================= */

    const isStoreDetailsComplete = () => {

        const details =
            storeDetails ||
            getLocalStoreDetails()

        if (!details) {
            return false
        }

        return Boolean(
            details.storeName?.trim() &&
            details.ownerName?.trim() &&
            details.email?.trim() &&
            details.mobile?.trim() &&
            details.businessType?.trim() &&
            details.gstNumber?.trim() &&
            details.addressLine?.trim() &&
            details.city?.trim() &&
            details.state?.trim() &&
            details.pincode?.trim()
        )
    }


    /* =========================================================
       BACKEND PRODUCT MAPPING
    ========================================================= */

    const mapBackendProduct = (
        product: BackendProduct
    ): Product => {

        return {
            id: product.productId,
            name: product.productName,
            category: product.category,
            price: Number(product.price),
            stock: product.stockQuantity
        }
    }


    /* =========================================================
       LOAD STORE + PRODUCTS
    ========================================================= */

    useEffect(() => {

        if (!user?.token) {
            setIsLoading(false)
            return
        }

        const loadStoreAndProducts =
            async () => {

                try {

                    const storeResponse =
                        await fetch(
                            `${API_BASE_URL}/api/store-owner/store`,
                            {
                                method: "GET",
                                headers: {
                                    Authorization:
                                        `Bearer ${user.token}`
                                }
                            }
                        )

                    if (!storeResponse.ok) {
                        throw new Error(
                            "Unable to load store details."
                        )
                    }

                    const storeData:
                        StoreOwnerResponse =
                        await storeResponse.json()

                    const details:
                        StoreDetails = {

                        storeName:
                        storeData.storeName,

                        ownerName:
                        storeData.ownerName,

                        email:
                        storeData.email,

                        mobile:
                        storeData.phone,

                        businessType:
                        storeData.businessType,

                        gstNumber:
                            storeData.gstNumber || "",

                        addressLine:
                        storeData.addressLine,

                        city:
                        storeData.city,

                        state:
                        storeData.state,

                        pincode:
                        storeData.pincode,

                        storeId:
                        storeData.storeId
                    }

                    setStoreDetails(details)

                    localStorage.setItem(
                        STORE_DETAILS_KEY,
                        JSON.stringify(details)
                    )


                    const productsResponse =
                        await fetch(
                            `${API_BASE_URL}/api/products/store/${storeData.storeId}`,
                            {
                                method: "GET",
                                headers: {
                                    Authorization:
                                        `Bearer ${user.token}`
                                }
                            }
                        )

                    if (!productsResponse.ok) {
                        throw new Error(
                            "Unable to load products."
                        )
                    }

                    const backendProducts:
                        BackendProduct[] =
                        await productsResponse.json()

                    setProducts(
                        backendProducts.map(
                            mapBackendProduct
                        )
                    )

                } catch (error) {

                    console.error(
                        "Error loading store products:",
                        error
                    )

                    alert(
                        "Unable to load store products."
                    )

                } finally {

                    setIsLoading(false)
                }
            }

        loadStoreAndProducts()

    }, [user?.token])


    /* =========================================================
       SEARCH
    ========================================================= */

    const filteredProducts =
        products.filter(product =>
            product.name
                .toLowerCase()
                .includes(
                    search.toLowerCase()
                )
        )


    /* =========================================================
       FORM INPUT
    ========================================================= */

    const handleInputChange = (
        e: React.ChangeEvent<
            HTMLInputElement |
            HTMLSelectElement
        >
    ) => {

        const { name, value } =
            e.target

        setFormData(prev => ({
            ...prev,
            [name]: value
        }))
    }


    /* =========================================================
       ADD PRODUCT
    ========================================================= */

    const handleAddProduct = () => {

        if (!isStoreDetailsComplete()) {

            alert(
                "Please complete and save all Store Details before adding a product."
            )

            return
        }

        setEditingProductId(null)

        setFormData({
            name: "",
            category: "",
            price: "",
            stock: ""
        })

        setShowForm(true)
    }


    /* =========================================================
       EDIT PRODUCT
    ========================================================= */

    const handleEditProduct = (
        product: Product
    ) => {

        if (!isStoreDetailsComplete()) {

            alert(
                "Please complete and save all Store Details before managing products."
            )

            return
        }

        setEditingProductId(
            product.id
        )

        setFormData({
            name: product.name,
            category: product.category,
            price:
                product.price.toString(),
            stock:
                product.stock.toString()
        })

        setShowForm(true)
    }


    /* =========================================================
       CANCEL
    ========================================================= */

    const handleCancel = () => {

        setShowForm(false)

        setEditingProductId(null)

        setFormData({
            name: "",
            category: "",
            price: "",
            stock: ""
        })
    }


    /* =========================================================
       SAVE PRODUCT
    ========================================================= */

    const handleSaveProduct =
        async () => {

            if (!isStoreDetailsComplete()) {

                alert(
                    "Please complete and save all Store Details first."
                )

                return
            }

            if (!storeDetails?.storeId) {

                alert(
                    "Store information could not be loaded."
                )

                return
            }

            if (!user?.token) {

                alert(
                    "Please login again."
                )

                return
            }

            if (
                !formData.name.trim() ||
                !formData.category.trim() ||
                !formData.price ||
                !formData.stock
            ) {

                alert(
                    "Please fill all product details."
                )

                return
            }

            const price =
                Number(formData.price)

            const stock =
                Number(formData.stock)

            if (
                Number.isNaN(price) ||
                Number.isNaN(stock) ||
                price < 0 ||
                stock < 0
            ) {

                alert(
                    "Price and stock must be valid positive values."
                )

                return
            }


            try {

                /* =================================================
                   UPDATE EXISTING PRODUCT
                ================================================= */

                if (
                    editingProductId !== null
                ) {

                    const response =
                        await fetch(
                            `${API_BASE_URL}/api/products/${editingProductId}`,
                            {
                                method: "PUT",

                                headers: {
                                    "Content-Type":
                                        "application/json",

                                    Authorization:
                                        `Bearer ${user.token}`
                                },

                                body:
                                    JSON.stringify({

                                        storeId:
                                        storeDetails.storeId,

                                        productName:
                                            formData.name.trim(),

                                        category:
                                            formData.category.trim(),

                                        description:
                                            null,

                                        price,

                                        unit:
                                            "piece",

                                        stockQuantity:
                                        stock,

                                        icon:
                                            null,

                                        isAvailable:
                                            true
                                    })
                            }
                        )

                    if (!response.ok) {

                        throw new Error(
                            "Product update failed."
                        )
                    }

                    const updatedProduct:
                        BackendProduct =
                        await response.json()

                    setProducts(prev =>
                        prev.map(product =>
                            product.id ===
                            editingProductId
                                ? mapBackendProduct(
                                    updatedProduct
                                )
                                : product
                        )
                    )

                    alert(
                        "Product updated successfully!"
                    )

                } else {

                    /* =================================================
                       CREATE NEW PRODUCT
                    ================================================= */

                    const response =
                        await fetch(
                            `${API_BASE_URL}/api/products`,
                            {
                                method: "POST",

                                headers: {
                                    "Content-Type":
                                        "application/json",

                                    Authorization:
                                        `Bearer ${user.token}`
                                },

                                body:
                                    JSON.stringify({

                                        storeId:
                                        storeDetails.storeId,

                                        productName:
                                            formData.name.trim(),

                                        category:
                                            formData.category.trim(),

                                        description:
                                            null,

                                        price,

                                        unit:
                                            "piece",

                                        stockQuantity:
                                        stock,

                                        icon:
                                            null,

                                        isAvailable:
                                            true
                                    })
                            }
                        )

                    if (!response.ok) {

                        throw new Error(
                            "Product creation failed."
                        )
                    }

                    const createdProduct:
                        BackendProduct =
                        await response.json()

                    setProducts(prev => [
                        ...prev,
                        mapBackendProduct(
                            createdProduct
                        )
                    ])

                    alert(
                        "Product added successfully!"
                    )
                }

                handleCancel()

            } catch (error) {

                console.error(
                    "Error saving product:",
                    error
                )

                alert(
                    "Unable to save product. Please try again."
                )
            }
        }


    /* =========================================================
       DELETE PRODUCT
    ========================================================= */

    const handleDeleteProduct =
        async (id: number) => {

            if (!isStoreDetailsComplete()) {

                alert(
                    "Please complete and save all Store Details first."
                )

                return
            }

            if (!user?.token) {

                alert(
                    "Please login again."
                )

                return
            }

            const product =
                products.find(
                    item => item.id === id
                )

            if (!product) {
                return
            }

            const confirmed =
                window.confirm(
                    `Are you sure you want to delete "${product.name}"?`
                )

            if (!confirmed) {
                return
            }


            try {

                const response =
                    await fetch(
                        `${API_BASE_URL}/api/products/${id}`,
                        {
                            method: "DELETE",

                            headers: {
                                Authorization:
                                    `Bearer ${user.token}`
                            }
                        }
                    )

                if (!response.ok) {

                    throw new Error(
                        "Product deletion failed."
                    )
                }

                setProducts(prev =>
                    prev.filter(
                        product =>
                            product.id !== id
                    )
                )

                alert(
                    "Product deleted successfully!"
                )

            } catch (error) {

                console.error(
                    "Error deleting product:",
                    error
                )

                alert(
                    "Unable to delete product. Please try again."
                )
            }
        }


    /* =========================================================
       STOCK STATUS
    ========================================================= */

    const getStockStatus =
        (stock: number) => {

            if (stock === 0) {

                return {
                    text: "Out of Stock",
                    className: "out-of-stock"
                }
            }

            if (stock <= 10) {

                return {
                    text: "Low Stock",
                    className: "low-stock"
                }

            }

            return {
                text: "In Stock",
                className: "in-stock"
            }
        }


    const storeDetailsComplete =
        isStoreDetailsComplete()


    /* =========================================================
       UI
    ========================================================= */

    return (
        <div className="owner-page">

            {/* =====================================================
                PAGE HEADER
            ===================================================== */}

            <div className="owner-page-header">

                <div className="owner-page-title-group">

                    <div className="owner-title-icon">

                    </div>

                    <div className="owner-page-title-content">

                        <h1>
                            📦 Products
                        </h1>

                        <p>
                            Manage the products available in your store.
                        </p>

                    </div>

                </div>


                <button
                    className="owner-primary-btn owner-add-product-btn"
                    onClick={handleAddProduct}
                >

                    <span className="owner-btn-icon">
                        ＋
                    </span>

                    <span>
                        Add Product
                    </span>

                </button>

            </div>


            {/* =====================================================
                STORE DETAILS WARNING
            ===================================================== */}

            {!storeDetailsComplete && (

                <div className="owner-section-card owner-warning-card">

                    <div className="owner-warning-content">

                        <div className="owner-warning-icon">
                            ⚠️
                        </div>

                        <div>

                            <h2>
                                Store Details Required
                            </h2>

                            <p>
                                Complete and save all your store
                                information before adding or managing
                                products.
                            </p>

                        </div>

                    </div>

                </div>
            )}


            {/* =====================================================
                PRODUCT FORM
            ===================================================== */}

            {showForm &&
                storeDetailsComplete && (

                    <div className="owner-section-card owner-product-form">

                        <div className="owner-section-header">

                            <div className="owner-form-title-group">

                                <div className="owner-form-icon">

                                    {
                                        editingProductId !== null
                                            ? "✏️"
                                            : "＋"
                                    }

                                </div>

                                <div>

                                    <h2>
                                        {
                                            editingProductId !== null
                                                ? "Edit Product"
                                                : "Add Product"
                                        }
                                    </h2>

                                    <p>
                                        {
                                            editingProductId !== null
                                                ? "Update the product information."
                                                : "Enter the details for the new product."
                                        }
                                    </p>

                                </div>

                            </div>

                        </div>


                        <div className="owner-form-grid">

                            <div className="owner-form-group">

                                <label>
                                    Product Name *
                                </label>

                                <input
                                    type="text"
                                    name="name"
                                    placeholder="Enter product name"
                                    value={formData.name}
                                    onChange={handleInputChange}
                                />

                            </div>


                            <div className="owner-form-group">

                                <label>
                                    Category *
                                </label>

                                <select
                                    name="category"
                                    value={formData.category}
                                    onChange={handleInputChange}
                                >

                                    <option value="">
                                        Select category
                                    </option>

                                    <option value="Groceries">
                                        Groceries
                                    </option>

                                    <option value="Fruits & Vegetables">
                                        Fruits & Vegetables
                                    </option>

                                    <option value="Dairy & Eggs">
                                        Dairy & Eggs
                                    </option>

                                    <option value="Bakery">
                                        Bakery
                                    </option>

                                    <option value="Beverages">
                                        Beverages
                                    </option>

                                    <option value="Snacks">
                                        Snacks
                                    </option>

                                    <option value="Personal Care">
                                        Personal Care
                                    </option>

                                    <option value="Household">
                                        Household
                                    </option>

                                </select>

                            </div>


                            <div className="owner-form-group">

                                <label>
                                    Price (₹) *
                                </label>

                                <input
                                    type="number"
                                    name="price"
                                    min="0"
                                    placeholder="Enter price"
                                    value={formData.price}
                                    onChange={handleInputChange}
                                />

                            </div>


                            <div className="owner-form-group">

                                <label>
                                    Stock *
                                </label>

                                <input
                                    type="number"
                                    name="stock"
                                    min="0"
                                    placeholder="Enter stock quantity"
                                    value={formData.stock}
                                    onChange={handleInputChange}
                                />

                            </div>

                        </div>


                        <div className="owner-form-actions">

                            <button
                                className="owner-secondary-btn"
                                onClick={handleCancel}
                            >
                                Cancel
                            </button>

                            <button
                                className="owner-primary-btn"
                                onClick={handleSaveProduct}
                            >

                                <span className="owner-btn-icon">
                                    💾
                                </span>

                                {
                                    editingProductId !== null
                                        ? "Update Product"
                                        : "Save Product"
                                }

                            </button>

                        </div>

                    </div>
                )}


            {/* =====================================================
                PRODUCT LIST
            ===================================================== */}

            <div className="owner-section-card owner-products-card">

                {/* =================================================
                    PRODUCT TOOLBAR
                ================================================= */}

                <div className="owner-products-toolbar">

                    <div className="owner-search-wrapper">

                        <div className="owner-search-box">

                            <span className="owner-search-icon">
                            </span>

                            <input
                                type="text"

                                placeholder=" 🔍 Search products..."
                                value={search}
                                onChange={e =>
                                    setSearch(
                                        e.target.value
                                    )
                                }
                            />

                        </div>

                    </div>


                    <div className="owner-product-count">

                        <span className="owner-count-number">
                            {
                                filteredProducts.length
                            }
                        </span>

                        <span className="owner-count-label">
                            Products
                        </span>

                    </div>

                </div>


                {/* =================================================
                    PRODUCT TABLE
                ================================================= */}

                <div className="owner-table-wrapper">

                    <table className="owner-table">

                        <thead>

                        <tr>

                            <th>
                                Product
                            </th>

                            <th>
                                Category
                            </th>

                            <th className="owner-align-right">
                                Price
                            </th>

                            <th className="owner-align-center">
                                Stock
                            </th>

                            <th className="owner-align-center">
                                Status
                            </th>

                            <th className="owner-align-center">
                                Actions
                            </th>

                        </tr>

                        </thead>


                        <tbody>

                        {isLoading ? (

                            <tr>

                                <td
                                    colSpan={6}
                                    className="owner-empty-state"
                                >

                                    <div className="owner-loading-state">

                                        <span className="owner-loading-icon">
                                            ⏳
                                        </span>

                                        Loading products...

                                    </div>

                                </td>

                            </tr>

                        ) : filteredProducts.length > 0 ? (

                            filteredProducts.map(product => {

                                const stockStatus =
                                    getStockStatus(
                                        product.stock
                                    )

                                return (

                                    <tr
                                        key={product.id}
                                    >

                                        <td className="owner-product-name-cell">

                                            <div className="owner-product-name">

                                                <div className="owner-product-icon">
                                                    📦
                                                </div>

                                                <strong>
                                                    {
                                                        product.name
                                                    }
                                                </strong>

                                            </div>

                                        </td>


                                        <td className="owner-category-cell">

                                            {
                                                product.category
                                            }

                                        </td>


                                        <td className="owner-price-cell owner-align-right">

                                            <strong>
                                                ₹
                                                {
                                                    product.price.toFixed(2)
                                                }
                                            </strong>

                                        </td>


                                        <td className="owner-stock-cell owner-align-center">

                                            <span className="owner-stock-value">
                                                {
                                                    product.stock
                                                }
                                            </span>

                                        </td>


                                        <td className="owner-align-center">

                                            <span
                                                className={
                                                    `owner-status ${stockStatus.className}`
                                                }
                                            >

                                                <span className="owner-status-dot">
                                                    ●
                                                </span>

                                                {
                                                    stockStatus.text
                                                }

                                            </span>

                                        </td>


                                        <td className="owner-align-center">

                                            <div className="owner-action-buttons">

                                                <button
                                                    className="owner-edit-btn"
                                                    onClick={() =>
                                                        handleEditProduct(
                                                            product
                                                        )
                                                    }
                                                >

                                                    <span>
                                                        ✏️
                                                    </span>

                                                    Edit

                                                </button>


                                                <button
                                                    className="owner-delete-btn"
                                                    onClick={() =>
                                                        handleDeleteProduct(
                                                            product.id
                                                        )
                                                    }
                                                >

                                                    <span>
                                                        🗑️
                                                    </span>

                                                    Delete

                                                </button>

                                            </div>

                                        </td>

                                    </tr>

                                )
                            })

                        ) : (

                            <tr>

                                <td
                                    colSpan={6}
                                    className="owner-empty-state"
                                >

                                    <div className="owner-no-products">

                                        <div className="owner-empty-icon">
                                            📦
                                        </div>

                                        <strong>
                                            No products found
                                        </strong>

                                        <span>
                                            {
                                                search
                                                    ? "Try a different search term."
                                                    : "Add your first product to get started."
                                            }
                                        </span>

                                    </div>

                                </td>

                            </tr>

                        )}

                        </tbody>

                    </table>

                </div>

            </div>

        </div>
    )
}

export default StoreOwnerProducts