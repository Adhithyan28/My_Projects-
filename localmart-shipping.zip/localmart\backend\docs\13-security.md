# LocalMart — Security Architecture

## 1. Overview

Security is a core part of LocalMart because the application handles:

* User accounts
* Passwords
* OTP-based authentication
* Social authentication
* JWT access tokens
* User sessions
* Customer addresses and location data
* Shopping carts
* Orders
* Payments
* Store-owner operations
* Delivery-partner operations
* Administrative operations

LocalMart uses a layered security approach rather than relying on a single authentication mechanism.

The main security mechanisms are:

1. **Spring Security**
2. **JWT-based authentication**
3. **BCrypt password hashing**
4. **Email OTP authentication**
5. **SMS OTP authentication**
6. **TOTP-based authentication**
7. **Google authentication**
8. **X authentication**
9. **Database-backed user sessions**
10. **Role-based authorization**
11. **Account-status checks**
12. **Rate limiting**
13. **Input validation**
14. **External-service validation**

---

# 2. Security Architecture

The security architecture can be viewed as several layers.

```text
                    Client
                      |
                      v
              HTTP Request
                      |
                      v
             +----------------+
             | Rate Limiting  |
             +----------------+
                      |
                      v
             +----------------+
             | Spring Security |
             +----------------+
                      |
                      v
             +----------------+
             | JWT Filter     |
             +----------------+
                      |
                      v
             +----------------+
             | JWT Validation |
             +----------------+
                      |
                      v
             +----------------+
             | User Session   |
             | Validation     |
             +----------------+
                      |
                      v
             +----------------+
             | Authorization  |
             | / Role Check   |
             +----------------+
                      |
                      v
             +----------------+
             | Controller     |
             +----------------+
                      |
                      v
             +----------------+
             | Service Layer  |
             +----------------+
                      |
                      v
             +----------------+
             | Repository / DB |
             +----------------+
```

Security therefore operates at multiple stages of a request.

---

# 3. Spring Security

LocalMart uses **Spring Security** as the main security framework.

The main security configuration is located at:

```text
security/
└── SecurityConfig.java
```

Spring Security is responsible for integrating authentication and authorization into the HTTP request-processing pipeline.

It allows LocalMart to control:

* Which endpoints are public
* Which endpoints require authentication
* Which endpoints require particular roles
* How authentication is represented internally
* How security filters process requests

---

# 4. Security Components

The major security-related components in the backend are:

```text
security/
├── SecurityConfig.java
├── JwtAuthenticationFilter.java
├── JwtService.java
└── RateLimitFilter.java
```

Other services also participate in authentication:

```text
service/
├── UserService.java
├── UserSessionService.java
├── OtpService.java
├── TotpService.java
├── RegistrationVerificationService.java
├── GoogleTokenVerificationService.java
├── XOAuthService.java
└── MessageCentralOtpService.java
```

These components have different responsibilities.

| Component                         | Responsibility                                 |
| --------------------------------- | ---------------------------------------------- |
| `SecurityConfig`                  | Configures Spring Security                     |
| `JwtAuthenticationFilter`         | Extracts and validates JWT authentication      |
| `JwtService`                      | Creates and validates JWTs                     |
| `RateLimitFilter`                 | Controls excessive requests                    |
| `UserSessionService`              | Manages authenticated sessions                 |
| `UserService`                     | Performs authentication-related business logic |
| `OtpService`                      | OTP-related operations                         |
| `TotpService`                     | TOTP generation/verification                   |
| `RegistrationVerificationService` | Registration OTP verification                  |
| `GoogleTokenVerificationService`  | Google identity-token verification             |
| `XOAuthService`                   | X authentication                               |
| `MessageCentralOtpService`        | SMS OTP delivery                               |

---

# 5. Authentication vs Authorization

LocalMart separates two important security concepts.

## Authentication

Authentication answers:

> "Who is this user?"

For example:

```text
User → Login → Credentials/OTP/Social Identity
                    ↓
               Authentication
                    ↓
               User Identity
```

## Authorization

Authorization answers:

> "What is this authenticated user allowed to do?"

For example:

```text
Authenticated User
        |
        +---- CUSTOMER
        |
        +---- STORE_OWNER
        |
        +---- DELIVERY_PARTNER
        |
        +---- ADMIN
```

A customer should not automatically be allowed to perform store-owner or administrator operations.

---

# 6. JWT Authentication

LocalMart uses JSON Web Tokens for authenticated API requests.

The relevant classes are:

```text
JwtService.java
JwtAuthenticationFilter.java
```

The general flow is:

```text
Login
  |
  v
User Verification
  |
  v
Create User Session
  |
  v
Generate JWT
  |
  v
Return JWT to frontend
```

The frontend stores the authenticated user information and token.

For subsequent protected requests, the frontend sends the token using the HTTP `Authorization` header:

```text
Authorization: Bearer <JWT>
```

---

# 7. JWT Request Flow

A protected request follows approximately this flow:

```text
Frontend
   |
   | Authorization: Bearer <JWT>
   v
HTTP Request
   |
   v
JwtAuthenticationFilter
   |
   | Extract Bearer token
   v
JwtService
   |
   | Validate token
   v
Extract user information
   |
   v
UserSessionService
   |
   | Validate session
   v
Spring Security Context
   |
   v
Controller
   |
   v
Service
```

The important idea is that the controller does not need to manually parse the JWT on every request.

The security layer establishes the authenticated user before protected business logic is executed.

---

# 8. JWT Service

`JwtService` is responsible for JWT-related operations.

Its responsibilities include concepts such as:

* Creating JWTs
* Embedding authentication information
* Validating JWTs
* Extracting information from JWTs
* Working with session identifiers

LocalMart's JWT authentication is therefore separated from business services.

For example:

```text
JwtService
     |
     +---- Create token
     |
     +---- Validate token
     |
     +---- Extract user ID
     |
     +---- Extract email
     |
     +---- Extract role
     |
     +---- Extract session ID
```

---

# 9. Why JWT Is Not the Entire Session

LocalMart does not treat the JWT as the only source of session state.

The application also has:

```text
UserSession.java
UserSessionRepository.java
UserSessionService.java
```

This creates a server-side session-management layer.

Conceptually:

```text
JWT
 |
 | contains session identity
 v
UserSession
 |
 v
Database
```

This gives the backend additional control over active sessions.

For example, logout can invalidate the associated server-side session rather than simply relying on the browser deleting its token.

---

# 10. Logout Security

LocalMart exposes a logout operation through:

```text
POST /api/users/logout
```

The controller can receive the Bearer token, validate it, extract the session identifier, and delegate logout to:

```text
UserSessionService
```

The conceptual flow is:

```text
Frontend
   |
   | POST /logout
   | Authorization: Bearer JWT
   v
UserController
   |
   v
JwtService
   |
   | Extract session ID
   v
UserSessionService
   |
   v
Invalidate Session
```

This prevents the server-side session from remaining active after logout.

---

# 11. Password Security

LocalMart does not store users' plain-text passwords.

Passwords are processed using **BCrypt**.

The password flow is:

```text
User Password
      |
      v
BCrypt Password Encoder
      |
      v
Password Hash
      |
      v
Database
```

During login:

```text
Entered Password
       |
       v
BCrypt Verification
       |
       +---- Match → Continue
       |
       +---- No Match → Reject
```

The backend therefore compares the supplied password against the stored BCrypt hash rather than retrieving a plain-text password.

---

# 12. BCrypt

BCrypt is a password-hashing mechanism designed specifically for password storage.

The important distinction is:

```text
Encryption:
plaintext → encrypted value → can be decrypted

Password hashing:
plaintext → hash → not normally reversed
```

LocalMart uses BCrypt for password hashing.

The password encoder is configured through the security configuration and used by the user-management logic.

---

# 13. OTP Security

LocalMart supports OTP-based authentication for several workflows.

OTP is used for operations such as:

* Registration verification
* Login verification
* Password-related verification
* SMS authentication

The backend contains dedicated OTP-related services.

```text
OtpService
RegistrationVerificationService
MessageCentralOtpService
EmailService
```

OTP-based authentication generally follows:

```text
User
 |
 | Request OTP
 v
Backend
 |
 +---- Generate/prepare OTP
 |
 +---- Store verification information
 |
 +---- Deliver OTP
 |
 v
User enters OTP
 |
 v
Backend verifies OTP
 |
 +---- Valid → Continue
 |
 +---- Invalid → Reject
```

---

# 14. Email OTP

LocalMart supports email-based OTP delivery.

The backend contains:

```text
EmailService
```

Email delivery uses SMTP.

The conceptual flow is:

```text
User
 |
 | Request OTP
 v
LocalMart Backend
 |
 v
OTP generation / verification logic
 |
 v
EmailService
 |
 v
SMTP Server
 |
 v
User Email
```

The OTP itself should not be treated as a permanent authentication credential.

It is a temporary verification mechanism.

---

# 15. SMS OTP

LocalMart also supports mobile-number OTP authentication.

The SMS implementation contains:

```text
MessageCentralOtpService
```

and the dedicated SMS OTP package:

```text
smsotp/
├── controller/
│   └── SmsOtpController.java
├── dto/
│   ├── SmsOtpSendRequest.java
│   └── SmsOtpVerifyRequest.java
├── model/
│   └── SmsOtpSession.java
└── service/
    └── SmsOtpFlowService.java
```

The flow is:

```text
User Phone Number
       |
       v
LocalMart Backend
       |
       v
Message Central
       |
       v
SMS OTP
       |
       v
User
       |
       | OTP
       v
LocalMart Backend
       |
       v
OTP Verification
```

This keeps external SMS delivery separate from the application's authentication logic.

---

# 16. TOTP Security

LocalMart also contains TOTP functionality.

The relevant service is:

```text
TotpService.java
```

and automated tests exist under:

```text
src/test/java/.../service/TotpServiceTest.java
```

TOTP is different from an OTP delivered through SMS or email.

TOTP is generated using a shared secret and time-based algorithm.

Conceptually:

```text
Shared Secret
      +
Current Time
      |
      v
TOTP Algorithm
      |
      v
Temporary Code
```

The authenticator application and backend independently calculate the expected code using the shared secret and current time.

---

# 17. Google Authentication

LocalMart supports Google authentication.

The relevant backend components include:

```text
GoogleTokenVerificationService.java
GoogleAuthProperties.java
```

and the user endpoints include:

```text
POST /api/users/google/login
POST /api/users/google/register
```

The frontend sends a Google credential to the backend.

The backend then verifies the Google identity token rather than simply trusting information supplied by the browser.

Conceptually:

```text
Google
  |
  v
Google Identity Services
  |
  v
Frontend
  |
  | Google credential
  v
LocalMart Backend
  |
  v
GoogleTokenVerificationService
  |
  v
Google token verification
  |
  v
Authenticated LocalMart User
```

This is an important security boundary because identity information received from the client must be validated.

---

# 18. X Authentication

LocalMart also contains X authentication support.

Relevant components include:

```text
XOAuthController.java
XOAuthService.java
XAuthProperties.java
```

X authentication follows the same general security principle:

```text
External Identity
       |
       v
Backend Verification
       |
       v
LocalMart User Identity
       |
       v
LocalMart Session + JWT
```

The external identity is linked to the LocalMart account only after the backend authentication flow succeeds.

---

# 19. Registration Verification

Registration is protected by a verification step.

The backend contains:

```text
RegistrationVerificationService.java
```

Relevant endpoints include:

```text
POST /api/users/register/send-otp
POST /api/users/register/verify-otp
```

The verification process creates a temporary registration authorization/token.

The final registration request can then be associated with the verified identifier.

Conceptually:

```text
Registration Request
        |
        v
Send OTP
        |
        v
Verify OTP
        |
        v
Temporary Registration Token
        |
        v
Final Registration
```

This prevents registration from being treated as verified before the required verification step has completed.

---

# 20. Account Status Security

Authentication alone does not mean that an account is permitted to use the system.

LocalMart tracks account status.

The current application-level status values used by `UserService` are:

```text
1 → ACTIVE
2 → INACTIVE
3 → BLOCKED
```

These states affect authentication and account access.

Conceptually:

```text
User
 |
 v
Account Status
 |
 +---- ACTIVE     → Continue
 |
 +---- INACTIVE   → Application/account restrictions
 |
 +---- BLOCKED    → Reject
```

This is especially important for store owners and delivery partners because their accounts can depend on administrative approval.

---

# 21. Role-Based Access Control

LocalMart has four primary roles:

```text
CUSTOMER
STORE_OWNER
DELIVERY_PARTNER
ADMIN
```

The backend assigns role information to authenticated users.

The role values used by `UserService` are:

```text
CUSTOMER          = 1
STORE_OWNER       = 2
DELIVERY_PARTNER  = 3
ADMIN             = 4
```

Authorization is then based on the user's role.

Conceptually:

```text
JWT
 |
 v
Authenticated User
 |
 v
Role
 |
 +---- CUSTOMER
 |
 +---- STORE_OWNER
 |
 +---- DELIVERY_PARTNER
 |
 +---- ADMIN
```

---

# 22. Role Isolation

Role isolation prevents one type of user from automatically accessing another role's functionality.

For example:

```text
CUSTOMER
 ├── Customer profile
 ├── Addresses
 ├── Stores
 ├── Products
 ├── Cart
 └── Orders
```

A store owner has store-management functionality, while a delivery partner has delivery-related functionality.

Administrative operations are restricted to the administrator role.

This is an authorization boundary rather than merely a frontend navigation decision.

---

# 23. Frontend Role Checks vs Backend Security

The frontend may hide or display pages based on the user's role.

However:

```text
Frontend role check ≠ security boundary
```

A malicious client can modify frontend JavaScript or manually send HTTP requests.

Therefore the backend must independently enforce authorization.

The secure architecture is:

```text
Frontend
   |
   | UI restriction
   v
Backend
   |
   | Actual authorization
   v
Protected operation
```

The backend is the authoritative security boundary.

---

# 24. Rate Limiting

LocalMart contains:

```text
RateLimitFilter.java
```

Rate limiting is intended to control excessive request activity.

Conceptually:

```text
Client
  |
  | Request 1
  | Request 2
  | Request 3
  | ...
  v
RateLimitFilter
  |
  +---- Within limit → Continue
  |
  +---- Excessive → Reject / limit request
```

Rate limiting is particularly relevant to endpoints involving:

* Login
* OTP requests
* Authentication
* Public APIs
* Repeated resource requests

It helps reduce automated abuse and excessive request traffic.

---

# 25. Why Rate Limiting and Authentication Are Different

These mechanisms solve different problems.

### Authentication

Answers:

> Who are you?

### Authorization

Answers:

> What are you allowed to do?

### Rate limiting

Answers:

> How many requests can you make within the permitted limits?

Therefore:

```text
Rate Limiting
      +
Authentication
      +
Authorization
```

provide complementary security controls.

---

# 26. Input Validation

LocalMart validates data before allowing it into business operations.

For example, address validation checks:

* Required fields
* Indian PIN-code format
* Latitude range
* Longitude range

Valid coordinate ranges are:

```text
Latitude:
-90 to +90

Longitude:
-180 to +180
```

This prevents obviously invalid location values from being persisted.

Input validation is also supported by Bean Validation dependencies in the backend.

---

# 27. Address and Location Security

LocalMart handles location information for:

* Customer addresses
* Stores
* Delivery partners

Location information can affect:

* Delivery fee
* Distance calculation
* Delivery routing
* Store selection
* Delivery tracking

Therefore the backend should not blindly trust location-related values from clients.

The application validates coordinate formats and ranges before processing them.

For delivery-partner location updates, authenticated delivery-partner access is required.

---

# 28. Payment Security

LocalMart integrates with Razorpay for payment processing.

The application should treat payment information as security-sensitive data.

The general principle is:

```text
LocalMart
    |
    | Payment request
    v
Razorpay
    |
    v
Payment Processing
```

LocalMart's backend contains:

```text
RazorpayService.java
Payment.java
PaymentRepository.java
```

Payment operations should be performed through the backend rather than allowing the frontend to directly modify order/payment state.

The backend remains responsible for validating the business state associated with a payment.

---

# 29. Order Security

Orders contain important business information.

Therefore order operations are associated with authenticated users and role-specific access.

For example:

```text
Customer
   |
   +---- Own cart
   +---- Own checkout
   +---- Own orders

Store Owner
   |
   +---- Relevant store orders

Delivery Partner
   |
   +---- Assigned/available delivery orders

Admin
   |
   +---- Administrative operations
```

The backend must enforce these ownership boundaries rather than relying only on frontend filtering.

---

# 30. Database Security

LocalMart uses PostgreSQL for persistent data.

Security-sensitive values such as passwords should not be stored as plain text.

The application uses JPA/Hibernate repositories to access the database.

The general architecture is:

```text
Controller
    |
    v
Service
    |
    v
Repository
    |
    v
Hibernate / JPA
    |
    v
PostgreSQL
```

Keeping business logic in the service layer prevents controllers from directly implementing database security rules.

---

# 31. External Service Security

LocalMart communicates with several external systems.

Examples include:

```text
Google
Message Central
Razorpay
Geocoding Service
OSRM
SMTP server
X
```

Credentials and configuration for external services should be kept outside source code wherever possible.

Examples include:

```text
API keys
Client IDs
Client secrets
SMTP credentials
JWT secrets
Database credentials
```

These should be supplied through environment-specific configuration rather than committed to GitHub.

---

# 32. Configuration Security

Sensitive configuration should not be hardcoded into Java source files.

A production deployment should separate:

```text
Application Code
        +
Environment Configuration
        +
Secrets
```

For example:

```text
Development
    ↓
Development credentials

Production
    ↓
Production credentials
```

This prevents development secrets from automatically becoming production secrets.

---

# 33. Security Filter Chain Concept

A simplified LocalMart request-processing model is:

```text
HTTP Request
     |
     v
RateLimitFilter
     |
     v
Spring Security Filter Chain
     |
     v
JwtAuthenticationFilter
     |
     v
JWT validation
     |
     v
Authentication established
     |
     v
Authorization
     |
     v
Controller
```

The exact ordering is controlled by the application's Spring Security configuration.

The important architectural idea is that security processing occurs before protected controller logic.

---

# 34. Authentication Context

After successful JWT authentication, Spring Security can place authentication information into its security context.

Conceptually:

```text
JWT
 |
 v
JwtAuthenticationFilter
 |
 v
Authentication Object
 |
 v
SecurityContextHolder
 |
 v
Protected Controller / Service
```

This allows downstream application code to work with the authenticated identity without repeatedly parsing the HTTP header.

---

# 35. Security Boundary

A useful way to understand LocalMart security is to divide the system into trust boundaries.

```text
             UNTRUSTED
                |
                v
        +---------------+
        |   Frontend    |
        +---------------+
                |
                | HTTP
                v
        +---------------+
        | Security Layer|
        +---------------+
                |
                v
        +---------------+
        | Application   |
        | Backend       |
        +---------------+
                |
                v
        +---------------+
        | Database      |
        +---------------+
```

The frontend is not considered trustworthy simply because it belongs to the LocalMart application.

The backend validates requests and enforces security rules.

---

# 36. Security of Business Operations

Security is not limited to login.

Every sensitive business operation should have appropriate checks.

For example:

```text
Add Product
    ↓
Authenticated?
    ↓
Store Owner?
    ↓
Owns Store?
    ↓
Valid Product Data?
    ↓
Save Product
```

Similarly:

```text
Update Order
    ↓
Authenticated?
    ↓
Correct Role?
    ↓
Allowed Order?
    ↓
Valid Status Transition?
    ↓
Update Order
```

This demonstrates the difference between authentication and business-level authorization.

---

# 37. Security of Delivery Operations

Delivery operations have their own security boundaries.

The delivery lifecycle is:

```text
READY_FOR_PICKUP
        ↓
ACCEPTED
        ↓
PICKED_UP
        ↓
OUT_FOR_DELIVERY
        ↓
DELIVERED
```

A delivery partner should only perform operations permitted for the delivery-partner role and relevant order state.

Location updates are similarly associated with delivery-partner functionality.

This prevents arbitrary users from manipulating delivery state.

---

# 38. Administrative Security

The ADMIN role has elevated privileges.

The application contains administrative controllers and services such as:

```text
AdminController.java
AdminDataController.java
AdminRequestController.java
AdminService.java
AdminDataService.java
AdminRequestService.java
```

Administrative operations include areas such as:

* Application approval
* Store-owner approval
* Delivery-partner approval
* Administrative data access

Because these operations have elevated privileges, they require stronger authorization boundaries than normal customer operations.

---

# 39. Application Approval Security

Store owners and delivery partners are not treated exactly like immediately active customer accounts.

The registration logic creates an application request.

The relevant application statuses are:

```text
PENDING  = 1
APPROVED = 2
REJECTED = 3
```

The security model therefore includes:

```text
Registration
     |
     v
Application
     |
     v
Admin Review
     |
     +---- PENDING
     |
     +---- APPROVED
     |
     +---- REJECTED
```

Account status and application status work together to determine whether role-specific access should be allowed.

---

# 40. Security Error Handling

Security-related failures should not expose unnecessary internal information.

Examples include:

```text
Invalid credentials
Invalid OTP
Expired OTP
Invalid JWT
Expired JWT
Blocked account
Unauthorized request
Forbidden operation
Invalid external identity
```

The backend contains:

```text
GlobalExceptionHandler.java
```

which provides centralized exception handling for application errors.

Security errors should be communicated to the client without exposing sensitive implementation details such as:

* Password hashes
* JWT signing secrets
* Database credentials
* Internal stack traces
* External-service credentials

---

# 41. Security and External APIs

External APIs introduce additional trust boundaries.

For example:

```text
LocalMart Backend
       |
       +---- Google
       |
       +---- Message Central
       |
       +---- Razorpay
       |
       +---- OSRM
       |
       +---- Geocoding Service
       |
       +---- SMTP
```

The backend should validate external responses before using them in business logic.

An external service being available does not automatically mean that its response should be trusted without validation.

---

# 42. Security Principles Used by LocalMart

The architecture follows several important security principles.

## 42.1 Never Trust the Client

Frontend validation improves user experience but cannot be the only security mechanism.

```text
Frontend validation
        +
Backend validation
```

is required.

---

## 42.2 Passwords Are Never Stored as Plain Text

```text
Password
   ↓
BCrypt
   ↓
Hash
   ↓
Database
```

---

## 42.3 Authentication and Authorization Are Separate

A valid login does not automatically grant access to every API.

---

## 42.4 Backend Is the Security Boundary

The backend independently validates:

* Identity
* Role
* Account status
* Business ownership
* Request data

---

## 42.5 Temporary Credentials Should Expire

OTP and temporary registration credentials are designed to be short-lived.

The current `UserService` OTP expiry configuration uses a five-minute OTP validity period.

---

## 42.6 External Identities Must Be Verified

Google and other social identities should be validated by the backend before creating or authenticating a LocalMart account.

---

## 42.7 Sensitive Secrets Stay Outside Source Code

API keys, passwords, signing secrets and other credentials should be supplied through secure configuration.

---

# 43. Complete Authentication Security Flow

A normal password/OTP-based login can be represented as:

```text
                    User
                     |
                     v
                  Login
                     |
                     v
              UserController
                     |
                     v
                UserService
                     |
          +----------+----------+
          |                     |
      Password              OTP flow
          |                     |
          v                     v
      BCrypt              OTP Service
          |                     |
          +----------+----------+
                     |
                     v
             Account Status
                     |
                     v
              User Identity
                     |
                     v
           UserSessionService
                     |
                     v
                JwtService
                     |
                     v
                  JWT
                     |
                     v
                Frontend
```

---

# 44. Complete Protected Request Flow

After login:

```text
Frontend
   |
   | Authorization: Bearer JWT
   v
Backend
   |
   v
RateLimitFilter
   |
   v
JwtAuthenticationFilter
   |
   v
Extract JWT
   |
   v
JwtService
   |
   v
Validate JWT
   |
   v
Extract Identity
   |
   v
UserSessionService
   |
   v
Spring Security Context
   |
   v
Authorization
   |
   v
Controller
   |
   v
Service
   |
   v
Repository
   |
   v
PostgreSQL
```

This is the central security path for authenticated API operations.

---

# 45. Security Responsibilities by Layer

| Layer             | Security Responsibility                                      |
| ----------------- | ------------------------------------------------------------ |
| Frontend          | Token handling, UI-level access control, input UX validation |
| Controller        | Request boundary and endpoint access                         |
| Spring Security   | Authentication/authorization integration                     |
| JWT Filter        | JWT extraction and authentication                            |
| JWT Service       | Token creation and validation                                |
| User Service      | Credential/account authentication logic                      |
| Session Service   | Session lifecycle                                            |
| Service Layer     | Business authorization and ownership checks                  |
| Repository        | Controlled persistence                                       |
| Database          | Persistent data protection                                   |
| External services | Identity, messaging, payment and location functionality      |

---

# 46. Security Threats Addressed

The architecture provides controls relevant to common threats such as:

### Credential theft

Mitigation:

```text
BCrypt password hashing
```

### Token misuse

Mitigation:

```text
JWT validation
+
server-side session management
```

### Brute-force / excessive requests

Mitigation:

```text
Rate limiting
+
OTP expiration
```

### Unauthorized role access

Mitigation:

```text
Role-based authorization
```

### Invalid account access

Mitigation:

```text
Account-status checks
```

### Fake social identity

Mitigation:

```text
Backend external-token verification
```

### Invalid location data

Mitigation:

```text
Coordinate validation
+
backend validation
```

### Unauthorized business operations

Mitigation:

```text
Authentication
+
role checks
+
ownership/business-rule checks
```

---

# 47. Security Architecture Summary

LocalMart uses a layered security model rather than depending on one mechanism.

```text
                 LOCALMART SECURITY
                        |
        +---------------+---------------+
        |               |               |
 Authentication    Authorization    Protection
        |               |               |
        v               v               v
   JWT / OTP       Roles / Status    Rate Limiting
   Google / X      Ownership         Validation
   BCrypt          Permissions       Secure Config
   TOTP
        |
        v
 User Sessions
        |
        v
 Spring Security
        |
        v
 Protected APIs
```

The most important architectural principle is:

> **Authentication establishes identity, authorization establishes permission, and the backend enforces both.**

LocalMart therefore does not treat the frontend, JWT alone, or any single external authentication provider as the complete security boundary. Security is distributed across authentication, session management, authorization, validation, rate limiting, business rules, and controlled access to persistent data.

---

# 48. Related Security Components

The primary source files for this security architecture are:

```text
src/main/java/com/localmart/localmartbackend/
│
├── config/
│   ├── AdminInitializer.java
│   ├── GoogleAuthProperties.java
│   └── XAuthProperties.java
│
├── security/
│   ├── JwtAuthenticationFilter.java
│   ├── JwtService.java
│   ├── RateLimitFilter.java
│   └── SecurityConfig.java
│
├── service/
│   ├── EmailService.java
│   ├── GoogleTokenVerificationService.java
│   ├── MessageCentralOtpService.java
│   ├── OtpDeliveryService.java
│   ├── OtpService.java
│   ├── RegistrationVerificationService.java
│   ├── RazorpayService.java
│   ├── TotpService.java
│   ├── UserService.java
│   ├── UserSessionService.java
│   └── XOAuthService.java
│
├── entity/
│   └── UserSession.java
│
└── repository/
    └── UserSessionRepository.java
```

These components collectively form the security infrastructure of LocalMart.
