
        package com.localmart.localmartbackend.controller;

import com.localmart.localmartbackend.entity.Order;
import com.localmart.localmartbackend.entity.OrderItem;
import com.localmart.localmartbackend.repository.StoreDetailsRepository;
import com.localmart.localmartbackend.service.OrderService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/store-owner/orders")
@CrossOrigin(origins = {
        "http://localhost:5173",
        "http://localhost:5174",
        "http://localhost:5175"
})
public class StoreOwnerOrderController {

    private final OrderService orderService;
    private final StoreDetailsRepository storeDetailsRepository;

    public StoreOwnerOrderController(
            OrderService orderService,
            StoreDetailsRepository storeDetailsRepository
    ) {
        this.orderService = orderService;
        this.storeDetailsRepository = storeDetailsRepository;
    }

    @GetMapping
    public ResponseEntity<List<Map<String, Object>>> getStoreOrders(
            Authentication authentication
    ) {

        Long userId = getAuthenticatedUserId(authentication);

        Long storeId = storeDetailsRepository
                .findByUserId(userId)
                .orElseThrow(() ->
                        new RuntimeException("Store not found for user: " + userId)
                )
                .getStoreId();

        List<Order> orders =
                orderService.getStoreOrders(storeId);

        List<Map<String, Object>> response = orders.stream()
                .map(this::buildOrderResponse)
                .toList();

        return ResponseEntity.ok(response);
    }

    @PutMapping("/{orderId}/status")
    public ResponseEntity<Map<String, Object>> updateOrderStatus(
            Authentication authentication,
            @PathVariable Long orderId,
            @RequestParam String status
    ) {

        Long userId = getAuthenticatedUserId(authentication);

        Long storeId = storeDetailsRepository
                .findByUserId(userId)
                .orElseThrow(() ->
                        new RuntimeException("Store not found for user: " + userId)
                )
                .getStoreId();

        Order order = orderService.updateStoreOrderStatus(
                orderId,
                storeId,
                status.toUpperCase()
        );

        return ResponseEntity.ok(
                buildOrderResponse(order)
        );
    }

    private Long getAuthenticatedUserId(Authentication authentication) {

        if (authentication == null || !authentication.isAuthenticated()) {
            throw new RuntimeException("User is not authenticated");
        }

        Object principal = authentication.getPrincipal();

        if (principal instanceof Long) {
            return (Long) principal;
        }

        if (principal instanceof Integer) {
            return ((Integer) principal).longValue();
        }

        if (principal instanceof String) {
            try {
                return Long.parseLong((String) principal);
            } catch (NumberFormatException e) {
                throw new RuntimeException(
                        "Invalid authenticated user ID: " + principal
                );
            }
        }

        throw new RuntimeException(
                "Unsupported authentication principal type: "
                        + principal.getClass().getName()
        );
    }

    private Map<String, Object> buildOrderResponse(Order order) {

        List<OrderItem> items =
                orderService.getOrderItems(order.getOrderId());

        Map<String, Object> response = new HashMap<>();

        response.put("orderId", order.getOrderId());
        response.put("orderNumber", order.getOrderNumber());
        response.put("customerId", order.getCustomerId());
        response.put("storeId", order.getStoreId());

        response.put("subtotal", order.getSubtotal());
        response.put("deliveryFee", order.getDeliveryFee());
        response.put("total", order.getTotal());

        response.put("paymentMethod", order.getPaymentMethod());
        response.put("paymentStatus", order.getPaymentStatus());
        response.put("orderStatus", order.getOrderStatus());

        response.put("deliveryName", order.getDeliveryName());
        response.put("deliveryPhone", order.getDeliveryPhone());
        response.put("deliveryAddress", order.getDeliveryAddress());
        response.put("deliveryCity", order.getDeliveryCity());
        response.put("deliveryPincode", order.getDeliveryPincode());

        response.put("createdAt", order.getCreatedAt());
        response.put("updatedAt", order.getUpdatedAt());

        response.put("items", items);

        return response;
    }
}
