# LocalMart — Software System Documentation

**Version:** 1.0
**Project:** LocalMart
**Document Type:** Software Architecture and Technical Documentation
**Application Type:** Full-Stack Local-Commerce / Quick-Commerce Platform
**Primary Backend:** Java 21 + Spring Boot
**Primary Frontend:** React + TypeScript + Vite
**Database:** PostgreSQL

---

# 1. Introduction

## 1.1 Project Overview

**LocalMart** is a full-stack local-commerce and quick-commerce platform designed to connect customers with participating local stores and support the complete lifecycle of an order.

The system covers the flow from:

```text
User Registration
      ↓
Authentication
      ↓
Store Discovery
      ↓
Product Selection
      ↓
Cart
      ↓
Checkout
      ↓
Payment
      ↓
Order Processing
      ↓
Delivery Assignment
      ↓
Delivery
      ↓
Order Completion
```

LocalMart uses a **multi-role architecture**, where different categories of users interact with the platform according to their responsibilities.

The primary roles are:

* **Customer**
* **Store Owner**
* **Delivery Partner**
* **Administrator**

The platform combines a database-driven backend, a web-based frontend, authentication and authorization mechanisms, payment processing, messaging services, and location-aware delivery functionality.

---

# 2. Project Objectives

The primary objective of LocalMart is to provide a centralized platform through which customers can purchase products from local stores while enabling stores, delivery partners, and administrators to perform their respective operations.

The system is designed around the following objectives:

1. Provide secure customer registration and authentication.
2. Support multiple authentication mechanisms.
3. Allow customers to manage their profiles and delivery addresses.
4. Allow customers to discover stores and browse their products.
5. Maintain shopping-cart information on the backend.
6. Calculate delivery-related information using geographical and road-routing data.
7. Support order creation and order lifecycle management.
8. Integrate online payment processing.
9. Provide delivery assignment and status management.
10. Support delivery-partner location-aware operations.
11. Provide store owners with store and product management capabilities.
12. Provide administrators with approval and management capabilities.
13. Maintain persistent business data in PostgreSQL.
14. Integrate specialized external services where required.

---

# 3. System Scope

LocalMart consists of several interconnected functional domains.

## 3.1 Customer Domain

The customer domain provides:

* Customer registration
* Authentication
* OTP verification
* Google authentication
* Profile management
* Address management
* Store discovery
* Category browsing
* Product browsing
* Cart management
* Checkout
* Order placement
* Payment
* Order tracking

---

## 3.2 Store Owner Domain

The store-owner domain provides functionality related to participating stores.

It includes:

* Store-owner registration
* Administrative approval
* Store information management
* Product management
* Product availability management
* Store-related operations

Store-owner registration is subject to the application's administrative approval workflow.

---

## 3.3 Delivery Domain

The delivery domain manages the fulfillment of customer orders.

It includes:

* Viewing available deliveries
* Accepting deliveries
* Updating delivery status
* Delivery-partner location
* Road-distance calculation
* Delivery-duration estimation
* Delivery-fee-related calculations

The delivery lifecycle currently uses the following statuses:

```text
READY_FOR_PICKUP
       ↓
   ACCEPTED
       ↓
  PICKED_UP
       ↓
OUT_FOR_DELIVERY
       ↓
   DELIVERED
```

The status transitions represent the operational state of a delivery rather than the complete financial or order lifecycle.

---

## 3.4 Administration Domain

The administration domain provides privileged operations such as:

* User management
* Store-owner approval
* Delivery-partner approval
* Account management
* Administrative operations

---

# 4. High-Level System Architecture

LocalMart follows a **client-server architecture**.

The major system components are:

```text
                         LOCALMART
                            │
             ┌──────────────┴──────────────┐
             │                             │
             ▼                             ▼
        WEB FRONTEND                  APPLICATION BACKEND
     React + TypeScript              Java 21 + Spring Boot
             │                             │
             │        HTTP / JSON           │
             └──────────────┬──────────────┘
                            │
                            ▼
                       PostgreSQL
                            │
             ┌──────────────┼──────────────┐
             │              │              │
             ▼              ▼              ▼
          Payment        Location       Messaging /
          Services       Services       Authentication
```

The **frontend** provides the user interface and initiates requests.

The **backend** acts as the central application layer. It processes requests, executes business rules, manages authentication and authorization, communicates with the database, and integrates with external services.

**PostgreSQL** provides persistent storage for application and business data.

External services provide specialized capabilities such as authentication, messaging, payments, geocoding, and route calculation.

---

# 5. Component Responsibility

The major components have distinct responsibilities.

| Component       | Primary Responsibility             |
| --------------- | ---------------------------------- |
| React           | User-interface development         |
| TypeScript      | Frontend type safety               |
| Vite            | Frontend development/build tooling |
| Spring Boot     | Backend application framework      |
| Spring MVC      | HTTP request/response processing   |
| Spring Security | Authentication and authorization   |
| Controllers     | REST endpoint handling             |
| DTOs            | API request/response contracts     |
| Services        | Application and business logic     |
| Repositories    | Database-access abstraction        |
| JPA             | Persistence abstraction            |
| Hibernate       | Object-relational mapping          |
| JDBC            | Database connectivity              |
| PostgreSQL      | Persistent data storage            |
| JWT             | Authentication token               |
| BCrypt          | Password hashing and verification  |
| External APIs   | Specialized external capabilities  |

This separation allows the system to avoid placing all application responsibilities inside a single layer.

---

# 6. Technology Stack

## 6.1 Frontend

| Technology                  | Purpose                                                   |
| --------------------------- | --------------------------------------------------------- |
| **React**                   | Component-based user-interface development                |
| **TypeScript**              | Static typing for frontend code                           |
| **Vite**                    | Development server and build tooling                      |
| **Fetch API**               | HTTP communication with backend APIs                      |
| **Browser Geolocation API** | Obtaining device coordinates                              |
| **localStorage**            | Client-side storage of authentication/session information |

The frontend communicates with the backend primarily through HTTP requests containing JSON data.

---

## 6.2 Backend

| Technology                  | Purpose                                 |
| --------------------------- | --------------------------------------- |
| **Java 21**                 | Backend programming language/runtime    |
| **Spring Boot**             | Application framework and configuration |
| **Spring Web / Spring MVC** | REST API and HTTP request handling      |
| **Spring Data JPA**         | Database-access abstraction             |
| **Hibernate**               | ORM implementation                      |
| **Spring Security**         | Authentication and authorization        |
| **JJWT**                    | JWT creation and validation             |
| **BCrypt**                  | Password hashing and verification       |
| **Bean Validation**         | Request-data validation                 |
| **Jackson**                 | JSON serialization/deserialization      |
| **Maven**                   | Dependency and build management         |
| **Apache Tomcat**           | Embedded Servlet container              |

---

## 6.3 Database

| Technology                 | Purpose                         |
| -------------------------- | ------------------------------- |
| **PostgreSQL**             | Relational persistent storage   |
| **PostgreSQL JDBC Driver** | Java-to-PostgreSQL connectivity |
| **JPA**                    | Persistence abstraction         |
| **Hibernate**              | ORM and entity-to-table mapping |

The persistence flow is:

```text
Java Entity
    ↓
JPA
    ↓
Hibernate
    ↓
JDBC
    ↓
PostgreSQL
```

---

# 7. External Services

LocalMart uses external services for capabilities that are provided outside the application's own infrastructure.

| External Service             | Purpose                             | Status      |
| ---------------------------- | ----------------------------------- | ----------- |
| **Google Identity Services** | Google authentication               | Implemented |
| **Message Central**          | SMS OTP delivery                    | Implemented |
| **Gmail SMTP**               | Email OTP delivery                  | Implemented |
| **Message Central WhatsApp** | WhatsApp-based OTP/TOTP delivery    | Planned     |
| **Razorpay**                 | Online payment processing           | Integrated  |
| **Geocoding API**            | Address ↔ geographical coordinates  | Integrated  |
| **OSRM**                     | Road routing, distance and duration | Integrated  |

### Important distinction

External services do not become part of LocalMart's internal business logic.

For example:

```text
OSRM
 ↓
Road distance + duration

LocalMart
 ↓
Uses distance
 ↓
Applies its own delivery rules
 ↓
Delivery fee / ETA
```

Therefore, OSRM provides routing information, while LocalMart determines how that information is used by the application.

---

# 8. User Roles

LocalMart follows a role-based access model.

```text
                     LOCALMART USERS
                            │
        ┌───────────────────┼───────────────────┐
        │                   │                   │
        ▼                   ▼                   ▼
    CUSTOMER           STORE OWNER       DELIVERY PARTNER
        │                   │                   │
        └───────────────────┼───────────────────┘
                            │
                            ▼
                         ADMIN
```

The diagram represents application roles rather than an inheritance relationship between user types.

---

# 9. Customer

The customer is the primary consumer of the platform.

A typical customer journey is:

```text
Registration
     ↓
Authentication
     ↓
Customer Dashboard
     ↓
Store Discovery
     ↓
Product Browsing
     ↓
Cart
     ↓
Address Selection
     ↓
Checkout
     ↓
Payment
     ↓
Order
     ↓
Delivery
```

Customer-specific data and operations are protected through backend authentication and authorization.

---

# 10. Store Owner

A store owner represents a business participating in the LocalMart platform.

The general lifecycle is:

```text
Store Owner Registration
          ↓
   Application Request
          ↓
   Administrative Review
          ↓
       Approval
          ↓
Store Owner Operations
```

Store owners can manage store-related information and products according to their authorized permissions.

---

# 11. Delivery Partner

Delivery partners are responsible for fulfilling delivery operations.

A simplified delivery flow is:

```text
Order Ready
    ↓
READY_FOR_PICKUP
    ↓
Delivery Partner Accepts
    ↓
ACCEPTED
    ↓
Order Picked Up
    ↓
PICKED_UP
    ↓
Partner Travels to Customer
    ↓
OUT_FOR_DELIVERY
    ↓
Order Delivered
    ↓
DELIVERED
```

The delivery-partner frontend can use the browser's Geolocation API to obtain the device's current coordinates.

Those coordinates can subsequently be used by backend location-related functionality.

---

# 12. Administrator

The administrator is responsible for privileged platform operations.

The administrative domain includes:

```text
Administrator
      │
      ├── User Management
      │
      ├── Store Owner Approval
      │
      ├── Delivery Partner Approval
      │
      └── Administrative Operations
```

Administrative endpoints are protected by backend authorization rules.

---

# 13. Functional Module Architecture

The application can be divided into the following major modules:

```text
LocalMart
│
├── Authentication & Security
│   ├── Registration
│   ├── Login
│   ├── Email OTP
│   ├── SMS OTP
│   ├── Google Authentication
│   ├── TOTP
│   ├── JWT
│   └── Authorization
│
├── Customer
│   ├── Profile
│   ├── Addresses
│   ├── Stores
│   ├── Categories
│   ├── Products
│   ├── Cart
│   └── Orders
│
├── Store Owner
│   ├── Registration
│   ├── Approval
│   ├── Store Management
│   └── Product Management
│
├── Delivery
│   ├── Available Deliveries
│   ├── Delivery Acceptance
│   ├── Delivery Status
│   ├── Partner Location
│   ├── Distance Calculation
│   └── Delivery Fee
│
├── Payment
│   └── Razorpay
│
├── Location
│   ├── Geocoding
│   ├── Reverse Geocoding
│   ├── Browser Geolocation
│   └── Road Routing
│
└── Administration
    ├── User Management
    ├── Approval Management
    └── System Management
```

---

# 14. Backend Layered Architecture

The LocalMart backend follows a layered architecture.

```text
                         HTTP REQUEST
                              │
                              ▼
                     Spring Security
                              │
                              ▼
                       Controller Layer
                              │
                              ▼
                          DTO Layer
                              │
                              ▼
                        Service Layer
                              │
                              ▼
                      Repository Layer
                              │
                              ▼
                         JPA / Hibernate
                              │
                              ▼
                            JDBC
                              │
                              ▼
                         PostgreSQL
```

The layers have distinct responsibilities.

---

## 14.1 Controller Layer

The controller layer is the HTTP entry point into the backend.

Its responsibilities include:

* Defining API endpoints
* Receiving HTTP requests
* Reading request bodies
* Reading path variables
* Reading query parameters
* Calling appropriate services
* Returning HTTP responses

Controllers should primarily coordinate HTTP communication rather than contain extensive business rules.

---

## 14.2 DTO Layer

DTO stands for **Data Transfer Object**.

DTOs define the data contract between the client and backend.

They are used to:

* Define request structures
* Define response structures
* Validate incoming data
* Control which information crosses the API boundary
* Prevent unnecessary exposure of persistence entities

Typical flow:

```text
JSON Request
     ↓
Request DTO
     ↓
Service
     ↓
Response DTO
     ↓
JSON Response
```

---

## 14.3 Service Layer

The service layer contains application-specific business logic.

Examples include:

* User registration
* Authentication
* OTP verification
* Address management
* Cart operations
* Order processing
* Delivery calculations
* Payment-related operations
* Store management

The service layer coordinates repositories and external integrations where required.

---

## 14.4 Repository Layer

The repository layer provides access to persistent data.

Spring Data JPA reduces the amount of database-access code that must be written manually.

Typical flow:

```text
Service
   ↓
Repository
   ↓
JPA
   ↓
Hibernate
   ↓
JDBC
   ↓
PostgreSQL
```

---

## 14.5 Entity Layer

JPA entities represent persistent application data.

Hibernate maps these Java objects to relational database structures.

Conceptually:

```text
Java Object
     │
     │ ORM Mapping
     ▼
Database Record
```

The entity model therefore acts as the bridge between the application's object-oriented model and the relational database.

---

# 15. General HTTP Request Lifecycle

A typical request can follow this lifecycle:

```text
                    CLIENT
                      │
                      ▼
                 React UI
                      │
                      │ HTTP + JSON
                      ▼
                   Browser
                      │
                      ▼
                   Tomcat
                      │
                      ▼
            Spring Security Filters
                      │
                      ▼
                 Controller
                      │
                      ▼
                 Request DTO
                      │
                      ▼
                   Service
                      │
            ┌─────────┴─────────┐
            │                   │
            ▼                   ▼
       Repository         External Service
            │
            ▼
        JPA/Hibernate
            │
            ▼
         PostgreSQL
            │
            ▼
          Service
            │
            ▼
       Response DTO
            │
            ▼
        Controller
            │
            ▼
         Jackson
            │
            ▼
       JSON Response
            │
            ▼
          Browser
            │
            ▼
         React UI
```

Not every request follows every branch.

For example:

* A database-only request may not call an external service.
* An external-service operation may not require a database query.
* A public authentication endpoint may pass through security filters without requiring an existing JWT.

---

# 16. Authentication Architecture

LocalMart supports multiple authentication mechanisms.

At a high level:

```text
                         AUTHENTICATION
                                │
              ┌─────────────────┼─────────────────┐
              │                 │                 │
              ▼                 ▼                 ▼
        Local Login        Google Login          TOTP
              │                 │                 │
              ▼                 ▼                 ▼
         Email/SMS OTP     Google Credential   TOTP Code
              │                 │                 │
              └─────────────────┼─────────────────┘
                                ▼
                       Authentication Success
                                │
                                ▼
                         JWT Generation
                                │
                                ▼
                       Client-side Session
                                │
                                ▼
                    Protected API Requests
```

Each authentication mechanism has its own detailed flow and will be documented separately.

---

# 17. JWT Security Architecture

After successful authentication, LocalMart can issue a JWT for authenticated API access.

A protected request follows the general flow:

```text
Frontend
   │
   │ Authorization: Bearer <JWT>
   ▼
Spring Security Filter Chain
   │
   ▼
JwtAuthenticationFilter
   │
   ▼
Extract JWT
   │
   ▼
Validate JWT
   │
   ▼
Create Authentication
   │
   ▼
SecurityContext
   │
   ▼
Authorization
   │
   ▼
Controller
```

The JWT establishes the authenticated identity used by protected backend operations.

---

# 18. Password Security

LocalMart uses BCrypt for password hashing and verification.

### Registration

```text
User Password
      │
      ▼
BCrypt
      │
      ▼
Password Hash
      │
      ▼
PostgreSQL
```

### Authentication

```text
Login Password
      │
      ▼
BCrypt Verification
      │
      ▼
Stored Password Hash
      │
      ▼
Match / Reject
```

The plaintext password is not stored as the persistent password representation.

---

# 19. Location Architecture

Location processing consists of several separate capabilities.

```text
                         LOCATION SYSTEM
                                │
                ┌───────────────┴───────────────┐
                │                               │
                ▼                               ▼
             ADDRESS                          DEVICE
                │                               │
                ▼                               ▼
          Geocoding API              Browser Geolocation API
                │                               │
                └───────────────┬───────────────┘
                                ▼
                           Coordinates
                                │
                                ▼
                              OSRM
                                │
                     ┌──────────┴──────────┐
                     ▼                     ▼
                  Distance              Duration
                     │                     │
                     └──────────┬──────────┘
                                ▼
                         LocalMart Logic
                                │
                     ┌──────────┴──────────┐
                     ▼                     ▼
                Delivery Fee              ETA
```

These components have different responsibilities.

### Geocoding

```text
Human-readable address
          ↓
     Geocoding API
          ↓
Latitude + Longitude
```

### Reverse Geocoding

```text
Latitude + Longitude
          ↓
   Reverse Geocoding
          ↓
Address / Location Information
```

### Browser Geolocation

```text
Browser
   ↓
Geolocation API
   ↓
Device position
   ↓
Latitude + Longitude
```

### OSRM

```text
Origin Coordinates
       +
Destination Coordinates
       ↓
      OSRM
       ↓
Road Route
       ↓
Distance + Duration
```

---

# 20. Cart Architecture

The cart is maintained through backend APIs and persistent application data.

The general flow is:

```text
Customer
    ↓
React Cart UI
    ↓
HTTP Request
    ↓
Cart Controller
    ↓
Cart Service
    ↓
Cart Repository
    ↓
PostgreSQL
```

This allows cart information to be associated with the authenticated customer and managed through backend business logic.

---

# 21. Order Architecture

Orders connect multiple LocalMart domains.

```text
Customer
    ↓
Cart
    ↓
Address Selection
    ↓
Order Calculation
    │
    ├── Store Information
    │
    ├── Product Information
    │
    ├── Customer Address
    │
    ├── Distance Information
    │
    └── Delivery Fee
    ↓
Order Creation
    ↓
Payment
    ↓
Order Processing
    ↓
Delivery Assignment
    ↓
Delivery Lifecycle
```

The detailed order document will trace the actual controllers, services, repositories, entities, transactions, and external calls involved.

---

# 22. Payment Architecture

Razorpay is used as an external payment-processing service.

The high-level interaction is:

```text
Customer
    ↓
Checkout
    ↓
LocalMart Backend
    ↓
Payment Initialization
    ↓
Razorpay
    ↓
Payment
    ↓
Payment Result
    ↓
LocalMart Backend
    ↓
Payment / Order State
```

The exact payment-verification sequence will be documented separately based on the implemented LocalMart payment classes.

---

# 23. Delivery Architecture

The delivery system connects order processing with delivery-partner operations.

```text
Order
  ↓
Delivery Created
  ↓
Available to Delivery Partners
  ↓
Partner Accepts
  ↓
Delivery Status Updates
  ↓
Customer Delivery
  ↓
DELIVERED
```

Location-aware delivery functionality can introduce:

```text
Delivery Partner Device
       ↓
Browser Geolocation
       ↓
Current Coordinates
       ↓
LocalMart
       ↓
Routing / Distance Services
       ↓
Distance + Duration
```

---

# 24. External Integration Architecture

External services are treated as independent systems.

```text
                          LOCALMART BACKEND
                                  │
       ┌───────────────┬──────────┼──────────┬───────────────┐
       │               │          │          │               │
       ▼               ▼          ▼          ▼               ▼
    Google       Message Central Razorpay Geocoding         OSRM
 Authentication      OTP        Payment    Location       Routing
       │               │          │          │               │
       └───────────────┴──────────┴──────────┴───────────────┘
```

The backend is responsible for coordinating external-service interactions with LocalMart's internal application logic.

---

# 25. Data Flow Principle

LocalMart follows a **database-driven application model** for persistent business data.

The general data flow is:

```text
PostgreSQL
     ↓
Repository
     ↓
Service
     ↓
Controller
     ↓
REST API
     ↓
Frontend
     ↓
User Interface
```

Business information such as users, stores, products, addresses, carts, orders, and delivery information is therefore represented through backend-managed data rather than relying exclusively on hardcoded frontend values.

---

# 26. Security Principles

The application security model is based on several mechanisms:

* Authentication
* JWT-based API authentication
* Role-based authorization
* BCrypt password hashing
* OTP verification
* Input validation
* Security filters
* Session/token management
* Rate limiting

A protected request generally follows:

```text
HTTP Request
     ↓
Security Filter Chain
     ↓
Authentication
     ↓
Authorization
     ↓
Controller
     ↓
Business Logic
```

Security enforcement occurs before protected business operations are executed.

---

# 27. Architectural Principles

## 27.1 Separation of Concerns

Each major layer has a defined responsibility.

```text
Controller
    ↓
HTTP/API responsibility

Service
    ↓
Business logic

Repository
    ↓
Persistence

Entity
    ↓
Database representation
```

---

## 27.2 Backend-Centric Business Logic

Important business rules are enforced by the backend.

Examples include:

* Authentication
* Authorization
* Cart persistence
* Order creation
* Delivery calculations
* User approval
* Payment-related processing

Frontend validation improves user experience, but backend validation remains important because the backend is the trusted application boundary.

---

## 27.3 Database-Driven Business Data

Persistent business information is stored and retrieved through the backend and PostgreSQL.

---

## 27.4 Role-Based Access Control

Different application roles receive different permissions.

```text
User
 ↓
Role
 ↓
Authorization Rules
 ↓
Allowed Operations
```

---

## 27.5 External-Service Separation

External API communication should be concentrated in appropriate backend integration components instead of being distributed throughout unrelated business classes.

This makes external integrations easier to maintain and replace.

---

## 27.6 API-Based Communication

The frontend and backend communicate using HTTP-based REST APIs and JSON.

```text
React
  │
  │ HTTP Request + JSON
  ▼
Spring Boot REST API
  │
  │ HTTP Response + JSON
  ▼
React
```

---

# 28. Implementation Status

The documentation distinguishes between functionality that currently exists in the codebase and functionality that is planned.

| Feature                           | Status                 |
| --------------------------------- | ---------------------- |
| Customer authentication           | Implemented            |
| Email OTP                         | Implemented            |
| SMS OTP                           | Implemented            |
| Google authentication             | Implemented            |
| JWT authentication                | Implemented            |
| Customer address management       | Implemented            |
| Store/product backend integration | Implemented / evolving |
| Cart backend integration          | Implemented            |
| Delivery partner workflow         | Implemented / evolving |
| Browser location                  | Implemented            |
| Geocoding                         | Integrated             |
| OSRM routing                      | Integrated             |
| Razorpay                          | Integrated             |
| WhatsApp TOTP delivery            | Planned                |
| Rate limiting                     | Implemented / evolving |

Implementation status may change as development continues; detailed feature documents should record the state at the time they are updated.

---

# 29. End-to-End Customer Journey

A simplified customer journey through the system is:

```text
                         CUSTOMER
                            │
                            ▼
                       Registration
                            │
                            ▼
                      Authentication
                            │
                            ▼
                           JWT
                            │
                            ▼
                     Customer Dashboard
                            │
                            ▼
                      Store Discovery
                            │
                            ▼
                     Store Selection
                            │
                            ▼
                    Product Browsing
                            │
                            ▼
                        Add to Cart
                            │
                            ▼
                     Select Address
                            │
                            ▼
                  Calculate Delivery
                            │
                            ▼
                        Checkout
                            │
                            ▼
                         Payment
                            │
                            ▼
                      Order Creation
                            │
                            ▼
                   Delivery Assignment
                            │
                            ▼
                  Delivery Processing
                            │
                            ▼
                         Delivered
```

This diagram represents the high-level business journey. Each stage has a separate technical flow that will be documented in the corresponding feature document.

---

# 30. Documentation Strategy

The LocalMart documentation will be developed progressively from the actual source code.

Each detailed feature will document:

1. **Purpose**
2. **Actors**
3. **Frontend components**
4. **API endpoints**
5. **Request structure**
6. **Controller**
7. **DTO**
8. **Service**
9. **Repository**
10. **Entity**
11. **Database interaction**
12. **External API interaction**
13. **Authentication and authorization**
14. **Validation**
15. **Transaction boundaries**
16. **Response structure**
17. **Error handling**
18. **Complete sequence flow**
19. **Actual source-code mapping**
20. **Implementation status**

The documentation should answer five fundamental questions for every feature:

```text
WHY does this feature exist?
        ↓
WHAT does it do?
        ↓
HOW does the request flow?
        ↓
WHERE is each responsibility implemented?
        ↓
WHAT happens to the data at every stage?
```

---

# 31. Planned Documentation Structure

The complete project documentation will be organized into the following sections:

```text
docs/
│
├── 01-project-overview.md
│
├── 02-system-architecture.md
├── 03-frontend-architecture.md
├── 04-backend-architecture.md
├── 05-database-architecture.md
├── 06-http-communication.md
│
├── authentication/
│   ├── registration.md
│   ├── login.md
│   ├── email-otp.md
│   ├── sms-otp.md
│   ├── google-login.md
│   ├── totp.md
│   └── jwt-security.md
│
├── customer/
│   ├── profile.md
│   ├── address-management.md
│   ├── store-browsing.md
│   ├── category-browsing.md
│   ├── product-browsing.md
│   ├── cart.md
│   └── orders.md
│
├── store-owner/
│   ├── registration.md
│   ├── approval.md
│   ├── store-management.md
│   └── product-management.md
│
├── delivery/
│   ├── delivery-flow.md
│   ├── assignment.md
│   ├── status-lifecycle.md
│   ├── location-tracking.md
│   └── distance-calculation.md
│
├── location/
│   ├── browser-geolocation.md
│   ├── geocoding.md
│   ├── reverse-geocoding.md
│   └── osrm.md
│
├── payment/
│   └── razorpay.md
│
├── security/
│   ├── spring-security.md
│   ├── jwt.md
│   ├── bcrypt.md
│   └── rate-limiting.md
│
├── database/
│   ├── schema.md
│   ├── relationships.md
│   └── data-flow.md
│
├── api/
│   └── api-reference.md
│
└── deployment/
    └── deployment.md
```

---

# 32. Documentation Standard

The documentation will use the following rule:

> **No technical flow should be documented as implemented unless it can be traced to the LocalMart source code or an explicitly documented project decision.**

For each feature, the documentation will distinguish:

```text
IMPLEMENTED
    ↓
Functionality exists in the current codebase.

PARTIALLY IMPLEMENTED
    ↓
Some components exist, but the complete flow is unfinished.

PLANNED
    ↓
The feature has been designed but is not currently implemented.
```

This prevents the documentation from becoming a theoretical description of a system that differs from the actual application.

---

# 33. Final Architecture Summary

At a high level, LocalMart can be represented as:

```text
                              LOCALMART
                                  │
             ┌────────────────────┼────────────────────┐
             │                    │                    │
             ▼                    ▼                    ▼
         FRONTEND              BACKEND             DATABASE
     React + TypeScript     Java + Spring Boot     PostgreSQL
             │                    │
             │                    ├── Security
             │                    ├── Controllers
             │                    ├── DTOs
             │                    ├── Services
             │                    ├── Repositories
             │                    └── External Integrations
             │                    │
             └──────── HTTP ──────┘
                                  │
                    ┌─────────────┼─────────────┐
                    │             │             │
                    ▼             ▼             ▼
                 Google       Messaging      Razorpay
                    │             │             │
                    └─────────────┼─────────────┘
                                  │
                            Location Services
                              │          │
                              ▼          ▼
                         Geocoding      OSRM
```

The detailed documentation that follows will move from this architectural level to the actual implementation level.

For every major flow, the source code will be traced from:

```text
Frontend
   ↓
HTTP Request
   ↓
Tomcat
   ↓
Spring Security
   ↓
Controller
   ↓
DTO
   ↓
Service
   ↓
Repository / External API
   ↓
Database / External Server
   ↓
Response
   ↓
Frontend
```

This creates a single consistent documentation model for the entire LocalMart system.
