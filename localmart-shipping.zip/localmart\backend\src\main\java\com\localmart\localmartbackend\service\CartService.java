package com.localmart.localmartbackend.service;

import com.localmart.localmartbackend.dto.AddCartItemRequest;
import com.localmart.localmartbackend.dto.CartItemResponse;
import com.localmart.localmartbackend.dto.CartResponse;
import com.localmart.localmartbackend.entity.Cart;
import com.localmart.localmartbackend.entity.CartItem;
import com.localmart.localmartbackend.entity.Product;
import com.localmart.localmartbackend.entity.StoreDetails;
import com.localmart.localmartbackend.repository.CartItemRepository;
import com.localmart.localmartbackend.repository.CartRepository;
import com.localmart.localmartbackend.repository.ProductRepository;
import com.localmart.localmartbackend.repository.StoreDetailsRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class CartService {

    private final CartRepository cartRepository;
    private final CartItemRepository cartItemRepository;
    private final ProductRepository productRepository;
    private final StoreDetailsRepository storeDetailsRepository;

    public CartService(
            CartRepository cartRepository,
            CartItemRepository cartItemRepository,
            ProductRepository productRepository,
            StoreDetailsRepository storeDetailsRepository
    ) {
        this.cartRepository = cartRepository;
        this.cartItemRepository = cartItemRepository;
        this.productRepository = productRepository;
        this.storeDetailsRepository = storeDetailsRepository;
    }

    @Transactional(readOnly = true)
    public CartResponse getCart(Long customerId) {

        Optional<Cart> cartOptional =
                cartRepository.findByCustomerId(customerId);

        if (cartOptional.isEmpty()) {
            return createEmptyCartResponse(customerId);
        }

        Cart cart = cartOptional.get();

        return buildCartResponse(cart);
    }

    @Transactional
    public CartResponse addItem(
            Long customerId,
            AddCartItemRequest request
    ) {

        if (request == null || request.getProductId() == null) {
            throw new RuntimeException("Product ID is required");
        }

        if (request.getQuantity() == null || request.getQuantity() <= 0) {
            throw new RuntimeException("Quantity must be greater than zero");
        }

        Product product =
                productRepository.findById(request.getProductId())
                        .orElseThrow(
                                () -> new RuntimeException("Product not found")
                        );

        if (!Boolean.TRUE.equals(product.getIsAvailable())) {
            throw new RuntimeException("Product is currently unavailable");
        }

        if (product.getStockQuantity() == null ||
                product.getStockQuantity() <= 0) {
            throw new RuntimeException("Product is out of stock");
        }

        if (request.getQuantity() > product.getStockQuantity()) {
            throw new RuntimeException(
                    "Requested quantity exceeds available stock"
            );
        }

        Cart cart =
                cartRepository.findByCustomerId(customerId)
                        .orElseGet(() -> createCart(customerId));

        List<CartItem> existingItems =
                cartItemRepository.findByCartId(cart.getCartId());

        for (CartItem existingItem : existingItems) {

            Product existingProduct =
                    productRepository.findById(existingItem.getProductId())
                            .orElse(null);

            if (existingProduct == null) {
                continue;
            }

            if (!existingProduct.getStoreId()
                    .equals(product.getStoreId())) {

                throw new RuntimeException(
                        "Your cart contains products from another store. " +
                                "Clear your cart before adding products from this store."
                );
            }
        }

        Optional<CartItem> existingItemOptional =
                cartItemRepository.findByCartIdAndProductId(
                        cart.getCartId(),
                        product.getProductId()
                );

        if (existingItemOptional.isPresent()) {

            CartItem existingItem =
                    existingItemOptional.get();

            int newQuantity =
                    existingItem.getQuantity()
                            + request.getQuantity();

            if (newQuantity > product.getStockQuantity()) {
                throw new RuntimeException(
                        "Requested quantity exceeds available stock"
                );
            }

            existingItem.setQuantity(newQuantity);

            cartItemRepository.save(existingItem);

        } else {

            CartItem cartItem = new CartItem();

            cartItem.setCartId(cart.getCartId());
            cartItem.setProductId(product.getProductId());
            cartItem.setQuantity(request.getQuantity());

            cartItemRepository.save(cartItem);
        }

        cart.setUpdatedAt(java.time.LocalDateTime.now());
        cartRepository.save(cart);

        return buildCartResponse(cart);
    }

    @Transactional
    public CartResponse updateItem(
            Long customerId,
            Long cartItemId,
            Integer quantity
    ) {

        if (quantity == null || quantity <= 0) {
            throw new RuntimeException(
                    "Quantity must be greater than zero"
            );
        }

        Cart cart =
                cartRepository.findByCustomerId(customerId)
                        .orElseThrow(
                                () -> new RuntimeException("Cart not found")
                        );

        CartItem cartItem =
                cartItemRepository
                        .findByCartItemIdAndCartId(
                                cartItemId,
                                cart.getCartId()
                        )
                        .orElseThrow(
                                () -> new RuntimeException(
                                        "Cart item not found"
                                )
                        );

        Product product =
                productRepository.findById(cartItem.getProductId())
                        .orElseThrow(
                                () -> new RuntimeException(
                                        "Product not found"
                                )
                        );

        if (!Boolean.TRUE.equals(product.getIsAvailable())) {
            throw new RuntimeException(
                    "Product is currently unavailable"
            );
        }

        if (product.getStockQuantity() == null ||
                quantity > product.getStockQuantity()) {
            throw new RuntimeException(
                    "Requested quantity exceeds available stock"
            );
        }

        cartItem.setQuantity(quantity);

        cartItemRepository.save(cartItem);

        cart.setUpdatedAt(java.time.LocalDateTime.now());
        cartRepository.save(cart);

        return buildCartResponse(cart);
    }

    @Transactional
    public void deleteItem(
            Long customerId,
            Long cartItemId
    ) {

        Cart cart =
                cartRepository.findByCustomerId(customerId)
                        .orElseThrow(
                                () -> new RuntimeException("Cart not found")
                        );

        CartItem cartItem =
                cartItemRepository
                        .findByCartItemIdAndCartId(
                                cartItemId,
                                cart.getCartId()
                        )
                        .orElseThrow(
                                () -> new RuntimeException(
                                        "Cart item not found"
                                )
                        );

        cartItemRepository.delete(cartItem);

        cart.setUpdatedAt(java.time.LocalDateTime.now());
        cartRepository.save(cart);
    }

    @Transactional
    public void clearCart(Long customerId) {

        Cart cart =
                cartRepository.findByCustomerId(customerId)
                        .orElseThrow(
                                () -> new RuntimeException("Cart not found")
                        );

        cartItemRepository.deleteByCartId(cart.getCartId());

        cart.setUpdatedAt(java.time.LocalDateTime.now());
        cartRepository.save(cart);
    }

    private Cart createCart(Long customerId) {

        Cart cart = new Cart();

        cart.setCustomerId(customerId);

        return cartRepository.save(cart);
    }

    private CartResponse createEmptyCartResponse(
            Long customerId
    ) {

        CartResponse response = new CartResponse();

        response.setCustomerId(customerId);
        response.setItems(new ArrayList<>());
        response.setSubtotal(BigDecimal.ZERO);
        response.setItemCount(0);

        return response;
    }

    private CartResponse buildCartResponse(Cart cart) {

        CartResponse response = new CartResponse();

        response.setCartId(cart.getCartId());
        response.setCustomerId(cart.getCustomerId());

        List<CartItem> cartItems =
                cartItemRepository.findByCartId(
                        cart.getCartId()
                );

        List<CartItemResponse> itemResponses =
                new ArrayList<>();

        BigDecimal subtotal = BigDecimal.ZERO;
        int itemCount = 0;

        Long cartStoreId = null;
        String cartStoreName = null;

        for (CartItem cartItem : cartItems) {

            Product product =
                    productRepository.findById(
                            cartItem.getProductId()
                    ).orElse(null);

            if (product == null) {
                continue;
            }

            CartItemResponse itemResponse =
                    new CartItemResponse();

            itemResponse.setCartItemId(
                    cartItem.getCartItemId()
            );

            itemResponse.setProductId(
                    product.getProductId()
            );

            itemResponse.setProductName(
                    product.getProductName()
            );

            itemResponse.setCategory(
                    product.getCategory()
            );

            itemResponse.setDescription(
                    product.getDescription()
            );

            itemResponse.setPrice(
                    product.getPrice()
            );

            itemResponse.setUnit(
                    product.getUnit()
            );

            itemResponse.setQuantity(
                    cartItem.getQuantity()
            );

            itemResponse.setStockQuantity(
                    product.getStockQuantity()
            );

            itemResponse.setIcon(
                    product.getIcon()
            );

            itemResponse.setIsAvailable(
                    product.getIsAvailable()
            );

            itemResponse.setStoreId(
                    product.getStoreId()
            );

            Optional<StoreDetails> storeOptional =
                    storeDetailsRepository.findById(
                            product.getStoreId()
                    );

            String storeName = null;

            if (storeOptional.isPresent()) {
                storeName =
                        storeOptional.get().getStoreName();
            }

            itemResponse.setStoreName(storeName);

            BigDecimal itemTotal =
                    product.getPrice()
                            .multiply(
                                    BigDecimal.valueOf(
                                            cartItem.getQuantity()
                                    )
                            );

            itemResponse.setItemTotal(itemTotal);

            itemResponses.add(itemResponse);

            subtotal = subtotal.add(itemTotal);

            itemCount += cartItem.getQuantity();

            if (cartStoreId == null) {
                cartStoreId = product.getStoreId();
                cartStoreName = storeName;
            }
        }

        response.setItems(itemResponses);
        response.setSubtotal(subtotal);
        response.setItemCount(itemCount);
        response.setStoreId(cartStoreId);
        response.setStoreName(cartStoreName);

        return response;
    }
}