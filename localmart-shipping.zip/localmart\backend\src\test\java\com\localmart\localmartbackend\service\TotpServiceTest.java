
        package com.localmart.localmartbackend.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TotpServiceTest {

    @Test
    void shouldGenerateAndVerifyTotp() {

        // Create our TOTP service
        TotpService totpService =
                new TotpService();

        // 1. Generate a secret
        String secret =
                totpService.generateSecret();

        System.out.println(
                "Secret: " + secret
        );

        // 2. Generate the current OTP
        String otp =
                totpService.generateOtp(secret);

        System.out.println(
                "Generated OTP: " + otp
        );

        // 3. Verify the generated OTP
        boolean valid =
                totpService.verifyOtp(
                        secret,
                        otp
                );

        System.out.println(
                "OTP valid: " + valid
        );

        // 4. The generated OTP must be valid
        assertTrue(valid);
    }


    @Test
    void shouldRejectWrongOtp() {

        TotpService totpService =
                new TotpService();

        String secret =
                totpService.generateSecret();

        String wrongOtp =
                "123456";

        boolean valid =
                totpService.verifyOtp(
                        secret,
                        wrongOtp
                );

        System.out.println(
                "Wrong OTP valid: " + valid
        );

        assertFalse(valid);
    }
}

