package com.localmart.localmartbackend.repository;

import com.localmart.localmartbackend.entity.ApplicationRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ApplicationRequestRepository
        extends JpaRepository<ApplicationRequest, Long> {

    List<ApplicationRequest> findByApplicationStatus(
            Integer applicationStatus
    );

    List<ApplicationRequest> findByApplicationTypeAndApplicationStatus(
            Integer applicationType,
            Integer applicationStatus
    );

    List<ApplicationRequest> findByUserId(
            Long userId
    );

    List<ApplicationRequest> findByUserIdAndApplicationStatus(
            Long userId,
            Integer applicationStatus
    );

    Optional<ApplicationRequest> findByUserIdAndApplicationType(
            Long userId,
            Integer applicationType
    );
}