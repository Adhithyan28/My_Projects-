
        package com.localmart.localmartbackend.service;

import com.localmart.localmartbackend.dto.CustomerProfileRequest;
import com.localmart.localmartbackend.dto.CustomerProfileResponse;
import com.localmart.localmartbackend.entity.Address;
import com.localmart.localmartbackend.entity.Role;
import com.localmart.localmartbackend.entity.User;
import com.localmart.localmartbackend.repository.AddressRepository;
import com.localmart.localmartbackend.repository.RoleRepository;
import com.localmart.localmartbackend.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
public class CustomerService {

    private static final int ROLE_CUSTOMER = 1;

    private static final Pattern PHONE_PATTERN =
            Pattern.compile("^[6-9][0-9]{9}$");

    private final UserRepository userRepository;
    private final AddressRepository addressRepository;
    private final RoleRepository roleRepository;

    public CustomerService(
            UserRepository userRepository,
            AddressRepository addressRepository,
            RoleRepository roleRepository) {

        this.userRepository = userRepository;
        this.addressRepository = addressRepository;
        this.roleRepository = roleRepository;
    }

    @Transactional(readOnly = true)
    public CustomerProfileResponse getProfile(Long userId) {

        User user = getCustomer(userId);

        List<Address> addresses =
                addressRepository.findByUserId(userId);

        return buildProfileResponse(
                user,
                addresses
        );
    }

    @Transactional
    public CustomerProfileResponse updateProfile(
            Long userId,
            CustomerProfileRequest request) {

        if (request == null) {
            throw new RuntimeException(
                    "Profile update request is required"
            );
        }

        User user = getCustomer(userId);

        if (isBlank(request.getFirstName())) {
            throw new RuntimeException(
                    "First name is required"
            );
        }

        if (isBlank(request.getLastName())) {
            throw new RuntimeException(
                    "Last name is required"
            );
        }

        if (isBlank(request.getPhone())) {
            throw new RuntimeException(
                    "Mobile number is required"
            );
        }

        String phone = request.getPhone().trim();

        if (!PHONE_PATTERN.matcher(phone).matches()) {
            throw new RuntimeException(
                    "Please enter a valid 10-digit Indian mobile number"
            );
        }

        Optional<User> existingUser =
                userRepository.findByPhone(phone);

        if (existingUser.isPresent()
                && !existingUser.get()
                .getUserId()
                .equals(userId)) {

            throw new RuntimeException(
                    "Mobile number is already registered"
            );
        }

        user.setFirstName(
                request.getFirstName().trim()
        );

        user.setLastName(
                request.getLastName().trim()
        );

        user.setPhone(phone);

        User savedUser =
                userRepository.save(user);

        List<Address> addresses =
                addressRepository.findByUserId(userId);

        return buildProfileResponse(
                savedUser,
                addresses
        );
    }

    private User getCustomer(Long userId) {

        if (userId == null) {
            throw new RuntimeException(
                    "User is not authenticated"
            );
        }

        User user =
                userRepository.findById(userId)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Customer account not found"
                                )
                        );

        Role role =
                roleRepository.findByUserId(userId)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "User role not found"
                                )
                        );

        if (role.getRole() != ROLE_CUSTOMER) {
            throw new RuntimeException(
                    "Only customers can access this profile"
            );
        }

        return user;
    }

    private CustomerProfileResponse buildProfileResponse(
            User user,
            List<Address> addresses) {

        CustomerProfileResponse response =
                new CustomerProfileResponse();

        response.setUserId(
                user.getUserId()
        );

        response.setFirstName(
                user.getFirstName()
        );

        response.setLastName(
                user.getLastName()
        );

        response.setEmail(
                user.getEmail()
        );

        response.setPhone(
                user.getPhone()
        );

        List<CustomerProfileResponse.AddressInfo>
                addressInfoList =
                addresses.stream()
                        .map(this::convertAddress)
                        .collect(Collectors.toList());

        response.setAddresses(
                addressInfoList
        );

        response.setProfileComplete(
                isProfileComplete(
                        user,
                        addresses
                )
        );

        return response;
    }

    private boolean isProfileComplete(
            User user,
            List<Address> addresses) {

        if (isBlank(user.getFirstName())) {
            return false;
        }

        if (isBlank(user.getLastName())) {
            return false;
        }

        if (isBlank(user.getPhone())) {
            return false;
        }

        if (addresses == null ||
                addresses.isEmpty()) {
            return false;
        }

        long defaultAddressCount =
                addresses.stream()
                        .filter(address ->
                                Boolean.TRUE.equals(
                                        address.getIsDefault()
                                )
                        )
                        .count();

        if (defaultAddressCount != 1) {
            return false;
        }

        return addresses.stream()
                .anyMatch(address ->
                        Boolean.TRUE.equals(
                                address.getIsDefault()
                        )
                                && address.getLatitude() != null
                                && address.getLongitude() != null
                                && !isBlank(
                                address.getAddressLine()
                        )
                                && !isBlank(
                                address.getCity()
                        )
                                && !isBlank(
                                address.getState()
                        )
                                && !isBlank(
                                address.getPincode()
                        )
                );
    }

    private CustomerProfileResponse.AddressInfo
    convertAddress(Address address) {

        CustomerProfileResponse.AddressInfo info =
                new CustomerProfileResponse.AddressInfo();

        info.setAddressId(
                address.getAddressId()
        );

        info.setAddressLine(
                address.getAddressLine()
        );

        info.setCity(
                address.getCity()
        );

        info.setState(
                address.getState()
        );

        info.setPincode(
                address.getPincode()
        );

        info.setLatitude(
                address.getLatitude()
        );

        info.setLongitude(
                address.getLongitude()
        );

        info.setDefault(
                Boolean.TRUE.equals(
                        address.getIsDefault()
                )
        );

        return info;
    }

    private boolean isBlank(String value) {

        return value == null ||
                value.trim().isEmpty();
    }
}
