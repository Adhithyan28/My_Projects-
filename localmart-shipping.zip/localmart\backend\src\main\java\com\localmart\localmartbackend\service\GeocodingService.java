
        package com.localmart.localmartbackend.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class GeocodingService {

    private final HttpClient httpClient;

    private final String locationIqAccessToken;

    public GeocodingService(@Value("${locationiq.access-token}") String locationIqAccessToken) {
        this.httpClient = HttpClient.newHttpClient();
        this.locationIqAccessToken = locationIqAccessToken;
    }

    public Coordinates geocode(
            String addressLine,
            String city,
            String state,
            String pincode
    ) {

        String address =
                String.join(
                        ", ",
                        addressLine,
                        city,
                        state,
                        pincode,
                        "India"
                );

        String encodedAddress =
                URLEncoder.encode(
                        address,
                        StandardCharsets.UTF_8
                );

        if (locationIqAccessToken.isBlank()) {
            throw new IllegalStateException("LOCATIONIQ_ACCESS_TOKEN is not configured.");
        }

        String url =
                "https://us1.locationiq.com/v1/search"
                        + "?key=" + locationIqAccessToken
                        + "&q=" + encodedAddress
                        + "&format=json"
                        + "&limit=1"
                        + "&countrycodes=in";

        try {

            HttpRequest request =
                    HttpRequest.newBuilder()
                            .uri(URI.create(url))
                            .header(
                                    "User-Agent",
                                    "LocalMart/1.0"
                            )
                            .header(
                                    "Accept",
                                    "application/json"
                            )
                            .GET()
                            .build();

            HttpResponse<String> response =
                    httpClient.send(
                            request,
                            HttpResponse.BodyHandlers.ofString()
                    );

            if (response.statusCode() != 200) {

                throw new RuntimeException(
                        "LocationIQ returned HTTP "
                                + response.statusCode()
                );
            }

            String responseBody =
                    response.body();

            Pattern latitudePattern =
                    Pattern.compile(
                            "\"lat\"\\s*:\\s*\"([^\"]+)\""
                    );

            Pattern longitudePattern =
                    Pattern.compile(
                            "\"lon\"\\s*:\\s*\"([^\"]+)\""
                    );

            Matcher latitudeMatcher =
                    latitudePattern.matcher(
                            responseBody
                    );

            Matcher longitudeMatcher =
                    longitudePattern.matcher(
                            responseBody
                    );

            if (!latitudeMatcher.find()
                    || !longitudeMatcher.find()) {

                throw new RuntimeException(
                        "LocationIQ could not find the location for the entered address."
                );
            }

            BigDecimal latitude =
                    new BigDecimal(
                            latitudeMatcher.group(1)
                    );

            BigDecimal longitude =
                    new BigDecimal(
                            longitudeMatcher.group(1)
                    );

            return new Coordinates(
                    latitude,
                    longitude
            );

        } catch (InterruptedException e) {

            Thread.currentThread().interrupt();

            throw new RuntimeException(
                    "Location search was interrupted.",
                    e
            );

        } catch (Exception e) {

            if (e instanceof RuntimeException) {
                throw (RuntimeException) e;
            }

            throw new RuntimeException(
                    "Unable to determine the store location from the address.",
                    e
            );
        }
    }

    public record Coordinates(
            BigDecimal latitude,
            BigDecimal longitude
    ) {}
}
