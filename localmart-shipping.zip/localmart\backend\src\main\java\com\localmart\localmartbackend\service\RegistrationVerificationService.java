package com.localmart.localmartbackend.service;

import org.springframework.stereotype.Service;
import com.localmart.localmartbackend.repository.UserRepository;

import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

@Service
public class RegistrationVerificationService {

    private static final int TOKEN_EXPIRY_MINUTES = 10;

    private static final Pattern EMAIL_PATTERN =
            Pattern.compile(
                    "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$"
            );

    private static final Pattern PHONE_PATTERN =
            Pattern.compile(
                    "^[6-9][0-9]{9}$"
            );

    private final OtpService otpService;
    private final OtpDeliveryService otpDeliveryService;
    private final UserRepository userRepository;

    private final SecureRandom secureRandom =
            new SecureRandom();

    /*
     * Key   = registration token
     * Value = temporary verified registration session
     */
    private final Map<String, RegistrationSession>
            registrationSessions =
            new ConcurrentHashMap<>();

    /*
     * Key = normalized identifier
     * Value = temporary OTP information
     *
     * This is mainly used for SMS because Message Central
     * returns a verificationId which must be retained until
     * the OTP is verified.
     */
    private final Map<String, PendingOtp>
            pendingOtps =
            new ConcurrentHashMap<>();

    public RegistrationVerificationService(
            OtpService otpService,
            OtpDeliveryService otpDeliveryService,
            UserRepository userRepository) {

        this.otpService = otpService;
        this.otpDeliveryService =
                otpDeliveryService;
        this.userRepository =
                userRepository;
    }


    // =========================================================
    // SEND REGISTRATION OTP
    // =========================================================

    public void sendOtp(String identifier) {

        IdentifierInfo identifierInfo =
                detectIdentifier(identifier);

        String normalizedIdentifier =
                identifierInfo.identifier();

        /*
         * Do not allow registration to begin with an
         * identifier that already belongs to an account.
         */
        if (identifierInfo.type()
                == IdentifierType.EMAIL) {

            if (userRepository
                    .findByEmail(normalizedIdentifier)
                    .isPresent()) {

                throw new RuntimeException(
                        "An account already exists with this email."
                );
            }

            /*
             * Existing email OTP service handles:
             *
             * OTP generation
             * BCrypt hashing
             * expiry
             * email delivery
             */
            otpService.sendEmailOtp(
                    normalizedIdentifier
            );

        } else {

            if (userRepository
                    .findByPhone(normalizedIdentifier)
                    .isPresent()) {

                throw new RuntimeException(
                        "An account already exists with this mobile number."
                );
            }

            /*
             * Message Central sends the SMS OTP.
             *
             * verificationId must be retained because
             * Message Central requires it when validating
             * the OTP.
             */
            String verificationId =
                    otpDeliveryService.sendSmsOtp(
                            normalizedIdentifier
                    );

            pendingOtps.put(
                    normalizedIdentifier,
                    new PendingOtp(
                            verificationId,
                            LocalDateTime.now()
                                    .plusMinutes(
                                            TOKEN_EXPIRY_MINUTES
                                    )
                    )
            );
        }
    }


    // =========================================================
    // VERIFY REGISTRATION OTP
    // =========================================================

    public RegistrationVerificationResult verifyOtp(
            String identifier,
            String otp) {

        IdentifierInfo identifierInfo =
                detectIdentifier(identifier);

        String normalizedIdentifier =
                identifierInfo.identifier();

        if (otp == null || otp.isBlank()) {

            throw new IllegalArgumentException(
                    "OTP is required."
            );
        }

        /*
         * Verify the OTP according to the identifier type.
         */
        if (identifierInfo.type()
                == IdentifierType.EMAIL) {

            otpService.verifyEmailOtp(
                    normalizedIdentifier,
                    otp.trim()
            );

        } else {

            PendingOtp pendingOtp =
                    pendingOtps.get(
                            normalizedIdentifier
                    );

            if (pendingOtp == null) {

                throw new RuntimeException(
                        "No OTP found. Please request a new OTP."
                );
            }

            if (LocalDateTime.now()
                    .isAfter(pendingOtp.expiresAt())) {

                pendingOtps.remove(
                        normalizedIdentifier
                );

                throw new RuntimeException(
                        "OTP has expired. Please request a new OTP."
                );
            }

            boolean verified =
                    otpDeliveryService.verifyOtp(
                            pendingOtp.verificationId(),
                            otp.trim()
                    );

            if (!verified) {

                throw new RuntimeException(
                        "Invalid OTP."
                );
            }

            /*
             * SMS OTP is single-use.
             */
            pendingOtps.remove(
                    normalizedIdentifier
            );
        }


        // =====================================================
        // OTP SUCCESSFUL
        // =====================================================

        /*
         * Generate a random token.
         *
         * This token is NOT a JWT.
         *
         * It only proves that this particular identifier
         * successfully completed registration OTP verification.
         */
        String registrationToken =
                generateRegistrationToken();

        LocalDateTime createdAt =
                LocalDateTime.now();

        LocalDateTime expiresAt =
                createdAt.plusMinutes(
                        TOKEN_EXPIRY_MINUTES
                );

        RegistrationSession session =
                new RegistrationSession(
                        registrationToken,
                        normalizedIdentifier,
                        identifierInfo.type(),
                        createdAt,
                        expiresAt
                );

        registrationSessions.put(
                registrationToken,
                session
        );

        return new RegistrationVerificationResult(
                registrationToken,
                normalizedIdentifier,
                identifierInfo.type().name()
        );
    }


    // =========================================================
    // GOOGLE REGISTRATION VERIFICATION
    // =========================================================

    public RegistrationVerificationResult
    createGoogleRegistrationVerification(
            String googleEmail) {

        /*
         * Normalize the Google verified email.
         */
        String normalizedEmail =
                normalizeEmail(googleEmail);

        /*
         * Google registration must not create a second
         * LocalMart account when the email already exists.
         */
        if (userRepository
                .findByEmail(normalizedEmail)
                .isPresent()) {

            throw new RuntimeException(
                    "An account already exists with this Google email."
            );
        }

        /*
         * Generate the same type of temporary registration
         * token used by Email and Mobile registration.
         *
         * This token is NOT a JWT.
         */
        String registrationToken =
                generateRegistrationToken();

        LocalDateTime createdAt =
                LocalDateTime.now();

        LocalDateTime expiresAt =
                createdAt.plusMinutes(
                        TOKEN_EXPIRY_MINUTES
                );

        /*
         * Store Google verification as a temporary
         * registration session.
         */
        RegistrationSession session =
                new RegistrationSession(
                        registrationToken,
                        normalizedEmail,
                        IdentifierType.GOOGLE,
                        createdAt,
                        expiresAt
                );

        registrationSessions.put(
                registrationToken,
                session
        );

        return new RegistrationVerificationResult(
                registrationToken,
                normalizedEmail,
                IdentifierType.GOOGLE.name()
        );
    }


    // =========================================================
    // VALIDATE REGISTRATION TOKEN
    // =========================================================

    public RegistrationSession validateToken(
            String registrationToken) {

        if (registrationToken == null
                || registrationToken.isBlank()) {

            throw new IllegalArgumentException(
                    "Registration verification token is required."
            );
        }

        RegistrationSession session =
                registrationSessions.get(
                        registrationToken
                );

        if (session == null) {

            throw new RuntimeException(
                    "Invalid or expired registration verification."
            );
        }

        if (LocalDateTime.now()
                .isAfter(session.expiresAt())) {

            registrationSessions.remove(
                    registrationToken
            );

            throw new RuntimeException(
                    "Registration verification has expired. Please verify OTP again."
            );
        }

        return session;
    }


    // =========================================================
    // CONSUME REGISTRATION TOKEN
    // =========================================================

    public void consumeToken(
            String registrationToken) {

        if (registrationToken != null) {

            registrationSessions.remove(
                    registrationToken
            );
        }
    }


    // =========================================================
    // VERIFY IDENTIFIER AGAINST TOKEN
    // =========================================================

    public void validateVerifiedIdentifier(
            RegistrationSession session,
            String email,
            String phone) {

        if (session == null) {

            throw new IllegalArgumentException(
                    "Registration verification session is required."
            );
        }

        /*
         * Email OTP registration
         */
        if (session.identifierType()
                == IdentifierType.EMAIL) {

            String normalizedEmail =
                    normalizeEmail(email);

            if (!session.identifier()
                    .equals(normalizedEmail)) {

                throw new RuntimeException(
                        "The registered email must match the email that was verified."
                );
            }

        }

        /*
         * Mobile OTP registration
         */
        else if (session.identifierType()
                == IdentifierType.MOBILE) {

            String normalizedPhone =
                    normalizePhone(phone);

            if (!session.identifier()
                    .equals(normalizedPhone)) {

                throw new RuntimeException(
                        "The registered mobile number must match the mobile number that was verified."
                );
            }

        }

        /*
         * Google registration
         */
        else if (session.identifierType()
                == IdentifierType.GOOGLE) {

            String normalizedEmail =
                    normalizeEmail(email);

            if (!session.identifier()
                    .equals(normalizedEmail)) {

                throw new RuntimeException(
                        "The registered email must match the Google account email."
                );
            }
        }

        else {

            throw new RuntimeException(
                    "Unsupported registration verification type."
            );
        }
    }


    // =========================================================
    // IDENTIFIER DETECTION
    // =========================================================

    private IdentifierInfo detectIdentifier(
            String identifier) {

        if (identifier == null
                || identifier.isBlank()) {

            throw new IllegalArgumentException(
                    "Email or mobile number is required."
            );
        }

        String trimmed =
                identifier.trim();

        /*
         * Email detection
         */
        if (EMAIL_PATTERN.matcher(trimmed).matches()) {

            return new IdentifierInfo(
                    normalizeEmail(trimmed),
                    IdentifierType.EMAIL
            );
        }

        /*
         * Mobile detection
         */
        String normalizedPhone =
                normalizePhone(trimmed);

        return new IdentifierInfo(
                normalizedPhone,
                IdentifierType.MOBILE
        );
    }


    // =========================================================
    // EMAIL NORMALIZATION
    // =========================================================

    private String normalizeEmail(
            String email) {

        if (email == null
                || email.isBlank()) {

            throw new IllegalArgumentException(
                    "Email is required."
            );
        }

        String normalized =
                email.trim().toLowerCase();

        if (!EMAIL_PATTERN
                .matcher(normalized)
                .matches()) {

            throw new IllegalArgumentException(
                    "Invalid email address."
            );
        }

        return normalized;
    }


    // =========================================================
    // MOBILE NORMALIZATION
    // =========================================================

    private String normalizePhone(
            String phone) {

        if (phone == null
                || phone.isBlank()) {

            throw new IllegalArgumentException(
                    "Mobile number is required."
            );
        }

        String cleaned =
                phone.trim()
                        .replaceAll(
                                "[^0-9]",
                                ""
                        );

        /*
         * Accept:
         *
         * 9876543210
         * +91 9876543210
         * 919876543210
         */
        if (cleaned.startsWith("91")
                && cleaned.length() == 12) {

            cleaned =
                    cleaned.substring(2);
        }

        if (!PHONE_PATTERN
                .matcher(cleaned)
                .matches()) {

            throw new IllegalArgumentException(
                    "Invalid Indian mobile number."
            );
        }

        return cleaned;
    }


    // =========================================================
    // SECURE TOKEN GENERATION
    // =========================================================

    private String generateRegistrationToken() {

        /*
         * UUID provides a large random identifier.
         *
         * Additional random value makes the temporary
         * registration token independent of the user's
         * email/mobile identifier.
         */
        long randomValue =
                secureRandom.nextLong();

        return UUID.randomUUID()
                + "-"
                + Long.toUnsignedString(
                randomValue
        );
    }


    // =========================================================
    // ENUMS
    // =========================================================

    public enum IdentifierType {

        EMAIL,
        MOBILE,
        GOOGLE
    }


    // =========================================================
    // TEMPORARY REGISTRATION SESSION
    // =========================================================

    public record RegistrationSession(
            String registrationToken,
            String identifier,
            IdentifierType identifierType,
            LocalDateTime createdAt,
            LocalDateTime expiresAt
    ) {
    }


    // =========================================================
    // OTP RESULT
    // =========================================================

    public record RegistrationVerificationResult(
            String registrationToken,
            String identifier,
            String identifierType
    ) {
    }


    // =========================================================
    // PENDING SMS OTP
    // =========================================================

    private record PendingOtp(
            String verificationId,
            LocalDateTime expiresAt
    ) {
    }


    // =========================================================
    // IDENTIFIER INFO
    // =========================================================

    private record IdentifierInfo(
            String identifier,
            IdentifierType type
    ) {
    }
}