package com.localmart.localmartbackend.service;

import com.localmart.localmartbackend.dto.DeliveryPartnerAvailabilityRequest;
import com.localmart.localmartbackend.dto.DeliveryPartnerLocationRequest;
import com.localmart.localmartbackend.entity.DeliveryPartnerLocation;
import com.localmart.localmartbackend.repository.DeliveryPartnerLocationRepository;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
public class DeliveryPartnerLocationService {

    private final DeliveryPartnerLocationRepository locationRepository;

    public DeliveryPartnerLocationService(
            DeliveryPartnerLocationRepository locationRepository) {

        this.locationRepository = locationRepository;
    }

    @Transactional
    public DeliveryPartnerLocation updateLocation(
            Long userId,
            DeliveryPartnerLocationRequest request) {

        DeliveryPartnerLocation location =
                locationRepository
                        .findById(userId)
                        .orElseGet(() -> {

                            DeliveryPartnerLocation newLocation =
                                    new DeliveryPartnerLocation();

                            newLocation.setUserId(userId);

                            return newLocation;
                        });

        location.setLatitude(request.getLatitude());
        location.setLongitude(request.getLongitude());
        location.setUpdatedAt(LocalDateTime.now());

        if (location.getAvailabilityStatus() == null) {
            location.setAvailabilityStatus("OFFLINE");
        }

        return locationRepository.save(location);
    }

    @Transactional
    public DeliveryPartnerLocation updateAvailability(
            Long userId,
            DeliveryPartnerAvailabilityRequest request) {

        String status =
                request.getStatus()
                        .trim()
                        .toUpperCase();

        if (!status.equals("AVAILABLE")
                && !status.equals("OFFLINE")) {

            throw new IllegalArgumentException(
                    "Invalid availability status"
            );
        }

        /*
         * Going ONLINE requires an actual GPS location.
         */
        if (status.equals("AVAILABLE")) {

            if (request.getLatitude() == null
                    || request.getLongitude() == null) {

                throw new IllegalArgumentException(
                        "GPS location is required to go online"
                );
            }

            DeliveryPartnerLocation location =
                    locationRepository
                            .findById(userId)
                            .orElseGet(() -> {

                                DeliveryPartnerLocation newLocation =
                                        new DeliveryPartnerLocation();

                                newLocation.setUserId(userId);

                                return newLocation;
                            });

            location.setLatitude(request.getLatitude());
            location.setLongitude(request.getLongitude());
            location.setUpdatedAt(LocalDateTime.now());
            location.setAvailabilityStatus("AVAILABLE");

            return locationRepository.save(location);
        }

        /*
         * Going OFFLINE.
         *
         * If a location row exists, simply change its
         * availability. We keep the last GPS coordinates
         * for reference, but the partner will no longer
         * qualify for delivery assignment.
         */
        DeliveryPartnerLocation location =
                locationRepository
                        .findById(userId)
                        .orElse(null);

        if (location != null) {

            location.setAvailabilityStatus("OFFLINE");
            location.setUpdatedAt(LocalDateTime.now());

            return locationRepository.save(location);
        }

        return null;
    }
    @Transactional(readOnly = true)
    public DeliveryPartnerLocation getLocation(Long userId) {

        return locationRepository
                .findById(userId)
                .orElse(null);
    }
}