package com.localmart.localmartbackend.controller;

import com.localmart.localmartbackend.dto.CreateOrderRequest;
import com.localmart.localmartbackend.dto.DeliveryFeeRequest;
import com.localmart.localmartbackend.dto.DeliveryOrderResponse;
import com.localmart.localmartbackend.entity.Address;
import com.localmart.localmartbackend.entity.Order;
import com.localmart.localmartbackend.entity.OrderItem;
import com.localmart.localmartbackend.repository.AddressRepository;
import com.localmart.localmartbackend.service.OrderService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/orders")
@CrossOrigin(origins = {
        "http://localhost:5173",
        "http://localhost:5174",
        "http://localhost:5175"
})
public class OrderController {

    private final OrderService orderService;
    private final AddressRepository addressRepository;

    public OrderController(
            OrderService orderService,
            AddressRepository addressRepository
    ) {
        this.orderService = orderService;
        this.addressRepository = addressRepository;
    }

    @PostMapping
    public ResponseEntity<Order> createOrder(
            Authentication authentication,
            @RequestBody CreateOrderRequest request
    ) {
        Long customerId =
                getUserId(authentication);

        return ResponseEntity.ok(
                orderService.createOrder(
                        customerId,
                        request
                )
        );
    }

    @PostMapping("/upi")
    public ResponseEntity<Map<String, Object>> createUpiPayment(
            Authentication authentication,
            @RequestBody CreateOrderRequest request
    ) {
        Long customerId =
                getUserId(authentication);

        return ResponseEntity.ok(
                orderService.createUpiPayment(
                        customerId,
                        request
                )
        );
    }

    /*
     * =============================================================
     * CHECKOUT DELIVERY FEE CALCULATION
     * =============================================================
     *
     * This endpoint is called by Checkout BEFORE the customer
     * places the order.
     *
     * It calculates:
     *
     * Store -> Customer road distance
     * +
     * Delivery fee based on that distance.
     *
     * The actual order creation still recalculates everything
     * on the backend. Therefore the customer cannot manipulate
     * the delivery fee from the frontend.
     */
    @PostMapping("/calculate-delivery-fee")
    public ResponseEntity<?> calculateDeliveryFee(
            Authentication authentication,
            @Valid @RequestBody DeliveryFeeRequest request
    ) {

        try {

            Long customerId =
                    getUserId(authentication);

            /*
             * Find the selected customer address.
             */
            Address customerAddress =
                    addressRepository
                            .findById(request.getAddressId())
                            .orElseThrow(() ->
                                    new RuntimeException(
                                            "Delivery address not found"
                                    )
                            );

            /*
             * Make sure the customer is using
             * their own address.
             */
            if (!customerAddress.getUserId().equals(customerId)) {

                return ResponseEntity
                        .status(403)
                        .body(
                                Map.of(
                                        "message",
                                        "You are not authorized to use this address"
                                )
                        );
            }

            /*
             * Calculate Store -> Customer road distance.
             */
            BigDecimal deliveryDistanceKm =
                    orderService.calculateDeliveryDistanceForCheckout(
                            request.getStoreId(),
                            customerAddress
                    );

            /*
             * Calculate delivery fee using the
             * same backend fare rules used during
             * actual order creation.
             */
            BigDecimal deliveryFee =
                    orderService.calculateDeliveryFeeForCheckout(
                            deliveryDistanceKm
                    );

            /*
             * Send the calculated values back to Checkout.
             */
            return ResponseEntity.ok(
                    Map.of(
                            "distanceKm",
                            deliveryDistanceKm,

                            "deliveryFee",
                            deliveryFee
                    )
            );

        } catch (Exception e) {

            return ResponseEntity
                    .badRequest()
                    .body(
                            Map.of(
                                    "message",
                                    e.getMessage() != null
                                            ? e.getMessage()
                                            : "Unable to calculate delivery fee"
                            )
                    );
        }
    }

    /*
     * =============================================================
     * RAZORPAY UPI PAYMENT VERIFICATION
     * =============================================================
     *
     * Razorpay Checkout returns:
     *
     * razorpay_payment_id
     * razorpay_order_id
     * razorpay_signature
     *
     * The frontend sends those three values here.
     *
     * IMPORTANT:
     *
     * The Razorpay SECRET is NEVER sent by the frontend.
     *
     * OrderService -> RazorpayService performs the actual
     * server-side signature verification.
     */
    @PostMapping("/{orderId}/payment/verify")
    public ResponseEntity<Order> verifyRazorpayUpiPayment(
            Authentication authentication,
            @PathVariable Long orderId,
            @RequestBody Map<String, String> request
    ) {
        Long customerId =
                getUserId(authentication);

        String razorpayOrderId =
                request.get("razorpayOrderId");

        String razorpayPaymentId =
                request.get("razorpayPaymentId");

        String razorpaySignature =
                request.get("razorpaySignature");

        return ResponseEntity.ok(
                orderService.verifyRazorpayUpiPayment(
                        customerId,
                        orderId,
                        razorpayOrderId,
                        razorpayPaymentId,
                        razorpaySignature
                )
        );
    }

    @GetMapping
    public ResponseEntity<List<Map<String, Object>>> getMyOrders(
            Authentication authentication
    ) {
        Long customerId =
                getUserId(authentication);

        List<Order> orders =
                orderService.getCustomerOrders(
                        customerId
                );

        List<Map<String, Object>> response =
                orders.stream()
                        .map(this::buildOrderResponse)
                        .toList();

        return ResponseEntity.ok(response);
    }

    @GetMapping("/{orderId}")
    public ResponseEntity<Map<String, Object>> getMyOrder(
            Authentication authentication,
            @PathVariable Long orderId
    ) {
        Long customerId =
                getUserId(authentication);

        Order order =
                orderService.getOrderById(
                        orderId
                );

        if (!order.getCustomerId().equals(
                customerId)) {

            return ResponseEntity
                    .status(403)
                    .build();
        }

        return ResponseEntity.ok(
                buildOrderResponse(order)
        );
    }

    /*
     * =============================================================
     * DELIVERY PARTNER - MY DELIVERIES
     * =============================================================
     *
     * OrderService now returns DeliveryOrderResponse directly.
     *
     * Therefore the controller must NOT treat the result as
     * List<Order> or rebuild the response here.
     */
    @GetMapping("/delivery-partner")
    public ResponseEntity<List<DeliveryOrderResponse>>
    getDeliveryPartnerOrders(
            Authentication authentication
    ) {
        Long deliveryPartnerId =
                getUserId(authentication);

        List<DeliveryOrderResponse> orders =
                orderService.getDeliveryPartnerOrders(
                        deliveryPartnerId
                );

        return ResponseEntity.ok(orders);
    }

    @PutMapping("/delivery-partner/{orderId}/status")
    public ResponseEntity<Map<String, Object>>
    updateDeliveryPartnerOrderStatus(
            Authentication authentication,
            @PathVariable Long orderId,
            @RequestBody Map<String, String> request
    ) {
        Long deliveryPartnerId =
                getUserId(authentication);

        String status =
                request.get("status");

        Order order =
                orderService.updateDeliveryPartnerOrderStatus(
                        orderId,
                        deliveryPartnerId,
                        status
                );

        return ResponseEntity.ok(
                buildOrderResponse(order)
        );
    }

    private Map<String, Object> buildOrderResponse(
            Order order
    ) {
        List<OrderItem> items =
                orderService.getOrderItems(
                        order.getOrderId()
                );

        Map<String, Object> response =
                new HashMap<>();

        response.put(
                "orderId",
                order.getOrderId()
        );

        response.put(
                "orderNumber",
                order.getOrderNumber()
        );

        response.put(
                "customerId",
                order.getCustomerId()
        );

        response.put(
                "storeId",
                order.getStoreId()
        );

        response.put(
                "deliveryPartnerId",
                order.getDeliveryPartnerId()
        );

        response.put(
                "subtotal",
                order.getSubtotal()
        );

        response.put(
                "deliveryFee",
                order.getDeliveryFee()
        );

        response.put(
                "total",
                order.getTotal()
        );

        /*
         * Road-distance information
         *
         * pickupDistanceKm:
         * Delivery Partner -> Store
         *
         * deliveryDistanceKm:
         * Store -> Customer
         *
         * totalDistanceKm:
         * Delivery Partner -> Store
         * +
         * Store -> Customer
         */
        response.put(
                "pickupDistanceKm",
                order.getPickupDistanceKm()
        );

        response.put(
                "deliveryDistanceKm",
                order.getDeliveryDistanceKm()
        );

        response.put(
                "totalDistanceKm",
                order.getTotalDistanceKm()
        );

        response.put(
                "paymentMethod",
                order.getPaymentMethod()
        );

        response.put(
                "paymentStatus",
                order.getPaymentStatus()
        );

        response.put(
                "orderStatus",
                order.getOrderStatus()
        );

        response.put(
                "deliveryName",
                order.getDeliveryName()
        );

        response.put(
                "deliveryPhone",
                order.getDeliveryPhone()
        );

        response.put(
                "deliveryAddress",
                order.getDeliveryAddress()
        );

        response.put(
                "deliveryCity",
                order.getDeliveryCity()
        );

        response.put(
                "deliveryPincode",
                order.getDeliveryPincode()
        );

        response.put(
                "createdAt",
                order.getCreatedAt()
        );

        response.put(
                "updatedAt",
                order.getUpdatedAt()
        );

        response.put(
                "items",
                items
        );

        return response;
    }

    private Long getUserId(
            Authentication authentication
    ) {
        return (Long) authentication.getPrincipal();
    }

    /*
     * =============================================================
     * DELIVERY PARTNER - AVAILABLE DELIVERIES
     * =============================================================
     *
     * Only authenticated users can request this endpoint.
     *
     * The delivery partner ID is intentionally NOT supplied
     * by the frontend.
     *
     * OrderService returns the complete DeliveryOrderResponse.
     */
    @GetMapping("/delivery-partner/available")
    public ResponseEntity<List<DeliveryOrderResponse>>
    getAvailableDeliveryOrders(
            Authentication authentication
    ) {

        /*
         * Make sure the request has an authenticated user.
         *
         * The actual delivery-partner ID is NOT sent
         * from the frontend.
         */
        getUserId(authentication);

        List<DeliveryOrderResponse> orders =
                orderService.getAvailableDeliveryOrders();

        return ResponseEntity.ok(orders);
    }

    @PutMapping("/delivery-partner/{orderId}/accept")
    public ResponseEntity<Map<String, Object>>
    acceptDeliveryOrder(
            Authentication authentication,
            @PathVariable Long orderId
    ) {

        /*
         * Get the delivery partner ID directly
         * from the authenticated JWT.
         */
        Long deliveryPartnerId =
                getUserId(authentication);

        /*
         * The frontend does NOT provide the partner ID.
         *
         * Backend determines which partner is accepting
         * the order from the JWT.
         */
        Order order =
                orderService.acceptDeliveryOrder(
                        orderId,
                        deliveryPartnerId
                );

        return ResponseEntity.ok(
                buildOrderResponse(order)
        );
    }
}