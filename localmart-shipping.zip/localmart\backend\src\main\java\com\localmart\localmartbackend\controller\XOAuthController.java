package com.localmart.localmartbackend.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.localmart.localmartbackend.dto.UserResponse;
import com.localmart.localmartbackend.dto.XUserInfo;
import com.localmart.localmartbackend.service.UserService;
import com.localmart.localmartbackend.service.XOAuthService;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/users/x")
public class XOAuthController {

    private static final String FRONTEND_ORIGIN =
            "https://snack-gurgle-fled.ngrok-free.dev";

    private final XOAuthService xOAuthService;
    private final UserService userService;
    private final ObjectMapper objectMapper;

    public XOAuthController(
            XOAuthService xOAuthService,
            UserService userService,
            ObjectMapper objectMapper) {

        this.xOAuthService = xOAuthService;
        this.userService = userService;
        this.objectMapper = objectMapper;
    }

    // ============================================================
    // START X LOGIN
    // ============================================================

    @GetMapping("/login")
    public ResponseEntity<Void> loginWithX() {

        System.out.println();
        System.out.println("========== X LOGIN START ==========");

        String authorizationUrl =xOAuthService.createLoginAuthorizationUrl();

        System.out.println("X authorization URL created");

        System.out.println(
                "Redirecting user to X"
        );

        return ResponseEntity
                .status(302)
                .header(
                        "Location",
                        authorizationUrl
                )
                .build();
    }

    // ============================================================
    // START X REGISTRATION
    // ============================================================

    @GetMapping("/register")
    public ResponseEntity<Void> registerWithX() {

        System.out.println();
        System.out.println(
                "========== X REGISTRATION START =========="
        );

        String authorizationUrl =
                xOAuthService.createRegistrationAuthorizationUrl();

        System.out.println(
                "X registration authorization URL created"
        );

        System.out.println(
                "Redirecting user to X"
        );

        return ResponseEntity
                .status(302)
                .header(
                        "Location",
                        authorizationUrl
                )
                .build();
    }

    // ============================================================
    // X CALLBACK
    // ============================================================

    @GetMapping("/callback")
    public ResponseEntity<String> callback(
            @RequestParam("code") String code,
            @RequestParam("state") String state) {

        System.out.println();
        System.out.println("========== X CALLBACK START ==========");
        System.out.println(
                "X callback request received"
        );

        try {

            // ====================================================
            // 1. FIND WHICH FLOW STARTED THIS OAUTH REQUEST
            // ====================================================

            System.out.println(
                    "Step 1: Recovering OAuth flow from state"
            );

            XOAuthService.OAuthFlow flow =
                    xOAuthService.getFlow(state);

            System.out.println(
                    "OAuth flow: " + flow
            );

            // ====================================================
            // 2. EXCHANGE AUTHORIZATION CODE
            //    FOR ACCESS TOKEN
            // ====================================================

            System.out.println(
                    "Step 2: Exchanging authorization code"
            );

            String accessToken =
                    xOAuthService.exchangeCodeForAccessToken(
                            code,
                            state
                    );

            System.out.println(
                    "Authorization code exchange completed"
            );

            // ====================================================
            // 3. GET USER INFORMATION FROM X
            // ====================================================

            System.out.println(
                    "Step 3: Requesting X user information"
            );

            XUserInfo xUserInfo =
                    xOAuthService.getCurrentUser(
                            accessToken
                    );

            System.out.println(
                    "X user information retrieved"
            );

            // ====================================================
            // 4. HANDLE LOGIN
            // ====================================================

            if (
                    flow ==
                            XOAuthService.OAuthFlow.LOGIN
            ) {

                System.out.println();
                System.out.println(
                        "========== X LOGIN =========="
                );

                System.out.println(
                        "Calling UserService.xLogin()"
                );

                UserResponse response =
                        userService.xLogin(
                                xUserInfo
                        );

                System.out.println(
                        "UserService.xLogin() completed"
                );

                System.out.println(
                        "Building X_LOGIN_SUCCESS callback response"
                );

                ResponseEntity<String> result =
                        buildSuccessResponse(
                                "X_LOGIN_SUCCESS",
                                response
                        );

                System.out.println(
                        "X_LOGIN_SUCCESS response created"
                );

                return result;
            }

            // ====================================================
            // 5. HANDLE REGISTRATION
            // ====================================================

            if (
                    flow ==
                            XOAuthService.OAuthFlow.REGISTER
            ) {

                System.out.println();
                System.out.println(
                        "========== X REGISTRATION =========="
                );

                System.out.println(
                        "Calling UserService.xRegister()"
                );

                Map<String, Object> response =
                        userService.xRegister(
                                xUserInfo
                        );

                System.out.println(
                        "UserService.xRegister() completed"
                );

                System.out.println(
                        "Building X_REGISTER_SUCCESS callback response"
                );

                ResponseEntity<String> result =
                        buildSuccessResponse(
                                "X_REGISTER_SUCCESS",
                                response
                        );

                System.out.println(
                        "X_REGISTER_SUCCESS response created"
                );

                return result;
            }

            // ====================================================
            // 6. UNKNOWN FLOW
            // ====================================================

            System.out.println(
                    "ERROR: Unknown X OAuth flow"
            );

            return buildErrorResponse(
                    "Invalid X OAuth flow"
            );

        } catch (Exception exception) {

            System.err.println();
            System.err.println(
                    "========== X OAUTH CALLBACK ERROR =========="
            );

            System.err.println(
                    "X OAuth callback failed"
            );

            System.err.println(
                    "Error: " + exception.getMessage()
            );

            return buildErrorResponse(
                    exception.getMessage() != null
                            ? exception.getMessage()
                            : "X authentication failed. Please try again."
            );
        }
    }

    // ============================================================
    // BUILD SUCCESS POPUP RESPONSE
    // ============================================================

    private ResponseEntity<String> buildSuccessResponse(
            String messageType,
            Object data) {

        try {

            System.out.println(
                    "Serializing X authentication response"
            );

            String json =
                    objectMapper.writeValueAsString(data);

            System.out.println(
                    "X authentication response serialized"
            );

            /*
             * IMPORTANT:
             *
             * This page intentionally has NO visible content.
             *
             * The popup only:
             *
             * 1. Sends the authentication result
             *    to the main LocalMart window.
             *
             * 2. Closes itself.
             *
             * The old testing text such as:
             *
             * LOCALMART X POPUP V4
             * MESSAGE SENT
             *
             * has been removed.
             */

            String html =
                    """
                    <!DOCTYPE html>
                    <html>
                    <head>
                        <meta charset="UTF-8">
                        <title>LocalMart</title>
                    </head>

                    <body>

                        <script>

                            if (window.opener) {

                                window.opener.postMessage(
                                    {
                                        type: "%s",
                                        data: %s
                                    },
                                    "%s"
                                );

                                window.close();

                            }

                        </script>

                    </body>
                    </html>
                    """.formatted(
                            messageType,
                            json,
                            FRONTEND_ORIGIN
                    );

            return ResponseEntity
                    .ok()
                    .contentType(MediaType.TEXT_HTML)
                    .body(html);

        } catch (JsonProcessingException exception) {

            System.err.println(
                    "Failed to serialize X authentication response"
            );

            return buildErrorResponse(
                    "Unable to process X authentication response."
            );
        }
    }

    // ============================================================
    // BUILD ERROR POPUP RESPONSE
    // ============================================================

    private ResponseEntity<String> buildErrorResponse(
            String message) {

        try {

            System.out.println(
                    "Building X authentication error response"
            );

            String json =
                    objectMapper.writeValueAsString(
                            message
                    );

            String html =
                    """
                    <!DOCTYPE html>
                    <html>
                    <head>
                        <meta charset="UTF-8">
                        <title>LocalMart X Authentication</title>
                    </head>

                    <body>

                        <p>Authentication failed.</p>

                        <script>

                            console.log(
                                "LOCALMART X ERROR CALLBACK PAGE"
                            );

                            console.log(
                                "WINDOW OPENER:",
                                window.opener
                            );

                            if (window.opener) {

                                console.log(
                                    "OPENER FOUND"
                                );

                                window.opener.postMessage(
                                    {
                                        type: "X_AUTH_ERROR",
                                        message: %s
                                    },
                                    "%s"
                                );

                                console.log(
                                    "ERROR MESSAGE SENT"
                                );

                            } else {

                                console.log(
                                    "NO OPENER FOUND"
                                );
                            }

                            // TEMPORARILY DO NOT CLOSE
                            // window.close();

                        </script>

                    </body>
                    </html>
                    """.formatted(
                            json,
                            FRONTEND_ORIGIN
                    );

            System.out.println(
                    "X authentication error response created"
            );

            return ResponseEntity
                    .status(400)
                    .contentType(
                            MediaType.TEXT_HTML
                    )
                    .body(html);

        } catch (JsonProcessingException exception) {

            System.err.println(
                    "Failed to serialize X authentication error"
            );

            return ResponseEntity
                    .status(400)
                    .contentType(
                            MediaType.TEXT_HTML
                    )
                    .body(
                            """
                            <!DOCTYPE html>
                            <html>
                            <body>
                                <p>X authentication failed.</p>
                            </body>
                            </html>
                            """
                    );
        }
    }
}