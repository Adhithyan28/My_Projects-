# LocalMart — Customer Module

## 1. Overview

The Customer Module is the part of LocalMart responsible for the complete shopping experience of a customer.

It connects the customer with the core commerce features of the platform:

```text id="7c8n2s"
Customer
   |
   +--> Profile
   |
   +--> Addresses
   |
   +--> Location
   |
   +--> Stores
   |
   +--> Products
   |
   +--> Cart
   |
   +--> Delivery Fee
   |
   +--> Checkout
   |
   +--> Payment
   |
   +--> Orders
```

The module is designed around a database-driven shopping workflow. Store and product information is retrieved from the backend rather than being treated as static frontend data.

---

# 2. Customer Responsibilities

A customer can use LocalMart to:

* Create and manage their account
* Maintain personal information
* Add and manage delivery addresses
* Search or select locations
* Browse available stores
* Browse products
* Browse products by category
* Add products to a cart
* Update cart quantities
* Remove cart items
* Calculate delivery charges
* Place orders
* Make payments
* View orders
* Track order status
* Receive deliveries

The overall customer journey is:

```text id="6wz2tm"
Login / Registration
       |
       v
Customer Dashboard
       |
       v
Select Location / Address
       |
       v
Browse Stores
       |
       v
Browse Products
       |
       v
Add to Cart
       |
       v
Review Cart
       |
       v
Calculate Delivery
       |
       v
Checkout
       |
       v
Payment
       |
       v
Order
       |
       v
Delivery
```

---

# 3. Customer Module Architecture

The customer module follows the application's layered architecture.

```text id="j8w3p0"
React Frontend
      |
      | HTTP
      v
Spring Boot REST API
      |
      v
Controllers
      |
      v
Services
      |
      v
Repositories
      |
      v
PostgreSQL
```

External services can participate in specific customer operations:

```text id="o4i6qf"
Customer Module
      |
      +--> Geocoding Service
      |
      +--> Road Distance / OSRM
      |
      +--> Payment Gateway
```

These services support location, delivery, and payment functionality rather than replacing the LocalMart backend.

---

# 4. Customer Identity

A customer is represented by the common LocalMart `User` account with:

```text id="a2fqxy"
Role = CUSTOMER
```

The customer account is associated with other customer-related data.

Conceptually:

```text id="f5e2p4"
User
 |
 +--> CUSTOMER Role
 |
 +--> Address
 |
 +--> Cart
 |
 +--> Orders
 |
 +--> Sessions
```

The `User` entity provides the customer's common identity, while customer-specific operations are implemented through the customer-related services and controllers.

---

# 5. Customer Authentication

Before accessing protected customer functionality, the customer must authenticate.

LocalMart supports multiple authentication mechanisms, including:

* Email/password
* Mobile/password
* Email OTP
* SMS OTP
* Google authentication
* X authentication

Successful authentication results in an authenticated LocalMart session and JWT.

The general flow is:

```text id="a8q3n4"
Customer
   |
   v
Login
   |
   v
Authentication
   |
   v
Server Session
   |
   v
JWT
   |
   v
Frontend
```

The frontend subsequently sends the JWT when accessing protected APIs.

Authentication itself is documented separately in:

```text id="f7o2ny"
docs/03-authentication.md
```

---

# 6. Customer Dashboard

The customer dashboard acts as the main entry point after authentication.

The dashboard provides access to the customer's shopping functionality.

Typical customer navigation includes:

```text id="6m9j43"
Customer Dashboard
 |
 +--> Stores
 |
 +--> Categories
 |
 +--> Products
 |
 +--> Cart
 |
 +--> Orders
 |
 +--> Profile
 |
 +--> Addresses
```

The frontend routes the authenticated user according to their role.

Therefore:

```text id="h4h0w6"
Authenticated User
       |
       v
Role
       |
       +--> CUSTOMER
       |       |
       |       v
       |  Customer Dashboard
       |
       +--> Other roles
```

---

# 7. Customer Profile

The customer profile contains information associated with the customer's account.

The common identity information includes:

```text id="0k9t4k"
First Name
Last Name
Email
Phone
```

Profile management is separated from authentication itself.

Authentication determines whether the user is allowed to access the account.

Profile management determines how the customer's account information is displayed and updated.

```text id="n7x4h8"
Authentication
     |
     v
"Who is the user?"

Profile Management
     |
     v
"What information belongs to the user?"
```

---

# 8. Customer Address Management

Addresses are a major part of the customer module because LocalMart is a location-dependent commerce platform.

A customer can manage their delivery addresses.

An address can contain:

```text id="v3j8w4"
Address Line
City
State
Pincode
Latitude
Longitude
Default Address
```

The relationship is:

```text id="t2x9c5"
Customer
   |
   +--> Address 1
   |
   +--> Address 2
   |
   +--> Address 3
```

This allows a customer to maintain multiple delivery locations.

---

# 9. Default Address

One address can be designated as the customer's default address.

Conceptually:

```text id="g9b1q2"
Customer
 |
 +--> Home       DEFAULT
 |
 +--> Office
 |
 +--> Other
```

The default address can be used as the preferred delivery destination.

When address management changes the default address, the system updates the address records so that the appropriate address is marked as default.

---

# 10. Address Coordinates

LocalMart stores geographic coordinates along with an address.

These include:

```text id="v6s4m8"
Latitude
Longitude
```

The coordinates allow the platform to perform location-dependent operations.

For example:

```text id="r1q5w8"
Customer Location
       |
       v
Store Location
       |
       v
Road Distance
       |
       v
Delivery Fee
```

Coordinates therefore connect the customer address system with the delivery and location systems.

---

# 11. Location Services

LocalMart uses location information for customer-facing commerce operations.

The location subsystem can involve:

```text id="y7d4p1"
Browser Geolocation
       |
       v
Latitude / Longitude
       |
       v
Geocoding
       |
       v
Address / Location
```

The browser can provide the customer's current device location through the browser's Geolocation API.

The application can then use geographic information for location-related operations.

The location architecture is documented in:

```text id="m0x5e2"
docs/12-location-services.md
```

---

# 12. Store Browsing

Customers can browse stores available through LocalMart.

The frontend requests store information from the backend rather than relying on a fixed list of stores.

The general flow is:

```text id="p3x7s1"
Customer
   |
   v
Stores Page
   |
   | HTTP GET
   v
Store Controller
   |
   v
Store Service
   |
   v
Store Repository
   |
   v
PostgreSQL
   |
   v
Store Data
   |
   v
Frontend
```

This allows the store catalog to reflect the actual database state.

---

# 13. Product Browsing

Customers can browse products belonging to LocalMart stores.

A simplified flow is:

```text id="q6v2m9"
Customer
   |
   v
Select Store
   |
   v
Store Products
   |
   | HTTP request
   v
Product Controller
   |
   v
Product Service
   |
   v
Product Repository
   |
   v
PostgreSQL
   |
   v
Products
```

Products are therefore retrieved from the backend and database.

---

# 14. Category-Based Browsing

Customers can also browse products by category.

The conceptual flow is:

```text id="u3k8r1"
Customer
   |
   v
Categories
   |
   v
Select Category
   |
   v
Category Products
   |
   v
Product Data
```

Category-based browsing provides another way for customers to discover products without manually searching through the complete product catalog.

---

# 15. Product Information

The product information presented to a customer can include information such as:

```text id="z5w1s7"
Product
├── Product ID
├── Product Name
├── Description
├── Price
├── Category
├── Store
└── Availability / Stock Information
```

The exact fields displayed depend on the frontend response model and product implementation.

The important architectural principle is that product information is sourced from the backend rather than being permanently embedded in the customer interface.

---

# 16. Shopping Cart

The cart represents the customer's current shopping selection.

The customer can:

* Add products
* Increase quantity
* Decrease quantity
* Remove products
* Review selected products
* View totals

The conceptual relationship is:

```text id="f9x3k2"
Customer
   |
   v
Cart
   |
   +--> Cart Item
   |       |
   |       +--> Product
   |
   +--> Cart Item
           |
           +--> Product
```

The cart is maintained by the backend.

This means the cart is not dependent on browser-only storage as the source of truth.

---

# 17. Backend Cart Flow

A typical cart operation follows:

```text id="c7r2m4"
Frontend
   |
   | HTTP Request
   v
CartController
   |
   v
CartService
   |
   +--> CartRepository
   |
   +--> CartItemRepository
   |
   +--> ProductRepository
   |
   v
PostgreSQL
   |
   v
Cart Response
   |
   v
Frontend
```

The authenticated customer is associated with the cart through their user identity.

---

# 18. Why the Cart Is Backend-Based

A database-backed cart provides several advantages.

The cart remains associated with the customer's account rather than only with a specific browser.

Conceptually:

```text id="p8v3d2"
Browser
   |
   v
JWT
   |
   v
LocalMart Backend
   |
   v
Customer
   |
   v
Database Cart
```

This allows the backend to remain the authoritative source for the customer's current cart.

It also makes the cart available across authenticated sessions and devices where the user logs into the same account.

---

# 19. Store-Based Cart Context

LocalMart's commerce model is store-oriented.

A customer's selected products are associated with stores.

Therefore, cart operations need to preserve the relationship between:

```text id="r5w9k2"
Customer
   |
   v
Cart
   |
   v
Products
   |
   v
Store
```

This becomes important when calculating delivery fees and placing orders.

---

# 20. Delivery Fee Calculation

Before checkout, LocalMart can calculate the delivery fee based on information such as:

```text id="y8c3v5"
Store
+
Customer Address
```

The customer-facing request uses:

```text id="e4m7q1"
storeId
addressId
```

The conceptual flow is:

```text id="d3k6s8"
Customer
   |
   v
Cart
   |
   +--> Store ID
   |
   v
Select Delivery Address
   |
   +--> Address ID
   |
   v
Calculate Delivery Fee
   |
   v
Location / Distance Services
   |
   v
Delivery Fee
```

The delivery-fee calculation connects commerce information with geographic information.

---

# 21. Road Distance

LocalMart can use road-distance information when determining delivery-related calculations.

The architecture can use:

```text id="p7m2x6"
Customer Coordinates
        +
Store Coordinates
        |
        v
OSRM
        |
        v
Road Distance / Duration
```

Road distance is different from simply calculating straight-line geographic distance.

For delivery operations, road-network distance provides a more useful representation of the actual travel route.

---

# 22. Checkout

Checkout is the transition between shopping and order creation.

A simplified checkout flow is:

```text id="h8x4q1"
Cart
 |
 v
Review Items
 |
 v
Select Address
 |
 v
Calculate Delivery Fee
 |
 v
Calculate Order Total
 |
 v
Payment
 |
 v
Create Order
```

The checkout process combines information from:

```text id="s3v9k5"
Customer
Cart
Products
Store
Address
Delivery
Payment
```

---

# 23. Order Creation

After successful checkout and payment processing according to the application's payment flow, an order can be created.

The order associates the customer with the purchased products.

Conceptually:

```text id="m2q7w4"
Customer
   |
   v
Order
   |
   +--> Order Item
   |       |
   |       +--> Product
   |
   +--> Order Item
           |
           +--> Product
```

The order also contains information necessary for fulfillment and delivery.

---

# 24. Order Lifecycle

The customer's order progresses through different stages.

A simplified customer-facing lifecycle is:

```text id="u4j8s2"
Order Created
      |
      v
Order Processing
      |
      v
Ready for Delivery
      |
      v
Accepted by Delivery Partner
      |
      v
Picked Up
      |
      v
Out for Delivery
      |
      v
Delivered
```

The exact order statuses and transitions are documented separately in the order and delivery flow documentation.

---

# 25. Order History

Customers can access their previous orders.

The general flow is:

```text id="x5p9c3"
Customer
   |
   v
Orders Page
   |
   | HTTP request
   v
Order Controller
   |
   v
Order Service
   |
   v
Order Repository
   |
   v
PostgreSQL
   |
   v
Order History
   |
   v
Frontend
```

The customer can use this information to review previously placed orders and their statuses.

---

# 26. Customer Order Tracking

Order tracking allows the customer to follow the progress of an order.

The customer-facing representation is based on backend order status.

Conceptually:

```text id="n6r2w8"
Order
 |
 v
Current Status
 |
 +--> READY_FOR_PICKUP
 |
 +--> ACCEPTED
 |
 +--> PICKED_UP
 |
 +--> OUT_FOR_DELIVERY
 |
 +--> DELIVERED
```

The delivery partner's actions cause the order's operational state to change, and the customer can observe the resulting status.

---

# 27. Payment Integration

Payment is part of the customer checkout process.

LocalMart integrates with a payment provider for online payment processing.

The payment flow conceptually is:

```text id="b7q3m1"
Customer
   |
   v
Checkout
   |
   v
Payment Request
   |
   v
Razorpay
   |
   v
Payment Result
   |
   v
LocalMart Backend
   |
   v
Order / Payment Records
```

The payment gateway handles payment processing, while LocalMart remains responsible for its own order and payment records.

Payment architecture is documented separately in:

```text id="k3f8p5"
docs/10-payment-system.md
```

---

# 28. Customer and Delivery Partner Interaction

The customer does not directly control delivery operations.

Instead, the relationship is mediated by the order.

```text id="e9s2w6"
CUSTOMER
    |
    v
ORDER
    |
    v
DELIVERY PARTNER
```

The customer creates the order.

The delivery partner receives and processes the delivery.

The customer then observes the delivery progress through the order status.

---

# 29. Customer Location and Delivery

Location information connects the customer with the delivery system.

```text id="r8v3k6"
Customer
   |
   v
Delivery Address
   |
   +--> Latitude
   +--> Longitude
   |
   v
Store Location
   |
   v
Road Distance
   |
   v
Delivery Calculation
```

This is one of the key differences between a normal e-commerce system and a location-aware local-commerce system.

---

# 30. Customer Data Flow

The overall customer data flow can be represented as:

```text id="w5q1n8"
                   CUSTOMER
                       |
        +--------------+--------------+
        |              |              |
        v              v              v
     PROFILE       ADDRESS         SESSION
                       |
                       v
                  LOCATION
                       |
                       v
                    STORE
                       |
                       v
                   PRODUCT
                       |
                       v
                     CART
                       |
                       v
                   CHECKOUT
                       |
              +--------+--------+
              |                 |
              v                 v
         DELIVERY FEE        PAYMENT
              |                 |
              +--------+--------+
                       |
                       v
                     ORDER
                       |
                       v
                   DELIVERY
                       |
                       v
                  DELIVERED
```

---

# 31. Customer Module Backend Components

The customer functionality is distributed across several backend components.

Relevant controllers include:

```text id="q6w2e9"
CustomerController
CustomerAddressController
CartController
StoreController
ProductController
OrderController
LocationController
```

Relevant services include:

```text id="u5m8r2"
CustomerService
CustomerAddressService
CartService
StoreService
ProductService
OrderService
GeocodingService
RoadDistanceService
RazorpayService
```

Relevant entities include:

```text id="a3k7p1"
User
Role
Address
Cart
CartItem
Product
Order
OrderItem
Payment
StoreDetails
```

The exact responsibility of each component is covered in the corresponding module documentation.

---

# 32. Customer Module Frontend Structure

The customer interface is divided into separate pages/features.

The current customer-facing pages include:

```text id="c9x4m7"
CustomerDashboard
Stores
StoreProducts
Categories
CategoryProducts
Products
Cart
Orders
```

These pages collectively implement the customer shopping journey.

Conceptually:

```text id="v2n8q5"
CustomerDashboard
      |
      +--> Stores
      |      |
      |      +--> StoreProducts
      |
      +--> Categories
      |      |
      |      +--> CategoryProducts
      |
      +--> Products
      |
      +--> Cart
      |
      +--> Orders
```

---

# 33. Frontend-to-Backend Communication

Customer pages communicate with the backend through HTTP requests.

The general pattern is:

```text id="h6r1w9"
React Component
      |
      | HTTP request
      v
Vite / API routing
      |
      v
Spring Boot
      |
      v
Controller
      |
      v
Service
      |
      v
Repository
      |
      v
PostgreSQL
```

The response travels back through the same application boundary:

```text id="p4x8m2"
PostgreSQL
    |
    v
Repository
    |
    v
Service
    |
    v
Controller
    |
    v
JSON Response
    |
    v
React
```

---

# 34. Customer Authorization

Customer endpoints must distinguish an authenticated customer from other user roles.

The security architecture provides the authenticated identity and role information.

Conceptually:

```text id="k8w3q6"
HTTP Request
      |
      v
JWT
      |
      v
Spring Security
      |
      v
Authenticated User
      |
      v
CUSTOMER role
      |
      v
Customer Operation
```

This prevents customer-only operations from being treated as anonymous operations.

Authorization rules are part of the application's security architecture.

---

# 35. Customer Data Ownership

Customer-specific data should be associated with the authenticated customer's identity.

For example:

```text id="r3m7x1"
Authenticated User
       |
       v
User ID
       |
       +--> Own Addresses
       |
       +--> Own Cart
       |
       +--> Own Orders
```

This relationship is important because the backend must not treat an arbitrary customer ID supplied by a client as proof of ownership.

The authenticated identity provides the basis for determining which customer data belongs to the current user.

---

# 36. Database-Centered Customer Experience

LocalMart's customer experience depends on backend data.

The major customer-facing resources are stored and retrieved through the database:

```text id="w2q6n9"
Stores
Products
Cart
Addresses
Orders
Payments
```

Therefore the frontend acts primarily as the presentation and interaction layer.

```text id="m7p3x5"
Database
   ↓
Backend
   ↓
JSON API
   ↓
React
   ↓
Customer UI
```

This keeps the backend as the source of truth for important commerce data.

---

# 37. Customer Module Security

Security considerations include:

### Authentication

Customers must authenticate before accessing protected account functionality.

### Authorization

Customer operations must be restricted according to the authenticated user's role and identity.

### Password protection

Passwords are encoded before persistence.

### JWT validation

Protected API requests use authenticated session information.

### Data ownership

Customers should only access their own account-specific information.

### Payment security

Payment processing is delegated to the payment gateway while LocalMart maintains its corresponding records.

### Input validation

Customer-provided data such as addresses and quantities must be validated before processing.

---

# 38. Customer Module External Integrations

The customer experience can interact with several external services:

| Service         | Customer Module Usage                   |
| --------------- | --------------------------------------- |
| Google          | Social authentication                   |
| X               | Social authentication                   |
| Geocoding API   | Location/address processing             |
| OSRM            | Road distance and delivery calculations |
| Razorpay        | Online payment processing               |
| Gmail SMTP      | Email-based OTP                         |
| Message Central | SMS OTP                                 |

These integrations are not themselves the customer module; they provide external capabilities consumed by specific customer workflows.

---

# 39. Customer Module Boundaries

The Customer Module interacts with several other LocalMart modules.

```text id="s8k4w2"
                 CUSTOMER MODULE
                       |
       +---------------+---------------+
       |               |               |
       v               v               v
 STORE MODULE     PRODUCT MODULE    LOCATION
       |               |               |
       +---------------+---------------+
                       |
                       v
                  CART MODULE
                       |
                       v
                 ORDER MODULE
                       |
             +---------+---------+
             |                   |
             v                   v
       PAYMENT MODULE       DELIVERY MODULE
```

The customer module therefore acts as a major consumer of the platform's other business modules.

---

# 40. End-to-End Customer Journey

A complete customer journey can be represented as:

```text id="c4n7m2"
                    CUSTOMER
                        |
                        v
                  Authentication
                        |
                        v
                   Dashboard
                        |
                        v
               Select Location
                        |
                        v
                 Browse Stores
                        |
                        v
                Select Store
                        |
                        v
               Browse Products
                        |
                        v
                Select Product
                        |
                        v
                  Add to Cart
                        |
                        v
                  Review Cart
                        |
                        v
              Select Address
                        |
                        v
            Calculate Delivery Fee
                        |
                        v
                    Checkout
                        |
                        v
                    Payment
                        |
                        v
                 Create Order
                        |
                        v
              Delivery Processing
                        |
                        v
                  Track Order
                        |
                        v
                   Delivered
```

---

# 41. Responsibility Breakdown

| Component                | Main Responsibility                              |
| ------------------------ | ------------------------------------------------ |
| Customer Dashboard       | Entry point for customer functionality           |
| Customer Service         | Customer-related business operations             |
| Customer Address Service | Address management                               |
| Store Service            | Store retrieval and store-related operations     |
| Product Service          | Product retrieval and product-related operations |
| Cart Service             | Cart and cart-item management                    |
| Order Service            | Order creation and order processing              |
| Geocoding Service        | Geographic/address conversion                    |
| Road Distance Service    | Road-distance calculation                        |
| Razorpay Service         | Payment-gateway integration                      |
| User Session Service     | Authenticated session management                 |

---

# 42. Customer Module and Other Modules

The Customer Module does not operate independently.

It depends on the following major modules:

```text id="m5x8r3"
Authentication
     ↓
Customer
     ↓
Store
     ↓
Product
     ↓
Cart
     ↓
Location
     ↓
Payment
     ↓
Order
     ↓
Delivery
```

The customer is the primary participant connecting these modules from the shopping side of the platform.

---

# 43. Important Architectural Principles

### Database as the commerce source of truth

Store, product, cart, order, and payment information is managed by the backend/database.

### Backend-driven cart

The customer's cart is maintained by the backend rather than relying on browser-only cart data.

### Identity-based ownership

Customer-specific resources are associated with the authenticated user.

### Role-based access

Customer functionality is separated from store-owner, delivery-partner, and administrator functionality.

### Location-aware commerce

Customer addresses and coordinates participate in delivery calculations.

### External-service separation

External APIs provide specialized capabilities while LocalMart retains responsibility for its own business logic and data.

### Modular architecture

Customer functionality is divided across focused controllers, services, repositories, and domain entities.

---

# 44. Summary

The LocalMart Customer Module provides the complete customer-side commerce experience.

The central flow is:

```text id="e1r7k4"
Customer
   |
   v
Authentication
   |
   v
Customer Account
   |
   +--> Profile
   |
   +--> Address
   |
   +--> Location
   |
   v
Stores
   |
   v
Products
   |
   v
Cart
   |
   v
Delivery Fee
   |
   v
Checkout
   |
   v
Payment
   |
   v
Order
   |
   v
Delivery
   |
   v
Delivered
```

The module brings together identity, location, commerce, payment, and delivery functionality into one customer journey.

At the architectural level:

```text id="w9p3c6"
React Customer UI
        |
        v
Customer REST APIs
        |
        v
Business Services
        |
        v
Repositories
        |
        v
PostgreSQL
        |
        +------> External Services
                   |
                   +--> Geocoding
                   +--> OSRM
                   +--> Razorpay
```

The result is a database-driven, authenticated, location-aware customer shopping system that connects customers to stores, products, payments, orders, and delivery.
