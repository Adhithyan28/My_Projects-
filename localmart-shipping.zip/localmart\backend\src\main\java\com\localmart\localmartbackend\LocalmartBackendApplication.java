package com.localmart.localmartbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LocalmartBackendApplication {

    public static void main(String[] args)
    {
        SpringApplication.run(LocalmartBackendApplication.class, args);
    }

}
