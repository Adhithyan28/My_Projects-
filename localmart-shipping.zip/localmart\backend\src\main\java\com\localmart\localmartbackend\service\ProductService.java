
        package com.localmart.localmartbackend.service;

import com.localmart.localmartbackend.entity.Product;
import com.localmart.localmartbackend.repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductService {

    private final ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    // Get all products
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    // Get product by ID
    public Optional<Product> getProductById(Long productId) {
        return productRepository.findById(productId);
    }

    // Get products belonging to a store
    public List<Product> getProductsByStore(Long storeId) {
        return productRepository.findByStoreId(storeId);
    }

    // Get products by category
    public List<Product> getProductsByCategory(String category) {
        return productRepository.findByCategoryIgnoreCase(category);
    }

    // Get all available products
    public List<Product> getAvailableProducts() {
        return productRepository.findByIsAvailableTrue();
    }

    // Get available products from a specific store
    public List<Product> getAvailableProductsByStore(Long storeId) {
        return productRepository.findByStoreIdAndIsAvailableTrue(storeId);
    }

    // Create a new product
    public Product createProduct(Product product) {
        return productRepository.save(product);
    }

    // Update an existing product
    public Product updateProduct(Long productId, Product updatedProduct) {

        Product existingProduct = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        existingProduct.setStoreId(updatedProduct.getStoreId());
        existingProduct.setProductName(updatedProduct.getProductName());
        existingProduct.setCategory(updatedProduct.getCategory());
        existingProduct.setDescription(updatedProduct.getDescription());
        existingProduct.setPrice(updatedProduct.getPrice());
        existingProduct.setUnit(updatedProduct.getUnit());
        existingProduct.setStockQuantity(updatedProduct.getStockQuantity());
        existingProduct.setIcon(updatedProduct.getIcon());
        existingProduct.setIsAvailable(updatedProduct.getIsAvailable());

        return productRepository.save(existingProduct);
    }

    // Delete a product
    public void deleteProduct(Long productId) {

        if (!productRepository.existsById(productId)) {
            throw new RuntimeException("Product not found");
        }

        productRepository.deleteById(productId);
    }
}
