function TermsOfService() {

    return (
        <div
            style={{
                minHeight: "100vh",
                padding: "40px",
                maxWidth: "900px",
                margin: "0 auto",
                fontFamily: "Arial, sans-serif",
                lineHeight: "1.7"
            }}
        >

            <h1>LocalMart Terms of Service</h1>

            <p>
                Welcome to LocalMart. These Terms of Service
                explain the rules for using the LocalMart
                application.
            </p>

            <h2>1. Use of LocalMart</h2>

            <p>
                LocalMart provides a platform that allows users
                to discover local stores, browse products,
                place orders, and access related marketplace
                services.
            </p>

            <h2>2. User Accounts</h2>

            <p>
                Users are responsible for providing accurate
                information when creating an account and for
                keeping their account credentials secure.
            </p>

            <h2>3. Orders and Payments</h2>

            <p>
                Users are responsible for reviewing their order
                details before confirming an order. Product
                availability, pricing, delivery, and related
                information may be provided by participating
                stores.
            </p>

            <h2>4. Acceptable Use</h2>

            <p>
                Users must not use LocalMart for unlawful
                activities, fraudulent transactions, abuse,
                unauthorized access, or activities that could
                harm the service or other users.
            </p>

            <h2>5. Account Termination</h2>

            <p>
                LocalMart may restrict or terminate access to
                accounts that violate these terms or misuse
                the platform.
            </p>

            <h2>6. Changes to These Terms</h2>

            <p>
                These Terms of Service may be updated from time
                to time. Continued use of LocalMart after
                changes are published constitutes acceptance
                of the updated terms.
            </p>

            <h2>7. Contact</h2>

            <p>
                For questions regarding these terms, please
                contact the LocalMart administration team.
            </p>

            <p>
                Last updated: September 2026
            </p>

        </div>
    )
}

export default TermsOfService