package com.localmart.localmartbackend.controller;

import com.localmart.localmartbackend.dto.AdminLoginOtpRequest;
import com.localmart.localmartbackend.dto.AdminVerifyOtpRequest;
import com.localmart.localmartbackend.dto.LoginRequest;
import com.localmart.localmartbackend.dto.UserResponse;
import com.localmart.localmartbackend.repository.UserRepository;
import com.localmart.localmartbackend.service.AdminService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    private static final int ACCOUNT_ACTIVE = 1;

    private final UserRepository userRepository;
    private final AdminService adminService;

    public AdminController(
            UserRepository userRepository,
            AdminService adminService) {

        this.userRepository = userRepository;
        this.adminService = adminService;
    }

    @GetMapping("/test")
    public ResponseEntity<String> testAdmin() {

        return ResponseEntity.ok(
                "Admin API is working"
        );
    }

    @GetMapping("/active-users-count")
    public ResponseEntity<Long> getActiveUsersCount() {

        long count =
                userRepository.countByAccountStatus(
                        ACCOUNT_ACTIVE
                );

        return ResponseEntity.ok(count);
    }

    /*
     * ADMIN LOGIN
     *
     * Direct email/password login.
     *
     * Kept for compatibility with the existing
     * AdminService functionality.
     */
    @PostMapping("/login")
    public ResponseEntity<UserResponse> loginAdmin(
            @RequestBody LoginRequest request) {

        return ResponseEntity.ok(
                adminService.loginAdmin(request)
        );
    }

    /*
     * ADMIN LOGIN - STEP 1
     *
     * Email + password
     * OR
     * Mobile + password
     *
     * Then sends:
     * EMAIL / SMS / WHATSAPP OTP
     */
    @PostMapping("/login/send-otp")
    public ResponseEntity<String> sendAdminLoginOtp(
            @RequestBody AdminLoginOtpRequest request) {

        return ResponseEntity.ok(
                adminService.sendAdminLoginOtp(
                        request
                )
        );
    }

    /*
     * ADMIN LOGIN - STEP 2
     *
     * Verify OTP and return JWT.
     */
    @PostMapping("/login/verify")
    public ResponseEntity<UserResponse> verifyAdminLoginOtp(
            @RequestBody AdminVerifyOtpRequest request) {

        return ResponseEntity.ok(
                adminService.verifyAdminLoginOtp(
                        request
                )
        );
    }
}