import { useEffect, useState } from "react"
import { useAuth } from "../context/AuthContext"


/* =========================================================
   TYPES
   ========================================================= */

interface Product {
    id: number
    name: string
    category: string
    description: string | null
    price: number
    unit: string
    icon: string | null
    storeId: number
    storeName: string
    stockQuantity: number
    isAvailable: boolean
}

interface Store {
    id: number
    name: string
    type: string
    city: string
    state: string
    latitude: number | null
    longitude: number | null
}

interface ProductsProps {
    onHome: () => void
    onStores: () => void
    onCategories: () => void
    onOrders: () => void
    onCart: () => void
}


/* =========================================================
   COMPONENT
   ========================================================= */

function Products({
                      onHome,
                      onStores,
                      onCategories,
                      onOrders,
                      onCart,
                  }: ProductsProps) {

    const { user, logout } = useAuth()

    const [search, setSearch] = useState("")
    const [selectedCategory, setSelectedCategory] = useState("All")
    const [selectedStore, setSelectedStore] = useState("All")

    const [products, setProducts] = useState<Product[]>([])
    const [stores, setStores] = useState<Store[]>([])

    const [loading, setLoading] = useState(true)
    const [error, setError] = useState("")


    /* =====================================================
       FETCH PRODUCTS + STORES
       ===================================================== */

    useEffect(() => {

        const fetchData = async () => {

            if (!user?.token) {
                setError("You must be logged in to view products.")
                setLoading(false)
                return
            }

            try {

                setLoading(true)
                setError("")

                const headers = {
                    Authorization: `Bearer ${user.token}`,
                }


                const [productsResponse, storesResponse] =
                    await Promise.all([

                        fetch("/api/products", {
                            headers,
                        }),

                        fetch("/api/stores", {
                            headers,
                        }),

                    ])


                if (!productsResponse.ok) {
                    throw new Error(
                        "Failed to load products."
                    )
                }

                if (!storesResponse.ok) {
                    throw new Error(
                        "Failed to load stores."
                    )
                }


                const productsData =
                    await productsResponse.json()

                const storesData =
                    await storesResponse.json()


                const storeMap = new Map<number, string>()

                storesData.forEach((store: Store) => {

                    storeMap.set(
                        store.id,
                        store.name
                    )

                })


                const mappedProducts: Product[] =
                    productsData.map((product: any) => ({

                        id: product.productId,

                        name: product.productName,

                        category: product.category,

                        description:
                            product.description ?? null,

                        price: Number(product.price),

                        unit: product.unit,

                        icon:
                            product.icon ?? null,

                        storeId: product.storeId,

                        storeName:
                            storeMap.get(product.storeId)
                            ?? `Store #${product.storeId}`,

                        stockQuantity:
                            Number(product.stockQuantity),

                        isAvailable:
                            Boolean(product.isAvailable),

                    }))


                setProducts(mappedProducts)
                setStores(storesData)

            } catch (err) {

                console.error(
                    "Products page error:",
                    err
                )

                setError(
                    err instanceof Error
                        ? err.message
                        : "Unable to load products."
                )

            } finally {

                setLoading(false)

            }

        }


        fetchData()

    }, [user?.token])


    /* =====================================================
       FILTER OPTIONS
       ===================================================== */

    const categories = [
        "All",
        ...Array.from(
            new Set(
                products
                    .map((product) => product.category)
                    .filter(Boolean)
            )
        ),
    ]


    const storeOptions = [
        "All",
        ...stores
            .filter((store) =>
                products.some(
                    (product) =>
                        product.storeId === store.id
                )
            )
            .map((store) => store.name),
    ]


    /* =====================================================
       FILTER PRODUCTS
       ===================================================== */

    const filteredProducts =
        products.filter((product) => {

            const normalizedSearch =
                search.toLowerCase().trim()


            const matchesSearch =
                product.name
                    .toLowerCase()
                    .includes(normalizedSearch)


            const matchesCategory =
                selectedCategory === "All" ||
                product.category === selectedCategory


            const matchesStore =
                selectedStore === "All" ||
                product.storeName === selectedStore


            return (
                matchesSearch &&
                matchesCategory &&
                matchesStore
            )

        })


    /* =====================================================
       FILTER RESET
       ===================================================== */

    const hasActiveFilters =
        search.trim() !== "" ||
        selectedCategory !== "All" ||
        selectedStore !== "All"


    const clearFilters = () => {

        setSearch("")
        setSelectedCategory("All")
        setSelectedStore("All")

    }


    /* =====================================================
       ADD TO CART
       ===================================================== */

    const addToCart = async (product: Product) => {

        if (!user?.token) {

            alert(
                "Please login to add products to your cart."
            )

            return
        }


        if (!product.isAvailable) {

            alert(
                `${product.name} is currently unavailable.`
            )

            return
        }


        if (product.stockQuantity <= 0) {

            alert(
                `${product.name} is out of stock.`
            )

            return
        }


        try {

            const response =
                await fetch("/api/cart/items", {

                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/json",

                        Authorization:
                            `Bearer ${user.token}`,
                    },

                    body: JSON.stringify({

                        productId:
                        product.id,

                        quantity: 1,

                    }),

                })


            const data =
                await response.json()


            if (!response.ok) {

                throw new Error(
                    data.message ||
                    data.error ||
                    "Unable to add product to cart."
                )

            }


            alert(
                `${product.name} added to cart`
            )

        } catch (err) {

            console.error(
                "Add to cart error:",
                err
            )

            alert(
                err instanceof Error
                    ? err.message
                    : "Unable to add product to cart."
            )

        }

    }


    /* =====================================================
       PRODUCT ICON
       ===================================================== */

    const getProductIcon = (
        product: Product
    ) => {

        if (product.icon) {
            return product.icon
        }


        const category =
            product.category
                ?.toLowerCase()


        if (category?.includes("fruit")) {
            return "🍎"
        }

        if (category?.includes("vegetable")) {
            return "🥦"
        }

        if (category?.includes("dairy")) {
            return "🥛"
        }

        if (category?.includes("bakery")) {
            return "🍞"
        }

        if (category?.includes("beverage")) {
            return "🥤"
        }

        if (category?.includes("snack")) {
            return "🍪"
        }

        if (category?.includes("personal")) {
            return "🧴"
        }

        if (category?.includes("household")) {
            return "🧺"
        }

        return "🛒"

    }


    /* =====================================================
       UI
       ===================================================== */

    return (

        <div className="customer-dashboard">


            {/* =================================================
                HEADER
            ================================================= */}

            <header className="customer-header">


                {/* LOGO */}

                <button
                    className="customer-logo"
                    type="button"
                    onClick={onHome}
                >

                    <span className="logo-icon">
                        🛒
                    </span>

                    <span>
                        LocalMart
                    </span>

                </button>


                {/* SEARCH */}

                <div className="customer-search">

                    <span className="search-icon">
                        ⌕
                    </span>

                    <input
                        type="text"
                        placeholder="Search products..."
                        value={search}
                        onChange={(e) =>
                            setSearch(e.target.value)
                        }
                    />

                </div>


                {/* LOCATION */}

                <div className="customer-location">

                    <span>
                        📍
                    </span>

                    <div>

                        <small>
                            Deliver to
                        </small>

                        <strong>
                            Chennai
                        </strong>

                    </div>

                </div>


                {/* CART */}

                <button
                    className="customer-cart-button"
                    type="button"
                    onClick={onCart}
                >
                    🛒
                </button>


                {/* PROFILE */}

                <div className="customer-profile">

                    <div className="profile-avatar">

                        {user?.email
                            ?.charAt(0)
                            .toUpperCase() || "U"}

                    </div>

                    <div className="profile-info">

                        <span>
                            Customer
                        </span>

                        <strong>
                            {user?.email || "User"}
                        </strong>

                    </div>

                </div>


                {/* LOGOUT */}

                <button
                    className="customer-logout"
                    type="button"
                    onClick={logout}
                >
                    Logout
                </button>

            </header>


            {/* =================================================
                NAVIGATION
            ================================================= */}

            <nav className="customer-navigation">

                <div className="navigation-inner">

                    <button
                        type="button"
                        onClick={onHome}
                    >
                        Home
                    </button>

                    <button
                        type="button"
                        onClick={onStores}
                    >
                        Stores
                    </button>


                    <button
                        type="button"
                        className="nav-active"
                    >
                        Products
                    </button>

                    <button
                        type="button"
                        onClick={onOrders}
                    >
                        Orders
                    </button>

                </div>

            </nav>


            {/* =================================================
                MAIN
            ================================================= */}

            <main className="customer-main">

                <div className="products-container">


                    {/* PAGE HEADING */}

                    <section className="products-heading">

                        <div>

                            <p className="section-eyebrow">
                                SHOP LOCAL
                            </p>

                            <h1>
                                All Products
                            </h1>

                            <p>
                                Discover products from
                                your nearby local stores.
                            </p>

                        </div>

                    </section>


                    {/* ERROR */}

                    {error && (

                        <section className="products-empty">

                            <div className="products-empty-icon">
                                ⚠️
                            </div>

                            <h2>
                                Unable to load products
                            </h2>

                            <p>
                                {error}
                            </p>

                        </section>

                    )}


                    {/* FILTERS */}

                    {!error && (

                        <section className="products-filters">

                            <div className="products-search-box">

                                <span>
                                    🔍
                                </span>

                                <input
                                    type="text"
                                    placeholder="Search products..."
                                    value={search}
                                    onChange={(e) =>
                                        setSearch(e.target.value)
                                    }
                                />

                            </div>


                            <select
                                value={selectedCategory}
                                onChange={(e) =>
                                    setSelectedCategory(
                                        e.target.value
                                    )
                                }
                                disabled={loading}
                            >

                                {categories.map(
                                    (category) => (

                                        <option
                                            key={category}
                                            value={category}
                                        >
                                            {category}
                                        </option>

                                    )
                                )}

                            </select>


                            <select
                                value={selectedStore}
                                onChange={(e) =>
                                    setSelectedStore(
                                        e.target.value
                                    )
                                }
                                disabled={loading}
                            >

                                {storeOptions.map(
                                    (store) => (

                                        <option
                                            key={store}
                                            value={store}
                                        >
                                            {store}
                                        </option>

                                    )
                                )}

                            </select>


                            {hasActiveFilters && (

                                <button
                                    type="button"
                                    className="products-clear-filters"
                                    onClick={clearFilters}
                                >
                                    <span>
                                        ↺
                                    </span>

                                    Clear Filters
                                </button>

                            )}

                        </section>

                    )}


                    {/* LOADING */}

                    {loading && (

                        <section className="products-empty">

                            <div className="products-empty-icon">
                                🛒
                            </div>

                            <h2>
                                Loading products...
                            </h2>

                            <p>
                                Getting the latest products
                                from local stores.
                            </p>

                        </section>

                    )}


                    {/* PRODUCT COUNT */}

                    {!loading && !error && (

                        <div className="products-title">

                            <div>

                                <h2>
                                    Products
                                </h2>

                                <p>
                                    {filteredProducts.length} products available
                                </p>

                            </div>

                        </div>

                    )}


                    {/* PRODUCTS */}

                    {!loading &&
                        !error &&
                        filteredProducts.length === 0 && (

                            <section className="products-empty">

                                <div className="products-empty-icon">
                                    🔍
                                </div>

                                <h2>
                                    No products found
                                </h2>

                                <p>
                                    Try changing your search
                                    or filters.
                                </p>

                                <button
                                    type="button"
                                    className="products-empty-clear"
                                    onClick={clearFilters}
                                >
                                    <span>
                                        ↺
                                    </span>

                                    Clear Filters
                                </button>

                            </section>

                        )}


                    {!loading &&
                        !error &&
                        filteredProducts.length > 0 && (

                            <section className="products-grid">

                                {filteredProducts.map(
                                    (product) => (

                                        <article
                                            className="product-card"
                                            key={product.id}
                                        >

                                            {/* PRODUCT IMAGE */}

                                            <div className="product-image">

                                                {getProductIcon(
                                                    product
                                                )}

                                            </div>


                                            {/* PRODUCT BODY */}

                                            <div className="product-body">

                                                <span className="product-category">

                                                    {product.category}

                                                </span>


                                                <h3>
                                                    {product.name}
                                                </h3>


                                                <p className="product-unit">

                                                    {product.unit}

                                                </p>


                                                <div className="product-store">

                                                    <span>
                                                        🏪
                                                    </span>

                                                    {product.storeName}

                                                </div>


                                                <div className="product-rating">

                                                    {product.stockQuantity > 0
                                                        ? `${product.stockQuantity} in stock`
                                                        : "Out of stock"}

                                                </div>


                                                <div className="product-bottom">

                                                    <strong>
                                                        ₹{product.price}
                                                    </strong>

                                                    <button
                                                        type="button"
                                                        disabled={
                                                            !product.isAvailable ||
                                                            product.stockQuantity <= 0
                                                        }
                                                        onClick={() =>
                                                            addToCart(
                                                                product
                                                            )
                                                        }
                                                    >
                                                        {!product.isAvailable
                                                            ? "Unavailable"
                                                            : product.stockQuantity <= 0
                                                                ? "Out of Stock"
                                                                : "Add to Cart"}
                                                    </button>

                                                </div>

                                            </div>

                                        </article>

                                    )
                                )}

                            </section>

                        )}

                </div>

            </main>


            {/* =================================================
                FOOTER
            ================================================= */}

            <footer className="customer-footer">

                <div className="footer-content">

                    <div className="footer-brand">

                        <div className="footer-logo">
                            🛒 LocalMart
                        </div>

                        <p>
                            Your local stores,
                            delivered to your door.
                        </p>

                    </div>


                    <div className="footer-links">

                        <button
                            type="button"
                            onClick={onHome}
                        >
                            Home
                        </button>

                        <button
                            type="button"
                            onClick={onStores}
                        >
                            Stores
                        </button>

                        <button
                            type="button"
                            onClick={onCategories}
                        >
                            Categories
                        </button>

                        <button
                            type="button"
                        >
                            Products
                        </button>

                        <button
                            type="button"
                            onClick={onOrders}
                        >
                            Orders
                        </button>

                        <button
                            type="button"
                            onClick={onCart}
                        >
                            Cart
                        </button>

                    </div>

                </div>


                <div className="footer-bottom">

                    <span>
                        © 2026 LocalMart
                    </span>

                    <span>
                        Shop local. Live local.
                    </span>

                </div>

            </footer>

        </div>
    )
}


export default Products