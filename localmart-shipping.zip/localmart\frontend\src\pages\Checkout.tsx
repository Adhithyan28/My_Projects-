import { useEffect, useState } from "react"
import { useAuth } from "../context/AuthContext"

interface CartItem {
    cartItemId: number
    productId: number
    productName: string
    category: string
    description: string | null
    price: number
    unit: string
    quantity: number
    stockQuantity: number
    icon: string | null
    isAvailable: boolean
    storeId: number
    storeName: string
    itemTotal: number
}

interface CartResponse {
    cartId: number
    customerId: number
    items: CartItem[]
    subtotal: number
    itemCount: number
    storeId: number | null
    storeName: string | null
}

interface AddressInfo {
    addressId: number
    addressLine: string
    city: string
    state: string
    pincode: string
    latitude: number
    longitude: number
    isDefault: boolean
}

interface CreateOrderResponse {
    orderId: number
    orderNumber: string
    customerId: number
    storeId: number
    subtotal: number
    deliveryFee: number
    total: number
    paymentMethod: string
    paymentStatus: string
    orderStatus: string
    deliveryName: string
    deliveryPhone: string
    deliveryAddress: string
    deliveryCity: string
    deliveryPincode: string
    createdAt: string
    updatedAt: string
}

interface UpiPaymentResponse {
    order: CreateOrderResponse
    paymentId: number
    paymentStatus: string
    paymentMethod: string
    amount: number
    currency: string
    razorpayKeyId: string
    razorpayOrderId: string
}

interface DeliveryFeeResponse {
    distanceKm: number
    deliveryFee: number
}

interface RazorpayPaymentResponse {
    razorpay_payment_id: string
    razorpay_order_id: string
    razorpay_signature: string
}

interface RazorpayOptions {
    key: string
    amount: number
    currency: string
    name: string
    description: string
    order_id: string

    prefill?: {
        name?: string
        email?: string
        contact?: string
    }

    notes?: {
        [key: string]: string
    }

    theme?: {
        color?: string
    }

    handler: (
        response: RazorpayPaymentResponse
    ) => void

    modal?: {
        ondismiss?: () => void
    }
}

interface RazorpayInstance {
    open: () => void
    close?: () => void
}

interface RazorpayConstructor {
    new (
        options: RazorpayOptions
    ): RazorpayInstance
}

declare global {
    interface Window {
        Razorpay: RazorpayConstructor
    }
}

interface CheckoutProps {
    onHome: () => void
    onStores: () => void
    onCategories: () => void
    onProducts: () => void
    onOrders: () => void
    onCart: () => void
    onAddNewAddress: () => void
    addressToSelect?: number | null
}

const API_BASE_URL = "http://localhost:8080"

const RAZORPAY_SCRIPT_URL =
    "https://checkout.razorpay.com/v1/checkout.js"

function Checkout({
                      onHome,
                      onStores,
                      onCategories,
                      onProducts,
                      onOrders,
                      onCart,
                      onAddNewAddress,
                      addressToSelect,
                  }: CheckoutProps) {

    const { user, logout } = useAuth()

    /* ==========================================
     * DELIVERY DETAILS
     * ========================================== */

    const [fullName, setFullName] = useState("")
    const [phone, setPhone] = useState("")

    /* ==========================================
     * DELIVERY ADDRESSES
     * ========================================== */

    const [addresses, setAddresses] =
        useState<AddressInfo[]>([])

    const [selectedAddressId, setSelectedAddressId] =
        useState<number | null>(null)

    const [loadingAddresses, setLoadingAddresses] =
        useState(true)

    const [addressError, setAddressError] =
        useState("")

    /* ==========================================
     * DELIVERY FEE
     * ========================================== */

    const [deliveryFee, setDeliveryFee] =
        useState(0)

    const [deliveryDistanceKm, setDeliveryDistanceKm] =
        useState<number | null>(null)

    const [loadingDeliveryFee, setLoadingDeliveryFee] =
        useState(false)

    const [deliveryFeeError, setDeliveryFeeError] =
        useState("")

    /* ==========================================
     * PAYMENT METHOD
     * ========================================== */

    const [paymentMethod, setPaymentMethod] =
        useState<"COD" | "UPI">("COD")

    /* ==========================================
     * RAZORPAY PAYMENT
     * ========================================== */

    const [upiPayment, setUpiPayment] =
        useState<UpiPaymentResponse | null>(null)

    const [verifyingPayment, setVerifyingPayment] =
        useState(false)

    /* ==========================================
     * CART
     * ========================================== */

    const [cart, setCart] =
        useState<CartResponse | null>(null)

    const [loading, setLoading] =
        useState(true)

    const [placingOrder, setPlacingOrder] =
        useState(false)

    const [error, setError] =
        useState("")

    /* ==========================================
     * LOAD RAZORPAY CHECKOUT SCRIPT
     * ========================================== */

    const loadRazorpayScript = (): Promise<boolean> => {

        return new Promise(
            (resolve) => {

                /*
                 * If Razorpay is already available,
                 * there is no reason to load the script again.
                 */

                if (window.Razorpay) {
                    resolve(true)
                    return
                }

                /*
                 * Check whether another request has
                 * already inserted the script.
                 */

                const existingScript =
                    document.querySelector(
                        `script[src="${RAZORPAY_SCRIPT_URL}"]`
                    )

                if (existingScript) {

                    existingScript.addEventListener(
                        "load",
                        () => resolve(true),
                        { once: true }
                    )

                    existingScript.addEventListener(
                        "error",
                        () => resolve(false),
                        { once: true }
                    )

                    return
                }

                /*
                 * Create Razorpay's official Checkout
                 * script dynamically.
                 */

                const script =
                    document.createElement("script")

                script.src =
                    RAZORPAY_SCRIPT_URL

                script.async = true

                script.onload = () => {
                    resolve(true)
                }

                script.onerror = () => {
                    resolve(false)
                }

                document.body.appendChild(script)
            }
        )
    }

    /* ==========================================
     * LOAD CART
     * ========================================== */

    useEffect(() => {

        const fetchCart = async () => {

            if (!user?.token) {
                setCart(null)
                setLoading(false)
                return
            }

            try {

                setLoading(true)
                setError("")

                const response =
                    await fetch(
                        `${API_BASE_URL}/api/cart`,
                        {
                            method: "GET",
                            headers: {
                                Authorization:
                                    `Bearer ${user.token}`,
                            },
                        }
                    )

                if (!response.ok) {
                    throw new Error(
                        `Failed to load cart (${response.status})`
                    )
                }

                const data: CartResponse =
                    await response.json()

                setCart(data)

            } catch (err) {

                console.error(
                    "Failed to fetch cart:",
                    err
                )

                setError(
                    "Unable to load your cart. Please try again."
                )

            } finally {

                setLoading(false)
            }
        }

        fetchCart()

    }, [user?.token])

    /* ==========================================
     * LOAD CUSTOMER DELIVERY ADDRESSES
     * ========================================== */

    useEffect(() => {

        const fetchAddresses = async () => {

            if (!user?.token) {
                setAddresses([])
                setSelectedAddressId(null)
                setLoadingAddresses(false)
                return
            }

            try {

                setLoadingAddresses(true)
                setAddressError("")

                const response =
                    await fetch(
                        `${API_BASE_URL}/api/customer/addresses`,
                        {
                            method: "GET",
                            headers: {
                                Authorization:
                                    `Bearer ${user.token}`,
                            },
                        }
                    )

                if (!response.ok) {
                    throw new Error(
                        `Failed to load delivery addresses (${response.status})`
                    )
                }

                const data: AddressInfo[] =
                    await response.json()

                setAddresses(data)

                /*
                 * If the customer has just returned from
                 * Profile after adding an address,
                 * automatically select that address.
                 */

                if (
                    addressToSelect !== null &&
                    addressToSelect !== undefined
                ) {

                    const newAddress =
                        data.find(
                            item =>
                                item.addressId ===
                                addressToSelect
                        )

                    if (newAddress) {

                        setSelectedAddressId(
                            newAddress.addressId
                        )

                        return
                    }
                }

                /*
                 * Otherwise select the default address.
                 */

                const defaultAddress =
                    data.find(
                        item =>
                            item.isDefault === true
                    )

                if (defaultAddress) {

                    setSelectedAddressId(
                        defaultAddress.addressId
                    )

                } else if (data.length > 0) {

                    setSelectedAddressId(
                        data[0].addressId
                    )

                } else {

                    setSelectedAddressId(null)
                }

            } catch (err) {

                console.error(
                    "Failed to fetch delivery addresses:",
                    err
                )

                setAddressError(
                    "Unable to load your saved delivery addresses."
                )

            } finally {

                setLoadingAddresses(false)
            }
        }

        fetchAddresses()

    }, [user?.token, addressToSelect])

    /* ==========================================
     * DELIVERY FEE CALCULATION
     * ========================================== */

    const storeId =
        cart?.storeId || null

    /*
     * CART DATA
     *
     * Declared before the delivery fee effect
     * so the effect can safely use cartItems.
     */

    const cartItems =
        cart?.items || []

    useEffect(() => {

        const calculateDeliveryFee = async () => {

            /*
             * We cannot calculate the delivery fee until:
             *
             * 1. Customer is authenticated
             * 2. Cart has a store
             * 3. Customer selected an address
             */

            if (
                !user?.token ||
                !storeId ||
                !selectedAddressId ||
                cartItems.length === 0
            ) {

                setDeliveryFee(0)
                setDeliveryDistanceKm(null)
                setDeliveryFeeError("")
                setLoadingDeliveryFee(false)

                return
            }

            try {

                setLoadingDeliveryFee(true)
                setDeliveryFeeError("")

                const response =
                    await fetch(
                        `${API_BASE_URL}/api/orders/calculate-delivery-fee`,
                        {
                            method: "POST",

                            headers: {
                                "Content-Type":
                                    "application/json",

                                Authorization:
                                    `Bearer ${user.token}`,
                            },

                            body:
                                JSON.stringify({
                                    storeId:
                                    storeId,

                                    addressId:
                                    selectedAddressId,
                                }),
                        }
                    )

                if (!response.ok) {

                    let message =
                        "Unable to calculate delivery fee."

                    try {

                        const errorData =
                            await response.json()

                        if (errorData?.message) {
                            message =
                                errorData.message
                        }

                    } catch {
                        // Keep default message.
                    }

                    throw new Error(message)
                }

                const data:
                    DeliveryFeeResponse =
                    await response.json()

                setDeliveryDistanceKm(
                    Number(data.distanceKm)
                )

                setDeliveryFee(
                    Number(data.deliveryFee)
                )

            } catch (err) {

                console.error(
                    "Failed to calculate delivery fee:",
                    err
                )

                setDeliveryFee(0)
                setDeliveryDistanceKm(null)

                setDeliveryFeeError(
                    err instanceof Error
                        ? err.message
                        : "Unable to calculate delivery fee."
                )

            } finally {

                setLoadingDeliveryFee(false)
            }
        }

        calculateDeliveryFee()

    }, [
        user?.token,
        storeId,
        selectedAddressId,
        cartItems.length,
    ])

    /* ==========================================
     * DELIVERY ADDRESS CHANGE
     * ========================================== */

    const handleAddressChange = (
        value: string
    ) => {

        if (value === "new") {

            onAddNewAddress()

            return
        }

        const addressId =
            Number(value)

        const selectedAddress =
            addresses.find(
                item =>
                    item.addressId ===
                    addressId
            )

        if (!selectedAddress) {
            return
        }

        setSelectedAddressId(
            selectedAddress.addressId
        )

        setAddressError("")
    }

    /* ==========================================
     * PAYMENT METHOD CHANGE
     * ========================================== */

    const handlePaymentMethodChange = (
        method: "COD" | "UPI"
    ) => {

        /*
         * If the customer switches payment method,
         * remove any pending Razorpay order from
         * the current screen.
         */

        setUpiPayment(null)
        setError("")

        setPaymentMethod(method)
    }

    /* ==========================================
     * CART DATA
     * ========================================== */

    const itemCount =
        cart?.itemCount || 0

    const subtotal =
        Number(cart?.subtotal || 0)

    const total =
        subtotal + deliveryFee

    const storeName =
        cart?.storeName || "Local Store"

    const selectedAddress =
        addresses.find(
            address =>
                address.addressId ===
                selectedAddressId
        )

    /* ==========================================
     * COMMON ORDER VALIDATION
     * ========================================== */

    const validateCheckout = () => {

        if (!user?.token) {

            alert(
                "Your session has expired. Please log in again."
            )

            return false
        }

        if (cartItems.length === 0) {

            alert(
                "Your cart is empty."
            )

            onCart()

            return false
        }

        if (!storeId) {

            alert(
                "Unable to determine the store for this order."
            )

            return false
        }

        if (!fullName.trim()) {

            alert(
                "Please enter your full name."
            )

            return false
        }

        if (!phone.trim()) {

            alert(
                "Please enter your phone number."
            )

            return false
        }

        if (!selectedAddressId) {

            alert(
                "Please select a delivery address."
            )

            return false
        }

        if (loadingDeliveryFee) {

            alert(
                "Please wait while the delivery fee is being calculated."
            )

            return false
        }

        if (deliveryFeeError) {

            alert(
                deliveryFeeError
            )

            return false
        }

        return true
    }

    /* ==========================================
     * BUILD ORDER REQUEST
     * ========================================== */

    const buildOrderRequest = () => {

        return {

            storeId,

            addressId:
            selectedAddressId,

            fullName:
                fullName.trim(),

            phone:
                phone.trim(),

            paymentMethod,

            items:
                cartItems.map(
                    item => ({
                        productId:
                        item.productId,

                        quantity:
                        item.quantity,
                    })
                ),
        }
    }

    /* ==========================================
     * COD ORDER
     * ========================================== */

    const placeCodOrder = async () => {

        const orderRequest =
            buildOrderRequest()

        const orderResponse =
            await fetch(
                `${API_BASE_URL}/api/orders`,
                {
                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/json",

                        Authorization:
                            `Bearer ${user!.token}`,
                    },

                    body:
                        JSON.stringify(
                            orderRequest
                        ),
                }
            )

        if (!orderResponse.ok) {

            let message =
                "Unable to place the order."

            try {

                const errorData =
                    await orderResponse.json()

                if (errorData?.message) {
                    message =
                        errorData.message
                }

            } catch {
                // Keep default message.
            }

            throw new Error(message)
        }

        const createdOrder:
            CreateOrderResponse =
            await orderResponse.json()

        /*
         * The backend clears the cart as part
         * of successful COD order creation.
         */

        alert(
            `Order placed successfully!\n\n` +
            `Order Number: ${createdOrder.orderNumber}`
        )

        onOrders()
    }

    /* ==========================================
     * CREATE RAZORPAY UPI PAYMENT
     * ========================================== */

    const createUpiPayment = async () => {

        const orderRequest =
            buildOrderRequest()

        /*
         * Step 1:
         *
         * Ask our backend to create the LocalMart
         * order and Razorpay TEST order.
         */

        const paymentResponse =
            await fetch(
                `${API_BASE_URL}/api/orders/upi`,
                {
                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/json",

                        Authorization:
                            `Bearer ${user!.token}`,
                    },

                    body:
                        JSON.stringify(
                            orderRequest
                        ),
                }
            )

        if (!paymentResponse.ok) {

            let message =
                "Unable to start UPI payment."

            try {

                const errorData =
                    await paymentResponse.json()

                if (errorData?.message) {
                    message =
                        errorData.message
                }

            } catch {
                // Keep default message.
            }

            throw new Error(message)
        }

        const paymentData:
            UpiPaymentResponse =
            await paymentResponse.json()

        /*
         * Save the backend response.
         *
         * Important values:
         *
         * paymentData.order.orderId
         * paymentData.razorpayKeyId
         * paymentData.razorpayOrderId
         * paymentData.amount
         */

        setUpiPayment(paymentData)

        /*
         * Step 2:
         *
         * Load Razorpay's Checkout JavaScript.
         */

        const razorpayLoaded =
            await loadRazorpayScript()

        if (!razorpayLoaded) {

            throw new Error(
                "Unable to load Razorpay Checkout. Please check your internet connection and try again."
            )
        }

        /*
         * Make sure the global Razorpay constructor
         * is actually available.
         */

        if (!window.Razorpay) {

            throw new Error(
                "Razorpay Checkout is unavailable."
            )
        }

        /*
         * Step 3:
         *
         * Create the Razorpay Checkout configuration.
         */

        const options:
            RazorpayOptions = {

            /*
             * This is the PUBLIC Razorpay TEST key.
             *
             * It is safe for the frontend.
             *
             * The secret key NEVER comes here.
             */

            key:
            paymentData.razorpayKeyId,

            /*
             * Razorpay expects amount in the smallest
             * currency unit.
             *
             * Backend has already created the order
             * using the correct paise amount.
             */

            amount:
                Math.round(
                    Number(paymentData.amount) * 100
                ),

            currency:
            paymentData.currency,

            name:
                "LocalMart",

            description:
                `LocalMart Order ${paymentData.order.orderNumber}`,

            /*
             * IMPORTANT:
             *
             * This is the Razorpay order ID generated
             * by our backend.
             */

            order_id:
            paymentData.razorpayOrderId,

            prefill: {

                name:
                    fullName.trim(),

                email:
                    user?.email || "",

                contact:
                    phone.trim(),
            },

            notes: {

                localmart_order_id:
                    String(
                        paymentData.order.orderId
                    ),

                localmart_order_number:
                paymentData.order.orderNumber,
            },

            theme: {

                color:
                    "#2e7d32",
            },

            /*
             * Razorpay calls this after the customer
             * successfully completes the payment.
             */

            handler:
                (response:
                 RazorpayPaymentResponse)    => {

                    verifyRazorpayPayment(
                        paymentData,
                        response
                    )
                },

            /*
             * Customer closed Razorpay without completing
             * the payment.
             */

            modal: {

                ondismiss: () => {

                    setPlacingOrder(false)

                    setError(
                        "Payment was cancelled. Your order is still awaiting payment."
                    )
                },
            },
        }

        /*
         * Step 4:
         *
         * Open Razorpay's TEST Checkout UI.
         */

        const razorpay =
            new window.Razorpay(options)

        razorpay.open()

        window.scrollTo({
            top: 0,
            behavior: "smooth",
        })
    }

    /* ==========================================
     * VERIFY RAZORPAY PAYMENT
     * ========================================== */

    const verifyRazorpayPayment = async (
        paymentData: UpiPaymentResponse,
        razorpayResponse: RazorpayPaymentResponse
    ) => {

        if (!user?.token) {

            alert(
                "Your session has expired. Please log in again."
            )

            return
        }

        try {

            setVerifyingPayment(true)
            setPlacingOrder(true)
            setError("")

            /*
             * The browser received these values from
             * Razorpay after successful checkout:
             *
             * razorpay_payment_id
             * razorpay_order_id
             * razorpay_signature
             *
             * We send them to our backend.
             *
             * The backend is responsible for verifying
             * the signature using the Razorpay SECRET.
             */

            const response =
                await fetch(
                    `${API_BASE_URL}/api/orders/${paymentData.order.orderId}/payment/verify`,
                    {
                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/json",

                            Authorization:
                                `Bearer ${user.token}`,
                        },

                        body:
                            JSON.stringify({

                                razorpayOrderId:
                                razorpayResponse.razorpay_order_id,

                                razorpayPaymentId:
                                razorpayResponse.razorpay_payment_id,

                                razorpaySignature:
                                razorpayResponse.razorpay_signature,
                            }),
                    }
                )

            if (!response.ok) {

                let message =
                    "Payment verification failed."

                try {

                    const errorData =
                        await response.json()

                    if (errorData?.message) {
                        message =
                            errorData.message
                    }

                } catch {
                    // Keep default message.
                }

                throw new Error(message)
            }

            const verifiedOrder:
                CreateOrderResponse =
                await response.json()

            /*
             * Backend has now:
             *
             * 1. Verified Razorpay signature
             * 2. Marked payment SUCCESS
             * 3. Stored Razorpay payment ID
             * 4. Deducted stock
             * 5. Marked order PLACED
             * 6. Cleared the customer's cart
             */

            alert(
                `Payment successful!\n\n` +
                `Order Number: ${verifiedOrder.orderNumber}`
            )

            setUpiPayment(null)

            onOrders()

        } catch (err) {

            console.error(
                "Failed to verify Razorpay payment:",
                err
            )

            const message =
                err instanceof Error
                    ? err.message
                    : "Payment verification failed. Please try again."

            setError(message)

            alert(message)

        } finally {

            setVerifyingPayment(false)
            setPlacingOrder(false)
        }
    }

    /* ==========================================
     * PLACE ORDER / START PAYMENT
     * ========================================== */

    const handlePlaceOrder = async () => {

        if (!validateCheckout()) {
            return
        }

        try {

            setPlacingOrder(true)
            setError("")

            if (paymentMethod === "COD") {

                await placeCodOrder()

            } else {

                await createUpiPayment()
            }

        } catch (err) {

            console.error(
                "Checkout failed:",
                err
            )

            const message =
                err instanceof Error
                    ? err.message
                    : "Unable to continue with checkout. Please try again."

            setError(message)

            alert(message)

            setPlacingOrder(false)
        }
    }

    return (

        <div className="customer-dashboard">

            {/* ==================================
             * HEADER
             * ================================== */}

            <header className="customer-header">

                <button
                    className="customer-logo"
                    type="button"
                    onClick={onHome}
                >
                    <span className="logo-icon">
                        🛒
                    </span>

                    <span>
                        LocalMart
                    </span>

                </button>

                <div className="customer-search">

                    <span className="search-icon">
                        ⌕
                    </span>

                    <input
                        type="text"
                        placeholder="Search products, stores..."
                    />

                </div>

                <div className="customer-location">

                    <span>
                        📍
                    </span>

                    <div>

                        <small>
                            Deliver to
                        </small>

                        <strong>
                            {
                                selectedAddress?.city ||
                                "Select address"
                            }
                        </strong>

                    </div>

                </div>

                <div className="customer-profile">

                    <div className="profile-avatar">

                        {user?.email
                                ?.charAt(0)
                                .toUpperCase() ||
                            "U"}

                    </div>

                    <div className="profile-info">

                        <span>
                            Customer
                        </span>

                        <strong>
                            {user?.email ||
                                "User"}
                        </strong>

                    </div>

                </div>

                <button
                    className="customer-logout"
                    type="button"
                    onClick={logout}
                    disabled={
                        placingOrder ||
                        verifyingPayment
                    }
                >
                    Logout
                </button>

            </header>

            {/* ==================================
             * NAVIGATION
             * ================================== */}

            <nav className="customer-nav">

                <button
                    type="button"
                    onClick={onHome}
                >
                    Home
                </button>

                <button
                    type="button"
                    onClick={onStores}
                >
                    Stores
                </button>

                <button
                    type="button"
                    onClick={onCategories}
                >
                    Categories
                </button>

                <button
                    type="button"
                    onClick={onProducts}
                >
                    Products
                </button>

                <button
                    type="button"
                    onClick={onOrders}
                >
                    Orders
                </button>

            </nav>

            {/* ==================================
             * MAIN
             * ================================== */}

            <main className="cart-main">

                <div className="cart-container">

                    <div className="cart-page-heading">

                        <div>

                            <button
                                className="cart-back-button"
                                type="button"
                                onClick={onCart}
                                disabled={
                                    placingOrder ||
                                    verifyingPayment
                                }
                            >
                                ← Back to Cart
                            </button>

                            <h1>
                                Checkout
                            </h1>

                            <p>
                                Complete your order
                                details below.
                            </p>

                        </div>

                    </div>

                    {loading ? (

                        <section className="cart-empty">

                            <div className="cart-empty-icon">
                                🛒
                            </div>

                            <h2>
                                Loading your cart...
                            </h2>

                            <p>
                                Please wait while we load your items.
                            </p>

                        </section>

                    ) : error &&
                    cartItems.length === 0 ? (

                        <section className="cart-empty">

                            <div className="cart-empty-icon">
                                ⚠️
                            </div>

                            <h2>
                                Unable to load checkout
                            </h2>

                            <p>
                                {error}
                            </p>

                            <button
                                className="cart-shop-button"
                                type="button"
                                onClick={() =>
                                    window.location.reload()
                                }
                            >
                                Try Again
                            </button>

                        </section>

                    ) : cartItems.length === 0 ? (

                        <section className="cart-empty">

                            <div className="cart-empty-icon">
                                🛒
                            </div>

                            <h2>
                                Your cart is empty
                            </h2>

                            <p>
                                Add some products before
                                proceeding to checkout.
                            </p>

                            <button
                                className="cart-shop-button"
                                type="button"
                                onClick={onProducts}
                            >
                                Start Shopping
                            </button>

                        </section>

                    ) : (

                        <div className="cart-layout">

                            {/* ==================================
                             * LEFT SIDE
                             * ================================== */}

                            <section className="cart-items-section">

                                {/* ==================================
                                 * DELIVERY DETAILS
                                 * ================================== */}

                                <div className="cart-store-group">

                                    <div className="cart-store-info">

                                        <div className="cart-store-icon">
                                            📍
                                        </div>

                                        <div>

                                            <span>
                                                DELIVERY DETAILS
                                            </span>

                                            <strong>
                                                Where should we deliver?
                                            </strong>

                                        </div>

                                    </div>

                                    <div className="checkout-form">

                                        {/* ==================================
                                         * FULL NAME + PHONE
                                         * ================================== */}

                                        <div className="checkout-form-row">

                                            <div className="checkout-field">

                                                <label>
                                                    Full Name
                                                </label>

                                                <input
                                                    type="text"
                                                    value={fullName}
                                                    onChange={
                                                        event =>
                                                            setFullName(
                                                                event.target.value
                                                            )
                                                    }
                                                    placeholder="Enter your full name"
                                                    disabled={
                                                        placingOrder ||
                                                        verifyingPayment
                                                    }
                                                />

                                            </div>

                                            <div className="checkout-field">

                                                <label>
                                                    Phone Number
                                                </label>

                                                <input
                                                    type="tel"
                                                    value={phone}
                                                    onChange={
                                                        event =>
                                                            setPhone(
                                                                event.target.value
                                                            )
                                                    }
                                                    placeholder="Enter your phone number"
                                                    disabled={
                                                        placingOrder ||
                                                        verifyingPayment
                                                    }
                                                />

                                            </div>

                                        </div>

                                        {/* ==================================
                                         * DELIVERY ADDRESS DROPDOWN
                                         * ================================== */}

                                        <div className="checkout-field">

                                            <label>
                                                Delivery Address
                                            </label>

                                            {loadingAddresses ? (

                                                <div className="checkout-address-loading">
                                                    Loading saved addresses...
                                                </div>

                                            ) : addresses.length === 0 ? (

                                                <div className="checkout-no-address">

                                                    <p>
                                                        You don't have a saved delivery address.
                                                    </p>

                                                    <button
                                                        type="button"
                                                        className="checkout-add-address-button"
                                                        onClick={
                                                            onAddNewAddress
                                                        }
                                                        disabled={
                                                            placingOrder ||
                                                            verifyingPayment
                                                        }
                                                    >
                                                        <span>
                                                            +
                                                        </span>

                                                        Add New Address

                                                        <span>
                                                            →
                                                        </span>

                                                    </button>

                                                </div>

                                            ) : (

                                                <>

                                                    <select
                                                        className="checkout-address-select"
                                                        value={
                                                            selectedAddressId ??
                                                            ""
                                                        }
                                                        onChange={
                                                            event =>
                                                                handleAddressChange(
                                                                    event.target.value
                                                                )
                                                        }
                                                        disabled={
                                                            placingOrder ||
                                                            verifyingPayment
                                                        }
                                                    >

                                                        <option
                                                            value=""
                                                            disabled
                                                        >
                                                            Select delivery address
                                                        </option>

                                                        {addresses.map(
                                                            savedAddress => (

                                                                <option
                                                                    key={
                                                                        savedAddress.addressId
                                                                    }
                                                                    value={
                                                                        savedAddress.addressId
                                                                    }
                                                                >

                                                                    {
                                                                        savedAddress.addressLine
                                                                    }
                                                                    {" — "}
                                                                    {
                                                                        savedAddress.city
                                                                    }
                                                                    {" — "}
                                                                    {
                                                                        savedAddress.pincode
                                                                    }

                                                                    {
                                                                        savedAddress.isDefault
                                                                            ? " (Default)"
                                                                            : ""
                                                                    }

                                                                </option>

                                                            )
                                                        )}

                                                    </select>

                                                    <button
                                                        type="button"
                                                        className="checkout-add-address-button"
                                                        onClick={
                                                            onAddNewAddress
                                                        }
                                                        disabled={
                                                            placingOrder ||
                                                            verifyingPayment
                                                        }
                                                    >

                                                        <span>
                                                            +
                                                        </span>

                                                        Add New Address

                                                        <span>
                                                            →
                                                        </span>

                                                    </button>

                                                </>

                                            )}

                                            {addressError && (

                                                <p className="checkout-address-error">
                                                    {addressError}
                                                </p>

                                            )}

                                        </div>

                                    </div>

                                </div>

                                {/* ==================================
                                 * PAYMENT METHOD
                                 * ================================== */}

                                <div className="cart-store-group">

                                    <div className="cart-store-info">

                                        <div className="cart-store-icon">
                                            💳
                                        </div>

                                        <div>

                                            <span>
                                                PAYMENT METHOD
                                            </span>

                                            <strong>
                                                Choose how to pay
                                            </strong>

                                        </div>

                                    </div>

                                    <div className="checkout-payment-options">

                                        <button
                                            type="button"
                                            className={
                                                paymentMethod === "COD"
                                                    ? "checkout-payment-option active"
                                                    : "checkout-payment-option"
                                            }
                                            onClick={() =>
                                                handlePaymentMethodChange(
                                                    "COD"
                                                )
                                            }
                                            disabled={
                                                placingOrder ||
                                                verifyingPayment
                                            }
                                        >

                                            <span>
                                                💵
                                            </span>

                                            <div>

                                                <strong>
                                                    Cash on Delivery
                                                </strong>

                                                <small>
                                                    Pay when your order arrives
                                                </small>

                                            </div>

                                        </button>

                                        <button
                                            type="button"
                                            className={
                                                paymentMethod === "UPI"
                                                    ? "checkout-payment-option active"
                                                    : "checkout-payment-option"
                                            }
                                            onClick={() =>
                                                handlePaymentMethodChange(
                                                    "UPI"
                                                )
                                            }
                                            disabled={
                                                placingOrder ||
                                                verifyingPayment
                                            }
                                        >

                                            <span>
                                                📱
                                            </span>

                                            <div>

                                                <strong>
                                                    UPI
                                                </strong>

                                                <small>
                                                    Pay using Razorpay
                                                </small>

                                            </div>

                                        </button>

                                    </div>

                                </div>

                                {/* ==================================
                                 * RAZORPAY PAYMENT STATUS
                                 * ================================== */}

                                {upiPayment && (

                                    <div className="cart-store-group">

                                        <div className="cart-store-info">

                                            <div className="cart-store-icon">
                                                📱
                                            </div>

                                            <div>

                                                <span>
                                                    RAZORPAY TEST PAYMENT
                                                </span>

                                                <strong>
                                                    Payment order created
                                                </strong>

                                            </div>

                                        </div>

                                        <div
                                            style={{
                                                display: "flex",
                                                flexDirection: "column",
                                                alignItems: "center",
                                                gap: "16px",
                                                padding: "20px",
                                                textAlign: "center",
                                            }}
                                        >

                                            <div>

                                                <strong
                                                    style={{
                                                        display: "block",
                                                        marginBottom: "6px",
                                                    }}
                                                >
                                                    Razorpay Test Mode
                                                </strong>

                                                <span
                                                    style={{
                                                        color: "#6b7280",
                                                        fontSize: "13px",
                                                    }}
                                                >
                                                    Amount: ₹
                                                    {Number(
                                                        upiPayment.amount
                                                    ).toFixed(2)}
                                                </span>

                                            </div>

                                            <div
                                                style={{
                                                    width: "100%",
                                                    maxWidth: "460px",
                                                    padding: "12px",
                                                    borderRadius: "8px",
                                                    background: "#f8faf8",
                                                    border: "1px solid #e5e7eb",
                                                }}
                                            >

                                                <small
                                                    style={{
                                                        display: "block",
                                                        color: "#6b7280",
                                                        marginBottom: "5px",
                                                    }}
                                                >
                                                    Razorpay Order ID
                                                </small>

                                                <strong
                                                    style={{
                                                        wordBreak: "break-all",
                                                    }}
                                                >
                                                    {
                                                        upiPayment.razorpayOrderId
                                                    }
                                                </strong>

                                            </div>

                                            <p
                                                style={{
                                                    margin: 0,
                                                    color: "#6b7280",
                                                    fontSize: "13px",
                                                    lineHeight: 1.5,
                                                    maxWidth: "500px",
                                                }}
                                            >
                                                This is Razorpay Test Mode.
                                                No real money will be
                                                transferred.
                                            </p>

                                            <button
                                                type="button"
                                                className="cart-checkout-button"
                                                onClick={
                                                    () => {

                                                        if (
                                                            !window.Razorpay
                                                        ) {

                                                            setError(
                                                                "Razorpay Checkout is unavailable. Please try starting the payment again."
                                                            )

                                                            return
                                                        }

                                                        const options:
                                                            RazorpayOptions = {

                                                            key:
                                                            upiPayment.razorpayKeyId,

                                                            amount:
                                                                Math.round(
                                                                    Number(
                                                                        upiPayment.amount
                                                                    ) *
                                                                    100
                                                                ),

                                                            currency:
                                                            upiPayment.currency,

                                                            name:
                                                                "LocalMart",

                                                            description:
                                                                `LocalMart Order ${upiPayment.order.orderNumber}`,

                                                            order_id:
                                                            upiPayment.razorpayOrderId,

                                                            prefill: {

                                                                name:
                                                                    fullName.trim(),

                                                                email:
                                                                    user?.email ||
                                                                    "",

                                                                contact:
                                                                    phone.trim(),
                                                            },

                                                            notes: {

                                                                localmart_order_id:
                                                                    String(
                                                                        upiPayment.order.orderId
                                                                    ),
                                                            },

                                                            theme: {

                                                                color:
                                                                    "#2e7d32",
                                                            },

                                                            handler:
                                                                (
                                                                    response:
                                                                    RazorpayPaymentResponse
                                                                ) => {

                                                                    verifyRazorpayPayment(
                                                                        upiPayment,
                                                                        response
                                                                    )
                                                                },

                                                            modal: {

                                                                ondismiss:
                                                                    () => {

                                                                        setPlacingOrder(
                                                                            false
                                                                        )

                                                                        setError(
                                                                            "Payment was cancelled. Your order is still awaiting payment."
                                                                        )
                                                                    },
                                                            },
                                                        }

                                                        const razorpay =
                                                            new window.Razorpay(
                                                                options
                                                            )

                                                        razorpay.open()
                                                    }
                                                }
                                                disabled={
                                                    verifyingPayment ||
                                                    placingOrder
                                                }
                                                style={{
                                                    maxWidth: "300px",
                                                }}
                                            >

                                                {verifyingPayment
                                                    ? "Verifying Payment..."
                                                    : "Open Razorpay Payment"}

                                                <span>
                                                    →
                                                </span>

                                            </button>

                                        </div>

                                    </div>

                                )}

                                {/* ==================================
                                 * ORDER ITEMS
                                 * ================================== */}

                                <div className="cart-store-group">

                                    <div className="cart-store-info">

                                        <div className="cart-store-icon">
                                            📦
                                        </div>

                                        <div>

                                            <span>
                                                YOUR ORDER
                                            </span>

                                            <strong>
                                                {itemCount} item
                                                {itemCount !== 1
                                                    ? "s"
                                                    : ""}
                                            </strong>

                                        </div>

                                    </div>

                                    <div className="cart-items">

                                        <div className="checkout-store-items">

                                            <div className="checkout-store-name">
                                                🏪{" "}
                                                {storeName}
                                            </div>

                                            {cartItems.map(
                                                item => (

                                                    <div
                                                        className="order-item"
                                                        key={
                                                            item.cartItemId
                                                        }
                                                    >

                                                        <div className="order-item-image">
                                                            {item.icon ||
                                                                "🛒"}
                                                        </div>

                                                        <div className="order-item-details">

                                                            <strong>
                                                                {
                                                                    item.productName
                                                                }
                                                            </strong>

                                                            <span>
                                                                {
                                                                    item.unit
                                                                }
                                                            </span>

                                                        </div>

                                                        <div className="order-item-quantity">

                                                            ×{" "}
                                                            {
                                                                item.quantity
                                                            }

                                                        </div>

                                                        <strong className="order-item-price">

                                                            ₹
                                                            {Number(
                                                                item.itemTotal
                                                            ).toFixed(0)}

                                                        </strong>

                                                    </div>

                                                )
                                            )}

                                        </div>

                                    </div>

                                </div>

                            </section>

                            {/* ==================================
                             * RIGHT SIDE
                             * ================================== */}

                            <aside className="cart-summary">

                                <h2>
                                    Order Summary
                                </h2>

                                <div className="cart-summary-row">

                                    <span>
                                        Items
                                    </span>

                                    <strong>
                                        {itemCount}
                                    </strong>

                                </div>

                                <div className="cart-summary-row">

                                    <span>
                                        Subtotal
                                    </span>

                                    <strong>
                                        ₹
                                        {subtotal.toFixed(0)}
                                    </strong>

                                </div>

                                <div className="cart-summary-row">

                                    <span>
                                        Delivery Fee
                                    </span>

                                    <strong>

                                        {loadingDeliveryFee
                                            ? "Calculating..."
                                            : deliveryFeeError
                                                ? "--"
                                                : `₹${deliveryFee.toFixed(0)}`}

                                    </strong>

                                </div>

                                {deliveryDistanceKm !== null &&
                                    !loadingDeliveryFee &&
                                    !deliveryFeeError && (

                                        <div
                                            style={{
                                                fontSize: "12px",
                                                color: "#6b7280",
                                                textAlign: "right",
                                                marginTop: "-6px",
                                                marginBottom: "8px",
                                            }}
                                        >
                                            Delivery distance:{" "}
                                            {deliveryDistanceKm.toFixed(2)}
                                            {" "}km
                                        </div>

                                    )}

                                <div className="cart-summary-divider" />

                                <div className="cart-summary-total">

                                    <span>
                                        Total
                                    </span>

                                    <strong>
                                        ₹
                                        {total.toFixed(0)}
                                    </strong>

                                </div>

                                {!upiPayment && (

                                    <button
                                        className="cart-checkout-button"
                                        type="button"
                                        onClick={
                                            handlePlaceOrder
                                        }
                                        disabled={
                                            placingOrder ||
                                            verifyingPayment ||
                                            loadingDeliveryFee ||
                                            !!deliveryFeeError ||
                                            !selectedAddressId ||
                                            cartItems.length === 0
                                        }
                                    >

                                        {placingOrder
                                            ? (
                                                paymentMethod === "COD"
                                                    ? "Placing Order..."
                                                    : "Creating Payment..."
                                            )
                                            : (
                                                loadingDeliveryFee
                                                    ? "Calculating Delivery Fee..."
                                                    : paymentMethod === "COD"
                                                        ? "Place Order"
                                                        : "Continue to UPI Payment"
                                            )}

                                        <span>
                                            →
                                        </span>

                                    </button>

                                )}

                                <div className="cart-security">

                                    <span>
                                        🔒
                                    </span>

                                    <p>
                                        Secure checkout
                                    </p>

                                </div>

                                <div className="checkout-payment-summary">

                                    <span>
                                        Payment
                                    </span>

                                    <strong>
                                        {paymentMethod === "COD"
                                            ? "Cash on Delivery"
                                            : "UPI"}
                                    </strong>

                                </div>

                                {selectedAddress && (

                                    <div
                                        style={{
                                            marginTop: "14px",
                                            padding: "12px",
                                            borderRadius: "8px",
                                            background: "#f8faf8",
                                            fontSize: "13px",
                                            lineHeight: 1.5,
                                            color: "#4b5563",
                                        }}
                                    >

                                        <strong
                                            style={{
                                                display: "block",
                                                color: "#1f2937",
                                                marginBottom: "4px",
                                            }}
                                        >
                                            Delivering to
                                        </strong>

                                        {selectedAddress.addressLine}
                                        <br />

                                        {selectedAddress.city},{" "}
                                        {selectedAddress.state}{" "}
                                        {selectedAddress.pincode}

                                    </div>

                                )}

                                {deliveryFeeError && (

                                    <p className="checkout-address-error">
                                        {deliveryFeeError}
                                    </p>

                                )}

                                {error && (

                                    <p className="checkout-address-error">
                                        {error}
                                    </p>

                                )}

                            </aside>

                        </div>

                    )}

                </div>

            </main>

            {/* ==================================
             * FOOTER
             * ================================== */}

            <footer className="customer-footer">

                <div className="footer-content">

                    <div className="footer-brand">

                        <div className="footer-logo">
                            🛒 LocalMart
                        </div>

                        <p>
                            Your local stores,
                            delivered to your door.
                        </p>

                    </div>

                    <div className="footer-links">

                        <button
                            type="button"
                            onClick={onHome}
                        >
                            Home
                        </button>

                        <button
                            type="button"
                            onClick={onStores}
                        >
                            Stores
                        </button>

                        <button
                            type="button"
                            onClick={onCategories}
                        >
                            Categories
                        </button>

                        <button
                            type="button"
                            onClick={onProducts}
                        >
                            Products
                        </button>

                        <button
                            type="button"
                            onClick={onOrders}
                        >
                            Orders
                        </button>

                        <button
                            type="button"
                            onClick={onCart}
                        >
                            Cart
                        </button>

                    </div>

                </div>

                <div className="footer-bottom">

                    <span>
                        © 2026 LocalMart
                    </span>

                    <span>
                        Shop local. Live local.
                    </span>

                </div>

            </footer>

        </div>
    )
}

export default Checkout