
        package com.localmart.localmartbackend.controller;

import com.localmart.localmartbackend.dto.UserResponse;
import com.localmart.localmartbackend.service.AdminRequestService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
public class AdminRequestController {

    private final AdminRequestService adminRequestService;

    public AdminRequestController(
            AdminRequestService adminRequestService) {

        this.adminRequestService = adminRequestService;
    }

    // ================================
    // STORE OWNER APPLICATIONS
    // ================================

    @GetMapping("/store-owner-requests")
    public ResponseEntity<List<UserResponse>>
    getPendingStoreOwnerRequests() {

        return ResponseEntity.ok(
                adminRequestService
                        .getPendingStoreOwnerRequests()
        );
    }

    // ================================
    // DELIVERY PARTNER APPLICATIONS
    // ================================

    @GetMapping("/delivery-partner-requests")
    public ResponseEntity<List<UserResponse>>
    getPendingDeliveryPartnerRequests() {

        return ResponseEntity.ok(
                adminRequestService
                        .getPendingDeliveryPartnerRequests()
        );
    }

    // ================================
    // APPROVE APPLICATION
    // ================================

    @PutMapping("/requests/{userId}/approve")
    public ResponseEntity<UserResponse>
    approveRequest(
            @PathVariable Long userId) {

        return ResponseEntity.ok(
                adminRequestService
                        .approveRequest(userId)
        );
    }

    // ================================
    // REJECT APPLICATION
    // ================================

    @PutMapping("/requests/{userId}/reject")
    public ResponseEntity<UserResponse>
    rejectRequest(
            @PathVariable Long userId) {

        return ResponseEntity.ok(
                adminRequestService
                        .rejectRequest(userId)
        );
    }
}
