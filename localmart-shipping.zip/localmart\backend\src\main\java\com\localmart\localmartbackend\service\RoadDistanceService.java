package com.localmart.localmartbackend.service;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;

@Service
public class RoadDistanceService {

    private static final String OSRM_BASE_URL =
            "https://router.project-osrm.org/route/v1/driving/";

    private final RestClient restClient;

    public RoadDistanceService() {

        this.restClient = RestClient.builder()
                .baseUrl(OSRM_BASE_URL)
                .defaultHeader(
                        "Accept-Encoding",
                        "identity"
                )
                .defaultHeader(
                        "Accept",
                        "application/json"
                )
                .defaultHeader(
                        "User-Agent",
                        "LocalMart/1.0"
                )
                .build();
    }

    public RoadRoute calculateRoute(
            BigDecimal fromLatitude,
            BigDecimal fromLongitude,
            BigDecimal toLatitude,
            BigDecimal toLongitude
    ) {

        if (fromLatitude == null
                || fromLongitude == null
                || toLatitude == null
                || toLongitude == null) {

            throw new IllegalArgumentException(
                    "All coordinates are required"
            );
        }

        /*
         * OSRM expects coordinates in:
         *
         * longitude,latitude
         *
         * Example:
         *
         * 80.2269849,13.1213975
         */
        String coordinates =
                fromLongitude
                        + ","
                        + fromLatitude
                        + ";"
                        + toLongitude
                        + ","
                        + toLatitude;

        try {

            Map<?, ?> response =
                    restClient.get()
                            .uri(
                                    coordinates
                                            + "?overview=false"
                            )
                            .retrieve()
                            .body(Map.class);

            if (response == null) {

                throw new RuntimeException(
                        "Empty response from road distance service"
                );
            }

            Object codeObject =
                    response.get("code");

            if (codeObject == null
                    || !"Ok".equalsIgnoreCase(
                    codeObject.toString())) {

                throw new RuntimeException(
                        "Unable to calculate road distance"
                );
            }

            Object routesObject =
                    response.get("routes");

            if (!(routesObject instanceof java.util.List<?> routes)
                    || routes.isEmpty()) {

                throw new RuntimeException(
                        "No road route found"
                );
            }

            Object firstRoute =
                    routes.get(0);

            if (!(firstRoute instanceof Map<?, ?> route)) {

                throw new RuntimeException(
                        "Invalid route response"
                );
            }

            Object distanceObject =
                    route.get("distance");

            Object durationObject =
                    route.get("duration");

            if (!(distanceObject instanceof Number)
                    || !(durationObject instanceof Number)) {

                throw new RuntimeException(
                        "Invalid distance or duration returned"
                );
            }

            /*
             * OSRM returns distance in meters.
             *
             * Convert:
             *
             * meters → kilometers
             */
            BigDecimal distanceKm =
                    BigDecimal.valueOf(
                                    ((Number) distanceObject)
                                            .doubleValue()
                            )
                            .divide(
                                    BigDecimal.valueOf(1000),
                                    2,
                                    RoundingMode.HALF_UP
                            );

            /*
             * OSRM returns duration in seconds.
             *
             * Convert:
             *
             * seconds → minutes
             */
            BigDecimal durationMinutes =
                    BigDecimal.valueOf(
                                    ((Number) durationObject)
                                            .doubleValue()
                            )
                            .divide(
                                    BigDecimal.valueOf(60),
                                    1,
                                    RoundingMode.HALF_UP
                            );

            return new RoadRoute(
                    distanceKm,
                    durationMinutes
            );

        } catch (Exception e) {

            throw new RuntimeException(
                    "Failed to calculate road distance: "
                            + e.getMessage(),
                    e
            );
        }
    }

    public static class RoadRoute {

        private final BigDecimal distanceKm;
        private final BigDecimal durationMinutes;

        public RoadRoute(
                BigDecimal distanceKm,
                BigDecimal durationMinutes
        ) {
            this.distanceKm = distanceKm;
            this.durationMinutes = durationMinutes;
        }

        public BigDecimal getDistanceKm() {
            return distanceKm;
        }

        public BigDecimal getDurationMinutes() {
            return durationMinutes;
        }
    }
}