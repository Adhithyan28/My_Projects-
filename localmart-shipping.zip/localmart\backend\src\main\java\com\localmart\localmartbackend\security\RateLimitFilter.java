package com.localmart.localmartbackend.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class RateLimitFilter extends OncePerRequestFilter {

    /*
     * --------------------------------------------------------
     * RATE LIMIT CONFIGURATION
     * --------------------------------------------------------
     *
     * Maximum number of requests allowed from one IP
     * during the configured time window.
     */
    private static final int MAX_REQUESTS = 10;

    /*
     * 1 minute window.
     */
    private static final long WINDOW_MILLISECONDS =
            60 * 1000L;

    /*
     * --------------------------------------------------------
     * REQUEST COUNTERS
     * --------------------------------------------------------
     *
     * Each IP address gets its own counter.
     *
     * Example:
     *
     * 192.168.1.10 -> 4 requests
     * 192.168.1.20 -> 8 requests
     * 192.168.1.30 -> 1 request
     */
    private final Map<String, RequestCounter> requestCounters =
            new ConcurrentHashMap<>();

    /*
     * --------------------------------------------------------
     * FILTER
     * --------------------------------------------------------
     */
    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain filterChain)
            throws ServletException, IOException {

        String requestUri =
                request.getRequestURI();

        /*
         * Only rate-limit authentication endpoints.
         */
        if (!isRateLimitedEndpoint(requestUri)) {

            filterChain.doFilter(
                    request,
                    response
            );

            return;
        }

        /*
         * ----------------------------------------------------
         * Identify the client
         * ----------------------------------------------------
         */
        String clientIp =
                getClientIp(request);

        /*
         * ----------------------------------------------------
         * Check rate limit
         * ----------------------------------------------------
         */
        if (!isRequestAllowed(clientIp)) {

            System.out.println(
                    "RATE LIMIT -> BLOCKED IP = "
                            + clientIp
                            + ", URI = "
                            + requestUri
            );

          response.setStatus(429);


            response.setContentType(
                    "application/json"
            );

            response.getWriter().write(
                    """
                    {
                        "error": "Too many requests",
                        "message": "Please try again later."
                    }
                    """
            );

            return;
        }

        System.out.println(
                "RATE LIMIT -> ALLOWED IP = "
                        + clientIp
                        + ", URI = "
                        + requestUri
        );

        /*
         * Request is within the limit.
         *
         * Continue to the next filter.
         */
        filterChain.doFilter(
                request,
                response
        );
    }

    /*
     * --------------------------------------------------------
     * DETERMINE WHICH ENDPOINTS ARE RATE LIMITED
     * --------------------------------------------------------
     */
    private boolean isRateLimitedEndpoint(
            String requestUri) {

        return requestUri.equals(
                "/api/users/login"
        )
                || requestUri.equals(
                "/api/users/login/send-otp"
        )
                || requestUri.equals(
                "/api/users/login/verify"
        )
                || requestUri.equals(
                "/api/users/google/login"
        )
                || requestUri.equals(
                "/api/users/google/register"
        )
                || requestUri.equals(
                "/api/sms-otp/send"
        )
                || requestUri.equals(
                "/api/sms-otp/verify"
        )
                || requestUri.equals(
                "/api/admin/login"
        )
                || requestUri.equals(
                "/api/admin/login/send-otp"
        )
                || requestUri.equals(
                "/api/admin/login/verify"
        );
    }

    /*
     * --------------------------------------------------------
     * CLIENT IP
     * --------------------------------------------------------
     */
    private String getClientIp(
            HttpServletRequest request) {

        return request.getRemoteAddr();
    }

    /*
     * --------------------------------------------------------
     * RATE LIMIT CHECK
     * --------------------------------------------------------
     */
    private boolean isRequestAllowed(
            String clientIp) {

        long currentTime =
                System.currentTimeMillis();

        RequestCounter counter =
                requestCounters.computeIfAbsent(
                        clientIp,
                        key -> new RequestCounter(
                                currentTime
                        )
                );

        synchronized (counter) {

            /*
             * ------------------------------------------------
             * Start a new window if the old window expired.
             * ------------------------------------------------
             */
            if (currentTime - counter.windowStart
                    >= WINDOW_MILLISECONDS) {

                counter.windowStart =
                        currentTime;

                counter.requestCount = 0;
            }

            /*
             * ------------------------------------------------
             * Check whether the limit has been reached.
             * ------------------------------------------------
             */
            if (counter.requestCount >= MAX_REQUESTS) {

                return false;
            }

            /*
             * ------------------------------------------------
             * Consume one request.
             * ------------------------------------------------
             */
            counter.requestCount++;

            return true;
        }
    }

    /*
     * --------------------------------------------------------
     * REQUEST COUNTER
     * --------------------------------------------------------
     */
    private static class RequestCounter {

        private long windowStart;

        private int requestCount;

        private RequestCounter(
                long windowStart) {

            this.windowStart =
                    windowStart;

            this.requestCount = 0;
        }
    }
}