# LocalMart — Payment System

## 1. Overview

The Payment System is responsible for handling payment-related operations during the LocalMart checkout process.

LocalMart integrates with **Razorpay** as the external payment gateway while maintaining its own order and payment information in the backend.

The high-level relationship is:

```text
Customer
   |
   v
Cart
   |
   v
Checkout
   |
   v
Order
   |
   v
Payment
   |
   v
Razorpay
   |
   v
Payment Result
```

The payment system separates payment processing from the rest of the application's business logic.

---

# 2. Purpose of the Payment System

The payment system is responsible for:

* Initiating payment-related operations
* Communicating with Razorpay
* Associating payment information with LocalMart orders
* Maintaining payment information in the database
* Processing payment results
* Supporting the checkout workflow
* Handling payment-related failures
* Keeping payment processing separate from order and delivery logic

The backend acts as the application's payment orchestration layer.

---

# 3. Payment Architecture

The high-level architecture is:

```text
React Frontend
      |
      | HTTP
      v
Order / Payment API
      |
      v
Backend Service
      |
      v
RazorpayService
      |
      | HTTPS
      v
Razorpay
```

The backend also maintains payment data:

```text
Razorpay
    |
    v
Payment Information
    |
    v
LocalMart Payment Entity
    |
    v
PostgreSQL
```

---

# 4. Payment and Order

Payment is closely related to an order, but the two represent different concepts.

```text
Order
 |
 +--> What the customer purchased
 |
 +--> Store
 |
 +--> Order Items
 |
 +--> Delivery information
 |
 v
Payment
 |
 +--> Payment processing information
 +--> Payment status
 +--> Gateway information
```

The order represents the business transaction.

The payment represents the financial transaction associated with that order.

---

# 5. Why Payment Is a Separate Module

Payment processing has different responsibilities from order management.

For example:

```text
Order Management
----------------
- Create order
- Manage order items
- Manage fulfillment
- Track order state

Payment System
--------------
- Initiate payment
- Communicate with gateway
- Track payment information
- Process payment result
```

Keeping these responsibilities separate makes the system easier to maintain and extend.

---

# 6. Razorpay Integration

LocalMart uses **Razorpay** as the external payment gateway.

The backend contains:

```text
RazorpayService
```

which acts as the integration layer between LocalMart and Razorpay.

The architecture is:

```text
LocalMart
    |
    v
RazorpayService
    |
    v
Razorpay API
```

This prevents Razorpay-specific communication logic from being spread throughout the application.

---

# 7. Razorpay Service

`RazorpayService` is responsible for communicating with the Razorpay platform.

Conceptually:

```text
Application Service
       |
       v
RazorpayService
       |
       v
Razorpay SDK/API
       |
       v
Razorpay
```

This service acts as an abstraction around the external payment provider.

If the application later changes payment providers, the gateway-specific logic can remain isolated within the payment integration layer.

---

# 8. Payment Entity

LocalMart contains a:

```text
Payment
```

entity.

This entity represents payment information maintained by LocalMart.

The conceptual relationship is:

```text
Order
  |
  v
Payment
  |
  +--> Payment information
  +--> Gateway information
  +--> Payment status
```

The exact database fields and relationships are determined by the current `Payment.java` entity.

---

# 9. Payment Repository

LocalMart contains:

```text
PaymentRepository
```

which provides persistence access to payment records.

The normal flow is:

```text
Payment Service / Order Service
          |
          v
PaymentRepository
          |
          v
PostgreSQL
```

The repository separates database access from business logic.

---

# 10. Checkout and Payment

Payment occurs as part of the checkout journey.

The overall flow is:

```text
Customer
   |
   v
Cart
   |
   v
Select Address
   |
   v
Calculate Delivery Fee
   |
   v
Review Total
   |
   v
Checkout
   |
   v
Payment
```

The checkout amount can be conceptually represented as:

```text
Product Amount
      +
Delivery Fee
      |
      v
Order Total
      |
      v
Payment Amount
```

The exact calculation rules are handled by the application's order/checkout implementation.

---

# 11. Complete Payment Flow

The high-level payment flow is:

```text
Customer
   |
   v
Checkout
   |
   v
Order Information
   |
   v
Backend
   |
   v
RazorpayService
   |
   v
Razorpay
   |
   v
Payment Interface
   |
   v
Customer Completes Payment
   |
   v
Payment Result
   |
   v
Backend
   |
   v
Payment Record
```

The exact sequence of order creation, Razorpay order creation, payment confirmation, and final order-state updates depends on the current implementation.

---

# 12. Frontend to Backend Communication

The React frontend communicates with the backend through HTTP.

Conceptually:

```text
React
 |
 | HTTP Request
 v
Spring Boot
 |
 v
Payment / Order Logic
 |
 v
Razorpay
```

The browser should not directly contain sensitive server-side payment credentials.

Instead:

```text
Frontend
   |
   v
Backend
   |
   v
Razorpay
```

The backend controls the server-side integration.

---

# 13. Payment Gateway Boundary

Razorpay is an external system.

Therefore LocalMart has a clear boundary:

```text
+---------------------------+
|       LocalMart           |
|                           |
| Order                     |
| Payment                   |
| Checkout                  |
| Database                  |
|                           |
+-------------+-------------+
              |
              | HTTPS / SDK
              v
+---------------------------+
|        Razorpay           |
|                           |
| Payment Gateway           |
| Payment Processing        |
|                           |
+---------------------------+
```

LocalMart should not assume that the external gateway and its own database are the same system.

---

# 14. Razorpay SDK

The backend uses the Razorpay Java SDK for communication with Razorpay.

Conceptually:

```text
RazorpayService
       |
       v
Razorpay Java SDK
       |
       v
Razorpay API
```

The SDK simplifies communication between the Java backend and Razorpay's APIs.

---

# 15. API Communication

The payment integration follows a server-to-server communication model where appropriate.

```text
LocalMart Backend
       |
       | HTTPS
       v
Razorpay
```

The backend sends the necessary payment-related information and receives a response from the gateway.

The application then uses the result to continue its own business workflow.

---

# 16. Payment Credentials

Payment gateway credentials are sensitive configuration values.

They should not be hardcoded into Java source files or committed to GitHub.

Conceptually:

```text
Environment / Configuration
          |
          v
Razorpay Credentials
          |
          v
RazorpayService
          |
          v
Razorpay
```

Typical deployment configuration should keep credentials outside source control.

The exact configuration property names should follow the current `application.properties` implementation.

---

# 17. Payment Data Flow

The payment data flow can be represented as:

```text
Customer
   |
   v
React Checkout
   |
   v
Backend
   |
   +--> Calculate / validate order amount
   |
   +--> Create or prepare payment information
   |
   v
RazorpayService
   |
   v
Razorpay
   |
   v
Payment Result
   |
   v
Backend
   |
   +--> Validate result
   |
   +--> Update Payment
   |
   +--> Update Order as appropriate
   |
   v
PostgreSQL
```

---

# 18. Payment Record

LocalMart maintains its own payment record rather than relying exclusively on the external payment gateway.

Conceptually:

```text
Razorpay
   |
   v
Gateway Payment Information
   |
   v
LocalMart Payment
   |
   v
PostgreSQL
```

This allows LocalMart to associate gateway information with its own order lifecycle.

---

# 19. Payment and Order Relationship

The conceptual relationship is:

```text
Order
 |
 +----------------+
 |                |
 v                v
Order Items     Payment
 |
 v
Products
```

The order provides the business context for the payment.

The payment provides the financial-processing context.

---

# 20. Payment Status

Payment processing requires a payment status.

Conceptually:

```text
Payment
   |
   +--> CREATED / INITIATED
   |
   +--> SUCCESS
   |
   +--> FAILED
```

The exact status names used by LocalMart should follow the current `Payment` entity and service implementation.

Payment status should not automatically be assumed to be identical to order status.

For example:

```text
Payment
   |
   v
SUCCESS
   |
   v
Order
   |
   v
FULFILLMENT
```

These represent different state machines.

---

# 21. Payment State vs Order State

Payment and order states have different meanings.

```text
PAYMENT
   |
   +--> Financial processing

ORDER
   |
   +--> Purchase and fulfillment
```

For example:

```text
Payment
   |
   v
Successful
   |
   v
Order
   |
   v
Store Processing
   |
   v
Delivery
```

A successful payment does not itself mean that the order has been delivered.

---

# 22. Payment Failure

A payment can fail.

Conceptually:

```text
Customer
   |
   v
Payment Attempt
   |
   v
Razorpay
   |
   v
Failure
   |
   v
Backend
   |
   v
Payment Failure Handling
```

The application must avoid treating an unsuccessful payment as a completed financial transaction.

The exact recovery behavior depends on the current order/payment implementation.

---

# 23. Payment Success

A successful payment follows the opposite path:

```text
Customer
   |
   v
Payment
   |
   v
Razorpay
   |
   v
Successful Result
   |
   v
Backend Validation
   |
   v
Payment Record
   |
   v
Order Processing
```

The backend should validate payment-related information before treating the payment as successful.

---

# 24. Why Backend Validation Matters

The browser is not a trusted authority for financial state.

For example, the frontend should not simply decide:

```text
"Payment successful"
```

and make the backend trust that value.

Instead:

```text
Frontend
   |
   v
Backend
   |
   v
Payment Gateway
   |
   v
Verified Result
   |
   v
Backend State
```

This protects the application's financial workflow from relying solely on client-controlled information.

---

# 25. Payment Security

Payment processing requires multiple layers of protection.

### Authentication

Protected payment operations should require an authenticated user where appropriate.

### Authorization

The customer should only operate on their own order/payment context.

### Credential protection

Gateway credentials must remain server-side.

### Server-side validation

Important payment information must be validated by the backend.

### HTTPS

Communication with external payment services should use secure transport.

### Database integrity

Payment records should remain associated with the correct order.

---

# 26. Payment and JWT

LocalMart uses JWT-based authentication.

The general request flow is:

```text
React
 |
 | Authorization: Bearer <JWT>
 v
JwtAuthenticationFilter
 |
 v
SecurityContext
 |
 v
Authenticated User
 |
 v
Order / Payment Logic
```

This provides the identity needed to associate protected operations with the authenticated user.

---

# 27. Payment and Customer Ownership

Payment information is connected to the customer's order.

Conceptually:

```text
JWT
 |
 v
Customer
 |
 v
Order
 |
 v
Payment
```

This relationship is important because one customer must not be able to manipulate another customer's payment/order information.

---

# 28. Payment and Store

The payment is ultimately associated with an order that belongs to a store context.

```text
Customer
   |
   v
Order
   |
   v
Store
```

Payment processing therefore indirectly participates in the store's order lifecycle.

The store owner should not receive unrestricted access to sensitive payment credentials or unrelated customer financial information.

---

# 29. Payment and Delivery

Payment and delivery are separate stages.

```text
Payment
   |
   v
Order
   |
   v
Store Fulfillment
   |
   v
Delivery
```

The delivery partner's job is to fulfill the delivery, not to process the customer's payment.

---

# 30. Payment Database Flow

The persistence architecture is:

```text
Payment Logic
      |
      v
PaymentRepository
      |
      v
Payment Entity
      |
      v
PostgreSQL
```

The database provides persistent payment information for the application's own records.

---

# 31. Payment Transaction Boundary

The payment gateway and LocalMart database are separate systems.

Therefore the application must consider the possibility that:

```text
Razorpay
   |
   v
Payment succeeds
```

while a subsequent application/database operation experiences a failure.

This is a distributed-system boundary.

Conceptually:

```text
LocalMart              Razorpay
    |                     |
    |------ Request ----->|
    |                     |
    |<----- Result -------|
    |                     |
    v                     |
Database                  |
```

This is one reason payment workflows require careful state handling and verification.

---

# 32. Idempotency Consideration

Payment operations can involve retries.

For example:

```text
Request
   |
   v
Network Problem
   |
   v
Client Retries
   |
   v
Same Payment Operation
```

Without appropriate protection, repeated requests can potentially create duplicate operations.

Therefore payment-related operations should be designed with idempotency and duplicate-processing considerations.

The exact idempotency mechanism currently implemented in LocalMart should be documented from the actual payment/order source.

---

# 33. Payment Error Handling

Payment-related errors can include:

```text
Invalid payment request
Invalid order
Unauthorized payment operation
Gateway communication failure
Payment failure
Invalid payment response
Database failure
Network timeout
```

The application's global exception-handling layer can provide consistent API responses where exceptions propagate to it.

---

# 34. Payment Architecture in LocalMart

The complete payment architecture is:

```text
                    CUSTOMER
                       |
                       v
                    REACT UI
                       |
                       v
                    CHECKOUT
                       |
                       v
                     ORDER
                       |
                       v
                    PAYMENT
                       |
                       v
                RazorpayService
                       |
                       v
                  Razorpay API
                       |
                       v
                 Payment Result
                       |
                       v
                LocalMart Backend
                       |
              +--------+--------+
              |                 |
              v                 v
        PaymentRepository   Order Logic
              |                 |
              v                 v
          PostgreSQL          Order
```

---

# 35. Backend Components

The main payment-related backend component currently present is:

### Service

```text
RazorpayService
```

### Entity

```text
Payment
```

### Repository

```text
PaymentRepository
```

Payment processing also integrates with order-related components.

Relevant components include:

```text
OrderController
OrderService
OrderRepository
```

The exact controller endpoints for payment should be kept synchronized with the current source implementation.

---

# 36. External Integration Boundary

The external integration can be summarized as:

```text
+--------------------------------------+
|            LocalMart                |
|                                      |
| OrderService                         |
| RazorpayService                      |
| Payment                              |
| PaymentRepository                    |
|                                      |
+------------------+-------------------+
                   |
                   | External API / SDK
                   v
+--------------------------------------+
|             Razorpay                 |
|                                      |
| Payment Gateway                      |
| Payment Processing                   |
|                                      |
+--------------------------------------+
```

This boundary is an important part of the system architecture.

---

# 37. End-to-End Checkout and Payment Flow

The complete customer journey is:

```text
Customer
   |
   v
Browse Products
   |
   v
Add Products to Cart
   |
   v
Review Cart
   |
   v
Select Address
   |
   v
Calculate Delivery Fee
   |
   v
Review Total
   |
   v
Checkout
   |
   v
Payment
   |
   v
Razorpay
   |
   v
Payment Result
   |
   v
Backend Verification / Processing
   |
   v
Payment Record
   |
   v
Order Processing
   |
   v
Store
   |
   v
Delivery
```

---

# 38. Failure Flow

A failure can occur at several points.

```text
Checkout
   |
   v
Payment
   |
   v
Razorpay
   |
   +------> SUCCESS
   |
   +------> FAILURE
             |
             v
       Payment Handling
             |
             v
       Customer Retry / Recovery
```

The system should preserve consistency between the payment state and the order state.

---

# 39. Payment Module Responsibilities

The payment module is responsible for:

```text
Payment Integration
        |
        +--> Razorpay communication
        |
        +--> Payment information
        |
        +--> Payment result handling
        |
        +--> Payment persistence
```

It should not become responsible for unrelated functionality such as:

* Product catalog management
* Cart management
* Store management
* Delivery-partner location tracking
* User registration

Those responsibilities belong to their respective modules.

---

# 40. Separation of Concerns

LocalMart follows a layered design:

```text
Controller
    |
    v
Service
    |
    v
Repository
    |
    v
Database
```

For the external payment provider:

```text
Service
    |
    v
RazorpayService
    |
    v
Razorpay
```

This keeps external integration logic isolated.

---

# 41. Payment Security Model

The security model can be summarized as:

```text
Customer
   |
   v
JWT Authentication
   |
   v
Authorization
   |
   v
Order Ownership
   |
   v
Payment Operation
   |
   v
Backend Validation
   |
   v
Razorpay
```

The client is therefore not treated as the final authority for payment state.

---

# 42. Payment Lifecycle

The conceptual payment lifecycle is:

```text
Checkout
   |
   v
Payment Initiation
   |
   v
Razorpay
   |
   +---------> Payment Success
   |
   +---------> Payment Failure
   |
   v
Backend Processing
   |
   v
Local Payment Record
   |
   v
Order Lifecycle
```

The exact state names and transition logic must follow the implementation in the current payment/order services.

---

# 43. Payment System and LocalMart Modules

The payment system interacts with several modules:

| Module   | Relationship                                 |
| -------- | -------------------------------------------- |
| Customer | Initiates purchase                           |
| Cart     | Provides selected products                   |
| Order    | Provides purchase context                    |
| Address  | Determines delivery destination              |
| Location | Can contribute to delivery-fee calculation   |
| Razorpay | External payment gateway                     |
| Database | Stores LocalMart payment information         |
| Delivery | Processes the order after fulfillment stages |

---

# 44. Design Principles

### External gateway isolation

Razorpay-specific code is isolated in `RazorpayService`.

### Backend authority

Financial state should be validated server-side.

### Persistent payment records

LocalMart maintains its own payment representation.

### Separation of payment and order state

A payment state and an order fulfillment state represent different concepts.

### Secure credentials

Gateway credentials remain server-side and outside source control.

### Role-based access

Protected payment/order operations use the application's authentication and authorization architecture.

### Failure awareness

The system must account for gateway failures, network failures, retries, and database failures.

---

# 45. Summary

The LocalMart Payment System provides the financial-processing layer between checkout and order fulfillment.

The central flow is:

```text
Customer
   |
   v
Cart
   |
   v
Checkout
   |
   v
Order
   |
   v
Payment
   |
   v
Razorpay
   |
   v
Payment Result
   |
   v
LocalMart Backend
   |
   +--> Payment
   |
   +--> Order
   |
   v
PostgreSQL
```

The major payment components are:

```text
RazorpayService
Payment
PaymentRepository
```

The payment system is intentionally separated from the order and delivery systems:

```text
                  ORDER
                    |
          +---------+---------+
          |                   |
          v                   v
       PAYMENT             FULFILLMENT
          |                   |
          v                   v
      RAZORPAY             DELIVERY
```

This architecture allows LocalMart to integrate with an external payment provider while retaining control over its own order, payment, and fulfillment data.
