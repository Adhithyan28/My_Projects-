# LocalMart — Configuration and Environment

## 1. Overview

LocalMart uses environment-specific configuration to control how the backend connects to external services, the database, authentication components, and the application runtime.

The purpose of configuration management is to keep environment-dependent values separate from application business logic.

Examples of environment-dependent values include:

* Database connection information
* Database username and password
* Server port
* JWT-related configuration
* Google OAuth configuration
* X OAuth configuration
* Email/SMTP configuration
* Message Central credentials
* Razorpay credentials
* Geocoding service configuration
* Other external-service credentials

The LocalMart backend is built using **Spring Boot**, which provides the configuration mechanism used by the application.

---

# 2. Backend Runtime Environment

The current LocalMart backend environment uses:

| Component                                  | Configuration               |
| ------------------------------------------ | --------------------------- |
| Programming language                       | Java 21                     |
| Backend framework                          | Spring Boot 4.1.1           |
| Build tool                                 | Maven                       |
| Database                                   | PostgreSQL                  |
| PostgreSQL version used during development | PostgreSQL 18.6             |
| ORM                                        | Hibernate                   |
| Persistence framework                      | Spring Data JPA             |
| Backend server                             | Embedded Tomcat             |
| Backend port                               | 8080                        |
| Frontend development port                  | 5174                        |
| API base URL during local development      | `http://localhost:8080/api` |

The frontend and backend run as separate applications during development.

```text
Browser
   |
   | HTTP
   v
React + Vite
localhost:5174
   |
   | API request
   v
Spring Boot
localhost:8080
   |
   v
PostgreSQL
localmart_db
```

---

# 3. Application Configuration

Spring Boot loads application configuration from the application's configuration files and environment-specific configuration sources.

The LocalMart project contains:

```text
src/
└── main/
    └── resources/
        └── application.properties
```

The `application.properties` file is therefore an important configuration entry point for the backend.

Configuration values are used by Spring Boot to initialize components such as:

* DataSource
* JPA/Hibernate
* Embedded server
* Mail services
* Application-specific services
* External integrations
* Security-related components

---

# 4. Database Configuration

LocalMart uses PostgreSQL as its persistent database.

The backend needs database configuration containing values such as:

```text
Database URL
Database username
Database password
JDBC driver configuration
```

Conceptually:

```text
Spring Boot
     |
     | Database configuration
     v
DataSource
     |
     | JDBC
     v
PostgreSQL
     |
     v
localmart_db
```

The application does not directly communicate with PostgreSQL from controllers.

The persistence path is:

```text
Controller
    ↓
Service
    ↓
Repository
    ↓
Spring Data JPA
    ↓
Hibernate
    ↓
JDBC
    ↓
PostgreSQL
```

This separation allows database configuration to change without changing controller or service business logic.

---

# 5. Database Schema Validation

LocalMart uses:

```text
spring.jpa.hibernate.ddl-auto=validate
```

The `validate` setting is important because Hibernate checks whether the database schema is compatible with the JPA entity mappings.

It does **not** automatically create or modify the database schema.

Conceptually:

```text
Application starts
       ↓
Hibernate reads entity mappings
       ↓
Hibernate checks PostgreSQL schema
       ↓
Schema compatible?
     /       \
   YES        NO
   ↓          ↓
Startup     Startup
continues   failure
```

This helps prevent accidental schema modification by the application.

It also means that database tables and columns must be prepared correctly before the application starts.

---

# 6. Server Configuration

The LocalMart backend runs on port:

```text
8080
```

Therefore, during local development the backend is accessed through:

```text
http://localhost:8080
```

The API endpoints are exposed under:

```text
/api
```

For example:

```text
http://localhost:8080/api/users/login
```

The frontend development server runs separately, normally on:

```text
http://localhost:5174
```

Therefore:

```text
Frontend
http://localhost:5174

Backend
http://localhost:8080
```

The two applications communicate using HTTP requests.

---

# 7. Frontend Environment Configuration

The LocalMart frontend uses Vite.

Vite supports environment variables using the `VITE_` prefix.

For example:

```text
VITE_GOOGLE_CLIENT_ID
```

The Google login implementation uses:

```text
VITE_GOOGLE_CLIENT_ID
```

to configure Google Identity Services on the frontend.

Conceptually:

```text
.env
   |
   | VITE_GOOGLE_CLIENT_ID
   v
Vite
   |
   v
React application
   |
   v
Google Sign-In component
```

Only variables intended to be exposed to browser-side code should use the `VITE_` prefix.

---

# 8. Secrets and Sensitive Configuration

LocalMart integrates with services that require credentials.

Examples include:

* Database password
* Google OAuth configuration
* X OAuth configuration
* Message Central credentials
* Razorpay credentials
* SMTP credentials
* Other API credentials

These values should not be hardcoded into Java source code or committed to a public Git repository.

A safer configuration model is:

```text
Environment variable
        ↓
Spring Boot configuration
        ↓
Service
        ↓
External API
```

For frontend configuration:

```text
Environment variable
        ↓
Vite
        ↓
React application
```

---

# 9. `.env` Files

For frontend development, environment-specific values can be stored in files such as:

```text
.env
.env.local
.env.development
.env.production
```

For example:

```text
VITE_GOOGLE_CLIENT_ID=...
```

The actual secret/value should depend on the environment.

Sensitive local configuration files should be excluded from Git when appropriate.

A common `.gitignore` strategy is to prevent local environment files containing credentials from being committed.

---

# 10. Backend Environment Variables

Spring Boot can obtain configuration values from environment variables.

For example, instead of putting a database password directly into a configuration file, the application can receive it from the environment.

Conceptually:

```text
Operating System
       |
       | DB_PASSWORD
       v
Spring Boot
       |
       v
DataSource
       |
       v
PostgreSQL
```

This allows the same application build to run in different environments.

For example:

```text
Development
    ↓
Development database

Testing
    ↓
Test database

Production
    ↓
Production database
```

The Java application does not need to be rewritten for each environment.

---

# 11. External Service Configuration

LocalMart communicates with several external systems.

The configuration for each integration generally contains:

| Integration              | Purpose                                     |
| ------------------------ | ------------------------------------------- |
| Google Identity Services | Google authentication                       |
| X OAuth                  | X authentication                            |
| Message Central          | SMS OTP                                     |
| Message Central WhatsApp | WhatsApp-based authentication/TOTP delivery |
| Gmail SMTP               | Email delivery                              |
| Razorpay                 | Payment processing                          |
| OSRM                     | Road-distance and route information         |
| Geocoding service        | Address/location conversion                 |

These services should be configured independently from the application's core business logic.

For example:

```text
OrderService
     |
     v
RazorpayService
     |
     v
Razorpay
```

The payment logic is therefore separated from the controller.

Similarly:

```text
Delivery / Location logic
          |
          v
RoadDistanceService
          |
          v
OSRM
```

---

# 12. Email Configuration

LocalMart uses email delivery for authentication-related functionality.

The backend contains:

```text
EmailService
```

The service communicates with an SMTP mail provider.

The conceptual flow is:

```text
User requests OTP
       ↓
Controller
       ↓
Service
       ↓
EmailService
       ↓
SMTP server
       ↓
User's email inbox
```

SMTP configuration contains environment-dependent values such as:

* SMTP host
* SMTP port
* SMTP username
* SMTP password
* Authentication settings
* TLS/security settings

These credentials should not be committed to a public repository.

---

# 13. SMS Configuration

LocalMart contains a Message Central integration for SMS OTP delivery.

The backend contains:

```text
MessageCentralOtpService
```

and the SMS OTP module contains:

```text
SmsOtpController
SmsOtpFlowService
SmsOtpSendRequest
SmsOtpVerifyRequest
SmsOtpSession
```

The configuration concept is:

```text
LocalMart
    ↓
MessageCentralOtpService
    ↓
Message Central
    ↓
SMS
    ↓
User
```

Message Central credentials and service-specific configuration should be supplied through environment-specific configuration rather than hardcoded values.

---

# 14. Authentication Configuration

LocalMart uses several authentication mechanisms.

These include:

* Password authentication
* Email OTP
* SMS OTP
* TOTP
* Google authentication
* X authentication
* JWT-based authentication
* User sessions

Security-related configuration may include:

```text
JWT secret/key configuration
JWT expiration configuration
OAuth client configuration
OTP configuration
TOTP configuration
Session-related configuration
```

Authentication configuration should be separated from authentication business logic.

For example:

```text
Configuration
      ↓
JwtService
      ↓
JWT generation / validation
```

and:

```text
Configuration
      ↓
Google/X authentication services
      ↓
External identity provider
```

---

# 15. JWT Configuration

LocalMart uses JSON Web Tokens for authenticated API requests.

The authentication flow is:

```text
Login
  ↓
UserService
  ↓
UserSessionService
  ↓
JwtService
  ↓
JWT generated
  ↓
Frontend
  ↓
Authorization: Bearer <token>
  ↓
JwtAuthenticationFilter
  ↓
SecurityContext
```

JWT-related configuration should be treated as security-sensitive.

The signing secret or key must not be publicly exposed.

If a JWT signing secret is compromised, an attacker could potentially create forged tokens depending on the signing configuration.

---

# 16. CORS Configuration

LocalMart has a dedicated:

```text
CorsConfig
```

class.

CORS controls which browser origins are allowed to communicate with the backend.

During development, the frontend and backend use different origins:

```text
Frontend:
http://localhost:5174

Backend:
http://localhost:8080
```

Therefore, the backend must allow the frontend origin when browser-based API requests are made.

Conceptually:

```text
Browser
   |
   | Origin: http://localhost:5174
   v
Spring Boot
   |
   | CORS validation
   v
Request allowed / rejected
```

CORS is different from authentication.

```text
CORS
→ Controls browser cross-origin access

Authentication
→ Determines who the user is

Authorization
→ Determines what the authenticated user can access
```

---

# 17. Google Configuration

Google authentication requires client configuration.

The backend contains:

```text
GoogleAuthProperties
GoogleTokenVerificationService
```

The frontend uses:

```text
VITE_GOOGLE_CLIENT_ID
```

The overall configuration relationship is:

```text
Google configuration
       ↓
Frontend Google Sign-In
       ↓
Google credential
       ↓
Backend
       ↓
GoogleTokenVerificationService
       ↓
Google token verification
       ↓
LocalMart authentication
```

The Google client identifier used by the frontend and the backend verification configuration must correspond to the intended Google application.

---

# 18. X OAuth Configuration

LocalMart also contains X authentication configuration.

The backend contains:

```text
XAuthProperties
XOAuthController
XOAuthService
```

X-specific configuration is environment dependent and should be supplied through configuration rather than embedded directly into application logic.

Conceptually:

```text
X OAuth configuration
        ↓
XOAuthService
        ↓
X
        ↓
Authenticated X identity
        ↓
LocalMart user
```

OAuth credentials must be protected because they identify the application's integration with the external provider.

---

# 19. Razorpay Configuration

LocalMart uses Razorpay for payment processing.

The backend contains:

```text
RazorpayService
Payment
```

The conceptual configuration flow is:

```text
Razorpay credentials/configuration
             ↓
      RazorpayService
             ↓
         Razorpay
             ↓
       Payment processing
```

Payment credentials should never be exposed through frontend source code unless a particular public identifier is explicitly intended for browser use.

Private payment credentials belong on the backend.

---

# 20. Location Service Configuration

LocalMart uses location-related services for address and delivery functionality.

The backend contains:

```text
GeocodingService
RoadDistanceService
LocationController
```

Two different concepts are involved.

### Geocoding

Converts between addresses and geographic coordinates.

```text
Address
   ↓
Geocoding service
   ↓
Latitude / Longitude
```

Reverse direction:

```text
Latitude / Longitude
   ↓
Geocoding service
   ↓
Address information
```

### Routing

Determines road distance and travel duration.

```text
Store coordinates
       +
Customer coordinates
       ↓
RoadDistanceService
       ↓
OSRM
       ↓
Road distance / duration
```

The browser's:

```text
navigator.geolocation.getCurrentPosition()
```

is different from both of these services.

It is a browser-provided Web API used to obtain the device's location, subject to browser permission.

---

# 21. Environment Separation

LocalMart should maintain separate configurations for different environments.

A typical environment model is:

```text
Development
    ↓
Local machine
    ↓
localhost services

Testing
    ↓
Test environment
    ↓
Isolated test database/services

Production
    ↓
Deployment environment
    ↓
Production database/services
```

The same application code can be deployed to multiple environments while changing configuration values.

For example:

| Configuration   | Development                    | Production                    |
| --------------- | ------------------------------ | ----------------------------- |
| Database        | Local PostgreSQL               | Production PostgreSQL         |
| Backend host    | localhost                      | Production host               |
| Frontend origin | localhost:5174                 | Production domain             |
| Payment mode    | Test configuration             | Production configuration      |
| OAuth           | Development credentials        | Production credentials        |
| Email           | Development SMTP configuration | Production SMTP configuration |
| External APIs   | Development/test configuration | Production configuration      |

The exact production values should be supplied during deployment rather than stored in source code.

---

# 22. Configuration vs Application Logic

A major design principle in LocalMart is separating **configuration** from **business logic**.

For example, this is configuration:

```text
Database URL
Database password
JWT secret
Google client ID
SMTP credentials
Razorpay credentials
```

Whereas this is business logic:

```text
A blocked account cannot log in.

A store owner requires admin approval.

An order must belong to the authenticated customer.

A delivery partner must follow the delivery status lifecycle.
```

The difference is:

```text
Configuration
→ Changes between environments

Business logic
→ Defines how LocalMart operates
```

This separation makes the application easier to deploy and maintain.

---

# 23. Configuration Flow

The general backend configuration flow is:

```text
Operating System / Environment
             |
             v
     Environment Variables
             |
             v
      Spring Boot Config
             |
             v
       Application Beans
             |
             v
      Services / Security
             |
             v
       External Systems
```

For database access:

```text
Environment
    ↓
Database configuration
    ↓
Spring DataSource
    ↓
Hibernate
    ↓
PostgreSQL
```

For authentication:

```text
Environment
    ↓
Security configuration
    ↓
JwtService / authentication services
    ↓
Authentication flow
```

For external APIs:

```text
Environment
    ↓
API credentials/configuration
    ↓
Integration service
    ↓
External provider
```

---

# 24. Local Development Startup

A typical LocalMart development environment contains:

```text
┌──────────────────────────────┐
│        PostgreSQL            │
│        localmart_db          │
└──────────────┬───────────────┘
               │
               │ JDBC
               ▼
┌──────────────────────────────┐
│       Spring Boot Backend    │
│       localhost:8080         │
└──────────────┬───────────────┘
               │
               │ HTTP API
               ▼
┌──────────────────────────────┐
│       React + Vite           │
│       localhost:5174         │
└──────────────┬───────────────┘
               │
               ▼
             Browser
```

External integrations are connected from the backend or browser according to their intended architecture.

---

# 25. Configuration Security Rules

The following rules should be followed when preparing LocalMart for GitHub or production.

### Rule 1 — Do not commit secrets

Never commit:

```text
Database passwords
JWT secrets
SMTP passwords
API private keys
OAuth client secrets
Payment secret keys
Message Central credentials
```

### Rule 2 — Use environment variables

Sensitive configuration should be supplied through the deployment environment.

### Rule 3 — Separate development and production credentials

Development credentials should not automatically be reused in production.

### Rule 4 — Rotate compromised credentials

If a credential is accidentally exposed, it should be revoked or rotated.

### Rule 5 — Keep public and private configuration separate

Some identifiers are intentionally public, while secrets must remain backend-only.

### Rule 6 — Do not trust frontend secrecy

Anything bundled into browser JavaScript should be considered potentially visible to users.

---

# 26. GitHub Considerations

Before pushing LocalMart to GitHub, the repository should be checked for sensitive configuration.

Potentially sensitive files include:

```text
.env
.env.local
application-local.properties
credentials files
private keys
API secret files
```

The repository should contain configuration templates where useful, rather than actual secrets.

For example:

```text
.env.example
```

can document the required variables without containing real credentials.

Conceptually:

```text
.env.example
    ↓
Documents required configuration

.env
    ↓
Contains actual local values
    ↓
Excluded from Git
```

This makes it easier for another developer to understand how to configure the project without exposing credentials.

---

# 27. Configuration Checklist

Before running LocalMart, verify:

### Backend

* [ ] Java 21 is available.
* [ ] Maven/Maven Wrapper is available.
* [ ] PostgreSQL is running.
* [ ] `localmart_db` exists.
* [ ] Database credentials are correct.
* [ ] Database schema matches JPA entities.
* [ ] `ddl-auto=validate` succeeds.
* [ ] Backend port is available.
* [ ] Required external-service configuration is present.

### Frontend

* [ ] Node.js/npm is available.
* [ ] Dependencies are installed.
* [ ] Vite configuration is valid.
* [ ] Required `VITE_` variables are present.
* [ ] Frontend port is available.
* [ ] Backend API is reachable.

### Security

* [ ] JWT configuration is present.
* [ ] OAuth configuration is correct.
* [ ] SMTP credentials are protected.
* [ ] Message Central credentials are protected.
* [ ] Razorpay secrets are protected.
* [ ] Environment files containing secrets are excluded from Git.

---

# 28. Production Configuration Principles

Before deploying LocalMart to production, configuration should be reviewed independently from development settings.

Important production considerations include:

* Production database credentials
* Secure database connectivity
* Production frontend origin
* CORS configuration
* HTTPS
* JWT secret management
* OAuth redirect configuration
* Payment production/test mode
* SMTP configuration
* SMS/WhatsApp provider configuration
* External API credentials
* Logging configuration
* Rate limiting
* Secret rotation
* Database backup strategy

The production deployment should use environment-specific configuration rather than modifying business logic.

---

# 29. Configuration Architecture Summary

LocalMart follows the general principle:

```text
                    CONFIGURATION
                         |
          ┌──────────────┼──────────────┐
          ↓              ↓              ↓
       Database       Security      Integrations
          |              |              |
          ↓              ↓              ↓
      PostgreSQL      JWT/OAuth      APIs/SMTP
```

The application itself remains responsible for business rules:

```text
Configuration
      ↓
Infrastructure setup
      ↓
Application services
      ↓
Business rules
      ↓
Controllers / APIs
```

This separation allows LocalMart to move from local development to testing and production without rewriting the application's core functionality.

---

# 30. Key Takeaways

LocalMart's configuration architecture provides the foundation for running the same application across different environments.

The key principles are:

1. **Spring Boot manages backend application configuration.**
2. **PostgreSQL configuration controls database connectivity.**
3. **Hibernate uses `ddl-auto=validate` to validate the existing schema.**
4. **Frontend configuration uses Vite environment variables where required.**
5. **Authentication and external-service credentials must be protected.**
6. **CORS configuration connects the browser frontend with the backend origin.**
7. **External integrations are configured separately from business logic.**
8. **Development, testing, and production should use separate environment-specific values.**
9. **Secrets should not be committed to GitHub.**
10. **Configuration changes between environments; business rules should remain in application code.**

The resulting architecture is:

```text
                Environment
                    |
                    v
             Configuration
                    |
       ┌────────────┼────────────┐
       ↓            ↓            ↓
   Database      Security     External APIs
       |            |            |
       └────────────┼────────────┘
                    ↓
              Spring Boot
                    |
          ┌─────────┼─────────┐
          ↓         ↓         ↓
     Controllers  Services  Security
                    |
                    ↓
              Repositories
                    |
                    ↓
               PostgreSQL
```

This configuration model provides the separation required to operate LocalMart safely across development, testing, and production environments.
