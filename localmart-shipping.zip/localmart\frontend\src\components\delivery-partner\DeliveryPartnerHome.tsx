import { useEffect, useState } from "react"
import { useAuth } from "../../context/AuthContext"

import {
    MapContainer,
    Marker,
    Popup,
    TileLayer,
    useMap,
} from "react-leaflet"

import L from "leaflet"

import "leaflet/dist/leaflet.css"

import {
    useDeliveryPartnerLocation,
} from "../../context/DeliveryPartnerLocationContext"


interface MapUpdaterProps {

    latitude: number
    longitude: number

}


function MapUpdater({
                        latitude,
                        longitude,
                    }: MapUpdaterProps) {

    const map =
        useMap()


    useEffect(() => {

        map.setView(
            [latitude, longitude],
            map.getZoom()
        )

    }, [
        latitude,
        longitude,
        map,
    ])


    return null

}


const deliveryIcon =
    L.icon({

        iconUrl:
            "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png",

        shadowUrl:
            "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png",

        iconSize: [25, 41],

        iconAnchor: [12, 41],

        popupAnchor: [1, -34],

        shadowSize: [41, 41],

    })


function DeliveryPartnerHome() {

    const { user } =
        useAuth()


    const {

        latitude,

        longitude,

        gpsStatus,

        availabilityStatus,

        goOnline,

        goOffline,

    } =
        useDeliveryPartnerLocation()


    const [loading, setLoading] =
        useState(false)


    const [message, setMessage] =
        useState("")


    /*
     * =============================================================
     * GO ONLINE
     * =============================================================
     */

    const handleGoOnline =
        async () => {

            setLoading(true)

            setMessage("")


            const success =
                await goOnline()


            if (success) {

                setMessage(
                    "You are now online and available for deliveries."
                )

            } else {

                setMessage(
                    "Unable to go online."
                )

            }


            setLoading(false)

        }


    /*
     * =============================================================
     * GO OFFLINE
     * =============================================================
     */

    const handleGoOffline =
        async () => {

            setLoading(true)

            setMessage("")


            const success =
                await goOffline()


            if (success) {

                setMessage(
                    "You are now offline. No new deliveries will be assigned."
                )

            }


            setLoading(false)

        }


    const isOnline =
        availabilityStatus === "AVAILABLE"


    return (

        <div className="delivery-home">


            {/* =====================================================
                    HEADER
                ===================================================== */}

            <div className="delivery-home-header">

                <div className="delivery-home-header-content">

                    <span className="delivery-home-eyebrow">
                        Dashboard
                    </span>

                    <h1>
                        Welcome back
                    </h1>

                    <p className="delivery-home-email">
                        {user?.email || "Delivery Partner"}
                    </p>

                </div>


                <div
                    className={
                        isOnline
                            ? "delivery-status online"
                            : "delivery-status offline"
                    }
                >

                    <span className="delivery-status-dot"></span>

                    {isOnline
                        ? "ONLINE"
                        : "OFFLINE"}

                </div>

            </div>


            {/* =====================================================
                    AVAILABILITY
                ===================================================== */}

            <div className="delivery-online-card">

                <div>

                    <h2>
                        Delivery availability
                    </h2>

                    <p>

                        {isOnline

                            ? "You are available to receive new delivery tasks."

                            : "You are currently offline and will not receive new delivery tasks."}

                    </p>

                </div>


                <button
                    type="button"

                    className={
                        isOnline
                            ? "delivery-online-button offline-button"
                            : "delivery-online-button"
                    }

                    onClick={
                        isOnline
                            ? handleGoOffline
                            : handleGoOnline
                    }

                    disabled={loading}
                >

                    {loading

                        ? "Please wait..."

                        : isOnline
                            ? "Go Offline"
                            : "Go Online"}

                </button>

            </div>


            {/* =====================================================
                    MESSAGE
                ===================================================== */}

            {message && (

                <div className="delivery-message">

                    {message}

                </div>

            )}


            {/* =====================================================
                    STATUS CARDS
                ===================================================== */}

            <div className="delivery-dashboard-grid">


                <div className="delivery-info-card">

                    <div className="delivery-card-icon">
                        📍
                    </div>


                    <div>

                        <h3>
                            GPS Status
                        </h3>


                        <p>
                            {gpsStatus}
                        </p>

                    </div>

                </div>


                <div className="delivery-info-card">

                    <div className="delivery-card-icon">
                        🚚
                    </div>


                    <div>

                        <h3>
                            Delivery Status
                        </h3>


                        <p>

                            {isOnline

                                ? "Ready for deliveries"

                                : "Not accepting deliveries"}

                        </p>

                    </div>

                </div>

            </div>


            {/* =====================================================
                    CURRENT LOCATION
                ===================================================== */}

            <div className="delivery-location-card">

                <div className="delivery-location-header">

                    <div>

                        <h2>
                            Current Location
                        </h2>

                        <p>
                            Your live GPS location
                        </p>

                    </div>


                    <span
                        className={
                            isOnline
                                ? "location-indicator active"
                                : "location-indicator"
                        }
                    >

                        {isOnline
                            ? "Live"
                            : "Inactive"}

                    </span>

                </div>


                {latitude !== null &&
                longitude !== null ? (

                    <div className="delivery-home-map-wrapper">

                        <MapContainer
                            center={[
                                latitude,
                                longitude,
                            ]}
                            zoom={15}
                            scrollWheelZoom={true}
                            className="delivery-home-map"
                        >

                            <TileLayer
                                attribution='&copy; OpenStreetMap contributors'
                                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                            />


                            <MapUpdater
                                latitude={latitude}
                                longitude={longitude}
                            />


                            <Marker
                                position={[
                                    latitude,
                                    longitude,
                                ]}
                                icon={deliveryIcon}
                            >

                                <Popup>

                                    <strong>
                                        Your Current Location
                                    </strong>

                                    <br />

                                    Delivery Partner

                                    <br />

                                    {latitude.toFixed(6)},
                                    {" "}
                                    {longitude.toFixed(6)}

                                </Popup>

                            </Marker>

                        </MapContainer>

                    </div>

                ) : (

                    <div className="delivery-no-location">

                        <div>
                            📍
                        </div>


                        <h3>
                            Location not available
                        </h3>


                        <p>
                            Go online to start GPS tracking
                            and display your current location.
                        </p>

                    </div>

                )}


                <div className="delivery-coordinates">

                    <div>

                        <span>
                            Latitude
                        </span>


                        <strong>

                            {latitude !== null

                                ? latitude.toFixed(6)

                                : "--"}

                        </strong>

                    </div>


                    <div>

                        <span>
                            Longitude
                        </span>


                        <strong>

                            {longitude !== null

                                ? longitude.toFixed(6)

                                : "--"}

                        </strong>

                    </div>

                </div>

            </div>


            {/* =====================================================
                    INFORMATION
                ===================================================== */}

            <div className="delivery-info-note">

                <span>
                    ℹ️
                </span>


                <p>

                    You must manually go online before
                    receiving delivery assignments. Your
                    GPS location is shared only while you
                    are online.

                </p>

            </div>


        </div>

    )

}


export default DeliveryPartnerHome