
            package com.localmart.localmartbackend.repository;

    import com.localmart.localmartbackend.entity.User;
    import org.springframework.data.jpa.repository.JpaRepository;
    import org.springframework.stereotype.Repository;

    import org.springframework.data.jpa.repository.Query;
    import org.springframework.data.repository.query.Param;

    import java.util.List;
    import java.util.Optional;



    @Repository
    public interface UserRepository extends JpaRepository<User, Long> {

        boolean existsByEmail(String email);

        boolean existsByPhone(String phone);

        boolean existsByGoogleId(String googleId);

        Optional<User> findByxId(String xId);

        Optional<User> findByEmail(String email);

        Optional<User> findByPhone(String phone);

        Optional<User> findByGoogleId(String googleId);

        long countByAccountStatus(Integer accountStatus);

        List<User> findByAccountStatus(Integer accountStatus);

        @Query(
                value = "SELECT crypt(:password, gen_salt('bf', 12))",
                nativeQuery = true
        )
        String hashPassword(
                @Param("password") String password
        );

        @Query(
                value = """
                SELECT crypt(:password, password) = password
                FROM users
                WHERE user_id = :userId
                """,
                nativeQuery = true
        )
        boolean verifyPassword(
                @Param("userId") Long userId,
                @Param("password") String password
        );
    }
