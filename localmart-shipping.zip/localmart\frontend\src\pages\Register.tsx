
import { useState } from "react"
import GoogleSignInButton from "../components/GoogleSignInButton"

type IdentifierType = "EMAIL" | "MOBILE" | ""

function Register() {

    const [step, setStep] = useState(0)

    // ============================================================
    // VERIFIED IDENTIFIER
    // ============================================================

    const [identifier, setIdentifier] = useState("")
    const [identifierType, setIdentifierType] =
        useState<IdentifierType>("")

    const [registrationToken, setRegistrationToken] =
        useState("")

    const [otp, setOtp] = useState("")


    // ============================================================
    // ACCOUNT DETAILS
    // ============================================================

    const [role, setRole] = useState("")

    const [email, setEmail] = useState("")
    const [password, setPassword] = useState("")
    const [showPassword, setShowPassword] = useState(false)


    // ============================================================
    // PERSONAL DETAILS
    // ============================================================

    const [fullName, setFullName] = useState("")
    const [ownerName, setOwnerName] = useState("")
    const [phone, setPhone] = useState("")


    // ============================================================
    // STORE DETAILS
    // ============================================================

    const [businessName, setBusinessName] = useState("")
    const [businessType, setBusinessType] = useState("")
    const [gstNumber, setGstNumber] = useState("")


    // ============================================================
    // DELIVERY PARTNER DETAILS
    // ============================================================

    const [vehicleType, setVehicleType] = useState("")
    const [vehicleNumber, setVehicleNumber] = useState("")
    const [drivingLicenseNumber, setDrivingLicenseNumber] =
        useState("")


    // ============================================================
    // UI
    // ============================================================

    const [message, setMessage] = useState("")
    const [loading, setLoading] = useState(false)


    // ============================================================
    // PASSWORD VALIDATION
    // ============================================================

    const isPasswordValid = () => {

        const value = password

        if (value.length < 8) {
            return false
        }

        if (!/[A-Z]/.test(value)) {
            return false
        }

        if (!/[a-z]/.test(value)) {
            return false
        }

        if (!/[0-9]/.test(value)) {
            return false
        }

        if (!/[^A-Za-z0-9]/.test(value)) {
            return false
        }

        return true
    }


    // ============================================================
    // EMAIL VALIDATION
    // ============================================================

    const isEmailValid = () => {

        const emailRegex =
            /^[^\s@]+@[^\s@]+\.[^\s@]+$/

        return emailRegex.test(
            email.trim()
        )
    }


    // ============================================================
    // PHONE VALIDATION
    // ============================================================

    const isPhoneValid = () => {

        const phoneRegex =
            /^[6-9][0-9]{9}$/

        return phoneRegex.test(
            phone.trim()
        )
    }


    // ============================================================
    // IDENTIFIER DETECTION
    // ============================================================

    const detectIdentifierType = (
        value: string
    ): IdentifierType => {

        const trimmed =
            value.trim()

        const emailRegex =
            /^[^\s@]+@[^\s@]+\.[^\s@]+$/

        const phoneRegex =
            /^[6-9][0-9]{9}$/

        if (emailRegex.test(trimmed)) {
            return "EMAIL"
        }

        if (phoneRegex.test(trimmed)) {
            return "MOBILE"
        }

        return ""
    }


    // ============================================================
    // BACKEND ERROR EXTRACTION
    // ============================================================

    const getErrorMessage = (
        data: any,
        fallback: string
    ) => {

        if (typeof data === "string") {

            return data || fallback
        }

        if (data?.message) {

            return data.message
        }

        if (data?.error) {

            return data.error
        }

        return fallback
    }


    // ============================================================
    // STEP 0 - SEND NORMAL REGISTRATION OTP
    // ============================================================

    const handleIdentifierNext = async () => {

        const value =
            identifier.trim()

        if (!value) {

            setMessage(
                "Please enter your email address or mobile number"
            )

            return
        }


        const detectedType =
            detectIdentifierType(value)


        if (!detectedType) {

            setMessage(
                "Please enter a valid email address or 10-digit Indian mobile number"
            )

            return
        }


        setLoading(true)
        setMessage("")


        try {

            const response =
                await fetch(
                    "http://localhost:8080/api/users/register/send-otp",
                    {
                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/json"
                        },

                        body: JSON.stringify({
                            identifier:
                                value
                        })
                    }
                )


            const contentType =
                response.headers.get(
                    "content-type"
                )


            let data: any


            if (
                contentType &&
                contentType.includes(
                    "application/json"
                )
            ) {

                data =
                    await response.json()

            } else {

                data =
                    await response.text()
            }


            if (!response.ok) {

                throw new Error(
                    getErrorMessage(
                        data,
                        "Failed to send verification OTP"
                    )
                )
            }


            setIdentifier(value)

            setIdentifierType(
                detectedType
            )

            setOtp("")

            setMessage(
                detectedType === "EMAIL"
                    ? "Verification OTP sent to your email"
                    : "Verification OTP sent to your mobile number"
            )

            setStep(1)


        } catch (error) {

            console.error(
                "Registration OTP error:",
                error
            )


            if (error instanceof Error) {

                setMessage(
                    error.message
                )

            } else {

                setMessage(
                    "Failed to send verification OTP"
                )
            }


        } finally {

            setLoading(false)
        }
    }


    // ============================================================
    // STEP 0 - GOOGLE REGISTRATION
    // ============================================================

    const handleGoogleRegister = async (
        credential: string
    ) => {

        setLoading(true)
        setMessage("")


        try {

            const response =
                await fetch(
                    "http://localhost:8080/api/users/google/register",
                    {
                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/json"
                        },

                        body: JSON.stringify({
                            credential:
                                credential
                        })
                    }
                )


            const contentType =
                response.headers.get(
                    "content-type"
                )


            let data: any


            if (
                contentType &&
                contentType.includes(
                    "application/json"
                )
            ) {

                data =
                    await response.json()

            } else {

                data =
                    await response.text()
            }


            if (!response.ok) {

                throw new Error(
                    getErrorMessage(
                        data,
                        "Google registration failed"
                    )
                )
            }


            if (
                !data?.registrationToken
            ) {

                throw new Error(
                    "Google registration verification token was not received."
                )
            }


            setRegistrationToken(
                data.registrationToken
            )


            const googleEmail =
                data.email ||
                data.identifier ||
                ""


            setEmail(
                googleEmail
            )


            setIdentifier(
                googleEmail
            )


            setIdentifierType(
                "EMAIL"
            )


            const googleName =
                data.name ||
                [
                    data.firstName,
                    data.lastName
                ]
                    .filter(Boolean)
                    .join(" ")


            if (googleName) {

                setFullName(
                    googleName
                )

                setOwnerName(
                    googleName
                )
            }


            setOtp("")

            setMessage(
                "Google account verified successfully. Please complete your registration."
            )


            setStep(2)


        } catch (error) {

            console.error(
                "Google registration error:",
                error
            )


            if (error instanceof Error) {

                setMessage(
                    error.message
                )

            } else {

                setMessage(
                    "Google registration failed. Please try again."
                )
            }


        } finally {

            setLoading(false)
        }
    }


    // ============================================================
    // STEP 0 - X REGISTRATION
    // ============================================================

    const handleXRegister = () => {

        setLoading(true)
        setMessage("")


        const X_OAUTH_ORIGIN =
            "http://localhost:8080"

        let messageHandled = false
        let popupCheckInterval: number | undefined


        const cleanup = () => {

            window.removeEventListener(
                "message",
                handleXMessage
            )

            if (
                popupCheckInterval !== undefined
            ) {

                window.clearInterval(
                    popupCheckInterval
                )

                popupCheckInterval =
                    undefined
            }
        }


        const handleXMessage = (
            event: MessageEvent
        ) => {

            /*
             * The callback page is served by the
             * Spring Boot backend on localhost:8080.
             *
             * Therefore we verify the sender origin
             * against localhost:8080.
             */

            if (
                event.origin !==
                X_OAUTH_ORIGIN
            ) {

                return
            }


            const data =
                event.data


            // ====================================================
            // X REGISTRATION SUCCESS
            // ====================================================

            if (
                data?.type ===
                "X_REGISTER_SUCCESS"
            ) {

                messageHandled = true

                cleanup()


                const registrationData =
                    data.data


                if (
                    !registrationData?.registrationToken
                ) {

                    setLoading(false)

                    setMessage(
                        "X registration verification token was not received."
                    )

                    return
                }


                // ------------------------------------------------
                // REGISTRATION TOKEN
                // ------------------------------------------------

                setRegistrationToken(
                    registrationData.registrationToken
                )


                // ------------------------------------------------
                // X EMAIL
                // ------------------------------------------------

                const xEmail =
                    registrationData.email ||
                    registrationData.identifier ||
                    ""


                if (xEmail) {

                    setEmail(
                        xEmail
                    )

                    setIdentifier(
                        xEmail
                    )

                    setIdentifierType(
                        "EMAIL"
                    )
                }


                // ------------------------------------------------
                // X NAME
                // ------------------------------------------------

                const xName =
                    registrationData.name ||
                    [
                        registrationData.firstName,
                        registrationData.lastName
                    ]
                        .filter(Boolean)
                        .join(" ")


                if (xName) {

                    setFullName(
                        xName
                    )

                    setOwnerName(
                        xName
                    )
                }


                setOtp("")

                setLoading(false)

                setMessage(
                    "X account verified successfully. Please complete your registration."
                )


                /*
                 * X has already verified the identity,
                 * so we skip the normal OTP step.
                 *
                 * Continue directly to:
                 *
                 * STEP 2 - Account Details
                 */

                setStep(2)

                return
            }


            // ====================================================
            // X REGISTRATION ERROR
            // ====================================================

            if (
                data?.type ===
                "X_AUTH_ERROR"
            ) {

                messageHandled = true

                cleanup()

                setLoading(false)

                setMessage(
                    data.message ||
                    "X registration failed. Please try again."
                )

                return
            }
        }


        window.addEventListener(
            "message",
            handleXMessage
        )


        // ========================================================
        // OPEN X REGISTRATION POPUP
        // ========================================================

        const popup =
            window.open(
                "/api/users/x/register",
                "localmart-x-register",
                "width=500,height=700,resizable=yes,scrollbars=yes"
            )


        if (!popup) {

            cleanup()

            setLoading(false)

            setMessage(
                "Please allow popups in your browser to continue with X."
            )

            return
        }


        // ========================================================
        // CHECK WHETHER POPUP WAS CLOSED
        // ========================================================

        popupCheckInterval =
            window.setInterval(() => {

                if (popup.closed) {

                    window.clearInterval(
                        popupCheckInterval
                    )

                    popupCheckInterval =
                        undefined

                    cleanup()


                    if (!messageHandled) {

                        setLoading(false)

                        setMessage(
                            "X registration was cancelled or the authentication window closed before LocalMart received the result."
                        )
                    }
                }

            }, 500)
    }


    // ============================================================
    // STEP 1 - NORMAL OTP VERIFICATION
    // ============================================================

    const handleOtpVerification = async () => {

        if (!otp.trim()) {

            setMessage(
                "Please enter the OTP"
            )

            return
        }


        if (otp.trim().length !== 6) {

            setMessage(
                "Please enter a valid 6-digit OTP"
            )

            return
        }


        setLoading(true)
        setMessage("")


        try {

            const response =
                await fetch(
                    "http://localhost:8080/api/users/register/verify-otp",
                    {
                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/json"
                        },

                        body: JSON.stringify({
                            login:
                                identifier.trim(),

                            otp:
                                otp.trim()
                        })
                    }
                )


            const contentType =
                response.headers.get(
                    "content-type"
                )


            let data: any


            if (
                contentType &&
                contentType.includes(
                    "application/json"
                )
            ) {

                data =
                    await response.json()

            } else {

                data =
                    await response.text()
            }


            if (!response.ok) {

                throw new Error(
                    getErrorMessage(
                        data,
                        "Invalid OTP"
                    )
                )
            }


            if (
                !data?.registrationToken
            ) {

                throw new Error(
                    "Registration verification token was not received."
                )
            }


            setRegistrationToken(
                data.registrationToken
            )


            if (
                data.identifier
            ) {

                setIdentifier(
                    data.identifier
                )
            }


            if (
                data.identifierType ===
                "EMAIL"
            ) {

                setIdentifierType(
                    "EMAIL"
                )

                setEmail(
                    data.identifier ||
                    identifier.trim()
                )

            } else if (
                data.identifierType ===
                "MOBILE"
            ) {

                setIdentifierType(
                    "MOBILE"
                )

                setPhone(
                    data.identifier ||
                    identifier.trim()
                )
            }


            setOtp("")


            setMessage(
                data.identifierType === "EMAIL"
                    ? "Email verified successfully"
                    : "Mobile number verified successfully"
            )


            setStep(2)


        } catch (error) {

            console.error(
                "OTP verification error:",
                error
            )


            if (error instanceof Error) {

                setMessage(
                    error.message
                )

            } else {

                setMessage(
                    "OTP verification failed"
                )
            }


        } finally {

            setLoading(false)
        }
    }


    // ============================================================
    // STEP 2 - ROLE + PASSWORD
    // ============================================================

    const handleAccountDetailsNext = () => {

        if (!role) {

            setMessage(
                "Please select an account type"
            )

            return
        }


        if (!password) {

            setMessage(
                "Please enter a password"
            )

            return
        }


        if (!isPasswordValid()) {

            setMessage(
                "Password must contain at least 8 characters, one uppercase letter, one lowercase letter, one number and one special character"
            )

            return
        }


        setMessage("")


        if (
            role === "DELIVERY_PARTNER"
        ) {

            setStep(4)

        } else {

            setStep(3)
        }
    }


    // ============================================================
    // STEP 3 - CUSTOMER / STORE OWNER DETAILS
    // ============================================================

    const handlePersonalDetailsNext = () => {

        if (
            role === "CUSTOMER"
        ) {

            if (!fullName.trim()) {

                setMessage(
                    "Please enter your full name"
                )

                return
            }
        }


        if (
            role === "STORE_OWNER"
        ) {

            if (!ownerName.trim()) {

                setMessage(
                    "Please enter the owner name"
                )

                return
            }


            if (!businessName.trim()) {

                setMessage(
                    "Please enter the business name"
                )

                return
            }


            if (!businessType.trim()) {

                setMessage(
                    "Please enter the business type"
                )

                return
            }
        }


        if (
            identifierType === "EMAIL"
        ) {

            if (!phone.trim()) {

                setMessage(
                    "Please enter your phone number"
                )

                return
            }


            if (!isPhoneValid()) {

                setMessage(
                    "Please enter a valid 10-digit Indian mobile number"
                )

                return
            }
        }


        setMessage("")
        setStep(6)
    }


    // ============================================================
    // STEP 4 - DELIVERY PARTNER PERSONAL DETAILS
    // ============================================================

    const handleDeliveryPersonalNext = () => {

        if (!fullName.trim()) {

            setMessage(
                "Please enter your full name"
            )

            return
        }


        if (
            identifierType === "EMAIL"
        ) {

            if (!phone.trim()) {

                setMessage(
                    "Please enter your phone number"
                )

                return
            }


            if (!isPhoneValid()) {

                setMessage(
                    "Please enter a valid 10-digit Indian mobile number"
                )

                return
            }
        }


        setMessage("")
        setStep(5)
    }


    // ============================================================
    // STEP 5 - DELIVERY PARTNER VEHICLE DETAILS
    // ============================================================

    const handleVehicleNext = () => {

        if (!vehicleType.trim()) {

            setMessage(
                "Please enter your vehicle type"
            )

            return
        }


        if (!vehicleNumber.trim()) {

            setMessage(
                "Please enter your vehicle number"
            )

            return
        }


        if (!drivingLicenseNumber.trim()) {

            setMessage(
                "Please enter your driving licence number"
            )

            return
        }


        setMessage("")
        setStep(6)
    }


    // ============================================================
    // STEP 6 - FINAL REGISTRATION
    // ============================================================

    const handleRegister = async () => {

        if (!registrationToken) {

            setMessage(
                "Registration verification is missing. Please verify OTP again."
            )

            return
        }


        if (!email.trim()) {

            setMessage(
                "Please enter your email address"
            )

            return
        }


        if (!isEmailValid()) {

            setMessage(
                "Please enter a valid email address"
            )

            return
        }


        if (!phone.trim()) {

            setMessage(
                "Please enter your phone number"
            )

            return
        }


        if (!isPhoneValid()) {

            setMessage(
                "Please enter a valid 10-digit Indian mobile number"
            )

            return
        }


        setLoading(true)
        setMessage("")


        try {

            const requestBody: any = {

                registrationToken:
                    registrationToken,

                email:
                    email.trim(),

                password:
                    password,

                role:
                    role,

                phone:
                    phone.trim()
            }


            // ====================================================
            // CUSTOMER
            // ====================================================

            if (
                role === "CUSTOMER"
            ) {

                requestBody.fullName =
                    fullName.trim()
            }


            // ====================================================
            // STORE OWNER
            // ====================================================

            if (
                role === "STORE_OWNER"
            ) {

                requestBody.ownerName =
                    ownerName.trim()

                requestBody.businessName =
                    businessName.trim()

                requestBody.businessType =
                    businessType.trim()


                if (
                    gstNumber.trim()
                ) {

                    requestBody.gstNumber =
                        gstNumber.trim()
                }
            }


            // ====================================================
            // DELIVERY PARTNER
            // ====================================================

            if (
                role === "DELIVERY_PARTNER"
            ) {

                requestBody.fullName =
                    fullName.trim()

                requestBody.vehicleType =
                    vehicleType.trim()

                requestBody.vehicleNumber =
                    vehicleNumber.trim()

                requestBody.drivingLicenceNumber =
                    drivingLicenseNumber.trim()
            }


            console.log(
                "Registration request:",
                requestBody
            )


            const response =
                await fetch(
                    "http://localhost:8080/api/users/register",
                    {
                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/json"
                        },

                        body: JSON.stringify(
                            requestBody
                        )
                    }
                )


            const contentType =
                response.headers.get(
                    "content-type"
                )


            let data: any


            if (
                contentType &&
                contentType.includes(
                    "application/json"
                )
            ) {

                data =
                    await response.json()

            } else {

                data =
                    await response.text()
            }


            if (!response.ok) {

                throw new Error(
                    getErrorMessage(
                        data,
                        "Registration failed"
                    )
                )
            }


            console.log(
                "Registration successful:",
                data
            )


            setStep(7)


        } catch (error) {

            console.error(
                "Registration error:",
                error
            )


            if (error instanceof Error) {

                setMessage(
                    error.message
                )

            } else {

                setMessage(
                    "Registration failed"
                )
            }


        } finally {

            setLoading(false)
        }
    }


    // ============================================================
    // PREVIOUS BUTTON
    // ============================================================

    const handlePrevious = () => {

        setMessage("")


        if (step === 1) {

            setStep(0)

        } else if (step === 2) {

            setStep(1)

        } else if (step === 3) {

            setStep(2)

        } else if (step === 4) {

            setStep(2)

        } else if (step === 5) {

            setStep(4)

        } else if (step === 6) {

            if (
                role === "DELIVERY_PARTNER"
            ) {

                setStep(5)

            } else {

                setStep(3)
            }

        } else if (step === 7) {

            setStep(6)
        }
    }


    // ============================================================
    // STEP TITLE
    // ============================================================

    const getStepTitle = () => {

        switch (step) {

            case 0:
                return "Email or Mobile Number"

            case 1:
                return identifierType === "MOBILE"
                    ? "Verify Mobile Number"
                    : "Verify Email"

            case 2:
                return "Account Details"

            case 3:
                return role === "STORE_OWNER"
                    ? "Owner Details"
                    : "Customer Details"

            case 4:
                return "Personal Details"

            case 5:
                return "Vehicle Details"

            case 6:
                return "Complete Registration"

            case 7:
                return "Registration Complete"

            default:
                return ""
        }
    }


    // ============================================================
    // NAVIGATION
    // ============================================================

    const renderNavigation = (
        onNext: () => void,
        nextText: string = "Next",
        showPrevious: boolean = true,
        disabled: boolean = false
    ) => {

        return (

            <div
                className="register-navigation"
                style={{
                    display: "flex",
                    justifyContent:
                        showPrevious
                            ? "space-between"
                            : "flex-end",
                    alignItems: "center",
                    gap: "16px",
                    marginTop: "24px",
                    width: "100%"
                }}
            >

                {showPrevious && (

                    <button
                        type="button"
                        className="button secondary-button"
                        onClick={
                            handlePrevious
                        }
                        disabled={
                            disabled
                        }
                        style={{
                            minWidth: "110px",
                            height: "44px"
                        }}
                    >
                        Previous
                    </button>

                )}


                <button
                    type="button"
                    className="button"
                    onClick={onNext}
                    disabled={disabled}
                    style={{
                        minWidth: "110px",
                        height: "44px"
                    }}
                >
                    {nextText}
                </button>

            </div>
        )
    }


    // ============================================================
    // RENDER
    // ============================================================

    return (

        <div className="register-form">

            <h2>
                {step === 7
                    ? "Registration Complete"
                    : "Create your account"
                }
            </h2>


            {step !== 7 && (

                <p className="form-subtitle">
                    {getStepTitle()}
                </p>

            )}


            {/* ================================================== */}
            {/* STEP 0 - EMAIL OR MOBILE */}
            {/* ================================================== */}

            {step === 0 && (

                <div className="form-section">

                    <h3>
                        Create Account
                    </h3>


                    <label>
                        Email or mobile number
                    </label>


                    <input
                        className="input"
                        type="text"
                        placeholder="Enter email or mobile number"
                        value={identifier}
                        onChange={(e) =>
                            setIdentifier(
                                e.target.value
                            )
                        }
                    />


                    <p className="form-subtitle">
                        Enter your email address or
                        10-digit mobile number. We will
                        automatically send the appropriate
                        verification OTP.
                    </p>


                    {renderNavigation(
                        handleIdentifierNext,
                        loading
                            ? "Sending..."
                            : "Continue",
                        false,
                        loading
                    )}


                    {/* =================================================
                            SOCIAL REGISTRATION
                        ================================================= */}

                    <div
                        style={{
                            marginTop: "24px",
                            borderTop: "1px solid #ddd",
                            paddingTop: "20px"
                        }}
                    >

                        <p
                            style={{
                                textAlign: "center",
                                fontSize: "14px",
                                marginBottom: "8px"
                            }}
                        >
                            Or continue with
                        </p>


                        {/* =================================================
                                GOOGLE REGISTRATION
                            ================================================= */}

                        <GoogleSignInButton
                            onCredential={
                                handleGoogleRegister
                            }
                            disabled={
                                loading
                            }
                        />


                        {/* =================================================
        X REGISTRATION
    ================================================= */}

                        <div
                            style={{
                                width:
                                    "240px",
                                height:
                                    "40px",
                                margin:
                                    "12px auto 0",
                                padding:
                                    0,
                                display:
                                    "flex",
                                justifyContent:
                                    "center",
                                alignItems:
                                    "center",
                                boxSizing:
                                    "border-box"
                            }}
                        >

                            <button
                                type="button"
                                onClick={
                                    handleXRegister
                                }
                                disabled={
                                    loading
                                }
                                style={{
                                    width:
                                        "240px",
                                    height:
                                        "40px",
                                    margin:
                                        0,
                                    padding:
                                        0,
                                    border:
                                        "1px solid #dadce0",
                                    borderRadius:
                                        "4px",
                                    background:
                                        "#ffffff",
                                    color:
                                        "#3c4043",
                                    cursor:
                                        loading
                                            ? "not-allowed"
                                            : "pointer",
                                    fontSize:
                                        "14px",
                                    fontWeight:
                                        500,
                                    display:
                                        "flex",
                                    alignItems:
                                        "center",
                                    justifyContent:
                                        "center",
                                    gap:
                                        "8px",
                                    boxSizing:
                                        "border-box",
                                    fontFamily:
                                        "Arial, sans-serif"
                                }}
                            >

        <span
            style={{
                fontSize:
                    "18px",
                fontWeight:
                    700,
                lineHeight:
                    1,
                display:
                    "flex",
                alignItems:
                    "center",
                justifyContent:
                    "center"
            }}
        >
            𝕏
        </span>

                                <span
                                    style={{
                                        lineHeight:
                                            "20px",
                                        display:
                                            "flex",
                                        alignItems:
                                            "center"
                                    }}
                                >
            {loading
                ? "Connecting..."
                : "Register with X"}
        </span>

                            </button>

                        </div>



                    </div>

                </div>
            )}


            {/* ================================================== */}
            {/* STEP 1 - OTP */}
            {/* ================================================== */}

            {step === 1 && (

                <div className="form-section">

                    <h3>
                        {identifierType === "MOBILE"
                            ? "Verify Mobile Number"
                            : "Verify Email"
                        }
                    </h3>


                    <p>
                        A verification OTP has been
                        sent to:
                    </p>


                    <strong>
                        {identifier}
                    </strong>


                    <label>
                        OTP
                    </label>


                    <input
                        className="input"
                        type="text"
                        inputMode="numeric"
                        maxLength={6}
                        placeholder="Enter OTP"
                        value={otp}
                        onChange={(e) =>
                            setOtp(
                                e.target.value
                                    .replace(
                                        /[^0-9]/g,
                                        ""
                                    )
                            )
                        }
                        autoComplete="one-time-code"
                    />


                    <p className="form-subtitle">
                        {identifierType === "MOBILE"
                            ? "The OTP was sent to your mobile number through SMS."
                            : "The OTP was sent to your email address."
                        }
                    </p>


                    {renderNavigation(
                        handleOtpVerification,
                        loading
                            ? "Verifying..."
                            : "Verify & Continue",
                        true,
                        loading
                    )}

                </div>
            )}


            {/* ================================================== */}
            {/* STEP 2 - ACCOUNT DETAILS */}
            {/* ================================================== */}

            {step === 2 && (

                <div className="form-section">

                    <h3>
                        Account Details
                    </h3>


                    <label>
                        Verified identifier
                    </label>


                    <input
                        className="input"
                        type="text"
                        value={identifier}
                        readOnly
                        style={{
                            backgroundColor:
                                "#f3f3f3",
                            cursor: "not-allowed"
                        }}
                    />


                    <p className="form-subtitle">
                        {identifierType === "EMAIL"
                            ? "This email has been verified and cannot be changed during registration."
                            : "This mobile number has been verified and cannot be changed during registration."
                        }
                    </p>


                    <label>
                        Account type
                    </label>


                    <select
                        className="input"
                        value={role}
                        onChange={(e) =>
                            setRole(
                                e.target.value
                            )
                        }
                    >

                        <option value="">
                            Select account type
                        </option>

                        <option value="CUSTOMER">
                            Customer
                        </option>

                        <option value="STORE_OWNER">
                            Store Owner
                        </option>

                        <option value="DELIVERY_PARTNER">
                            Delivery Partner
                        </option>

                    </select>


                    <label>
                        Password
                    </label>


                    <div
                        style={{
                            position: "relative",
                            width: "100%"
                        }}
                    >

                        <input
                            className="input"
                            type={
                                showPassword
                                    ? "text"
                                    : "password"
                            }
                            placeholder="Create a password"
                            value={password}
                            onChange={(e) =>
                                setPassword(
                                    e.target.value
                                )
                            }
                            style={{
                                paddingRight: "48px"
                            }}
                        />


                        <button
                            type="button"
                            onClick={() =>
                                setShowPassword(
                                    !showPassword
                                )
                            }
                            aria-label={
                                showPassword
                                    ? "Hide password"
                                    : "Show password"
                            }
                            style={{
                                position: "absolute",
                                right: "12px",
                                top: "50%",
                                transform:
                                    "translateY(-50%)",
                                border: "none",
                                background:
                                    "transparent",
                                cursor: "pointer",
                                padding: "4px",
                                fontSize: "18px",
                                lineHeight: "1"
                            }}
                        >
                            {showPassword
                                ? "🙈"
                                : "👁️"
                            }
                        </button>

                    </div>


                    <p className="form-subtitle">
                        Password must contain at least 8
                        characters, one uppercase letter,
                        one lowercase letter, one number
                        and one special character.
                    </p>


                    {renderNavigation(
                        handleAccountDetailsNext,
                        "Next",
                        true,
                        loading
                    )}

                </div>
            )}


            {/* ================================================== */}
            {/* STEP 3 - CUSTOMER */}
            {/* ================================================== */}

            {step === 3 &&
                role === "CUSTOMER" && (

                    <div className="form-section">

                        <h3>
                            Customer Details
                        </h3>


                        <label>
                            Full name
                        </label>


                        <input
                            className="input"
                            type="text"
                            placeholder="Enter your full name"
                            value={fullName}
                            onChange={(e) =>
                                setFullName(
                                    e.target.value
                                )
                            }
                        />


                        <label>
                            Phone
                        </label>


                        <input
                            className="input"
                            type="text"
                            inputMode="numeric"
                            placeholder={
                                identifierType === "MOBILE"
                                    ? "Verified mobile number"
                                    : "Enter your 10-digit phone number"
                            }
                            value={phone}
                            onChange={(e) =>
                                setPhone(
                                    e.target.value
                                )
                            }
                            readOnly={
                                identifierType ===
                                "MOBILE"
                            }
                            style={
                                identifierType ===
                                "MOBILE"
                                    ? {
                                        backgroundColor:
                                            "#f3f3f3",
                                        cursor:
                                            "not-allowed"
                                    }
                                    : undefined
                            }
                        />


                        {identifierType ===
                            "MOBILE" && (

                                <p className="form-subtitle">
                                    This mobile number has
                                    already been verified.
                                </p>

                            )}


                        {renderNavigation(
                            handlePersonalDetailsNext,
                            "Continue",
                            true,
                            loading
                        )}

                    </div>
                )}


            {/* ================================================== */}
            {/* STEP 3 - STORE OWNER */}
            {/* ================================================== */}

            {step === 3 &&
                role === "STORE_OWNER" && (

                    <div className="form-section">

                        <h3>
                            Owner Details
                        </h3>


                        <label>
                            Owner name
                        </label>


                        <input
                            className="input"
                            type="text"
                            placeholder="Enter owner name"
                            value={ownerName}
                            onChange={(e) =>
                                setOwnerName(
                                    e.target.value
                                )
                            }
                        />


                        <label>
                            Phone
                        </label>


                        <input
                            className="input"
                            type="text"
                            inputMode="numeric"
                            placeholder={
                                identifierType === "MOBILE"
                                    ? "Verified mobile number"
                                    : "Enter your 10-digit phone number"
                            }
                            value={phone}
                            onChange={(e) =>
                                setPhone(
                                    e.target.value
                                )
                            }
                            readOnly={
                                identifierType ===
                                "MOBILE"
                            }
                            style={
                                identifierType ===
                                "MOBILE"
                                    ? {
                                        backgroundColor:
                                            "#f3f3f3",
                                        cursor:
                                            "not-allowed"
                                    }
                                    : undefined
                            }
                        />


                        {identifierType ===
                            "MOBILE" && (

                                <p className="form-subtitle">
                                    This mobile number has
                                    already been verified.
                                </p>

                            )}


                        <label>
                            Business name
                        </label>


                        <input
                            className="input"
                            type="text"
                            placeholder="Enter your business/store name"
                            value={businessName}
                            onChange={(e) =>
                                setBusinessName(
                                    e.target.value
                                )
                            }
                        />


                        <label>
                            Business type
                        </label>


                        <input
                            className="input"
                            type="text"
                            placeholder="Example: Grocery Store"
                            value={businessType}
                            onChange={(e) =>
                                setBusinessType(
                                    e.target.value
                                )
                            }
                        />


                        <label>
                            GST number
                        </label>


                        <input
                            className="input"
                            type="text"
                            placeholder="Enter GST number (optional)"
                            value={gstNumber}
                            onChange={(e) =>
                                setGstNumber(
                                    e.target.value
                                )
                            }
                        />


                        {renderNavigation(
                            handlePersonalDetailsNext,
                            "Continue",
                            true,
                            loading
                        )}

                    </div>
                )}


            {/* ================================================== */}
            {/* STEP 4 - DELIVERY PARTNER PERSONAL */}
            {/* ================================================== */}

            {step === 4 &&
                role === "DELIVERY_PARTNER" && (

                    <div className="form-section">

                        <h3>
                            Personal Details
                        </h3>


                        <label>
                            Full name
                        </label>


                        <input
                            className="input"
                            type="text"
                            placeholder="Enter your full name"
                            value={fullName}
                            onChange={(e) =>
                                setFullName(
                                    e.target.value
                                )
                            }
                        />


                        <label>
                            Phone
                        </label>


                        <input
                            className="input"
                            type="text"
                            inputMode="numeric"
                            placeholder={
                                identifierType === "MOBILE"
                                    ? "Verified mobile number"
                                    : "Enter your 10-digit phone number"
                            }
                            value={phone}
                            onChange={(e) =>
                                setPhone(
                                    e.target.value
                                )
                            }
                            readOnly={
                                identifierType ===
                                "MOBILE"
                            }
                            style={
                                identifierType ===
                                "MOBILE"
                                    ? {
                                        backgroundColor:
                                            "#f3f3f3",
                                        cursor:
                                            "not-allowed"
                                    }
                                    : undefined
                            }
                        />


                        {identifierType ===
                            "MOBILE" && (

                                <p className="form-subtitle">
                                    This mobile number has
                                    already been verified.
                                </p>

                            )}


                        {renderNavigation(
                            handleDeliveryPersonalNext,
                            "Next",
                            true,
                            loading
                        )}

                    </div>
                )}


            {/* ================================================== */}
            {/* STEP 5 - VEHICLE */}
            {/* ================================================== */}

            {step === 5 &&
                role === "DELIVERY_PARTNER" && (

                    <div className="form-section">

                        <h3>
                            Vehicle Details
                        </h3>


                        <label>
                            Vehicle type
                        </label>


                        <input
                            className="input"
                            type="text"
                            placeholder="Example: Bike"
                            value={vehicleType}
                            onChange={(e) =>
                                setVehicleType(
                                    e.target.value
                                )
                            }
                        />


                        <label>
                            Vehicle number
                        </label>


                        <input
                            className="input"
                            type="text"
                            placeholder="Enter vehicle number"
                            value={vehicleNumber}
                            onChange={(e) =>
                                setVehicleNumber(
                                    e.target.value
                                )
                            }
                        />


                        <label>
                            Driving Licence Number
                        </label>


                        <input
                            className="input"
                            type="text"
                            placeholder="Enter driving licence number"
                            value={drivingLicenseNumber}
                            onChange={(e) =>
                                setDrivingLicenseNumber(
                                    e.target.value
                                )
                            }
                        />


                        {renderNavigation(
                            handleVehicleNext,
                            "Continue",
                            true,
                            loading
                        )}

                    </div>
                )}


            {/* ================================================== */}
            {/* STEP 6 - COMPLETE REGISTRATION */}
            {/* ================================================== */}

            {step === 6 && (

                <div className="form-section">

                    <h3>
                        Complete Registration
                    </h3>


                    <p>
                        Your{" "}
                        {identifierType === "EMAIL"
                            ? "email address"
                            : "mobile number"
                        }{" "}
                        has been verified successfully.
                    </p>


                    <p>
                        All required registration details
                        are ready to be submitted.
                    </p>


                    {role === "STORE_OWNER" && (

                        <p>
                            Your store application will be
                            sent to the admin for approval.
                        </p>

                    )}


                    {role === "DELIVERY_PARTNER" && (

                        <p>
                            Your delivery partner application
                            will be sent to the admin for
                            approval.
                        </p>

                    )}


                    {renderNavigation(
                        handleRegister,
                        loading
                            ? "Creating..."
                            : "Complete Registration",
                        true,
                        loading
                    )}

                </div>
            )}


            {/* ================================================== */}
            {/* STEP 7 - SUCCESS */}
            {/* ================================================== */}

            {step === 7 && (

                <div className="form-section">

                    <h3>
                        Registration successful
                    </h3>


                    <p>
                        Your LocalMart account has been
                        created successfully.
                    </p>


                    {role !== "CUSTOMER" && (

                        <p>
                            Your application is now
                            waiting for admin approval.
                        </p>

                    )}


                    <button
                        type="button"
                        className="button"
                        onClick={() =>
                            window.location.href =
                                "/login"
                        }
                        style={{
                            marginTop: "20px",
                            minWidth: "150px",
                            height: "44px"
                        }}
                    >
                        Go to Login
                    </button>

                </div>
            )}


            {/* ================================================== */}
            {/* MESSAGE */}
            {/* ================================================== */}

            {message && (

                <p className="message">
                    {message}
                </p>

            )}

        </div>
    )
}

export default Register
