import { useEffect, useState } from "react"
import { useAuth } from "../context/AuthContext"

interface CustomerDashboardProps {
    onStores: () => void
    onCart: () => void
    onCategories: () => void
    onProducts: () => void
    onOrders: () => void
    onProfile: () => void
}

interface Store {
    storeId: number
    storeName: string
    businessType: string
    city: string | null
    state: string | null
    latitude: number | null
    longitude: number | null
}

interface Product {
    productId: number
    productName: string
    category: string
    description: string | null
    price: number
    unit: string
    stockQuantity: number
    isAvailable: boolean
    storeId: number
}

interface Category {
    name: string
    description: string
    icon: string
    className: string
}

function CustomerDashboard({
                               onStores,
                               onCart,
                               onCategories,
                               onProducts,
                               onOrders,
                               onProfile,
                           }: CustomerDashboardProps) {

    const { user, logout } = useAuth()

    const [stores, setStores] = useState<Store[]>([])
    const [categories, setCategories] = useState<Category[]>([])

    const [loadingStores, setLoadingStores] = useState(true)
    const [loadingCategories, setLoadingCategories] = useState(true)

    const [storeError, setStoreError] = useState("")
    const [categoryError, setCategoryError] = useState("")

    useEffect(() => {

        if (!user?.token) {
            return
        }

        const fetchDashboardData = async () => {

            try {

                setLoadingStores(true)
                setLoadingCategories(true)

                setStoreError("")
                setCategoryError("")

                const headers = {
                    Authorization: `Bearer ${user.token}`,
                }

                const [storesResponse, productsResponse] =
                    await Promise.all([
                        fetch("/api/stores", {
                            headers,
                        }),

                        fetch("/api/products", {
                            headers,
                        }),
                    ])

                if (!storesResponse.ok) {
                    throw new Error(
                        `Stores request failed: ${storesResponse.status}`
                    )
                }

                if (!productsResponse.ok) {
                    throw new Error(
                        `Products request failed: ${productsResponse.status}`
                    )
                }

                const storesData: Store[] =
                    await storesResponse.json()

                const productsData: Product[] =
                    await productsResponse.json()

                setStores(storesData)

                const categoryMap =
                    new Map<string, Category>()

                productsData.forEach((product) => {

                    if (!product.category) {
                        return
                    }

                    const categoryName =
                        product.category.trim()

                    if (!categoryName) {
                        return
                    }

                    const normalized =
                        categoryName.toLowerCase()

                    if (categoryMap.has(normalized)) {
                        return
                    }

                    categoryMap.set(
                        normalized,
                        createCategory(categoryName)
                    )
                })

                setCategories(
                    Array.from(categoryMap.values())
                )

            } catch (error) {

                console.error(
                    "Failed to load customer dashboard:",
                    error
                )

                setStoreError(
                    "Unable to load stores."
                )

                setCategoryError(
                    "Unable to load categories."
                )

            } finally {

                setLoadingStores(false)
                setLoadingCategories(false)
            }
        }

        fetchDashboardData()

    }, [user?.token])


    function createCategory(
        categoryName: string
    ): Category {

        const normalized =
            categoryName.toLowerCase()

        if (normalized.includes("grocery")) {
            return {
                name: categoryName,
                description: "Daily essentials",
                icon: "🛒",
                className: "grocery",
            }
        }

        if (normalized.includes("food")) {
            return {
                name: categoryName,
                description: "Restaurants & meals",
                icon: "🍱",
                className: "food",
            }
        }

        if (normalized.includes("pharmacy")) {
            return {
                name: categoryName,
                description: "Health essentials",
                icon: "💊",
                className: "pharmacy",
            }
        }

        if (normalized.includes("electronic")) {
            return {
                name: categoryName,
                description: "Gadgets & accessories",
                icon: "📱",
                className: "electronics",
            }
        }

        if (normalized.includes("fashion")) {
            return {
                name: categoryName,
                description: "Clothing & accessories",
                icon: "👕",
                className: "fashion",
            }
        }

        if (normalized.includes("home")) {
            return {
                name: categoryName,
                description: "Home essentials",
                icon: "🏠",
                className: "home",
            }
        }

        return {
            name: categoryName,
            description: "Products from local stores",
            icon: "🛍️",
            className: "grocery",
        }
    }


    function getStoreIcon(
        businessType: string
    ) {

        const type =
            businessType?.toLowerCase() || ""

        if (type.includes("food") ||
            type.includes("restaurant") ||
            type.includes("kitchen")) {

            return "🍱"
        }

        if (type.includes("grocery")) {
            return "🛒"
        }

        if (type.includes("pharmacy")) {
            return "💊"
        }

        if (type.includes("electronic")) {
            return "📱"
        }

        if (type.includes("fashion")) {
            return "👕"
        }

        return "🏪"
    }


    return (
        <div className="customer-dashboard">

            {/* ================= HEADER ================= */}

            <header className="customer-header">

                <div className="customer-logo">
                    Local<span>Mart</span>
                </div>

                <div className="customer-search">

                    <span className="search-icon">
                        🔍
                    </span>

                    <input
                        type="text"
                        placeholder="Search products or stores..."
                    />

                </div>

                <div className="customer-location">

                    <span className="location-icon">
                        📍
                    </span>

                    <div>
                        <small>Deliver to</small>
                        <strong>Chennai</strong>
                    </div>

                </div>

                <div className="customer-header-actions">

                    <button
                        className="header-icon-button"
                        title="Cart"
                        type="button"
                        onClick={onCart}
                    >
                        🛒
                    </button>

                    <button
                        className="customer-profile"
                        type="button"
                        onClick={onProfile}
                        title="My Profile"
                    >

                        <div className="profile-avatar">
                            {user?.email?.charAt(0).toUpperCase()}
                        </div>

                        <div className="profile-details">

                            <strong>
                                Customer
                            </strong>

                            <small>
                                {user?.email}
                            </small>

                        </div>

                    </button>

                    <button
                        className="logout-button"
                        onClick={logout}
                        type="button"
                    >
                        Logout
                    </button>

                </div>

            </header>


            {/* ================= NAVIGATION ================= */}

            <nav className="customer-navigation">

                <div className="navigation-inner">

                    <button
                        className="nav-active"
                        type="button"
                    >
                        Home
                    </button>

                    <button
                        onClick={onStores}
                        type="button"
                    >
                        Stores
                    </button>



                    <button
                        onClick={onProducts}
                        type="button"
                    >
                        Products
                    </button>

                    <button
                        onClick={onOrders}
                        type="button"
                    >
                        Orders
                    </button>

                    <button
                        onClick={onProfile}
                        type="button"
                    >
                        My Profile
                    </button>

                </div>

            </nav>


            {/* ================= MAIN ================= */}

            <main className="customer-main">

                {/* ================= HERO ================= */}

                <section className="customer-hero">

                    <div className="hero-content">

                        <span className="hero-label">
                            LOCAL SHOPPING, MADE EASY
                        </span>

                        <h1>
                            Everything you need,
                            <br />
                            <span>right around you.</span>
                        </h1>

                        <p>
                            Discover trusted local stores and find
                            everyday products near you.
                        </p>

                        <div className="hero-buttons">

                            <button
                                className="primary-button"
                                onClick={onStores}
                                type="button"
                            >
                                Explore Stores
                            </button>

                            <button
                                className="secondary-button"
                                onClick={onCategories}
                                type="button"
                            >
                                Browse Categories
                            </button>

                        </div>

                    </div>


                    <div className="hero-visual">

                        <div className="hero-circle">

                            <div className="hero-shopping-bag">
                                🛍️
                            </div>

                        </div>

                        <div className="floating-card delivery-card">

                            <span>
                                🚚
                            </span>

                            <div>
                                <strong>
                                    Fast delivery
                                </strong>

                                <small>
                                    From local stores
                                </small>
                            </div>

                        </div>

                        <div className="floating-card store-card">

                            <span>
                                🏪
                            </span>

                            <div>
                                <strong>
                                    Local stores
                                </strong>

                                <small>
                                    Near your location
                                </small>
                            </div>

                        </div>

                    </div>

                </section>


                {/* ================= CATEGORIES ================= */}

                <section className="customer-section">

                    <div className="section-header">

                        <div>

                            <span className="section-label">
                                EXPLORE
                            </span>

                            <h2>
                                Shop by category
                            </h2>

                            <p>
                                Find what you need from local businesses.
                            </p>

                        </div>

                        <button
                            className="section-link"
                            onClick={onCategories}
                            type="button"
                        >
                            View all →
                        </button>

                    </div>


                    <div className="category-grid">

                        {loadingCategories && (
                            <p>
                                Loading categories...
                            </p>
                        )}

                        {!loadingCategories &&
                            categoryError && (
                                <p>
                                    {categoryError}
                                </p>
                            )}

                        {!loadingCategories &&
                            !categoryError &&
                            categories.length === 0 && (
                                <p>
                                    No product categories available.
                                </p>
                            )}

                        {!loadingCategories &&
                            !categoryError &&
                            categories.map((category) => (

                                <button
                                    key={category.name}
                                    className="category-item"
                                    type="button"
                                    onClick={onCategories}
                                >

                                    <div
                                        className={`category-image ${category.className}`}
                                    >
                                        {category.icon}
                                    </div>

                                    <h3>
                                        {category.name}
                                    </h3>

                                    <p>
                                        {category.description}
                                    </p>

                                </button>

                            ))}

                    </div>

                </section>


                {/* ================= NEARBY STORES ================= */}

                <section className="customer-section">

                    <div className="section-header">

                        <div>

                            <span className="section-label">
                                NEAR YOU
                            </span>

                            <h2>
                                Nearby stores
                            </h2>

                            <p>
                                Stores available around your location.
                            </p>

                        </div>

                        <button
                            className="section-link"
                            onClick={onStores}
                            type="button"
                        >
                            View all →
                        </button>

                    </div>


                    <div className="store-grid">

                        {loadingStores && (
                            <p>
                                Loading stores...
                            </p>
                        )}

                        {!loadingStores &&
                            storeError && (
                                <p>
                                    {storeError}
                                </p>
                            )}

                        {!loadingStores &&
                            !storeError &&
                            stores.length === 0 && (
                                <p>
                                    No stores are currently available.
                                </p>
                            )}

                        {!loadingStores &&
                            !storeError &&
                            stores.slice(0, 3).map((store) => (

                                <div
                                    className="store-card"
                                    key={store.storeId}
                                >

                                    <div className="store-image">
                                        {getStoreIcon(
                                            store.businessType
                                        )}
                                    </div>

                                    <div className="store-info">

                                        <div className="store-title">

                                            <h3>
                                                {store.storeName}
                                            </h3>

                                            <span className="store-status">
                                                Available
                                            </span>

                                        </div>

                                        <p>
                                            {store.businessType}
                                        </p>

                                        <div className="store-meta">
                                            📍{" "}
                                            {store.city ||
                                                "Location unavailable"}
                                            {store.state
                                                ? `, ${store.state}`
                                                : ""}
                                        </div>

                                        <button
                                            className="store-button"
                                            onClick={onStores}
                                            type="button"
                                        >
                                            View Store
                                        </button>

                                    </div>

                                </div>

                            ))}

                    </div>

                </section>

            </main>


            {/* ================= FOOTER ================= */}

            <footer className="customer-footer">

                <div className="footer-content">

                    <div>

                        <div className="customer-logo">
                            Local<span>Mart</span>
                        </div>

                        <p>
                            Shop local. Live local.
                        </p>

                    </div>

                    <div className="footer-links">

                        <button
                            onClick={onStores}
                            type="button"
                        >
                            Stores
                        </button>

                        <button
                            onClick={onCategories}
                            type="button"
                        >
                            Categories
                        </button>

                        <button
                            onClick={onProducts}
                            type="button"
                        >
                            Products
                        </button>

                        <button
                            onClick={onOrders}
                            type="button"
                        >
                            Orders
                        </button>

                        <button
                            onClick={onCart}
                            type="button"
                        >
                            Cart
                        </button>

                    </div>

                </div>

            </footer>

        </div>
    )
}

export default CustomerDashboard