package com.localmart.localmartbackend.service;

import com.localmart.localmartbackend.dto.StoreResponse;
import com.localmart.localmartbackend.entity.Address;
import com.localmart.localmartbackend.entity.StoreDetails;
import com.localmart.localmartbackend.repository.AddressRepository;
import com.localmart.localmartbackend.repository.StoreDetailsRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class StoreService {

    private final StoreDetailsRepository storeDetailsRepository;
    private final AddressRepository addressRepository;

    public StoreService(
            StoreDetailsRepository storeDetailsRepository,
            AddressRepository addressRepository
    ) {
        this.storeDetailsRepository = storeDetailsRepository;
        this.addressRepository = addressRepository;
    }

    public List<StoreResponse> getAllStores() {

        List<StoreDetails> stores =
                storeDetailsRepository.findAll();

        List<StoreResponse> responses =
                new ArrayList<>();

        for (StoreDetails store : stores) {

            Optional<Address> addressOptional =
                    addressRepository.findByUserIdAndIsDefaultTrue(
                            store.getUserId()
                    );

            Address address =
                    addressOptional.orElse(null);

            responses.add(
                    new StoreResponse(
                            store.getStoreId(),
                            store.getStoreName(),
                            store.getBusinessType(),
                            address != null
                                    ? address.getCity()
                                    : null,
                            address != null
                                    ? address.getState()
                                    : null,
                            address != null
                                    ? address.getLatitude()
                                    : null,
                            address != null
                                    ? address.getLongitude()
                                    : null
                    )
            );
        }

        return responses;
    }
}