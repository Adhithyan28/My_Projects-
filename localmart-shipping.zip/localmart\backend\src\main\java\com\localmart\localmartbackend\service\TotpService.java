package com.localmart.localmartbackend.service;

import dev.samstevens.totp.exceptions.CodeGenerationException;
import dev.samstevens.totp.code.DefaultCodeGenerator;
import dev.samstevens.totp.code.DefaultCodeVerifier;
import dev.samstevens.totp.code.HashingAlgorithm;
import dev.samstevens.totp.secret.DefaultSecretGenerator;
import dev.samstevens.totp.secret.SecretGenerator;
import dev.samstevens.totp.time.SystemTimeProvider;
import dev.samstevens.totp.time.TimeProvider;
import org.springframework.stereotype.Service;

@Service
public class TotpService {

    private static final int SECRET_LENGTH = 32;

    private final SecretGenerator secretGenerator;
    private final DefaultCodeGenerator codeGenerator;
    private final DefaultCodeVerifier codeVerifier;

    public TotpService() {

        /*
         * Generates the secret that will be used
         * to generate the TOTP.
         */
        this.secretGenerator =
                new DefaultSecretGenerator(
                        SECRET_LENGTH
                );

        /*
         * Generates a 6-digit OTP using SHA-1.
         */
        this.codeGenerator =
                new DefaultCodeGenerator(
                        HashingAlgorithm.SHA1,
                        6
                );

        /*
         * Provides the current Unix time to the
         * TOTP verifier.
         */
        TimeProvider timeProvider =
                new SystemTimeProvider();

        /*
         * The verifier needs BOTH:
         *
         * 1. CodeGenerator
         * 2. TimeProvider
         */
        this.codeVerifier =
                new DefaultCodeVerifier(
                        codeGenerator,
                        timeProvider
                );
    }

    /*
     * =========================================================
     * GENERATE SECRET
     * =========================================================
     */

    public String generateSecret() {

        return secretGenerator.generate();
    }

    /*
     * =========================================================
     * GENERATE CURRENT TOTP
     * =========================================================
     */

    public String generateOtp(String secret) {

        long currentTimeSeconds =
                System.currentTimeMillis() / 1000;

        /*
         * TOTP uses a 30-second time period.
         *
         * Convert Unix seconds into the current
         * 30-second time bucket.
         */
        long currentTimeBucket =
                currentTimeSeconds / 30;

        try {

            return codeGenerator.generate(
                    secret,
                    currentTimeBucket
            );

        } catch (CodeGenerationException exception) {

            throw new IllegalStateException(
                    "Unable to generate TOTP",
                    exception
            );
        }
    }

    /*
     * =========================================================
     * VERIFY TOTP
     * =========================================================
     */

    public boolean verifyOtp(
            String secret,
            String otp
    ) {

        return codeVerifier.isValidCode(
                secret,
                otp
        );
    }
}