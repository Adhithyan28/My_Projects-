
        package com.localmart.localmartbackend.controller;

import com.localmart.localmartbackend.dto.CustomerAddressRequest;
import com.localmart.localmartbackend.dto.CustomerProfileResponse;
import com.localmart.localmartbackend.service.CustomerAddressService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/customer/addresses")
@CrossOrigin(origins = {
        "http://localhost:5173",
        "http://localhost:5174",
        "http://localhost:5175"
})
public class CustomerAddressController {

    private final CustomerAddressService customerAddressService;

    public CustomerAddressController(
            CustomerAddressService customerAddressService) {

        this.customerAddressService =
                customerAddressService;
    }

    @GetMapping
    public ResponseEntity<
            List<CustomerProfileResponse.AddressInfo>
            > getAddresses(
            Authentication authentication) {

        Long userId =
                getAuthenticatedUserId(authentication);

        return ResponseEntity.ok(
                customerAddressService.getAddresses(
                        userId
                )
        );
    }

    @PostMapping
    public ResponseEntity<
            CustomerProfileResponse.AddressInfo
            > addAddress(
            Authentication authentication,
            @RequestBody CustomerAddressRequest request) {

        Long userId =
                getAuthenticatedUserId(authentication);

        return ResponseEntity.ok(
                customerAddressService.addAddress(
                        userId,
                        request
                )
        );
    }

    @PutMapping("/{addressId}")
    public ResponseEntity<
            CustomerProfileResponse.AddressInfo
            > updateAddress(
            Authentication authentication,
            @PathVariable Long addressId,
            @RequestBody CustomerAddressRequest request) {

        Long userId =
                getAuthenticatedUserId(authentication);

        return ResponseEntity.ok(
                customerAddressService.updateAddress(
                        userId,
                        addressId,
                        request
                )
        );
    }

    @DeleteMapping("/{addressId}")
    public ResponseEntity<String> deleteAddress(
            Authentication authentication,
            @PathVariable Long addressId) {

        Long userId =
                getAuthenticatedUserId(authentication);

        customerAddressService.deleteAddress(
                userId,
                addressId
        );

        return ResponseEntity.ok(
                "Address deleted successfully"
        );
    }

    @PutMapping("/{addressId}/default")
    public ResponseEntity<
            CustomerProfileResponse.AddressInfo
            > setDefaultAddress(
            Authentication authentication,
            @PathVariable Long addressId) {

        Long userId =
                getAuthenticatedUserId(authentication);

        return ResponseEntity.ok(
                customerAddressService.setDefaultAddress(
                        userId,
                        addressId
                )
        );
    }

    private Long getAuthenticatedUserId(
            Authentication authentication) {

        if (authentication == null ||
                authentication.getPrincipal() == null) {

            throw new RuntimeException(
                    "User is not authenticated"
            );
        }

        Object principal =
                authentication.getPrincipal();

        if (principal instanceof Long userId) {
            return userId;
        }

        if (principal instanceof String userId) {

            try {

                return Long.valueOf(userId);

            } catch (NumberFormatException exception) {

                throw new RuntimeException(
                        "Invalid authenticated user ID"
                );
            }
        }

        throw new RuntimeException(
                "Invalid authenticated user"
        );
    }
}
