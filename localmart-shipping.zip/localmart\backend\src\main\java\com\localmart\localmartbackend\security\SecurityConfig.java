
        package com.localmart.localmartbackend.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.context.SecurityContextHolderFilter;

@Configuration
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtAuthenticationFilter;

    public SecurityConfig(
            JwtAuthenticationFilter jwtAuthenticationFilter) {

        this.jwtAuthenticationFilter =
                jwtAuthenticationFilter;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {

        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(
            HttpSecurity http) throws Exception {

        http
                .csrf(csrf ->
                        csrf.disable())

                .cors(cors -> {})

                .httpBasic(httpBasic ->
                        httpBasic.disable())

                .formLogin(formLogin ->
                        formLogin.disable())

                .authorizeHttpRequests(auth -> auth

                        /*
                         * ------------------------------------------------
                         * PUBLIC USER AUTHENTICATION ENDPOINTS
                         * ------------------------------------------------
                         */
                        .requestMatchers(
                                "/api/users/login",
                                "/api/users/register",

                                // Login OTP
                                "/api/users/login/send-otp",
                                "/api/users/login/verify",

                                // Registration OTP
                                "/api/users/register/send-otp",
                                "/api/users/register/verify",
                                "/api/users/register/verify-otp",

                                // Google
                                "/api/users/google/login",

                                // X
                                "/api/users/x/login",
                                "/api/users/x/callback",
                                "/api/users/x/register",

                                // Logout
                                "/api/users/logout"
                        )
                        .permitAll()

                        /*
                         * ------------------------------------------------
                         * SMS OTP ENDPOINTS
                         * ------------------------------------------------
                         */
                        .requestMatchers(
                                "/api/sms-otp/send",
                                "/api/sms-otp/verify"
                        )
                        .permitAll()

                        /*
                         * ------------------------------------------------
                         * PUBLIC ADMIN LOGIN ENDPOINTS
                         * ------------------------------------------------
                         */
                        .requestMatchers(
                                "/api/admin/login",
                                "/api/admin/login/send-otp",
                                "/api/admin/login/verify"
                        )
                        .permitAll()

                        /*
                         * ------------------------------------------------
                         * ADMIN APIs
                         * ------------------------------------------------
                         */
                        .requestMatchers("/api/admin/**")
                        .hasRole("ADMIN")

                        /*
                         * ------------------------------------------------
                         * EVERYTHING ELSE
                         * ------------------------------------------------
                         */
                        .anyRequest()
                        .authenticated()
                )

                /*
                 * ------------------------------------------------
                 * RATE LIMIT FILTER
                 * ------------------------------------------------
                 */
                .addFilterAfter(
                        new RateLimitFilter(),
                        SecurityContextHolderFilter.class
                )

                /*
                 * ------------------------------------------------
                 * JWT FILTER
                 * ------------------------------------------------
                 */
                .addFilterBefore(
                        jwtAuthenticationFilter,
                        UsernamePasswordAuthenticationFilter.class
                );

        return http.build();
    }
}
