package com.localmart.localmartbackend.repository;

import com.localmart.localmartbackend.entity.UserSession;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserSessionRepository
        extends JpaRepository<UserSession, Long> {

    Optional<UserSession> findByUserId(Long userId);

    Optional<UserSession> findBySessionId(String sessionId);

    boolean existsByUserId(Long userId);

    void deleteByUserId(Long userId);

    void deleteBySessionId(String sessionId);
}