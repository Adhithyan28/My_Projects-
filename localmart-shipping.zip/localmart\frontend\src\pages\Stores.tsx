import { useEffect, useState } from "react"
import { useAuth } from "../context/AuthContext"


/* ==========================================
 * STORE TYPE
 * ========================================== */

interface Store {

    id: number
    name: string
    type: string
    city: string | null
    state: string | null
    latitude: number | null
    longitude: number | null

}


/* ==========================================
 * BACKEND STORE RESPONSE
 * ========================================== */

interface StoreResponse {

    storeId: number
    storeName: string
    businessType: string
    city: string | null
    state: string | null
    latitude: number | null
    longitude: number | null

}


/* ==========================================
 * PROPS
 * ========================================== */

interface StoresProps {

    onHome: () => void

    onViewStore: (store: Store) => void

    onCategories: () => void

    onProducts: () => void

    onOrders: () => void

    onCart: () => void

}


/* ==========================================
 * STORES PAGE
 * ========================================== */

function Stores({
                    onHome,
                    onViewStore,
                    onCategories,
                    onProducts,
                    onOrders,
                    onCart,
                }: StoresProps) {

    const { user, logout } = useAuth()

    const [search, setSearch] =
        useState("")

    const [stores, setStores] =
        useState<Store[]>([])

    const [loading, setLoading] =
        useState(true)

    const [error, setError] =
        useState("")


    /* ==========================================
     * LOAD STORES FROM DATABASE
     * ========================================== */

    useEffect(() => {

        const loadStores = async () => {

            try {

                setLoading(true)
                setError("")

                if (!user?.token) {

                    throw new Error(
                        "User authentication token is missing"
                    )

                }

                const response =
                    await fetch("/api/stores", {

                        method: "GET",

                        headers: {
                            Authorization:
                                `Bearer ${user.token}`,
                        },

                    })


                if (!response.ok) {

                    if (response.status === 401) {

                        throw new Error(
                            "Your session has expired. Please login again."
                        )

                    }

                    if (response.status === 403) {

                        throw new Error(
                            "You are not authorized to view stores."
                        )

                    }

                    throw new Error(
                        `Failed to load stores (${response.status})`
                    )

                }


                const data: StoreResponse[] =
                    await response.json()


                /* ==================================
                 * CONVERT BACKEND RESPONSE
                 * TO FRONTEND STORE MODEL
                 * ================================== */

                const mappedStores: Store[] =
                    data.map((store) => ({

                        id: store.storeId,

                        name: store.storeName,

                        type: store.businessType,

                        city: store.city,

                        state: store.state,

                        latitude: store.latitude,

                        longitude: store.longitude,

                    }))


                setStores(mappedStores)

            } catch (error) {

                console.error(
                    "Failed to load stores:",
                    error
                )

                setError(
                    error instanceof Error
                        ? error.message
                        : "Unable to load stores."
                )

            } finally {

                setLoading(false)

            }

        }


        loadStores()

    }, [user?.token])


    /* ==========================================
     * SEARCH
     * ========================================== */

    const filteredStores =
        stores.filter((store) => {

            const searchText =
                `${store.name} ${store.type} ${store.city ?? ""} ${store.state ?? ""}`
                    .toLowerCase()

            return searchText.includes(
                search.toLowerCase()
            )

        })


    return (

        <div className="customer-dashboard">


            {/* ==================================
             * HEADER
             * ================================== */}

            <header className="customer-header">


                {/* LOGO */}

                <button
                    className="customer-logo"
                    onClick={onHome}
                    type="button"
                >
                    Local<span>Mart</span>
                </button>


                {/* SEARCH */}

                <div className="customer-search">

                    <span className="search-icon">
                        🔍
                    </span>

                    <input
                        type="text"
                        placeholder="Search products or stores..."
                    />

                </div>


                {/* LOCATION */}

                <div className="customer-location">

                    <span className="location-icon">
                        📍
                    </span>

                    <div>

                        <small>
                            Deliver to
                        </small>

                        <strong>
                            Chennai
                        </strong>

                    </div>

                </div>


                {/* ACTIONS */}

                <div className="customer-header-actions">


                    {/* CART */}

                    <button
                        className="header-icon-button"
                        title="Cart"
                        type="button"
                        onClick={onCart}
                    >
                        🛒
                    </button>


                    {/* PROFILE */}

                    <div className="customer-profile">

                        <div className="profile-avatar">

                            {user?.email
                                ?.charAt(0)
                                .toUpperCase() || "U"}

                        </div>


                        <div className="profile-details">

                            <strong>
                                Customer
                            </strong>

                            <small>
                                {user?.email}
                            </small>

                        </div>

                    </div>


                    {/* LOGOUT */}

                    <button
                        className="logout-button"
                        onClick={logout}
                        type="button"
                    >
                        Logout
                    </button>


                </div>

            </header>


            {/* ==================================
             * NAVIGATION
             * ================================== */}

            <nav className="customer-navigation">

                <div className="navigation-inner">

                    <button
                        type="button"
                        onClick={onHome}
                    >
                        Home
                    </button>


                    <button
                        type="button"
                        className="nav-active"
                    >
                        Stores
                    </button>






                    <button
                        type="button"
                        onClick={onProducts}
                    >
                        Products
                    </button>


                    <button
                        type="button"
                        onClick={onOrders}
                    >
                        Orders
                    </button>



                </div>

            </nav>


            {/* ==================================
             * MAIN
             * ================================== */}

            <main className="customer-main">

                <section className="customer-section stores-page">


                    {/* PAGE HEADER */}

                    <div className="section-header">

                        <div>

                            <span className="section-label">
                                LOCAL STORES
                            </span>

                            <h2>
                                Stores near you
                            </h2>

                            <p>
                                Discover trusted local businesses around your location.
                            </p>

                        </div>

                    </div>


                    {/* SEARCH */}

                    <div className="stores-search">

                        <span>
                            🔍
                        </span>

                        <input
                            type="text"
                            placeholder="Search stores..."
                            value={search}
                            onChange={(event) =>
                                setSearch(
                                    event.target.value
                                )
                            }
                        />

                    </div>


                    {/* RESULT COUNT */}

                    <div className="stores-result-info">

                        <span>
                            {loading
                                ? "Loading stores..."
                                : `${filteredStores.length} stores available`
                            }
                        </span>

                        <span>
                            📍 Chennai
                        </span>

                    </div>


                    {/* ERROR */}

                    {error && (

                        <div className="stores-empty">

                            <div>
                                ⚠️
                            </div>

                            <h3>
                                Unable to load stores
                            </h3>

                            <p>
                                {error}
                            </p>

                        </div>

                    )}


                    {/* STORE GRID */}

                    {!loading &&
                    !error &&
                    filteredStores.length > 0 ? (

                        <div className="store-grid">

                            {filteredStores.map(
                                (store) => (

                                    <div
                                        className="store-card"
                                        key={store.id}
                                    >

                                        <div className="store-image">
                                            🏪
                                        </div>


                                        <div className="store-info">

                                            <div className="store-title">

                                                <h3>
                                                    {store.name}
                                                </h3>

                                            </div>


                                            <p>
                                                {store.type}
                                            </p>


                                            <div className="store-meta">

                                                📍{" "}

                                                {store.city
                                                    ? `${store.city}${store.state ? `, ${store.state}` : ""}`
                                                    : "Location unavailable"
                                                }

                                            </div>


                                            <button
                                                type="button"
                                                className="store-button"
                                                onClick={() =>
                                                    onViewStore(
                                                        store
                                                    )
                                                }
                                            >
                                                View Store
                                            </button>

                                        </div>

                                    </div>

                                )
                            )}

                        </div>

                    ) : (

                        !loading &&
                        !error && (

                            <div className="stores-empty">

                                <div>
                                    🔍
                                </div>

                                <h3>
                                    No stores found
                                </h3>

                                <p>
                                    Try searching with a different store name or category.
                                </p>

                            </div>

                        )

                    )}

                </section>

            </main>


            {/* ==================================
             * FOOTER
             * ================================== */}

            <footer className="customer-footer">

                <div className="footer-content">

                    <div>

                        <button
                            className="customer-logo"
                            onClick={onHome}
                            type="button"
                        >
                            Local<span>Mart</span>
                        </button>

                        <p>
                            Shop local. Live local.
                        </p>

                    </div>


                    <div className="footer-links">

                        <button
                            type="button"
                            onClick={onHome}
                        >
                            Home
                        </button>


                        <button
                            type="button"
                            onClick={onCategories}
                        >
                            Categories
                        </button>


                        <button
                            type="button"
                            onClick={onProducts}
                        >
                            Products
                        </button>


                        <button
                            type="button"
                            onClick={onOrders}
                        >
                            Orders
                        </button>


                        <button
                            type="button"
                            onClick={onCart}
                        >
                            Cart
                        </button>

                    </div>

                </div>

            </footer>

        </div>
    )
}


export default Stores