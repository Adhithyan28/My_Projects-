package com.localmart.localmartbackend.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Collections;

@Service
public class MessageCentralOtpService
        implements OtpDeliveryService {

    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;

    private final String baseUrl;
    private final String customerId;
    private final String authToken;

    public MessageCentralOtpService(
            @Value("${messagecentral.base-url}")
            String baseUrl,

            @Value("${messagecentral.customer-id}")
            String customerId,

            @Value("${messagecentral.auth-token}")
            String authToken) {

        this.baseUrl = baseUrl;
        this.customerId = customerId;
        this.authToken = authToken;

        this.restTemplate =
                new RestTemplate();

        this.objectMapper =
                new ObjectMapper();
    }

    // ============================================================
    // SEND SMS OTP
    // ============================================================

    @Override
    public String sendSmsOtp(
            String phone) {

        return sendOtp(
                phone,
                "SMS"
        );
    }

    // ============================================================
    // SEND WHATSAPP OTP
    // ============================================================

    @Override
    public String sendWhatsAppOtp(
            String phone) {

        return sendOtp(
                phone,
                "WHATSAPP"
        );
    }

    // ============================================================
    // SEND OTP
    // ============================================================

    private String sendOtp(
            String phone,
            String flowType) {

        String mobileNumber =
                normalizeIndianPhone(phone);

        String url =
                UriComponentsBuilder
                        .fromUriString(
                                baseUrl +
                                        "/verification/v3/send"
                        )
                        .queryParam(
                                "countryCode",
                                "91"
                        )
                        .queryParam(
                                "customerId",
                                customerId
                        )
                        .queryParam(
                                "flowType",
                                flowType
                        )
                        .queryParam(
                                "mobileNumber",
                                mobileNumber
                        )
                        .queryParam(
                                "otpLength",
                                6
                        )
                        .toUriString();

        HttpHeaders headers =
                new HttpHeaders();

        headers.set(
                "authToken",
                authToken
        );

        headers.setAccept(
                Collections.singletonList(
                        MediaType.APPLICATION_JSON
                )
        );

        HttpEntity<Void> request =
                new HttpEntity<>(
                        headers
                );

        ResponseEntity<String> response =
                restTemplate.exchange(
                        url,
                        HttpMethod.POST,
                        request,
                        String.class
                );

        if (!response.getStatusCode()
                .is2xxSuccessful()) {

            throw new RuntimeException(
                    "Message Central returned HTTP "
                            + response.getStatusCode()
                            + ": "
                            + response.getBody()
            );
        }

        try {

            JsonNode root =
                    objectMapper.readTree(
                            response.getBody()
                    );

            int responseCode =
                    root.path(
                            "responseCode"
                    ).asInt();

            if (responseCode != 200) {

                throw new RuntimeException(
                        "Message Central rejected OTP request: "
                                + root.path(
                                "message"
                        ).asText()
                );
            }

            JsonNode data =
                    root.path("data");

            String verificationId =
                    data.path(
                            "verificationId"
                    ).asText();

            if (verificationId == null
                    || verificationId.isBlank()) {

                throw new RuntimeException(
                        "Message Central did not return a verification ID."
                );
            }

            return verificationId;

        } catch (RuntimeException exception) {

            throw exception;

        } catch (Exception exception) {

            throw new RuntimeException(
                    "Unable to process Message Central response.",
                    exception
            );
        }
    }

    // ============================================================
    // VERIFY OTP
    // ============================================================

    @Override
    public boolean verifyOtp(
            String verificationId,
            String otp) {

        if (verificationId == null
                || verificationId.isBlank()) {

            System.out.println(
                    "MESSAGE CENTRAL VERIFY ERROR: "
                            + "Verification ID is missing."
            );

            return false;
        }

        if (otp == null
                || otp.isBlank()) {

            System.out.println(
                    "MESSAGE CENTRAL VERIFY ERROR: "
                            + "OTP is missing."
            );

            return false;
        }

        String url =
                UriComponentsBuilder
                        .fromUriString(
                                baseUrl +
                                        "/verification/v3/validateOtp"
                        )
                        .queryParam(
                                "verificationId",
                                verificationId
                        )
                        .queryParam(
                                "code",
                                otp.trim()
                        )
                        .toUriString();

        HttpHeaders headers =
                new HttpHeaders();

        headers.set(
                "authToken",
                authToken
        );

        headers.setAccept(
                Collections.singletonList(
                        MediaType.APPLICATION_JSON
                )
        );

        HttpEntity<Void> request =
                new HttpEntity<>(
                        headers
                );

        ResponseEntity<String> response;

        try {

            response =
                    restTemplate.exchange(
                            url,
                            HttpMethod.GET,
                            request,
                            String.class
                    );

        } catch (Exception exception) {

            System.out.println(
                    "MESSAGE CENTRAL VERIFY HTTP ERROR: "
                            + exception.getMessage()
            );

            return false;
        }

        /*
         * --------------------------------------------------------
         * DEBUG RESPONSE
         * --------------------------------------------------------
         *
         * This shows the actual response returned by
         * Message Central so we can determine why OTP
         * verification is failing.
         */
        System.out.println(
                "MESSAGE CENTRAL VERIFY STATUS: "
                        + response.getStatusCode()
        );

        System.out.println(
                "MESSAGE CENTRAL VERIFY RESPONSE: "
                        + response.getBody()
        );

        if (!response.getStatusCode()
                .is2xxSuccessful()) {

            return false;
        }

        try {

            JsonNode root =
                    objectMapper.readTree(
                            response.getBody()
                    );

            JsonNode data =
                    root.path("data");

            String verificationStatus =
                    data.path(
                            "verificationStatus"
                    ).asText();

            System.out.println(
                    "MESSAGE CENTRAL VERIFICATION STATUS: "
                            + verificationStatus
            );

            return "VERIFICATION_COMPLETED"
                    .equalsIgnoreCase(
                            verificationStatus
                    );

        } catch (Exception exception) {

            System.out.println(
                    "MESSAGE CENTRAL VERIFY PARSE ERROR: "
                            + exception.getMessage()
            );

            return false;
        }
    }

    // ============================================================
    // NORMALIZE INDIAN PHONE
    // ============================================================

    private String normalizeIndianPhone(
            String phone) {

        if (phone == null
                || phone.isBlank()) {

            throw new IllegalArgumentException(
                    "Mobile number is required."
            );
        }

        String cleaned =
                phone.trim()
                        .replaceAll(
                                "[^0-9]",
                                ""
                        );

        if (cleaned.startsWith("91")
                && cleaned.length() == 12) {

            cleaned =
                    cleaned.substring(2);
        }

        if (cleaned.length() != 10) {

            throw new IllegalArgumentException(
                    "Invalid Indian mobile number."
            );
        }

        if (!cleaned.matches(
                "^[6-9][0-9]{9}$"
        )) {

            throw new IllegalArgumentException(
                    "Invalid Indian mobile number."
            );
        }

        return cleaned;
    }
}