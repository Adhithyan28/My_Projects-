# LocalMart — Store Management

## 1. Overview

The Store Management Module is responsible for managing the stores that participate in the LocalMart marketplace.

A store represents a business that provides products to customers through the LocalMart platform.

The module connects:

```text
Store Owner
     |
     v
Store
     |
     v
Products
     |
     v
Customers
     |
     v
Orders
```

The store-management functionality is primarily concerned with:

* Store-owner association
* Store business information
* Store address
* Store ownership
* Store products
* Store availability
* Store-related order processing
* Store-owner access to store data

---

# 2. Store Management Architecture

The store-management architecture follows the standard LocalMart backend structure:

```text
Store Owner / Customer
        |
        v
React Frontend
        |
        | HTTP
        v
Store Controller
        |
        v
Store Service
        |
        v
Store Repository
        |
        v
PostgreSQL
```

Store-related operations can also interact with other modules:

```text
                    Store
                      |
        +-------------+-------------+
        |             |             |
        v             v             v
     Address       Products       Orders
                                    |
                                    v
                                Delivery
```

---

# 3. Store and Store Owner

A store is associated with a LocalMart user who has the:

```text
STORE_OWNER
```

role.

The relationship can be represented as:

```text
User
  |
  +--> Role = STORE_OWNER
  |
  v
Store Details
```

The store owner's identity is therefore separate from the store's business information.

The `User` represents the person/account.

The `StoreDetails` entity represents the business/store information.

---

# 4. Store Owner Registration

Store owners cannot simply become active store owners through ordinary customer registration.

The registration process creates the necessary store-owner information and an approval request.

The conceptual flow is:

```text
Store Owner Registration
          |
          v
User Account
          |
          v
STORE_OWNER Role
          |
          v
Store Details
          |
          v
Application Request
          |
          v
Admin Review
```

The application request allows the administrator to control whether the store-owner account is approved.

---

# 5. Store Owner Approval

Store-owner onboarding involves an administrative approval process.

The application lifecycle is:

```text
Application Created
        |
        v
PENDING
        |
   +----+----+
   |         |
   v         v
APPROVED   REJECTED
```

The application status is separate from the user's account status.

This distinction is important because:

```text
Application Status
        !=
Account Status
```

An application describes the onboarding decision.

The account status describes whether the account itself can currently operate.

---

# 6. Store Details

The store's business information is represented separately from the common user information.

Store-related information can include:

```text
Store
 |
 +--> Store ID
 |
 +--> User / Owner ID
 |
 +--> Business Name
 |
 +--> Business Type
 |
 +--> GST Information
 |
 +--> Address
```

The exact fields are determined by the `StoreDetails` entity and its associated database structure.

---

# 7. Business Name

The business name identifies the store presented to customers.

For example:

```text
User
 └── Store Owner

Store
 └── Business Name
```

The customer's store-browsing experience is based on store information rather than the store owner's personal name.

This keeps personal identity and business identity conceptually separate.

---

# 8. Business Type

The store also maintains a business type.

The business type describes the nature/category of the business operated by the store owner.

This information can be used by the platform when displaying or managing stores.

The exact permitted values are determined by the application's validation and database configuration.

---

# 9. GST Information

Store-owner registration can include GST information.

The backend performs duplicate checking when GST information is supplied.

Conceptually:

```text
Store Owner
     |
     v
GST Number
     |
     v
Duplicate Check
     |
     +----> Already exists → Reject
     |
     +----> Available → Continue
```

This prevents the same GST identifier from being associated with multiple stores when the application's business rules require uniqueness.

---

# 10. Store Address

A store requires a physical delivery origin.

The store's address is associated with the LocalMart address system.

Conceptually:

```text
Store
  |
  v
Address
  |
  +--> Address Line
  +--> City
  +--> State
  +--> Pincode
  +--> Latitude
  +--> Longitude
```

The geographic coordinates are important because the store's location can participate in delivery-distance calculations.

---

# 11. Store Location

A store has a geographic location represented by latitude and longitude.

The relationship is:

```text
Store
  |
  +--> Latitude
  |
  +--> Longitude
```

This location can later be combined with a customer's delivery coordinates.

```text
Store Coordinates
        +
Customer Coordinates
        |
        v
Road Distance
        |
        v
Delivery Calculation
```

This connects Store Management with the Location and Delivery modules.

---

# 12. Store and Customer Relationship

Customers do not normally interact directly with a store-owner account.

Instead, customers interact with the store through the marketplace.

```text
Customer
   |
   v
Store
   |
   v
Products
   |
   v
Cart
   |
   v
Order
```

The store therefore acts as the business-side representation visible to customers.

---

# 13. Store Browsing

Customers can retrieve stores from the backend.

The general request flow is:

```text
Customer
   |
   v
Stores Page
   |
   | HTTP Request
   v
StoreController
   |
   v
StoreService
   |
   v
StoreDetailsRepository
   |
   v
PostgreSQL
   |
   v
Store Data
   |
   v
JSON Response
   |
   v
React
```

The database is the source of store information.

This allows the store catalog to change without requiring the frontend source code to be modified.

---

# 14. Store Selection

Once a customer selects a store, the selected store becomes the context for product browsing.

```text
Stores
   |
   v
Selected Store
   |
   v
Store Products
   |
   v
Product Selection
```

The store identifier is used to determine which store's products should be displayed.

---

# 15. Store and Products

Products are associated with stores.

The relationship can be represented as:

```text
Store
 |
 +--> Product 1
 |
 +--> Product 2
 |
 +--> Product 3
 |
 +--> Product 4
```

This relationship is essential to LocalMart's marketplace model because the same type of product may potentially be available from different stores.

The store provides the business context for the product.

---

# 16. Store Product Flow

A customer selecting a store follows this flow:

```text
Customer
    |
    v
Store
    |
    v
Product Controller
    |
    v
Product Service
    |
    v
Product Repository
    |
    v
Database
    |
    v
Products belonging to Store
```

The frontend then displays those products to the customer.

---

# 17. Store Ownership of Products

Store management and product management are closely related.

Conceptually:

```text
Store Owner
     |
     v
Store
     |
     v
Products
```

The store owner manages products associated with their store.

Customers, on the other hand, primarily consume this information by browsing and purchasing products.

This creates a separation between:

```text
Business-side operation
        |
        v
Store Owner

Customer-side consumption
        |
        v
Customer
```

---

# 18. Store Management and Orders

Orders connect customers with stores.

The relationship is:

```text
Customer
    |
    v
Order
    |
    v
Store
    |
    v
Store Owner
```

Once an order is created, the store owner needs access to the orders relevant to their store.

This is handled through store-owner order functionality.

The backend contains a dedicated:

```text
StoreOwnerOrderController
```

for this purpose.

---

# 19. Store Owner Order Flow

The store-owner side of order processing can be represented as:

```text
Customer places order
          |
          v
        Order
          |
          v
       Store
          |
          v
    Store Owner
          |
          v
Process Order
```

The store owner interacts with orders belonging to their store rather than with unrelated marketplace orders.

---

# 20. Store and Delivery

The store is also the origin point for delivery.

A simplified delivery relationship is:

```text
Store
  |
  | Pickup
  v
Delivery Partner
  |
  | Delivery
  v
Customer Address
```

This makes the store's location important for delivery calculations.

---

# 21. Store-to-Customer Distance

LocalMart can calculate a road distance between:

```text
Store Location
        |
        v
Road Distance Service
        ^
        |
Customer Location
```

The resulting distance can contribute to delivery-fee calculations.

The OSRM-based road-distance functionality belongs to the Location/Delivery infrastructure rather than to the store entity itself.

---

# 22. Store Availability

Store availability is an important concept in a marketplace.

A store should only participate in customer shopping operations when it is considered available according to the application's business rules.

Conceptually:

```text
Store
  |
  v
Availability
  |
  +----> Available
  |
  +----> Not Available
```

The exact availability fields and rules depend on the current `StoreDetails` entity and service implementation.

---

# 23. Store Data Ownership

The backend must associate store operations with the authenticated store owner.

Conceptually:

```text
Authenticated User
        |
        v
STORE_OWNER
        |
        v
Owned Store
        |
        v
Store Operation
```

This prevents a store owner from treating another owner's store as their own through a client-supplied identifier.

The authenticated identity should be used as the basis for ownership checks.

---

# 24. Store Owner vs Store

These are two different concepts.

| Store Owner                          | Store                          |
| ------------------------------------ | ------------------------------ |
| User/account                         | Business entity                |
| Has authentication credentials       | Has business information       |
| Has `STORE_OWNER` role               | Represents a marketplace store |
| Owns/manages store                   | Contains products              |
| Can access store-owner functionality | Visible to customers           |

Relationship:

```text
User
  |
  | owns/manages
  v
Store
```

---

# 25. Store Management Backend Components

The store-related backend structure includes:

### Controller

```text
StoreController
```

Responsible for handling store-related HTTP requests.

### Service

```text
StoreService
```

Responsible for store-related business logic.

### Repository

```text
StoreDetailsRepository
```

Responsible for persistence and database access for store details.

### Entity

```text
StoreDetails
```

Represents store information in the persistence layer.

---

# 26. Store-Owner Backend Components

Store-owner functionality is supported by:

```text
StoreOwnerController
StoreOwnerService
StoreOwnerOrderController
```

These components handle store-owner-specific operations separately from customer-facing store browsing.

This separation allows the same store data to be used by different roles while exposing different operations.

```text
                    Store
                      |
          +-----------+-----------+
          |                       |
          v                       v
      Customer               Store Owner
          |                       |
      Browse                  Manage
          |                       |
      Products                Orders
```

---

# 27. Store Data Flow

A typical store retrieval flow is:

```text
React
  |
  | GET store data
  v
StoreController
  |
  v
StoreService
  |
  v
StoreDetailsRepository
  |
  v
PostgreSQL
  |
  v
StoreDetails
  |
  v
Service
  |
  v
Controller
  |
  v
JSON
  |
  v
React
```

This is the standard controller → service → repository flow used throughout the backend.

---

# 28. Store Creation Flow

The store-owner creation process can be summarized as:

```text
Store Owner Registration
          |
          v
Validate Registration
          |
          v
Create User
          |
          v
Assign STORE_OWNER Role
          |
          v
Create Store Details
          |
          v
Create Application Request
          |
          v
Admin Review
          |
     +----+----+
     |         |
     v         v
 Approved   Rejected
```

The exact activation behavior is controlled by the account and application business rules.

---

# 29. Store Management Lifecycle

A simplified store lifecycle is:

```text
Store Owner Registration
          |
          v
Store Information Submitted
          |
          v
Application Pending
          |
          v
Admin Decision
          |
     +----+----+
     |         |
     v         v
 Approved   Rejected
     |
     v
Store Owner Account
     |
     v
Store Operations
     |
     v
Products / Orders
```

This lifecycle connects the Store Management Module with User Management and Admin Management.

---

# 30. Store Management and Role-Based Access

Different roles interact with stores differently.

| Role             | Store Interaction                             |
| ---------------- | --------------------------------------------- |
| CUSTOMER         | Browse stores and products                    |
| STORE_OWNER      | Manage their store and associated operations  |
| DELIVERY_PARTNER | Pickup/delivery involving a store             |
| ADMIN            | Manage/approve store-owner-related operations |

The same store can therefore participate in multiple workflows without giving every role identical permissions.

---

# 31. Store Security

Important security considerations include:

### Authentication

Store-owner operations require an authenticated account.

### Role authorization

Store-management operations should require the appropriate role.

### Ownership validation

A store owner should only operate on stores they own.

### Input validation

Business and store information must be validated before persistence.

### Duplicate prevention

Unique business identifiers such as GST information and other store-related identifiers must be checked where required.

### Account status

Store-owner account status affects whether the user can operate through the platform.

---

# 32. Store and Database Relationships

At a conceptual level, the store-related database relationships are:

```text
users
  |
  +---- roles
  |
  +---- store_details
  |
  +---- addresses
  |
  +---- application_requests
             |
             v
        approval workflow
```

Products then connect to the store:

```text
store_details
      |
      v
   products
      |
      v
   cart_items
      |
      v
   order_items
```

The exact foreign-key structure is defined by the entity mappings and database schema.

---

# 33. Store and Cart Relationship

When a customer adds a product to the cart, the product provides the store context.

Conceptually:

```text
Cart
 |
 +--> Cart Item
        |
        v
     Product
        |
        v
      Store
```

This information becomes relevant during checkout and delivery-fee calculation.

The backend can therefore determine which store is associated with the selected product.

---

# 34. Store and Delivery Fee

The delivery-fee calculation can use:

```text
Store ID
+
Customer Address ID
```

The backend can then obtain:

```text
Store Coordinates
Customer Coordinates
```

and use the location subsystem to calculate the delivery distance.

Conceptually:

```text
Store ID
   |
   v
Store
   |
   v
Store Coordinates
             +
Customer Address ID
   |
   v
Customer Coordinates
             |
             v
       Road Distance
             |
             v
      Delivery Fee
```

---

# 35. Store and Order Fulfillment

The store is responsible for the store-side portion of the order lifecycle.

A simplified model is:

```text
Customer
   |
   v
Order
   |
   v
Store
   |
   v
Order Preparation
   |
   v
READY_FOR_PICKUP
   |
   v
Delivery Partner
```

Once the order is ready, the delivery process can take over.

---

# 36. Store Module Boundaries

The Store Management Module interacts with several other modules:

```text
                    STORE MANAGEMENT
                           |
       +-------------------+-------------------+
       |                   |                   |
       v                   v                   v
 USER MANAGEMENT      PRODUCT MANAGEMENT   ADMIN MANAGEMENT
       |                   |                   |
       +-------------------+-------------------+
                           |
                           v
                      ORDER MANAGEMENT
                           |
                           v
                     DELIVERY SYSTEM
                           |
                           v
                    LOCATION SERVICES
```

This makes Store Management one of the central business modules in LocalMart.

---

# 37. Customer vs Store-Owner Store Flow

The same store is used differently by different users.

### Customer

```text
Customer
   |
   v
Browse Store
   |
   v
View Products
   |
   v
Purchase
```

### Store Owner

```text
Store Owner
   |
   v
Access Own Store
   |
   v
Manage Store Operations
   |
   v
Manage Products / Orders
```

### Admin

```text
Admin
   |
   v
Review Store-Owner Application
   |
   v
Approve / Reject
```

This role-specific behavior is an important part of LocalMart's authorization architecture.

---

# 38. Separation of Responsibilities

The Store Management Module follows separation of concerns.

```text
StoreController
      |
      | HTTP handling
      v
StoreService
      |
      | Business logic
      v
StoreDetailsRepository
      |
      | Persistence
      v
PostgreSQL
```

The controller should not be responsible for directly manipulating database records.

The repository should not contain business workflows.

The service acts as the business-logic layer between the HTTP layer and persistence layer.

---

# 39. Important Design Principles

### Store is a business entity

A store represents a business participating in LocalMart.

### Store owner is a user

The person managing the store is represented by a user account.

### Store ownership must be enforced

Store-owner operations should be tied to the authenticated owner.

### Store data is database-driven

Customer-facing store information comes from backend-managed data.

### Store location matters

Store coordinates participate in location-aware delivery functionality.

### Store connects multiple modules

Products, carts, orders, delivery, and location services all depend on store context.

### Approval is separate from account identity

The store-owner application process is distinct from the user's basic identity.

---

# 40. End-to-End Store Flow

The complete store lifecycle can be represented as:

```text
                 STORE OWNER
                      |
                      v
              Registration
                      |
                      v
                User Account
                      |
                      v
              STORE_OWNER Role
                      |
                      v
               Store Details
                      |
                      v
           Application Request
                      |
                      v
                Admin Review
                      |
               +------+------+
               |             |
               v             v
           APPROVED       REJECTED
               |
               v
          Store Operations
               |
       +-------+-------+
       |               |
       v               v
    Products         Orders
                       |
                       v
                  READY_FOR_PICKUP
                       |
                       v
                 Delivery Partner
                       |
                       v
                    Customer
```

---

# 41. Store Module Summary

The Store Management Module provides the business-side representation of stores within LocalMart.

Its core relationship is:

```text
Store Owner
     |
     v
   Store
     |
     +--> Address / Location
     |
     +--> Products
     |
     +--> Orders
     |
     v
Customers
```

The module works together with:

```text
User Management
Product Management
Cart Management
Order Management
Payment System
Delivery System
Location Services
Admin Management
```

The overall architecture can therefore be summarized as:

```text
                    LOCALMART
                        |
                  STORE MANAGEMENT
                        |
          +-------------+-------------+
          |             |             |
          v             v             v
       OWNER         PRODUCTS       ORDERS
          |             |             |
          v             v             v
       STORE --------> CART ------> DELIVERY
          |
          v
       LOCATION
```

Store Management is consequently a central bridge between the business owners who provide products and the customers who purchase them.
