package com.localmart.localmartbackend.service;

public interface OtpDeliveryService {

    String sendSmsOtp(String phone);

    String sendWhatsAppOtp(String phone);

    boolean verifyOtp(
            String verificationId,
            String otp
    );
}