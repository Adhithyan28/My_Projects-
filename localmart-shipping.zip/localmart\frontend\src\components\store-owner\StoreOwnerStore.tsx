import { useEffect, useState } from "react"
import { useAuth } from "../../context/AuthContext"
import LocationPicker from "../location/LocationPicker"

interface StoreDetails {
    storeName: string
    storeId: string
    ownerName: string
    email: string
    mobile: string
    businessType: string
    gstNumber: string
    addressLine: string
    city: string
    state: string
    pincode: string
    latitude: number | null
    longitude: number | null
}

interface StoreOwnerDetailsResponse {
    storeId: number
    firstName: string
    lastName: string
    ownerName: string
    email: string
    phone: string
    storeName: string
    businessType: string
    gstNumber: string | null
    addressLine: string | null
    city: string | null
    state: string | null
    pincode: string | null
    latitude: number | null
    longitude: number | null
}

const STORE_DETAILS_KEY =
    "localmart_store_owner_details"

function StoreOwnerStore() {

    const { user } = useAuth()

    const createDefaultDetails = (): StoreDetails => ({
        storeName: "",
        storeId: "STORE-001",
        ownerName: "",
        email: user?.email || "",
        mobile: "",
        businessType: "",
        gstNumber: "",
        addressLine: "",
        city: "",
        state: "",
        pincode: "",
        latitude: null,
        longitude: null
    })

    const getSavedDetails = (): StoreDetails => {

        const saved =
            localStorage.getItem(STORE_DETAILS_KEY)

        if (!saved) {
            return createDefaultDetails()
        }

        try {

            const parsed = JSON.parse(saved)

            return {
                storeName:
                    parsed.storeName ?? "",

                storeId:
                    parsed.storeId ?? "STORE-001",

                ownerName:
                    parsed.ownerName ?? "",

                email:
                    user?.email ||
                    parsed.email ||
                    "",

                mobile:
                    parsed.mobile ?? "",

                businessType:
                    parsed.businessType ?? "",

                gstNumber:
                    parsed.gstNumber ?? "",

                addressLine:
                    parsed.addressLine ?? "",

                city:
                    parsed.city ?? "",

                state:
                    parsed.state ?? "",

                pincode:
                    parsed.pincode ?? "",

                latitude:
                    parsed.latitude ?? null,

                longitude:
                    parsed.longitude ?? null
            }

        } catch {

            return createDefaultDetails()
        }
    }

    const [storeDetails, setStoreDetails] =
        useState<StoreDetails>(getSavedDetails)

    const [formData, setFormData] =
        useState<StoreDetails>(getSavedDetails)

    const [isEditing, setIsEditing] =
        useState(
            !isStoreDetailsComplete(
                getSavedDetails()
            )
        )

    const [isLoading, setIsLoading] =
        useState(true)

    const [isSaving, setIsSaving] =
        useState(false)

    const [error, setError] =
        useState("")

    const [isFindingLocation, setIsFindingLocation] =
        useState(false)

    const [locationConfirmed, setLocationConfirmed] =
        useState(false)

    function isStoreDetailsComplete(
        details: StoreDetails
    ) {

        return Boolean(
            details.storeName.trim() &&
            details.ownerName.trim() &&
            details.email.trim() &&
            details.mobile.trim() &&
            details.businessType.trim() &&
            details.gstNumber.trim() &&
            details.addressLine.trim() &&
            details.city.trim() &&
            details.state.trim() &&
            details.pincode.trim() &&
            details.latitude !== null &&
            details.longitude !== null
        )
    }

    useEffect(() => {

        let cancelled = false

        const fetchStoreDetails = async () => {

            await Promise.resolve()

            if (!user?.token) {

                if (cancelled) {
                    return
                }

                setIsLoading(false)

                setError(
                    "You are not logged in."
                )

                return
            }

            try {

                const response = await fetch(
                    "http://localhost:8080/api/store-owner/store",
                    {
                        method: "GET",
                        headers: {
                            "Authorization":
                                `Bearer ${user.token}`,
                            "Content-Type":
                                "application/json"
                        }
                    }
                )

                if (!response.ok) {

                    if (response.status === 401) {

                        throw new Error(
                            "Your session has expired. Please login again."
                        )
                    }

                    if (response.status === 403) {

                        throw new Error(
                            "You do not have permission to access store details."
                        )
                    }

                    const errorText =
                        await response.text()

                    throw new Error(
                        errorText ||
                        "Failed to load store details."
                    )
                }

                const data:
                    StoreOwnerDetailsResponse =
                    await response.json()

                if (cancelled) {
                    return
                }

                const details: StoreDetails = {

                    storeName:
                        data.storeName || "",

                    storeId:
                        data.storeId
                            ? `STORE-${String(
                                data.storeId
                            ).padStart(3, "0")}`
                            : "STORE-001",

                    ownerName:
                        data.ownerName ||
                        `${data.firstName || ""} ${
                            data.lastName || ""
                        }`.trim(),

                    email:
                        data.email ||
                        user.email ||
                        "",

                    mobile:
                        data.phone || "",

                    businessType:
                        data.businessType || "",

                    gstNumber:
                        data.gstNumber || "",

                    addressLine:
                        data.addressLine || "",

                    city:
                        data.city || "",

                    state:
                        data.state || "",

                    pincode:
                        data.pincode || "",

                    latitude:
                        data.latitude ?? null,

                    longitude:
                        data.longitude ?? null
                }

                setStoreDetails(details)
                setFormData(details)

                localStorage.setItem(
                    STORE_DETAILS_KEY,
                    JSON.stringify(details)
                )

                setIsEditing(
                    !isStoreDetailsComplete(details)
                )

                setLocationConfirmed(
                    details.latitude !== null &&
                    details.longitude !== null
                )

                setError("")
                setIsLoading(false)

            } catch (err) {

                if (cancelled) {
                    return
                }

                console.error(
                    "Failed to load store details:",
                    err
                )

                setError(
                    err instanceof Error
                        ? err.message
                        : "Failed to load store details."
                )

                setIsLoading(false)
            }
        }

        fetchStoreDetails()

        return () => {
            cancelled = true
        }

    }, [user?.token, user?.email])

    const handleEdit = () => {

        setFormData(storeDetails)

        setLocationConfirmed(
            storeDetails.latitude !== null &&
            storeDetails.longitude !== null
        )

        setIsEditing(true)
        setError("")
    }

    const handleCancel = () => {

        setFormData(storeDetails)

        setLocationConfirmed(
            storeDetails.latitude !== null &&
            storeDetails.longitude !== null
        )

        setError("")

        if (isStoreDetailsComplete(storeDetails)) {
            setIsEditing(false)
        }
    }

    const handleChange = (
        e: React.ChangeEvent<HTMLInputElement>
    ) => {

        const { name, value } = e.target

        setFormData(prev => ({
            ...prev,
            [name]: value
        }))

        if (
            name === "addressLine" ||
            name === "city" ||
            name === "state" ||
            name === "pincode"
        ) {
            setLocationConfirmed(false)
        }
    }

    const handleFindLocation = async () => {

        if (!user?.token) {

            setError(
                "You are not logged in. Please login again."
            )

            return
        }

        if (
            !formData.addressLine.trim() ||
            !formData.city.trim() ||
            !formData.state.trim() ||
            !formData.pincode.trim()
        ) {

            setError(
                "Please complete the address, city, state and pincode before finding the location."
            )

            return
        }

        try {

            setIsFindingLocation(true)
            setLocationConfirmed(false)
            setError("")

            const response = await fetch(
                "http://localhost:8080/api/location/search",
                {
                    method: "POST",
                    headers: {
                        "Authorization":
                            `Bearer ${user.token}`,
                        "Content-Type":
                            "application/json"
                    },
                    body: JSON.stringify({

                        addressLine:
                            formData.addressLine.trim(),

                        city:
                            formData.city.trim(),

                        state:
                            formData.state.trim(),

                        pincode:
                            formData.pincode.trim()
                    })
                }
            )

            if (!response.ok) {

                const errorText =
                    await response.text()

                let message =
                    "Unable to find the location."

                try {

                    const errorData =
                        JSON.parse(errorText)

                    message =
                        errorData.message ||
                        errorData.error ||
                        message

                } catch {

                    if (errorText) {
                        message = errorText
                    }
                }

                throw new Error(message)
            }

            const data =
                await response.json()

            if (
                typeof data.latitude !==
                "number" ||
                typeof data.longitude !==
                "number"
            ) {

                throw new Error(
                    "The location service did not return valid coordinates."
                )
            }

            setFormData(prev => ({
                ...prev,
                latitude:
                data.latitude,
                longitude:
                data.longitude
            }))

        } catch (err) {

            console.error(
                "Failed to find location:",
                err
            )

            setError(
                err instanceof Error
                    ? err.message
                    : "Unable to find the location."
            )

        } finally {

            setIsFindingLocation(false)
        }
    }

    const handleLocationChange = (
        latitude: number,
        longitude: number
    ) => {

        setFormData(prev => ({
            ...prev,
            latitude,
            longitude
        }))

        setLocationConfirmed(false)
    }

    const handleConfirmLocation = () => {

        if (
            formData.latitude === null ||
            formData.longitude === null
        ) {

            setError(
                "Please find and select a location on the map first."
            )

            return
        }

        setLocationConfirmed(true)
        setError("")
    }

    const handleSave = async () => {

        if (!user?.token) {

            alert(
                "You are not logged in. Please login again."
            )

            return
        }

        if (!isStoreDetailsComplete(formData)) {

            alert(
                "Please complete all store details before saving."
            )

            return
        }

        if (
            !locationConfirmed ||
            formData.latitude === null ||
            formData.longitude === null
        ) {

            alert(
                "Please find and confirm your store location before saving."
            )

            return
        }

        try {

            setIsSaving(true)
            setError("")

            const ownerNameParts =
                formData.ownerName
                    .trim()
                    .split(/\s+/)

            const firstName =
                ownerNameParts[0] || ""

            const lastName =
                ownerNameParts
                    .slice(1)
                    .join(" ")

            if (!firstName || !lastName) {

                throw new Error(
                    "Please enter the owner's first name and last name."
                )
            }

            const requestBody = {

                firstName,

                lastName,

                phone:
                    formData.mobile.trim(),

                storeName:
                    formData.storeName.trim(),

                businessType:
                    formData.businessType.trim(),

                gstNumber:
                    formData.gstNumber.trim(),

                addressLine:
                    formData.addressLine.trim(),

                city:
                    formData.city.trim(),

                state:
                    formData.state.trim(),

                pincode:
                    formData.pincode.trim(),

                latitude:
                formData.latitude,

                longitude:
                formData.longitude
            }

            const response = await fetch(
                "http://localhost:8080/api/store-owner/store",
                {
                    method: "PUT",
                    headers: {
                        "Authorization":
                            `Bearer ${user.token}`,
                        "Content-Type":
                            "application/json"
                    },
                    body:
                        JSON.stringify(
                            requestBody
                        )
                }
            )

            if (!response.ok) {

                const errorText =
                    await response.text()

                let message =
                    "Failed to update store details."

                try {

                    const errorData =
                        JSON.parse(errorText)

                    message =
                        errorData.message ||
                        errorData.error ||
                        message

                } catch {

                    if (errorText) {
                        message = errorText
                    }
                }

                throw new Error(message)
            }

            const data:
                StoreOwnerDetailsResponse =
                await response.json()

            const updatedDetails:
                StoreDetails = {

                storeName:
                    data.storeName || "",

                storeId:
                    data.storeId
                        ? `STORE-${String(
                            data.storeId
                        ).padStart(3, "0")}`
                        : formData.storeId,

                ownerName:
                    data.ownerName ||
                    `${data.firstName || ""} ${
                        data.lastName || ""
                    }`.trim(),

                email:
                    data.email ||
                    user.email ||
                    "",

                mobile:
                    data.phone || "",

                businessType:
                    data.businessType || "",

                gstNumber:
                    data.gstNumber || "",

                addressLine:
                    data.addressLine || "",

                city:
                    data.city || "",

                state:
                    data.state || "",

                pincode:
                    data.pincode || "",

                latitude:
                    data.latitude ?? null,

                longitude:
                    data.longitude ?? null
            }

            setStoreDetails(updatedDetails)
            setFormData(updatedDetails)

            localStorage.setItem(
                STORE_DETAILS_KEY,
                JSON.stringify(
                    updatedDetails
                )
            )

            setLocationConfirmed(
                updatedDetails.latitude !== null &&
                updatedDetails.longitude !== null
            )

            setIsEditing(false)

            alert(
                "Store details updated successfully!"
            )

        } catch (err) {

            console.error(
                "Failed to save store details:",
                err
            )

            const message =
                err instanceof Error
                    ? err.message
                    : "Failed to update store details."

            setError(message)
            alert(message)

        } finally {

            setIsSaving(false)
        }
    }

    const detailsComplete =
        isStoreDetailsComplete(storeDetails)

    if (isLoading) {

        return (
            <div className="owner-page">

                <div className="owner-page-header">

                    <div>

                        <h1>
                            My Store
                        </h1>

                        <p>
                            Manage your store and business information.
                        </p>

                    </div>

                </div>

                <div className="owner-section-card owner-loading-card">

                    <div className="owner-loading-icon">
                        🏪
                    </div>

                    <div>

                        <h2>
                            Loading Store Details
                        </h2>

                        <p>
                            Getting your store information from the database.
                        </p>

                    </div>

                </div>

            </div>
        )
    }

    return (
        <div className="owner-page">

            {/* =====================================================
                PAGE HEADER
            ===================================================== */}

            <div className="owner-page-header">

                <div>

                    <h1>
                        My Store
                    </h1>

                    <p>
                        Manage your store profile, business information,
                        address and location.
                    </p>

                </div>

                {!isEditing && (
                    <button
                        className="owner-primary-btn owner-edit-store-btn"
                        onClick={handleEdit}
                    >
                        <span>✏️</span>
                        Edit Details
                    </button>
                )}

            </div>


            {/* =====================================================
                ERROR
            ===================================================== */}

            {error && (

                <div className="owner-store-alert">

                    <div className="owner-store-alert-icon">
                        !
                    </div>

                    <div>

                        <strong>
                            Store information issue
                        </strong>

                        <p>
                            {error}
                        </p>

                    </div>

                </div>
            )}


            {/* =====================================================
                INCOMPLETE STORE
            ===================================================== */}

            {!detailsComplete && !isEditing && (

                <div className="owner-store-completion-card">

                    <div className="owner-store-completion-icon">
                        ⚠
                    </div>

                    <div className="owner-store-completion-content">

                        <span className="owner-mini-label">
                            ACTION REQUIRED
                        </span>

                        <h2>
                            Complete Your Store Details
                        </h2>

                        <p>
                            Complete your store information and confirm
                            your location before adding products.
                        </p>

                    </div>

                    <button
                        className="owner-primary-btn"
                        onClick={handleEdit}
                    >
                        Complete Store
                    </button>

                </div>
            )}


            {/* =====================================================
                EDIT MODE
            ===================================================== */}

            {isEditing ? (

                <div className="owner-store-edit">

                    {/* =================================================
                        STORE DETAILS
                    ================================================= */}

                    <div className="owner-section-card owner-store-form-card">

                        <div className="owner-section-header owner-enhanced-section-header">

                            <div className="owner-section-heading-wrap">

                                <div className="owner-section-icon">
                                    🏪
                                </div>

                                <div>

                                    <span className="owner-card-eyebrow">
                                        STORE PROFILE
                                    </span>

                                    <h2>
                                        Store Details
                                    </h2>

                                    <p>
                                        Basic information about your store
                                        and store owner.
                                    </p>

                                </div>

                            </div>

                        </div>

                        <div className="owner-form-grid">

                            <div className="owner-form-group">

                                <label>
                                    Store Name *
                                </label>

                                <input
                                    type="text"
                                    name="storeName"
                                    value={formData.storeName}
                                    onChange={handleChange}
                                    placeholder="Enter store name"
                                />

                            </div>

                            <div className="owner-form-group">

                                <label>
                                    Store ID
                                </label>

                                <input
                                    type="text"
                                    value={formData.storeId}
                                    disabled
                                />

                                <small className="owner-field-hint">
                                    Store ID is assigned automatically.
                                </small>

                            </div>

                            <div className="owner-form-group">

                                <label>
                                    Owner Name *
                                </label>

                                <input
                                    type="text"
                                    name="ownerName"
                                    value={formData.ownerName}
                                    onChange={handleChange}
                                    placeholder="Enter first and last name"
                                />

                            </div>

                            <div className="owner-form-group">

                                <label>
                                    Email
                                </label>

                                <input
                                    type="email"
                                    value={formData.email}
                                    disabled
                                />

                                <small className="owner-field-hint">
                                    Email is linked to your account.
                                </small>

                            </div>

                            <div className="owner-form-group">

                                <label>
                                    Mobile *
                                </label>

                                <input
                                    type="text"
                                    name="mobile"
                                    value={formData.mobile}
                                    onChange={handleChange}
                                    placeholder="Enter mobile number"
                                />

                            </div>

                        </div>

                    </div>


                    {/* =================================================
                        BUSINESS INFORMATION
                    ================================================= */}

                    <div className="owner-section-card owner-store-form-card">

                        <div className="owner-section-header owner-enhanced-section-header">

                            <div className="owner-section-heading-wrap">

                                <div className="owner-section-icon">
                                    📄
                                </div>

                                <div>

                                    <span className="owner-card-eyebrow">
                                        BUSINESS PROFILE
                                    </span>

                                    <h2>
                                        Business Information
                                    </h2>

                                    <p>
                                        Enter your business registration
                                        information.
                                    </p>

                                </div>

                            </div>

                        </div>

                        <div className="owner-form-grid">

                            <div className="owner-form-group">

                                <label>
                                    Business Type *
                                </label>

                                <input
                                    type="text"
                                    name="businessType"
                                    value={formData.businessType}
                                    onChange={handleChange}
                                    placeholder="Example: Grocery"
                                />

                            </div>

                            <div className="owner-form-group">

                                <label>
                                    GST Number *
                                </label>

                                <input
                                    type="text"
                                    name="gstNumber"
                                    value={formData.gstNumber}
                                    onChange={handleChange}
                                    placeholder="Enter GST number"
                                />

                            </div>

                        </div>

                    </div>


                    {/* =================================================
                        ADDRESS
                    ================================================= */}

                    <div className="owner-section-card owner-store-form-card owner-address-form-card">

                        <div className="owner-section-header owner-enhanced-section-header">

                            <div className="owner-section-heading-wrap">

                                <div className="owner-section-icon">
                                    📍
                                </div>

                                <div>

                                    <span className="owner-card-eyebrow">
                                        STORE LOCATION
                                    </span>

                                    <h2>
                                        Address
                                    </h2>

                                    <p>
                                        Enter your complete store address
                                        to locate it on the map.
                                    </p>

                                </div>

                            </div>

                        </div>

                        <div className="owner-form-grid">

                            <div className="owner-form-group owner-full-width">

                                <label>
                                    Address Line *
                                </label>

                                <input
                                    type="text"
                                    name="addressLine"
                                    value={formData.addressLine}
                                    onChange={handleChange}
                                    placeholder="Enter complete store address"
                                />

                            </div>

                            <div className="owner-form-group">

                                <label>
                                    City *
                                </label>

                                <input
                                    type="text"
                                    name="city"
                                    value={formData.city}
                                    onChange={handleChange}
                                    placeholder="Enter city"
                                />

                            </div>

                            <div className="owner-form-group">

                                <label>
                                    State *
                                </label>

                                <input
                                    type="text"
                                    name="state"
                                    value={formData.state}
                                    onChange={handleChange}
                                    placeholder="Enter state"
                                />

                            </div>

                            <div className="owner-form-group">

                                <label>
                                    Pincode *
                                </label>

                                <input
                                    type="text"
                                    name="pincode"
                                    value={formData.pincode}
                                    onChange={handleChange}
                                    placeholder="Enter pincode"
                                />

                            </div>

                        </div>


                        {/* =================================================
                            LOCATION SEARCH
                        ================================================= */}

                        <div className="owner-location-action-area">

                            <div className="owner-location-action-info">

                                <div className="owner-location-action-icon">
                                    📍
                                </div>

                                <div>

                                    <strong>
                                        Find Store Location
                                    </strong>

                                    <span>
                                        Use the address above to locate
                                        your store on the map.
                                    </span>

                                </div>

                            </div>

                            <button
                                type="button"
                                className="owner-primary-btn owner-location-button"
                                onClick={handleFindLocation}
                                disabled={isFindingLocation}
                            >
                                {isFindingLocation
                                    ? "Finding Location..."
                                    : "📍 Find Location"
                                }
                            </button>

                        </div>


                        {/* =================================================
                            LOCATION PICKER
                        ================================================= */}

                        {formData.latitude !== null &&
                            formData.longitude !== null && (

                                <div className="owner-location-picker-wrapper">

                                    <div className="owner-map-header">

                                        <div>

                                            <span className="owner-card-eyebrow">
                                                MAP POSITION
                                            </span>

                                            <strong>
                                                Confirm Your Store Location
                                            </strong>

                                            <p>
                                                Move the marker if necessary
                                                and confirm the exact location.
                                            </p>

                                        </div>

                                        <span
                                            className={
                                                locationConfirmed
                                                    ? "owner-location-status confirmed"
                                                    : "owner-location-status pending"
                                            }
                                        >
                                            {locationConfirmed
                                                ? "✓ Confirmed"
                                                : "Pending Confirmation"
                                            }
                                        </span>

                                    </div>

                                    <LocationPicker
                                        initialLatitude={
                                            formData.latitude
                                        }
                                        initialLongitude={
                                            formData.longitude
                                        }
                                        onLocationChange={
                                            handleLocationChange
                                        }
                                        onConfirm={
                                            handleConfirmLocation
                                        }
                                    />

                                    <div
                                        className={
                                            locationConfirmed
                                                ? "location-confirmation-success"
                                                : "location-confirmation-pending"
                                        }
                                    >
                                        <span>
                                            {locationConfirmed
                                                ? "✓"
                                                : "!"}
                                        </span>

                                        <div>

                                            <strong>
                                                {locationConfirmed
                                                    ? "Location confirmed"
                                                    : "Location confirmation required"}
                                            </strong>

                                            <p>
                                                {locationConfirmed
                                                    ? "Your store location is ready to be saved."
                                                    : "Move the marker if necessary, then click Confirm Location."
                                                }
                                            </p>

                                        </div>

                                    </div>

                                </div>
                            )}

                    </div>


                    {/* =================================================
                        FORM ACTIONS
                    ================================================= */}

                    <div className="owner-form-actions owner-store-form-actions">

                        <div className="owner-form-action-note">

                            <span>
                                🔒
                            </span>

                            <p>
                                Your store information is securely
                                saved to your account.
                            </p>

                        </div>

                        <div className="owner-form-action-buttons">

                            {detailsComplete && (

                                <button
                                    className="owner-secondary-btn"
                                    onClick={handleCancel}
                                    disabled={isSaving}
                                >
                                    Cancel
                                </button>
                            )}

                            <button
                                className="owner-primary-btn owner-save-store-btn"
                                onClick={handleSave}
                                disabled={
                                    isSaving ||
                                    !locationConfirmed
                                }
                            >
                                {isSaving
                                    ? "Saving..."
                                    : "💾 Save Store Details"
                                }
                            </button>

                        </div>

                    </div>

                </div>

            ) : (

                /* =====================================================
                   VIEW MODE
                ===================================================== */

                <div className="owner-store-grid">

                    {/* =================================================
                        STORE DETAILS
                    ================================================= */}

                    <div className="owner-section-card owner-store-view-card">

                        <div className="owner-section-header owner-enhanced-section-header">

                            <div className="owner-section-heading-wrap">

                                <div className="owner-section-icon">
                                    🏪
                                </div>

                                <div>

                                    <span className="owner-card-eyebrow">
                                        STORE PROFILE
                                    </span>

                                    <h2>
                                        Store Details
                                    </h2>

                                    <p>
                                        Basic information about your store.
                                    </p>

                                </div>

                            </div>

                            <div className="owner-profile-status">
                                <span></span>
                                Active
                            </div>

                        </div>

                        <div className="owner-info-list owner-enhanced-info-list">

                            <div className="owner-info-row">

                                <div className="owner-info-label">

                                    <span className="owner-info-icon">
                                        🏪
                                    </span>

                                    <span>
                                        Store Name
                                    </span>

                                </div>

                                <strong>
                                    {storeDetails.storeName}
                                </strong>

                            </div>

                            <div className="owner-info-row">

                                <div className="owner-info-label">

                                    <span className="owner-info-icon">
                                        #
                                    </span>

                                    <span>
                                        Store ID
                                    </span>

                                </div>

                                <strong className="owner-store-id-value">
                                    {storeDetails.storeId}
                                </strong>

                            </div>

                            <div className="owner-info-row">

                                <div className="owner-info-label">

                                    <span className="owner-info-icon">
                                        👤
                                    </span>

                                    <span>
                                        Owner Name
                                    </span>

                                </div>

                                <strong>
                                    {storeDetails.ownerName}
                                </strong>

                            </div>

                            <div className="owner-info-row">

                                <div className="owner-info-label">

                                    <span className="owner-info-icon">
                                        ✉
                                    </span>

                                    <span>
                                        Email
                                    </span>

                                </div>

                                <strong>
                                    {storeDetails.email}
                                </strong>

                            </div>

                            <div className="owner-info-row">

                                <div className="owner-info-label">

                                    <span className="owner-info-icon">
                                        ☎
                                    </span>

                                    <span>
                                        Mobile
                                    </span>

                                </div>

                                <strong>
                                    {storeDetails.mobile}
                                </strong>

                            </div>

                        </div>

                    </div>


                    {/* =================================================
                        BUSINESS INFORMATION
                    ================================================= */}

                    <div className="owner-section-card owner-store-view-card">

                        <div className="owner-section-header owner-enhanced-section-header">

                            <div className="owner-section-heading-wrap">

                                <div className="owner-section-icon">
                                    📄
                                </div>

                                <div>

                                    <span className="owner-card-eyebrow">
                                        BUSINESS PROFILE
                                    </span>

                                    <h2>
                                        Business Information
                                    </h2>

                                    <p>
                                        Business and registration details.
                                    </p>

                                </div>

                            </div>

                        </div>

                        <div className="owner-business-highlight">

                            <div className="owner-business-highlight-icon">
                                🏢
                            </div>

                            <div>

                                <span>
                                    BUSINESS TYPE
                                </span>

                                <strong>
                                    {storeDetails.businessType}
                                </strong>

                            </div>

                        </div>

                        <div className="owner-info-list owner-enhanced-info-list">

                            <div className="owner-info-row">

                                <div className="owner-info-label">

                                    <span className="owner-info-icon">
                                        🏷
                                    </span>

                                    <span>
                                        Business Type
                                    </span>

                                </div>

                                <strong>
                                    {storeDetails.businessType}
                                </strong>

                            </div>

                            <div className="owner-info-row">

                                <div className="owner-info-label">

                                    <span className="owner-info-icon">
                                        ✓
                                    </span>

                                    <span>
                                        GST Number
                                    </span>

                                </div>

                                <strong>
                                    {storeDetails.gstNumber}
                                </strong>

                            </div>

                        </div>

                    </div>


                    {/* =================================================
                        ADDRESS
                    ================================================= */}

                    <div className="owner-section-card owner-full-width owner-store-view-card owner-address-view-card">

                        <div className="owner-section-header owner-enhanced-section-header">

                            <div className="owner-section-heading-wrap">

                                <div className="owner-section-icon">
                                    📍
                                </div>

                                <div>

                                    <span className="owner-card-eyebrow">
                                        STORE LOCATION
                                    </span>

                                    <h2>
                                        Address
                                    </h2>

                                    <p>
                                        Registered store address and
                                        location status.
                                    </p>

                                </div>

                            </div>

                            {storeDetails.latitude !== null &&
                                storeDetails.longitude !== null && (

                                    <div className="owner-profile-status">

                                        <span></span>
                                        Location Confirmed

                                    </div>
                                )}

                        </div>

                        <div className="owner-address-display">

                            <div className="owner-address-icon">
                                📍
                            </div>

                            <div className="owner-address-content">

                                <span>
                                    REGISTERED STORE ADDRESS
                                </span>

                                <strong>
                                    {storeDetails.addressLine}
                                </strong>

                                <p>
                                    {storeDetails.city},{" "}
                                    {storeDetails.state} -{" "}
                                    {storeDetails.pincode}
                                </p>

                            </div>

                        </div>

                        <div className="owner-location-summary">

                            <div className="owner-location-summary-icon">
                                {storeDetails.latitude !== null &&
                                storeDetails.longitude !== null
                                    ? "✓"
                                    : "!"}
                            </div>

                            <div>

                                <strong>
                                    {storeDetails.latitude !== null &&
                                    storeDetails.longitude !== null
                                        ? "Store location confirmed"
                                        : "Store location not confirmed"}
                                </strong>

                                <span>
                                    {storeDetails.latitude !== null &&
                                    storeDetails.longitude !== null
                                        ? "Your store has a verified map location."
                                        : "Edit your store details and confirm the map location."
                                    }
                                </span>

                            </div>

                        </div>

                    </div>

                </div>
            )}

        </div>
    )
}

export default StoreOwnerStore