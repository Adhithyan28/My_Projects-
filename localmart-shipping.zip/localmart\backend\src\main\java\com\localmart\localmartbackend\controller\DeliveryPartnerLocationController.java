package com.localmart.localmartbackend.controller;

import com.localmart.localmartbackend.dto.DeliveryPartnerAvailabilityRequest;
import com.localmart.localmartbackend.dto.DeliveryPartnerLocationRequest;
import com.localmart.localmartbackend.entity.DeliveryPartnerLocation;
import com.localmart.localmartbackend.service.DeliveryPartnerLocationService;

import jakarta.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/delivery-partner")
public class DeliveryPartnerLocationController {

    private final DeliveryPartnerLocationService locationService;

    public DeliveryPartnerLocationController(
            DeliveryPartnerLocationService locationService) {

        this.locationService = locationService;
    }

    @PostMapping("/location")
    public ResponseEntity<?> updateLocation(
            @Valid @RequestBody DeliveryPartnerLocationRequest request,
            Authentication authentication) {

        Long userId;

        try {

            userId = Long.valueOf(
                    authentication.getPrincipal().toString()
            );

        } catch (Exception e) {

            return ResponseEntity
                    .badRequest()
                    .body(Map.of(
                            "message",
                            "Unable to identify authenticated user"
                    ));
        }

        DeliveryPartnerLocation location =
                locationService.updateLocation(
                        userId,
                        request
                );

        return ResponseEntity.ok(
                Map.of(
                        "message",
                        "Location updated successfully",
                        "userId",
                        location.getUserId(),
                        "latitude",
                        location.getLatitude(),
                        "longitude",
                        location.getLongitude(),
                        "updatedAt",
                        location.getUpdatedAt()
                )
        );
    }

    @PostMapping("/availability")
    public ResponseEntity<?> updateAvailability(
            @Valid @RequestBody DeliveryPartnerAvailabilityRequest request,
            Authentication authentication) {

        Long userId;

        try {

            userId = Long.valueOf(
                    authentication.getPrincipal().toString()
            );

        } catch (Exception e) {

            return ResponseEntity
                    .badRequest()
                    .body(Map.of(
                            "message",
                            "Unable to identify authenticated user"
                    ));
        }

        try {

            DeliveryPartnerLocation location =
                    locationService.updateAvailability(
                            userId,
                            request
                    );

            if (location == null) {

                return ResponseEntity.ok(
                        Map.of(
                                "message",
                                "Delivery partner is now offline",
                                "status",
                                "OFFLINE"
                        )
                );
            }

            return ResponseEntity.ok(
                    Map.of(
                            "message",
                            request.getStatus()
                                    .equalsIgnoreCase("AVAILABLE")
                                    ? "You are now online"
                                    : "You are now offline",

                            "status",
                            location.getAvailabilityStatus(),

                            "userId",
                            location.getUserId(),

                            "updatedAt",
                            location.getUpdatedAt()
                    )
            );

        } catch (IllegalArgumentException e) {

            return ResponseEntity
                    .badRequest()
                    .body(Map.of(
                            "message",
                            e.getMessage()
                    ));
        }
    }
    @GetMapping("/location")
    public ResponseEntity<?> getLocation(
            Authentication authentication) {

        Long userId;

        try {

            userId = Long.valueOf(
                    authentication.getPrincipal().toString()
            );

        } catch (Exception e) {

            return ResponseEntity
                    .badRequest()
                    .body(
                            Map.of(
                                    "message",
                                    "Unable to identify authenticated user"
                            )
                    );
        }

        DeliveryPartnerLocation location =
                locationService.getLocation(userId);

        if (location == null) {

            return ResponseEntity
                    .ok(
                            Map.of(
                                    "message",
                                    "No location available"
                            )
                    );
        }

        return ResponseEntity.ok(
                Map.of(
                        "userId",
                        location.getUserId(),

                        "latitude",
                        location.getLatitude(),

                        "longitude",
                        location.getLongitude(),

                        "availabilityStatus",
                        location.getAvailabilityStatus(),

                        "updatedAt",
                        location.getUpdatedAt()
                )
        );
    }
}