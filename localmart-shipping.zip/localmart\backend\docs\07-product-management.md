# LocalMart — Product Management

## 1. Overview

The Product Management Module is responsible for managing the products available through LocalMart stores.

Products are the core items that customers browse, add to their cart, purchase, and receive through the delivery system.

The product module connects the store side of the platform with the customer shopping experience:

```text
Store Owner
     |
     v
   Store
     |
     v
 Products
     |
     v
 Customers
     |
     v
    Cart
     |
     v
   Orders
```

The module is responsible for the product-related lifecycle from storing product information to making products available for customer browsing and purchasing.

---

# 2. Product Management Responsibilities

The Product Management Module handles product-related operations such as:

* Product creation
* Product retrieval
* Product updates
* Product association with stores
* Product categorization
* Product pricing
* Product availability
* Product information presented to customers
* Product usage within carts
* Product usage within orders

The exact fields and business rules are defined by the `Product` entity, `ProductService`, `ProductController`, and database schema.

---

# 3. Product Management Architecture

The module follows the standard LocalMart layered architecture:

```text
Store Owner / Customer
        |
        v
React Frontend
        |
        | HTTP
        v
ProductController
        |
        v
ProductService
        |
        v
ProductRepository
        |
        v
PostgreSQL
```

The product module also interacts with other business modules:

```text
                    Product
                       |
       +---------------+---------------+
       |               |               |
       v               v               v
     Store          Category          Cart
                                       |
                                       v
                                     Order
```

---

# 4. Product Entity

The `Product` entity represents a product stored in the LocalMart database.

Conceptually:

```text
Product
 |
 +--> Product ID
 |
 +--> Product Name
 |
 +--> Description
 |
 +--> Price
 |
 +--> Category
 |
 +--> Store
 |
 +--> Availability / Stock
```

The actual attributes depend on the current `Product` entity and database schema.

---

# 5. Product and Store Relationship

A product belongs to a store context.

The relationship can be represented as:

```text
Store
 |
 +--> Product 1
 |
 +--> Product 2
 |
 +--> Product 3
 |
 +--> Product 4
```

This is important because LocalMart is a multi-store local-commerce platform.

The same type of product can potentially exist in different stores with different store-specific information.

For example:

```text
Store A
   |
   +--> Milk
   +--> Bread

Store B
   |
   +--> Milk
   +--> Eggs
```

The product is therefore associated with the store from which the customer purchases it.

---

# 6. Store Owner and Product Ownership

Products are managed within the store-owner side of the application.

The conceptual relationship is:

```text
Store Owner
     |
     v
   Store
     |
     v
 Products
```

The store owner is responsible for managing products associated with their store.

Customers consume the product information through the shopping interface.

```text
Store Owner
     |
     | manages
     v
  Products
     |
     | browses
     v
 Customer
```

---

# 7. Product Creation

The product creation process begins from the store-owner side.

A simplified flow is:

```text
Store Owner
     |
     v
Product Management
     |
     v
Enter Product Information
     |
     v
ProductController
     |
     v
ProductService
     |
     v
ProductRepository
     |
     v
PostgreSQL
```

The service layer performs the relevant business processing before the product is persisted.

---

# 8. Product Validation

Product information received from a client should be validated before persistence.

Typical validation concerns include:

* Required product information
* Valid product name
* Valid price
* Valid category
* Valid store association
* Valid availability/stock information where applicable

The exact validation rules are determined by the current implementation.

The general principle is:

```text
Client Input
     |
     v
Validation
     |
     +---- Invalid ---> Error
     |
     v
Business Logic
     |
     v
Database
```

---

# 9. Product Identification

Each product has a unique identifier.

The product ID allows the backend to identify a specific product when performing operations such as:

```text
Get Product
Update Product
Delete Product
Add to Cart
Create Order Item
```

Conceptually:

```text
Product ID
    |
    +--> Product Details
    |
    +--> Cart Item
    |
    +--> Order Item
```

The product ID therefore becomes an important reference across the commerce system.

---

# 10. Product Name

The product name is the primary human-readable identifier displayed to customers.

For example:

```text
Product
 |
 +--> Name
```

The name is used throughout the customer shopping experience:

```text
Store
  |
  v
Products
  |
  v
Product Name
  |
  v
Cart
  |
  v
Order
```

---

# 11. Product Description

A product can contain descriptive information that helps customers understand what they are purchasing.

Conceptually:

```text
Product
 |
 +--> Name
 |
 +--> Description
```

The description is customer-facing information and should be returned through the product API where supported.

---

# 12. Product Price

The product price represents the product's monetary value within the LocalMart shopping system.

Conceptually:

```text
Product
   |
   v
Price
   |
   v
Cart Item
   |
   v
Order Item
```

Price information becomes important when calculating:

* Cart subtotal
* Order total
* Payment amount

The actual pricing rules are determined by the current order and product implementation.

---

# 13. Product Category

Products can be organized by category.

The customer frontend contains category-based browsing functionality:

```text
Categories
     |
     v
Category Products
```

Conceptually:

```text
Category
   |
   +--> Product
   +--> Product
   +--> Product
```

Categories provide a way for customers to discover products without browsing every product individually.

---

# 14. Category-Based Product Browsing

The customer flow is:

```text
Customer
   |
   v
Categories
   |
   v
Select Category
   |
   v
Category Products
   |
   v
Products
```

The backend retrieves the appropriate product data and returns it to the frontend.

This makes category browsing a product-discovery mechanism rather than a separate product storage system.

---

# 15. Store-Based Product Browsing

Customers can also discover products by first selecting a store.

The flow is:

```text
Customer
   |
   v
Stores
   |
   v
Select Store
   |
   v
Store Products
   |
   v
Product
```

This provides the store context for every product displayed.

---

# 16. Product Retrieval

Product retrieval follows the standard backend request flow:

```text
React
  |
  | HTTP Request
  v
ProductController
  |
  v
ProductService
  |
  v
ProductRepository
  |
  v
PostgreSQL
  |
  v
Product Data
  |
  v
JSON Response
  |
  v
React
```

The controller handles the HTTP boundary.

The service handles business logic.

The repository handles persistence.

---

# 17. ProductService

`ProductService` acts as the business-logic layer for product operations.

Its responsibility is to coordinate product-related operations between:

```text
Controller
     |
     v
ProductService
     |
     v
Repository
```

This keeps product business logic out of the controller and database-access logic out of the frontend.

---

# 18. ProductController

`ProductController` exposes product-related REST endpoints.

Its role is to:

* Receive HTTP requests
* Read request parameters/body data
* Call `ProductService`
* Return appropriate responses

The controller should act as the API boundary rather than containing the complete product business workflow.

The architectural pattern is:

```text
HTTP Request
     |
     v
ProductController
     |
     v
ProductService
     |
     v
ProductRepository
```

---

# 19. ProductRepository

`ProductRepository` provides the persistence layer for products.

Conceptually:

```text
ProductService
      |
      v
ProductRepository
      |
      v
PostgreSQL
```

The repository abstracts database operations from the service layer.

This allows the service to work with product data without directly managing SQL/database connections.

---

# 20. Product and Cart Relationship

When a customer adds a product to their cart, the cart item references the product.

The relationship is:

```text
Cart
 |
 +--> Cart Item
        |
        +--> Product
```

A cart item therefore represents a customer's selected quantity of a particular product.

For example:

```text
Cart
 |
 +--> Product A × 2
 |
 +--> Product B × 1
```

---

# 21. Adding a Product to Cart

The conceptual flow is:

```text
Customer
    |
    v
Select Product
    |
    v
Add to Cart
    |
    v
CartController
    |
    v
CartService
    |
    v
ProductRepository
    |
    v
Validate Product
    |
    v
Cart Item
```

The product's identity and relevant information are used to create or update the corresponding cart item.

---

# 22. Product Quantity

A product can appear in the cart with a specific quantity.

Conceptually:

```text
Product
   |
   v
Cart Item
   |
   +--> Quantity
```

Changing the quantity changes the cart's calculated subtotal.

```text
Product Price × Quantity
          |
          v
     Cart Subtotal
```

The exact calculation is performed by the cart/order business logic.

---

# 23. Product and Orders

Products become part of an order through order items.

The relationship is:

```text
Order
 |
 +--> Order Item
        |
        +--> Product
```

An order can contain multiple products:

```text
Order
 |
 +--> Order Item
 |      |
 |      +--> Product A
 |
 +--> Order Item
        |
        +--> Product B
```

This allows the order to preserve the purchased product information as part of the order structure.

---

# 24. Product Lifecycle

A simplified product lifecycle is:

```text
Product Creation
       |
       v
Validation
       |
       v
Database Persistence
       |
       v
Available to Customers
       |
       v
Added to Cart
       |
       v
Purchased
       |
       v
Order Item
```

The product can continue to exist in the store catalog after a particular order has been completed.

---

# 25. Product Availability

Product availability determines whether a customer can meaningfully purchase a product.

Conceptually:

```text
Product
   |
   v
Availability
   |
   +----> Available
   |
   +----> Unavailable
```

Availability may depend on product/store business rules.

The exact implementation should follow the current `Product` entity and `ProductService`.

---

# 26. Product Stock

Where stock information is maintained, it becomes important during cart and order processing.

Conceptually:

```text
Product
   |
   v
Available Quantity
   |
   v
Customer Cart Quantity
   |
   v
Order
```

A typical business rule is:

```text
Requested Quantity <= Available Quantity
```

If the current implementation enforces stock differently, the actual implementation takes precedence over this conceptual model.

---

# 27. Product Updates

Store owners may need to update product information.

The general flow is:

```text
Store Owner
     |
     v
Edit Product
     |
     v
ProductController
     |
     v
ProductService
     |
     v
Validate Ownership / Input
     |
     v
Update Product
     |
     v
ProductRepository
     |
     v
PostgreSQL
```

Ownership validation is important so that one store owner cannot modify another store's products.

---

# 28. Product Deletion

If product deletion is supported, it follows the same ownership and business-rule principles.

```text
Store Owner
     |
     v
Delete Product
     |
     v
ProductController
     |
     v
ProductService
     |
     v
Validate Product
     |
     v
Validate Ownership
     |
     v
Repository
     |
     v
Database
```

Deletion behavior must also account for references from carts and orders according to the application's database constraints and business rules.

---

# 29. Product Ownership and Authorization

Product operations performed by store owners must be associated with the authenticated store owner.

Conceptually:

```text
JWT
 |
 v
Authenticated User
 |
 v
STORE_OWNER
 |
 v
Owned Store
 |
 v
Owned Product
```

This prevents a client from simply changing a product ID in a request and gaining access to another store's product.

Ownership is therefore a business-security concern as well as a database relationship.

---

# 30. Product and Customer Authorization

Customers interact with products differently from store owners.

### Customer

```text
Customer
   |
   +--> Browse
   +--> View
   +--> Add to Cart
   +--> Purchase
```

### Store Owner

```text
Store Owner
   |
   +--> Manage
   +--> Update
   +--> Maintain
```

The same product resource can therefore have different permissions depending on the authenticated role.

---

# 31. Product Data Flow

A customer retrieving a product can trigger:

```text
Customer
   |
   v
React Products Page
   |
   | HTTP
   v
ProductController
   |
   v
ProductService
   |
   v
ProductRepository
   |
   v
PostgreSQL
   |
   v
Product
   |
   v
JSON
   |
   v
React
```

This is the standard LocalMart read flow.

---

# 32. Product-to-Order Data Flow

When a product becomes part of a purchase:

```text
Product
   |
   v
Cart Item
   |
   v
Checkout
   |
   v
Order Item
   |
   v
Order
   |
   v
Payment
   |
   v
Delivery
```

This illustrates how the product module participates in the larger commerce lifecycle.

---

# 33. Product and Payment

Products indirectly contribute to the payment amount.

The relationship is:

```text
Product Price
      |
      v
Quantity
      |
      v
Order Item Amount
      |
      v
Order Total
      |
      v
Payment
```

The payment system uses the resulting order amount rather than independently managing product prices.

---

# 34. Product and Delivery

Products themselves are not delivered independently.

They become part of an order, and the order is delivered.

```text
Product
   |
   v
Order Item
   |
   v
Order
   |
   v
Delivery Partner
   |
   v
Customer
```

This keeps product management separate from delivery management.

---

# 35. Product and Store Location

Products inherit their delivery context from the store.

Conceptually:

```text
Product
   |
   v
Store
   |
   v
Store Location
   |
   v
Delivery Calculation
```

Therefore the product does not need to independently determine the delivery route.

The store provides the origin for the delivery process.

---

# 36. Database Relationships

The conceptual product relationships are:

```text
users
  |
  v
store_details
  |
  v
products
  |
  +--> cart_items
  |
  +--> order_items
```

Categories may also participate in the product relationship:

```text
category
    |
    v
products
```

The exact foreign-key mappings are determined by the current JPA entity relationships and PostgreSQL schema.

---

# 37. Product Module Backend Components

The product module contains the following major backend components:

```text
Controller
    |
    +--> ProductController

Service
    |
    +--> ProductService

Repository
    |
    +--> ProductRepository

Entity
    |
    +--> Product
```

These components follow the layered backend architecture.

---

# 38. Product Module Frontend Components

The current customer-facing product functionality includes pages such as:

```text
Products
StoreProducts
Categories
CategoryProducts
```

The conceptual navigation is:

```text
Customer
   |
   +--> Stores
   |      |
   |      +--> StoreProducts
   |
   +--> Categories
          |
          +--> CategoryProducts
```

The product information displayed by these pages comes through backend API communication.

---

# 39. Product Management and Store Management

The two modules have a direct relationship:

```text
Store Management
       |
       v
     Store
       |
       v
Product Management
       |
       v
    Products
```

Store Management establishes the business context.

Product Management manages the items offered within that context.

---

# 40. Product Management and Cart Management

The relationship is:

```text
Product Management
       |
       v
    Product
       |
       v
Cart Management
       |
       v
   Cart Item
```

The cart references products rather than duplicating the entire product-management responsibility.

---

# 41. Product Management and Order Management

The relationship is:

```text
Product Management
       |
       v
    Product
       |
       v
Order Management
       |
       v
   Order Item
```

The order module is responsible for the purchase lifecycle, while the product module provides the product information required by that lifecycle.

---

# 42. Product Management Security

Important security considerations include:

### Authentication

Protected product-management operations require an authenticated user.

### Role authorization

Store-owner operations should be restricted to the appropriate role.

### Ownership verification

A store owner should only modify products belonging to their store.

### Input validation

Product information must be validated before persistence.

### Database integrity

Product relationships with stores, carts, and orders must respect database constraints.

### Price integrity

Critical monetary values should be determined and validated by the backend rather than blindly trusting client-provided totals.

---

# 43. Product Module Request Flow

A typical product API request follows:

```text
Browser
   |
   | HTTP
   v
Spring Security
   |
   v
ProductController
   |
   v
ProductService
   |
   v
ProductRepository
   |
   v
PostgreSQL
```

The response travels back:

```text
PostgreSQL
   |
   v
ProductRepository
   |
   v
ProductService
   |
   v
ProductController
   |
   v
JSON
   |
   v
Browser
```

This separation keeps the responsibilities of each layer clear.

---

# 44. End-to-End Product Journey

A complete product journey can be represented as:

```text
                    STORE OWNER
                         |
                         v
                    Store Setup
                         |
                         v
                  Create Product
                         |
                         v
                    Validation
                         |
                         v
                    PostgreSQL
                         |
                         v
                     Product
                         |
              +----------+----------+
              |                     |
              v                     v
        Customer Browsing      Category Browsing
              |                     |
              +----------+----------+
                         |
                         v
                    Product View
                         |
                         v
                    Add to Cart
                         |
                         v
                     Checkout
                         |
                         v
                       Order
                         |
                         v
                    Order Item
                         |
                         v
                     Delivery
```

---

# 45. Product Module Boundaries

The Product Management Module interacts with:

```text
                 PRODUCT MANAGEMENT
                         |
       +-----------------+-----------------+
       |                 |                 |
       v                 v                 v
    STORE             CATEGORY           CART
       |                                   |
       |                                   v
       +-------------------------------> ORDER
                                           |
                                           v
                                       PAYMENT
                                           |
                                           v
                                       DELIVERY
```

This makes the product module one of the central components of LocalMart's commerce lifecycle.

---

# 46. Separation of Responsibilities

The module follows separation of concerns:

| Layer               | Responsibility                  |
| ------------------- | ------------------------------- |
| ProductController   | HTTP/API handling               |
| ProductService      | Product business logic          |
| ProductRepository   | Product persistence             |
| Product Entity      | Product database representation |
| React Product Pages | Customer/store-owner UI         |

The layers communicate in a controlled direction:

```text
Controller
    ↓
Service
    ↓
Repository
    ↓
Database
```

---

# 47. Important Design Principles

### Store-scoped products

Products belong to a store context.

### Database-driven catalog

Product information is retrieved from backend-managed data.

### Role-specific operations

Customers browse products while store owners manage their products.

### Ownership enforcement

Store owners should only modify products belonging to their stores.

### Product references

Cart items and order items reference products rather than making the product module responsible for cart/order behavior.

### Separation of concerns

Product business logic belongs in the service layer rather than the controller.

### Backend authority

Important product and monetary information should be validated by the backend.

---

# 48. Customer Product Experience

From the customer's perspective, the product module provides:

```text
Browse Stores
     |
     v
Select Store
     |
     v
View Products
     |
     +----> Select Category
     |          |
     |          v
     |      Category Products
     |
     v
Select Product
     |
     v
Add to Cart
     |
     v
Checkout
```

The customer does not need to understand the internal controller/service/repository architecture.

Those layers exist to provide a reliable backend for the shopping experience.

---

# 49. Store Owner Product Experience

From the store owner's perspective:

```text
Store Owner
     |
     v
Own Store
     |
     v
Product Management
     |
     +--> Create Product
     |
     +--> View Products
     |
     +--> Update Product
     |
     +--> Maintain Availability
```

The exact operations exposed by the current application are determined by the implemented `ProductController` and `ProductService`.

---

# 50. Summary

The Product Management Module manages the products offered by LocalMart stores and connects store operations with customer shopping.

The core relationship is:

```text
Store Owner
     |
     v
   Store
     |
     v
  Product
     |
     +------> Customer Browsing
     |
     +------> Cart
     |
     +------> Order
                  |
                  v
               Payment
                  |
                  v
               Delivery
```

At the backend level:

```text
React
  |
  v
ProductController
  |
  v
ProductService
  |
  v
ProductRepository
  |
  v
PostgreSQL
```

The Product Module therefore acts as the central catalog layer of LocalMart, providing the products that move through the rest of the commerce lifecycle—from store management, to customer browsing, to cart, checkout, order, payment, and delivery.
