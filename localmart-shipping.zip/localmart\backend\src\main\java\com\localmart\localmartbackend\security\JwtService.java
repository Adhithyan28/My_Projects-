package com.localmart.localmartbackend.security;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;

@Service
public class JwtService {

    private static final long EXPIRATION_TIME =
            1000L * 60 * 60 * 24;

    private final SecretKey key;

    public JwtService(@Value("${localmart.jwt.secret}") String secret) {

        if (secret == null || secret.length() < 32) {
            throw new IllegalStateException("LOCALMART_JWT_SECRET must contain at least 32 characters.");
        }

        key = Keys.hmacShaKeyFor(
                secret.getBytes(StandardCharsets.UTF_8)
        );
    }

    // ============================================================
    // GENERATE TOKEN
    // ============================================================

    public String generateToken(
            Long userId,
            String email,
            String role,
            String sessionId) {

        Date now =
                new Date();

        Date expiration =
                new Date(
                        now.getTime()
                                + EXPIRATION_TIME
                );

        return Jwts.builder()
                .subject(
                        String.valueOf(userId)
                )
                .claim(
                        "email",
                        email
                )
                .claim(
                        "role",
                        role
                )
                .claim(
                        "sessionId",
                        sessionId
                )
                .issuedAt(now)
                .expiration(expiration)
                .signWith(key)
                .compact();
    }

    // ============================================================
    // EXTRACT USER ID
    // ============================================================

    public Long extractUserId(
            String token) {

        String userId =
                Jwts.parser()
                        .verifyWith(key)
                        .build()
                        .parseSignedClaims(token)
                        .getPayload()
                        .getSubject();

        return Long.valueOf(userId);
    }

    // ============================================================
    // EXTRACT ROLE
    // ============================================================

    public String extractRole(
            String token) {

        return Jwts.parser()
                .verifyWith(key)
                .build()
                .parseSignedClaims(token)
                .getPayload()
                .get(
                        "role",
                        String.class
                );
    }

    // ============================================================
    // EXTRACT SESSION ID
    // ============================================================

    public String extractSessionId(
            String token) {

        return Jwts.parser()
                .verifyWith(key)
                .build()
                .parseSignedClaims(token)
                .getPayload()
                .get(
                        "sessionId",
                        String.class
                );
    }

    // ============================================================
    // TOKEN VALIDATION
    // ============================================================

    public boolean isTokenValid(
            String token) {

        try {

            Jwts.parser()
                    .verifyWith(key)
                    .build()
                    .parseSignedClaims(token);

            return true;

        } catch (Exception e) {

            return false;
        }
    }
}