
        package com.localmart.localmartbackend.dto;

import java.math.BigDecimal;

public class LocationSearchResponse {

    private BigDecimal latitude;
    private BigDecimal longitude;

    public LocationSearchResponse() {
    }

    public LocationSearchResponse(
            BigDecimal latitude,
            BigDecimal longitude
    ) {
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public BigDecimal getLatitude() {
        return latitude;
    }

    public void setLatitude(BigDecimal latitude) {
        this.latitude = latitude;
    }

    public BigDecimal getLongitude() {
        return longitude;
    }

    public void setLongitude(BigDecimal longitude) {
        this.longitude = longitude;
    }
}
