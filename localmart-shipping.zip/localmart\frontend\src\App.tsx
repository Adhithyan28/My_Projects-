
import { useState } from "react"
import "./App.css"

import ForgotPassword from "./pages/ForgotPassword"
import ChangePassword from "./pages/ChangePassword"
import Register from "./pages/Register"
import Login from "./pages/Login"
import CustomerDashboard from "./pages/CustomerDashboard"
import CustomerProfile from "./pages/CustomerProfile"
import StoreOwnerDashboard from "./pages/StoreOwnerDashboard"
import DeliveryPartnerDashboard from "./pages/DeliveryPartnerDashboard"
import AdminDashboard from "./pages/AdminDashboard"

import Stores from "./pages/Stores"
import StoreProducts from "./pages/StoreProducts"
import Categories from "./pages/Categories"
import CategoryProducts from "./pages/CategoryProducts"
import Products from "./pages/Products"
import Cart from "./pages/Cart"
import Checkout from "./pages/Checkout"
import Orders from "./pages/Orders"

import {
    AuthProvider,
    useAuth
} from "./context/AuthContext"


/* =========================================
 * STORE TYPE
 * ========================================= */

interface Store {
    id: number
    name: string
    type: string
    city: string | null
    state: string | null
    latitude: number | null
    longitude: number | null
}


/* =========================================
 * CATEGORY TYPE
 * ========================================= */

interface Category {
    id: number
    name: string
    description: string
    icon: string
    productCount: number
}


/* =========================================
 * CUSTOMER PAGE TYPE
 * ========================================= */

type CustomerPage =
    | "home"
    | "stores"
    | "store-products"
    | "categories"
    | "category-products"
    | "products"
    | "cart"
    | "checkout"
    | "orders"
    | "profile"


/* =========================================
 * APP CONTENT
 * ========================================= */

function AppContent() {

    const {
        user
    } = useAuth()


    /* =========================================
     * AUTH MODE
     * ========================================= */

    const [mode, setMode] =
        useState<
            "login"
            | "register"
            | "forgot-password"
        >("login")


    /* =========================================
     * CUSTOMER PAGE
     * ========================================= */

    const [customerPage, setCustomerPage] =
        useState<CustomerPage>("home")


    /* =========================================
     * SELECTED STORE
     * ========================================= */

    const [selectedStore, setSelectedStore] =
        useState<Store | null>(null)


    /* =========================================
     * SELECTED CATEGORY
     * ========================================= */

    const [selectedCategory, setSelectedCategory] =
        useState<Category | null>(null)


    /* =========================================
     * ADDRESS RETURN FLOW
     * ========================================= */

    const [
        returnToCheckoutAfterAddress,
        setReturnToCheckoutAfterAddress
    ] = useState(false)


    /* =========================================
     * NEW ADDRESS ID
     * ========================================= */

    const [
        newAddressId,
        setNewAddressId
    ] = useState<number | null>(null)


    /* =========================================
     * CUSTOMER NAVIGATION
     * ========================================= */

    const goHome = () => {

        setSelectedStore(null)
        setSelectedCategory(null)

        setCustomerPage("home")
    }


    const goStores = () => {

        setCustomerPage("stores")
    }


    const goCategories = () => {

        setSelectedCategory(null)

        setCustomerPage("categories")
    }


    const goProducts = () => {

        setCustomerPage("products")
    }


    const goStoreProducts = (
        store: Store
    ) => {

        setSelectedStore(store)

        setCustomerPage(
            "store-products"
        )
    }


    const goCategoryProducts = (
        category: Category
    ) => {

        setSelectedCategory(category)

        setCustomerPage(
            "category-products"
        )
    }


    const goCart = () => {

        setCustomerPage("cart")
    }


    /* =========================================
     * CHECKOUT NAVIGATION
     * ========================================= */

    const goCheckout = () => {

        setNewAddressId(null)

        setReturnToCheckoutAfterAddress(
            false
        )

        setCustomerPage("checkout")
    }


    const goOrders = () => {

        setCustomerPage("orders")
    }


    /* =========================================
     * PROFILE NAVIGATION
     * ========================================= */

    const goProfile = () => {

        setCustomerPage("profile")
    }


    /* =========================================
     * CHECKOUT → PROFILE
     * ========================================= */

    const goAddAddressFromCheckout = () => {

        setReturnToCheckoutAfterAddress(
            true
        )

        setNewAddressId(null)

        setCustomerPage("profile")
    }


    /* =========================================
     * PROFILE → CHECKOUT
     * ========================================= */

    const handleAddressSaved = (
        addressId: number
    ) => {

        if (
            !returnToCheckoutAfterAddress
        ) {
            return
        }


        setNewAddressId(
            addressId
        )


        setReturnToCheckoutAfterAddress(
            false
        )


        setCustomerPage(
            "checkout"
        )
    }


    /* =========================================
     * LOGGED-IN USER
     * ========================================= */

    if (user) {

        /* =========================================
         * PASSWORD ROTATION
         * ========================================= */

        if (user.passwordChangeRequired) {

            return (
                <ChangePassword
                    onPasswordChanged={() => {}}
                />
            )
        }


        switch (user.role) {


            /* =====================================
             * CUSTOMER
             * ===================================== */

            case "CUSTOMER":


                /* =================================
                 * CUSTOMER PROFILE
                 * ================================= */

                if (
                    customerPage === "profile"
                ) {

                    return (
                        <CustomerProfile
                            onHome={goHome}
                            onStores={goStores}
                            onCategories={
                                goCategories
                            }
                            onProducts={
                                goProducts
                            }
                            onOrders={
                                goOrders
                            }
                            onCart={goCart}

                            onAddressSaved={
                                handleAddressSaved
                            }
                        />
                    )
                }


                /* =================================
                 * ORDERS
                 * ================================= */

                if (
                    customerPage === "orders"
                ) {

                    return (
                        <Orders
                            onHome={goHome}
                            onStores={goStores}
                            onCategories={
                                goCategories
                            }
                            onProducts={
                                goProducts
                            }
                            onCart={goCart}
                        />
                    )
                }


                /* =================================
                 * CHECKOUT
                 * ================================= */

                if (
                    customerPage === "checkout"
                ) {

                    return (
                        <Checkout
                            onHome={goHome}
                            onStores={goStores}
                            onCategories={
                                goCategories
                            }
                            onProducts={
                                goProducts
                            }
                            onOrders={
                                goOrders
                            }
                            onCart={goCart}

                            onAddNewAddress={
                                goAddAddressFromCheckout
                            }

                            addressToSelect={
                                newAddressId
                            }
                        />
                    )
                }


                /* =================================
                 * CART
                 * ================================= */

                if (
                    customerPage === "cart"
                ) {

                    return (
                        <Cart
                            onHome={goHome}
                            onStores={goStores}
                            onCategories={
                                goCategories
                            }
                            onProducts={
                                goProducts
                            }
                            onOrders={
                                goOrders
                            }
                            onCheckout={
                                goCheckout
                            }
                        />
                    )
                }


                /* =================================
                 * PRODUCTS
                 * ================================= */

                if (
                    customerPage === "products"
                ) {

                    return (
                        <Products
                            onHome={
                                goHome
                            }

                            onStores={
                                goStores
                            }

                            onCategories={
                                goCategories
                            }

                            onOrders={
                                goOrders
                            }

                            onCart={
                                goCart
                            }
                        />
                    )
                }


                /* =================================
                 * CATEGORY PRODUCTS
                 * ================================= */

                if (
                    customerPage ===
                    "category-products" &&
                    selectedCategory !== null
                ) {

                    return (
                        <CategoryProducts
                            category={
                                selectedCategory
                            }

                            onHome={
                                goHome
                            }

                            onStores={
                                goStores
                            }

                            onCategories={
                                goCategories
                            }

                            onProducts={
                                goProducts
                            }

                            onOrders={
                                goOrders
                            }

                            onCart={
                                goCart
                            }
                        />
                    )
                }


                /* =================================
                 * CATEGORIES
                 * ================================= */

                if (
                    customerPage === "categories"
                ) {

                    return (
                        <Categories
                            onHome={
                                goHome
                            }

                            onStores={
                                goStores
                            }

                            onCart={
                                goCart
                            }

                            onProducts={
                                goProducts
                            }

                            onOrders={
                                goOrders
                            }

                            onCategoryClick={
                                goCategoryProducts
                            }
                        />
                    )
                }


                /* =================================
                 * STORE PRODUCTS
                 * ================================= */

                if (
                    customerPage ===
                    "store-products" &&
                    selectedStore !== null
                ) {

                    return (
                        <StoreProducts
                            store={
                                selectedStore
                            }

                            onBack={
                                goStores
                            }

                            onHome={
                                goHome
                            }

                            onCategories={
                                goCategories
                            }

                            onProducts={
                                goProducts
                            }

                            onOrders={
                                goOrders
                            }

                            onCart={
                                goCart
                            }
                        />
                    )
                }


                /* =================================
                 * STORES
                 * ================================= */

                if (
                    customerPage === "stores"
                ) {

                    return (
                        <Stores
                            onHome={
                                goHome
                            }

                            onViewStore={
                                goStoreProducts
                            }

                            onCategories={
                                goCategories
                            }

                            onProducts={
                                goProducts
                            }

                            onOrders={
                                goOrders
                            }

                            onCart={
                                goCart
                            }
                        />
                    )
                }


                /* =================================
                 * CUSTOMER HOME
                 * ================================= */

                return (
                    <CustomerDashboard
                        onStores={
                            goStores
                        }

                        onCart={
                            goCart
                        }

                        onCategories={
                            goCategories
                        }

                        onProducts={
                            goProducts
                        }

                        onOrders={
                            goOrders
                        }

                        onProfile={
                            goProfile
                        }
                    />
                )


            /* =====================================
             * STORE OWNER
             * ===================================== */

            case "STORE_OWNER":

                return (
                    <StoreOwnerDashboard />
                )


            /* =====================================
             * DELIVERY PARTNER
             * ===================================== */

            case "DELIVERY_PARTNER":

                return (
                    <DeliveryPartnerDashboard />
                )


            /* =====================================
             * ADMIN
             * ===================================== */

            case "ADMIN":

                return (
                    <AdminDashboard />
                )


            /* =====================================
             * INVALID ROLE
             * ===================================== */

            default:

                return (

                    <div className="app">

                        <main className="main">

                            <section className="auth-card">

                                <div className="auth-form">

                                    <h2>
                                        Invalid User Role
                                    </h2>

                                    <p>
                                        Your account role could not
                                        be recognized.
                                    </p>

                                    <button
                                        type="button"
                                        onClick={() => {

                                            localStorage.removeItem(
                                                "localmart_user"
                                            )

                                            window.location.reload()

                                        }}
                                    >
                                        Return to Login
                                    </button>

                                </div>

                            </section>

                        </main>

                    </div>

                )
        }
    }


    /* =========================================
     * LOGIN / REGISTER / FORGOT PASSWORD
     * ========================================= */

    return (

        <div className="app">

            {/* ==================================
             * HEADER
             * ================================== */}

            <header className="header">

                <div className="logo">
                    Local<span>Mart</span>
                </div>

                <div className="header-text">
                    Your local marketplace
                </div>

            </header>


            {/* ==================================
             * MAIN
             * ================================== */}

            <main className="main">

                {/* =================================
                 * WELCOME SECTION
                 * ================================= */}

                <section className="welcome">

                    <div className="accent"></div>

                    <p className="eyebrow">
                        WELCOME TO LOCALMART
                    </p>


                    <h1>
                        Shop local.
                        <br />
                        <span>Live local.</span>
                    </h1>


                    <p className="welcome-text">
                        Discover nearby stores, find products
                        you love, and support the businesses
                        that make your community special.
                    </p>


                    <div>


                    </div>


                    {/* FEATURES */}

                    <div className="features">

                        <div className="feature">

                            <div className="feature-icon">
                                ✓
                            </div>

                            <div>

                                <strong>
                                    Local Stores
                                </strong>

                                <p>
                                    Discover businesses around you
                                </p>

                            </div>

                        </div>


                        <div className="feature">

                            <div className="feature-icon">
                                ✓
                            </div>

                            <div>

                                <strong>
                                    Easy Shopping
                                </strong>

                                <p>
                                    Everything you need in one place
                                </p>

                            </div>

                        </div>


                        <div className="feature">

                            <div className="feature-icon">
                                ✓
                            </div>

                            <div>

                                <strong>
                                    Fast Delivery
                                </strong>

                                <p>
                                    Get your orders delivered locally
                                </p>

                            </div>

                        </div>

                    </div>

                </section>


                {/* =================================
                 * AUTH CARD
                 * ================================= */}

                <section className="auth-card">

                    {/* =================================
                     * AUTH TABS
                     * ================================= */}

                    {
                        mode !==
                        "forgot-password" && (

                            <div className="auth-tabs">

                                <button
                                    type="button"

                                    className={
                                        mode ===
                                        "login"
                                            ? "tab active"
                                            : "tab"
                                    }

                                    onClick={() =>
                                        setMode(
                                            "login"
                                        )
                                    }
                                >
                                    Login
                                </button>


                                <button
                                    type="button"

                                    className={
                                        mode ===
                                        "register"
                                            ? "tab active"
                                            : "tab"
                                    }

                                    onClick={() =>
                                        setMode(
                                            "register"
                                        )
                                    }
                                >
                                    Register
                                </button>

                            </div>

                        )
                    }


                    {/* =================================
                     * AUTH FORM
                     * ================================= */}

                    <div className="auth-form">

                        {
                            mode ===
                            "login" ? (

                                <Login
                                    onRegister={() =>
                                        setMode(
                                            "register"
                                        )
                                    }

                                    onForgotPassword={() =>
                                        setMode(
                                            "forgot-password"
                                        )
                                    }
                                />

                            ) : mode ===
                            "register" ? (

                                <Register />

                            ) : (

                                <ForgotPassword
                                    onBackToLogin={() =>
                                        setMode(
                                            "login"
                                        )
                                    }
                                />

                            )
                        }

                    </div>

                </section>

            </main>

        </div>
    )
}


/* =========================================
 * APP
 * ========================================= */

function App() {

    return (
        <AuthProvider>

            <AppContent />

        </AuthProvider>
    )
}


export default App
