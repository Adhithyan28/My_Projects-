package com.localmart.localmartbackend.service;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

@Service
public class OtpService {

    private static final int OTP_EXPIRY_MINUTES = 5;

    private final PasswordEncoder passwordEncoder;
    private final EmailService emailService;

    /*
     * Temporary in-memory OTP storage.
     *
     * Key   = email
     * Value = hashed OTP + expiry time
     */
    private final Map<String, OtpData> otpStore =
            new ConcurrentHashMap<>();

    public OtpService(
            PasswordEncoder passwordEncoder,
            EmailService emailService) {

        this.passwordEncoder = passwordEncoder;
        this.emailService = emailService;
    }

    /*
     * Generate OTP, hash it, temporarily store the hash,
     * and send the actual OTP through email.
     */
    public void sendEmailOtp(String email) {

        String otp = String.format(
                "%06d",
                ThreadLocalRandom.current()
                        .nextInt(1_000_000)
        );

        String otpHash =
                passwordEncoder.encode(otp);

        LocalDateTime expiresAt =
                LocalDateTime.now()
                        .plusMinutes(OTP_EXPIRY_MINUTES);

        otpStore.put(
                normalizeEmail(email),
                new OtpData(
                        otpHash,
                        expiresAt
                )
        );

        emailService.sendOtpEmail(
                email,
                otp
        );
    }

    /*
     * Verify the OTP.
     */
    public void verifyEmailOtp(
            String email,
            String enteredOtp) {

        String key = normalizeEmail(email);

        OtpData otpData =
                otpStore.get(key);

        if (otpData == null) {

            throw new RuntimeException(
                    "No OTP found"
            );
        }

        /*
         * Check expiry.
         */
        if (LocalDateTime.now()
                .isAfter(otpData.expiresAt())) {

            otpStore.remove(key);

            throw new RuntimeException(
                    "OTP has expired"
            );
        }

        /*
         * Compare entered OTP against
         * the BCrypt hash.
         */
        if (!passwordEncoder.matches(
                enteredOtp,
                otpData.otpHash())) {

            throw new RuntimeException(
                    "Invalid OTP"
            );
        }

        /*
         * OTP is single-use.
         */
        otpStore.remove(key);
    }

    private String normalizeEmail(String email) {

        return email
                .trim()
                .toLowerCase();
    }

    /*
     * Temporary OTP information.
     */
    private record OtpData(
            String otpHash,
            LocalDateTime expiresAt
    ) {
    }
}