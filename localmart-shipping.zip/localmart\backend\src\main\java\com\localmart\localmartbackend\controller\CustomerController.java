
        package com.localmart.localmartbackend.controller;

import com.localmart.localmartbackend.dto.CustomerProfileRequest;
import com.localmart.localmartbackend.dto.CustomerProfileResponse;
import com.localmart.localmartbackend.service.CustomerService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/customer")
@CrossOrigin(origins = {
        "http://localhost:5173",
        "http://localhost:5174",
        "http://localhost:5175"
})
public class CustomerController {

    private final CustomerService customerService;

    public CustomerController(
            CustomerService customerService) {

        this.customerService =
                customerService;
    }

    @GetMapping("/profile")
    public ResponseEntity<CustomerProfileResponse>
    getProfile(
            Authentication authentication) {

        Long userId =
                getAuthenticatedUserId(
                        authentication
                );

        return ResponseEntity.ok(
                customerService.getProfile(
                        userId
                )
        );
    }

    @PutMapping("/profile")
    public ResponseEntity<CustomerProfileResponse>
    updateProfile(
            Authentication authentication,
            @RequestBody CustomerProfileRequest request) {

        Long userId =
                getAuthenticatedUserId(
                        authentication
                );

        return ResponseEntity.ok(
                customerService.updateProfile(
                        userId,
                        request
                )
        );
    }

    private Long getAuthenticatedUserId(
            Authentication authentication) {

        if (authentication == null ||
                authentication.getPrincipal() == null) {

            throw new RuntimeException(
                    "User is not authenticated"
            );
        }

        Object principal =
                authentication.getPrincipal();

        if (principal instanceof Long userId) {
            return userId;
        }

        if (principal instanceof String userId) {

            try {

                return Long.valueOf(userId);

            } catch (NumberFormatException exception) {

                throw new RuntimeException(
                        "Invalid authenticated user ID"
                );
            }
        }

        throw new RuntimeException(
                "Invalid authenticated user"
        );
    }
}
