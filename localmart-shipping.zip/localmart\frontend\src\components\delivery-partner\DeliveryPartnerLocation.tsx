import {
    MapContainer,
    Marker,
    Popup,
    TileLayer,
} from "react-leaflet"

import L from "leaflet"

import "leaflet/dist/leaflet.css"

import {
    useDeliveryPartnerLocation,
} from "../../context/DeliveryPartnerLocationContext"


const deliveryIcon =
    L.icon({

        iconUrl:
            "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png",

        shadowUrl:
            "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png",

        iconSize: [25, 41],

        iconAnchor: [12, 41],

        popupAnchor: [1, -34],

        shadowSize: [41, 41],

    })


function DeliveryPartnerLocation() {

    const {

        latitude,

        longitude,

        availabilityStatus,

        gpsStatus,

    } =
        useDeliveryPartnerLocation()


    const isOnline =
        availabilityStatus === "AVAILABLE"


    return (

        <div className="delivery-location-page">


            <div className="delivery-location-page-header">

                <div>

                    <p className="delivery-home-label">
                        DELIVERY PARTNER
                    </p>

                    <h1>
                        My Location
                    </h1>

                    <p>
                        Your current delivery location
                    </p>

                </div>


                <div
                    className={
                        isOnline
                            ? "delivery-status online"
                            : "delivery-status offline"
                    }
                >

                    <span className="delivery-status-dot"></span>

                    {isOnline
                        ? "LIVE"
                        : "OFFLINE"}

                </div>

            </div>


            <div className="delivery-message">

                {gpsStatus}

            </div>


            {latitude !== null &&
            longitude !== null ? (

                <>

                    <div className="delivery-map-card">

                        <MapContainer
                            center={[
                                latitude,
                                longitude,
                            ]}
                            zoom={15}
                            scrollWheelZoom={true}
                            className="delivery-map"
                        >

                            <TileLayer
                                attribution='&copy; OpenStreetMap contributors'
                                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                            />


                            <Marker
                                position={[
                                    latitude,
                                    longitude,
                                ]}
                                icon={deliveryIcon}
                            >

                                <Popup>

                                    <strong>
                                        Your Location
                                    </strong>

                                    <br />

                                    {isOnline
                                        ? "You are online"
                                        : "You are offline"}

                                </Popup>

                            </Marker>

                        </MapContainer>

                    </div>


                    <div className="delivery-location-details">

                        <div>

                            <span>
                                Latitude
                            </span>

                            <strong>
                                {latitude.toFixed(6)}
                            </strong>

                        </div>


                        <div>

                            <span>
                                Longitude
                            </span>

                            <strong>
                                {longitude.toFixed(6)}
                            </strong>

                        </div>


                        <div>

                            <span>
                                Status
                            </span>

                            <strong>
                                {availabilityStatus}
                            </strong>

                        </div>


                        <div>

                            <span>
                                GPS
                            </span>

                            <strong>
                                {gpsStatus}
                            </strong>

                        </div>

                    </div>

                </>

            ) : (

                <div className="delivery-no-location">

                    <div>
                        📍
                    </div>

                    <h2>
                        Location not available
                    </h2>

                    <p>

                        Go online from the Dashboard to
                        start sharing your current GPS
                        location.

                    </p>

                </div>

            )}

        </div>

    )

}


export default DeliveryPartnerLocation