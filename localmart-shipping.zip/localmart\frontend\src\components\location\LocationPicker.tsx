
import { useEffect, useState } from "react"
import {
    MapContainer,
    Marker,
    TileLayer,
    useMap,
    useMapEvents
} from "react-leaflet"
import L from "leaflet"
import "leaflet/dist/leaflet.css"

interface LocationPickerProps {
    initialLatitude: number
    initialLongitude: number
    onLocationChange: (latitude: number, longitude: number) => void
    onConfirm: () => void
}

interface MapPosition {
    latitude: number
    longitude: number
}

const markerIcon = L.icon({
    iconUrl:
        "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png",
    iconRetinaUrl:
        "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png",
    shadowUrl:
        "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png",
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
    shadowSize: [41, 41]
})

function MapController({
    position
}: {
    position: MapPosition
}) {
    const map = useMap()

    useEffect(() => {
        map.setView(
            [position.latitude, position.longitude],
            map.getZoom()
        )
    }, [
        map,
        position.latitude,
        position.longitude
    ])

    return null
}

function MapClickHandler({
    onLocationChange
}: {
    onLocationChange: (
        latitude: number,
        longitude: number
    ) => void
}) {
    useMapEvents({
        click(event) {
            onLocationChange(
                event.latlng.lat,
                event.latlng.lng
            )
        }
    })

    return null
}

function LocationPicker({
    initialLatitude,
    initialLongitude,
    onLocationChange,
    onConfirm
}: LocationPickerProps) {

    const [position, setPosition] =
        useState<MapPosition>({
            latitude: initialLatitude,
            longitude: initialLongitude
        })

    useEffect(() => {

        setPosition({
            latitude: initialLatitude,
            longitude: initialLongitude
        })

    }, [
        initialLatitude,
        initialLongitude
    ])

    const handleLocationChange = (
        latitude: number,
        longitude: number
    ) => {

        const newPosition = {
            latitude,
            longitude
        }

        setPosition(newPosition)

        onLocationChange(
            latitude,
            longitude
        )
    }

    return (
        <div className="location-picker">

            <div className="location-picker-map">

                <MapContainer
                    center={[
                        position.latitude,
                        position.longitude
                    ]}
                    zoom={17}
                    scrollWheelZoom={true}
                    style={{
                        width: "100%",
                        height: "350px"
                    }}
                >

                    <TileLayer
                        attribution="&copy; OpenStreetMap contributors"
                        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    />

                    <MapController
                        position={position}
                    />

                    <MapClickHandler
                        onLocationChange={
                            handleLocationChange
                        }
                    />

                    <Marker
                        position={[
                            position.latitude,
                            position.longitude
                        ]}
                        icon={markerIcon}
                        draggable={true}
                        eventHandlers={{
                            dragend: event => {

                                const marker =
                                    event.target as L.Marker

                                const coordinates =
                                    marker.getLatLng()

                                handleLocationChange(
                                    coordinates.lat,
                                    coordinates.lng
                                )
                            }
                        }}
                    />

                </MapContainer>

            </div>

            <div className="location-picker-info">

                <strong>
                    Select Your Store Location
                </strong>

                <p>
                    The marker shows the location found
                    from your address. Move the marker or
                    click on the map to select the exact
                    location of your store.
                </p>

                <div className="location-picker-coordinates">

                    <span>
                        Latitude:
                        {" "}
                        {position.latitude.toFixed(7)}
                    </span>

                    <span>
                        Longitude:
                        {" "}
                        {position.longitude.toFixed(7)}
                    </span>

                </div>

                <button
                    type="button"
                    className="owner-primary-btn"
                    onClick={onConfirm}
                >
                    📍 Confirm Location
                </button>

            </div>

        </div>
    )
}

export default LocationPicker
