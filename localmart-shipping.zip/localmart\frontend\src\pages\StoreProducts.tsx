import { useEffect, useState } from "react"
import { useAuth } from "../context/AuthContext"

interface Store {
    id: number
    name: string
    type: string
    city: string | null
    state: string | null
    latitude: number | null
    longitude: number | null
}

interface Product {
    id: number
    name: string
    category: string
    description: string | null
    price: number
    unit: string
    icon: string | null
    stockQuantity: number
    isAvailable: boolean
}

interface StoreProductsProps {
    store: Store
    onBack: () => void
    onHome: () => void
    onCategories: () => void
    onProducts: () => void
    onOrders: () => void
    onCart: () => void
}

function StoreProducts({
                           store,
                           onBack,
                           onHome,
                           onCategories,
                           onProducts,
                           onOrders,
                           onCart,
                       }: StoreProductsProps) {

    const { user, logout } = useAuth()

    const [search, setSearch] = useState("")

    const [products, setProducts] =
        useState<Product[]>([])

    const [loading, setLoading] =
        useState(true)

    const [error, setError] =
        useState("")


    /* ==========================================
     * LOAD PRODUCTS FROM DATABASE
     * ========================================== */

    useEffect(() => {

        const loadProducts = async () => {

            try {

                setLoading(true)
                setError("")

                if (!user?.token) {
                    throw new Error(
                        "User authentication token is missing"
                    )
                }

                const response =
                    await fetch(
                        `/api/products/store/${store.id}`,
                        {
                            method: "GET",
                            headers: {
                                Authorization:
                                    `Bearer ${user.token}`,
                            },
                        }
                    )

                if (!response.ok) {

                    if (response.status === 401) {
                        throw new Error(
                            "Your session has expired. Please login again."
                        )
                    }

                    if (response.status === 403) {
                        throw new Error(
                            "You are not authorized to view products."
                        )
                    }

                    if (response.status === 404) {
                        throw new Error(
                            "Store products could not be found."
                        )
                    }

                    throw new Error(
                        `Failed to load products (${response.status})`
                    )

                }

                const data =
                    await response.json()


                /* ==================================
                 * MAP BACKEND PRODUCT ENTITY
                 * TO FRONTEND PRODUCT MODEL
                 * ================================== */

                const mappedProducts: Product[] =
                    data.map((product: any) => ({

                        id: product.productId,

                        name: product.productName,

                        category: product.category,

                        description:
                            product.description ?? null,

                        price:
                            Number(product.price),

                        unit: product.unit,

                        icon:
                            product.icon ?? "🛍️",

                        stockQuantity:
                            Number(product.stockQuantity),

                        isAvailable:
                            Boolean(product.isAvailable),

                    }))


                setProducts(mappedProducts)

            } catch (error) {

                console.error(
                    "Failed to load store products:",
                    error
                )

                setError(
                    error instanceof Error
                        ? error.message
                        : "Unable to load products."
                )

            } finally {

                setLoading(false)

            }

        }

        loadProducts()

    }, [store.id, user?.token])


    /* ==========================================
     * SEARCH
     * ========================================== */

    const filteredProducts =
        products.filter((product) => {

            const searchText =
                `${product.name} ${product.category}`
                    .toLowerCase()

            return searchText.includes(
                search.toLowerCase()
            )

        })


    /* ==========================================
     * ADD TO CART
     * ========================================== */

    const handleAddToCart = async (
        product: Product
    ) => {

        try {

            if (!user?.token) {
                alert(
                    "Please login again to add products to your cart."
                )
                return
            }

            if (!product.isAvailable) {
                alert(
                    `${product.name} is currently unavailable.`
                )
                return
            }

            if (product.stockQuantity <= 0) {
                alert(
                    `${product.name} is out of stock.`
                )
                return
            }

            const response =
                await fetch(
                    "/api/cart/items",
                    {
                        method: "POST",
                        headers: {
                            "Content-Type":
                                "application/json",

                            Authorization:
                                `Bearer ${user.token}`,
                        },
                        body: JSON.stringify({
                            productId: product.id,
                            quantity: 1,
                        }),
                    }
                )


            if (!response.ok) {

                let errorMessage =
                    "Unable to add product to cart."

                try {

                    const errorData =
                        await response.json()

                    if (errorData?.message) {
                        errorMessage =
                            errorData.message
                    }

                } catch {
                    // Keep default error message.
                }

                throw new Error(errorMessage)

            }

            alert(
                `${product.name} added to cart`
            )

        } catch (error) {

            console.error(
                "Failed to add product to cart:",
                error
            )

            alert(
                error instanceof Error
                    ? error.message
                    : "Unable to add product to cart."
            )

        }

    }


    return (

        <div className="customer-dashboard">

            {/* =========================================
             * HEADER
             * ========================================= */}

            <header className="customer-header">

                <button
                    className="customer-logo"
                    onClick={onHome}
                    type="button"
                >
                    Local<span>Mart</span>
                </button>

                <div className="customer-search">

                    <span className="search-icon">
                        🔍
                    </span>

                    <input
                        type="text"
                        placeholder="Search products or stores..."
                    />

                </div>

                <div className="customer-location">

                    <span className="location-icon">
                        📍
                    </span>

                    <div>

                        <small>
                            Deliver to
                        </small>

                        <strong>
                            {store.city || "Chennai"}
                        </strong>

                    </div>

                </div>

                <div className="customer-header-actions">

                    <button
                        className="header-icon-button"
                        title="Cart"
                        type="button"
                        onClick={onCart}
                    >
                        🛒
                    </button>

                    <div className="customer-profile">

                        <div className="profile-avatar">

                            {user?.email
                                ?.charAt(0)
                                .toUpperCase()}

                        </div>

                        <div className="profile-details">

                            <strong>
                                Customer
                            </strong>

                            <small>
                                {user?.email}
                            </small>

                        </div>

                    </div>

                    <button
                        className="logout-button"
                        onClick={logout}
                        type="button"
                    >
                        Logout
                    </button>

                </div>

            </header>

            {/* =========================================
             * NAVIGATION
             * ========================================= */}

            <nav className="customer-navigation">

                <div className="navigation-inner">

                    <button
                        type="button"
                        onClick={onHome}
                    >
                        Home
                    </button>

                    <button
                        type="button"
                        className="nav-active"
                        onClick={onBack}
                    >
                        Stores
                    </button>

                    <button
                        type="button"
                        onClick={onCategories}
                    >
                        Categories
                    </button>

                    <button
                        type="button"
                        onClick={onProducts}
                    >
                        Products
                    </button>

                    <button
                        type="button"
                        onClick={onOrders}
                    >
                        Orders
                    </button>

                </div>

            </nav>

            {/* =========================================
             * MAIN
             * ========================================= */}

            <main className="customer-main store-products-main">

                <section className="customer-section store-products-section">

                    {/* BACK */}

                    <button
                        type="button"
                        className="section-link store-back-link"
                        onClick={onBack}
                    >
                        ← Back to Stores
                    </button>

                    {/* =====================================
                     * STORE HERO
                     * ===================================== */}

                    <div className="store-hero-card">

                        <div className="store-hero-background">

                            <div className="store-hero-pattern"></div>

                        </div>

                        <div className="store-hero-content">

                            <div className="store-hero-icon">
                                🏪
                            </div>

                            <div className="store-hero-details">

                                <span className="store-hero-label">
                                    LOCAL STORE
                                </span>

                                <h1>
                                    {store.name}
                                </h1>

                                <p className="store-hero-type">
                                    {store.type}
                                </p>

                                <div className="store-hero-meta">

                                    <span>
                                        📍{" "}
                                        {store.city
                                            ? `${store.city}${store.state ? `, ${store.state}` : ""}`
                                            : "Location unavailable"
                                        }
                                    </span>

                                </div>

                            </div>

                            <button
                                type="button"
                                className="store-hero-back"
                                onClick={onBack}
                            >
                                View all stores
                            </button>

                        </div>

                    </div>

                    {/* =====================================
                     * PRODUCTS HEADER
                     * ===================================== */}

                    <div className="store-products-heading">

                        <div>

                            <span className="section-label">
                                SHOP PRODUCTS
                            </span>

                            <h2>
                                Products from {store.name}
                            </h2>

                            <p>
                                Find what you need and add it to your cart.
                            </p>

                        </div>

                        <div className="product-count">

                            {loading
                                ? "Loading..."
                                : `${filteredProducts.length} products`
                            }

                        </div>

                    </div>

                    {/* =====================================
                     * SEARCH
                     * ===================================== */}

                    <div className="store-product-search">

                        <span>
                            🔍
                        </span>

                        <input
                            type="text"
                            placeholder="Search products in this store..."
                            value={search}
                            onChange={(event) =>
                                setSearch(event.target.value)
                            }
                        />

                        {search && (

                            <button
                                type="button"
                                className="search-clear"
                                onClick={() =>
                                    setSearch("")
                                }
                            >
                                ✕
                            </button>

                        )}

                    </div>

                    {/* =====================================
                     * ERROR
                     * ===================================== */}

                    {error && (

                        <div className="store-products-empty">

                            <div className="store-products-empty-icon">
                                ⚠️
                            </div>

                            <h3>
                                Unable to load products
                            </h3>

                            <p>
                                {error}
                            </p>

                        </div>

                    )}

                    {/* =====================================
                     * PRODUCT GRID
                     * ===================================== */}

                    {!loading &&
                    !error &&
                    filteredProducts.length > 0 ? (

                        <div className="store-product-grid">

                            {filteredProducts.map((product) => (

                                <article
                                    className="store-product-card"
                                    key={product.id}
                                >

                                    <div className="store-product-image">

                                        <span>
                                            {product.icon || "🛍️"}
                                        </span>

                                    </div>

                                    <div className="store-product-content">

                                        <span className="store-product-category">
                                            {product.category}
                                        </span>

                                        <h3>
                                            {product.name}
                                        </h3>

                                        <p className="store-product-unit">
                                            {product.unit}
                                        </p>

                                        <div className="store-product-footer">

                                            <div className="store-product-price">

                                                <span>
                                                    ₹
                                                </span>

                                                {product.price}

                                            </div>

                                            <button
                                                type="button"
                                                className="add-cart-button"
                                                onClick={() =>
                                                    handleAddToCart(
                                                        product
                                                    )
                                                }
                                                disabled={
                                                    !product.isAvailable ||
                                                    product.stockQuantity <= 0
                                                }
                                            >

                                                <span>
                                                    +
                                                </span>

                                                {product.stockQuantity <= 0
                                                    ? "Out of Stock"
                                                    : "Add to Cart"
                                                }

                                            </button>

                                        </div>

                                    </div>

                                </article>

                            ))}

                        </div>

                    ) : (

                        !loading &&
                        !error && (

                            <div className="store-products-empty">

                                <div className="store-products-empty-icon">
                                    🔍
                                </div>

                                <h3>
                                    No products found
                                </h3>

                                <p>
                                    We couldn't find a product matching "{search}".
                                </p>

                                <button
                                    type="button"
                                    onClick={() =>
                                        setSearch("")
                                    }
                                >
                                    Clear Search
                                </button>

                            </div>

                        )

                    )}

                </section>

            </main>

            {/* =========================================
             * FOOTER
             * ========================================= */}

            <footer className="customer-footer">

                <div className="footer-content">

                    <div>

                        <button
                            className="customer-logo"
                            onClick={onHome}
                            type="button"
                        >
                            Local<span>Mart</span>
                        </button>

                        <p>
                            Shop local. Live local.
                        </p>

                    </div>

                    <div className="footer-links">

                        <button
                            type="button"
                            onClick={onHome}
                        >
                            Home
                        </button>

                        <button
                            type="button"
                            onClick={onBack}
                        >
                            Stores
                        </button>

                        <button
                            type="button"
                            onClick={onCategories}
                        >
                            Categories
                        </button>

                        <button
                            type="button"
                            onClick={onProducts}
                        >
                            Products
                        </button>

                        <button
                            type="button"
                            onClick={onOrders}
                        >
                            Orders
                        </button>

                        <button
                            type="button"
                            onClick={onCart}
                        >
                            Cart
                        </button>

                    </div>

                </div>

            </footer>

        </div>
    )
}

export default StoreProducts