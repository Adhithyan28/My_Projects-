
        package com.localmart.localmartbackend.repository;

import com.localmart.localmartbackend.entity.DeliveryPartner;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DeliveryPartnerRepository extends JpaRepository<DeliveryPartner, Long> {

    boolean existsByDrivingLicenceNumber(String drivingLicenceNumber);

}

