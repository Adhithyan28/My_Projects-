
import { useEffect, useRef, useState } from "react"

interface GoogleSignInButtonProps {
    onCredential: (credential: string) => void
    disabled?: boolean
}

interface GoogleAccountsId {
    initialize: (config: {
        client_id: string
        callback: (response: {
            credential: string
            select_by?: string
        }) => void
    }) => void

    renderButton: (
        parent: HTMLElement,
        options: {
            theme?: string
            size?: string
            width?: number
            text?: string
            shape?: string
        }
    ) => void
}

interface GoogleAccounts {
    id: GoogleAccountsId
}

interface Google {
    accounts: GoogleAccounts
}

declare global {
    interface Window {
        google?: Google
    }
}


/*
=========================================================
GOOGLE IDENTITY SERVICES - GLOBAL STATE
=========================================================
*/

let initializedClientId: string | null = null

let activeCredentialHandler:
    ((credential: string) => void) | null = null

let googleScriptPromise:
    Promise<void> | null = null


/*
=========================================================
LOAD GOOGLE IDENTITY SERVICES
=========================================================
*/

function loadGoogleIdentityServices(): Promise<void> {

    if (
        window.google?.accounts?.id
    ) {
        return Promise.resolve()
    }


    if (googleScriptPromise) {
        return googleScriptPromise
    }


    googleScriptPromise =
        new Promise<void>((resolve, reject) => {

            const existingScript =
                document.getElementById(
                    "google-identity-services"
                ) as HTMLScriptElement | null


            if (existingScript) {

                if (
                    window.google?.accounts?.id
                ) {
                    resolve()
                    return
                }


                existingScript.addEventListener(
                    "load",
                    () => resolve(),
                    {
                        once: true
                    }
                )


                existingScript.addEventListener(
                    "error",
                    () => reject(
                        new Error(
                            "Failed to load Google Identity Services."
                        )
                    ),
                    {
                        once: true
                    }
                )

                return
            }


            const script =
                document.createElement("script")


            script.id =
                "google-identity-services"


            script.src =
                "https://accounts.google.com/gsi/client"


            script.async =
                true


            script.defer =
                true


            script.onload =
                () => resolve()


            script.onerror =
                () => reject(
                    new Error(
                        "Failed to load Google Identity Services."
                    )
                )


            document.head.appendChild(script)

        })


    return googleScriptPromise
}


/*
=========================================================
COMPONENT
=========================================================
*/

function GoogleSignInButton({
                                onCredential,
                                disabled = false
                            }: GoogleSignInButtonProps) {

    const buttonRef =
        useRef<HTMLDivElement | null>(null)


    const callbackRef =
        useRef(onCredential)


    const disabledRef =
        useRef(disabled)


    const [ready, setReady] =
        useState(false)


    const clientId =
        import.meta.env.VITE_GOOGLE_CLIENT_ID


    /*
    =====================================================
    KEEP CALLBACK UPDATED
    =====================================================
    */

    useEffect(() => {

        callbackRef.current =
            onCredential


        activeCredentialHandler =
            (credential: string) => {

                if (
                    disabledRef.current
                ) {

                    console.log(
                        "Google Sign-In is currently disabled."
                    )

                    return
                }


                console.log(
                    "Sending Google credential to parent component..."
                )


                callbackRef.current(
                    credential
                )

            }

    }, [onCredential])


    /*
    =====================================================
    KEEP DISABLED STATE UPDATED
    =====================================================
    */

    useEffect(() => {

        disabledRef.current =
            disabled

    }, [disabled])


    /*
    =====================================================
    LOAD GOOGLE SCRIPT
    =====================================================
    */

    useEffect(() => {

        if (!clientId) {

            console.error(
                "VITE_GOOGLE_CLIENT_ID is not configured."
            )

            return
        }


        let cancelled = false


        loadGoogleIdentityServices()
            .then(() => {

                if (!cancelled) {

                    console.log(
                        "Google Identity Services loaded successfully."
                    )

                    setReady(true)
                }

            })
            .catch((error) => {

                console.error(
                    "Google Identity Services loading error:",
                    error
                )

            })


        return () => {

            cancelled = true

        }

    }, [clientId])


    /*
    =====================================================
    INITIALIZE GOOGLE ONLY ONCE
    =====================================================
    */

    useEffect(() => {

        if (
            !ready ||
            !clientId ||
            !buttonRef.current ||
            !window.google?.accounts?.id
        ) {
            return
        }


        const google =
            window.google


        /*
        -------------------------------------------------
        INITIALIZE ONLY ONCE FOR THIS CLIENT ID
        -------------------------------------------------
        */

        if (
            initializedClientId !== clientId
        ) {

            console.log(
                "Initializing Google Identity Services..."
            )


            google.accounts.id.initialize({

                client_id:
                    clientId,

                callback: (response) => {



                    console.log(

                        response
                    )




                    console.log(

                        response?.credential
                    )





                    /*
                    =========================================
                    CHECK CREDENTIAL
                    =========================================
                    */

                    if (
                        !response?.credential
                    ) {

                        console.error(
                            "Google did not return a credential."
                        )

                        return
                    }


                    /*
                    =========================================
                    SEND CREDENTIAL TO PARENT
                    =========================================
                    */

                    if (
                        activeCredentialHandler
                    ) {

                        console.log(
                            "Google credential received successfully."
                        )

                        console.log(
                            "Calling onCredential()..."
                        )


                        activeCredentialHandler(
                            response.credential
                        )

                    }

                    else {

                        console.error(
                            "No active Google credential handler found."
                        )

                    }

                }

            })


            initializedClientId =
                clientId


            console.log(
                "Google Identity Services initialized."
            )
        }


        /*
        -------------------------------------------------
        RENDER BUTTON
        -------------------------------------------------
        */

        buttonRef.current.innerHTML = ""


        google.accounts.id.renderButton(
            buttonRef.current,
            {
                theme: "outline",
                size: "large",
                width: 240,
                text: "continue_with",
                shape: "rectangle"
            }
        )


        console.log(
            "Google Sign-In button rendered."
        )


    }, [
        ready,
        clientId
    ])


    /*
    =====================================================
    MISSING CLIENT ID
    =====================================================
    */

    if (!clientId) {

        return (
            <div
                style={{
                    textAlign: "center",
                    fontSize: "13px",
                    color: "red",
                    marginTop: "12px"
                }}
            >
                Google Sign-In is not configured.
            </div>
        )
    }


    /*
    =====================================================
    RENDER
    =====================================================
    */

    return (

        <div
            style={{
                display: "flex",
                justifyContent: "center",
                marginTop: "20px",
                opacity:
                    disabled
                        ? 0.6
                        : 1,
                pointerEvents:
                    disabled
                        ? "none"
                        : "auto"
            }}
        >

            <div
                ref={buttonRef}
            />

        </div>
    )
}


export default GoogleSignInButton
