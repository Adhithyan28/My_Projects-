# LocalMart — Database Architecture

## 1. Overview

LocalMart uses **PostgreSQL** as its primary relational database.

The backend accesses PostgreSQL through:

```text
Spring Data JPA
        |
        v
Hibernate ORM
        |
        v
PostgreSQL
```

The database is the persistent source of truth for the application's core business data.

LocalMart stores information related to:

* Users
* Roles
* Addresses
* Store owners
* Stores
* Products
* Delivery partners
* Vehicles
* Applications
* Shopping carts
* Cart items
* Orders
* Order items
* Payments
* Delivery-partner locations
* User sessions
* Password-reset sessions

---

# 2. Database Technology

The current backend environment uses:

```text
Database: PostgreSQL
ORM: Hibernate
Persistence abstraction: Spring Data JPA
Java: Java 21
Spring Boot: Spring Boot 4.1.1
```

The PostgreSQL database used by the local development environment is:

```text
localmart_db
```

The backend is configured to validate the existing database schema rather than automatically creating or modifying it.

The current configuration uses:

```properties
spring.jpa.hibernate.ddl-auto=validate
```

This is an important architectural choice.

With `validate`, Hibernate checks whether the database schema is compatible with the entity mappings but does not automatically create the tables.

---

# 3. Database Architecture

The persistence architecture follows the standard layered model:

```text
React Frontend
       |
       | HTTP / JSON
       v
Spring Boot Controllers
       |
       v
Service Layer
       |
       v
Spring Data JPA Repositories
       |
       v
Hibernate ORM
       |
       v
PostgreSQL
```

Each layer has a separate responsibility.

### Controller

Handles HTTP requests and responses.

### Service

Contains business logic.

### Repository

Provides database-access operations.

### Hibernate

Maps Java entities to relational database structures.

### PostgreSQL

Stores the persistent data.

---

# 4. Entity Model

The backend contains the following primary entity classes:

```text
entity/
├── Address.java
├── ApplicationRequest.java
├── Cart.java
├── CartItem.java
├── DeliveryPartner.java
├── DeliveryPartnerLocation.java
├── Order.java
├── OrderItem.java
├── Payment.java
├── Product.java
├── Role.java
├── StoreDetails.java
├── User.java
├── UserSession.java
└── VehicleDetails.java
```

There is also a password-reset persistence model:

```text
passwordreset/
└── entity/
    └── PasswordResetSession.java
```

These entities represent the application's persistent domain model.

---

# 5. User Data

`User.java` represents the common user account.

The user entity acts as the central identity record for the application.

Conceptually:

```text
User
 |
 +---- Role
 |
 +---- Address
 |
 +---- StoreDetails
 |
 +---- DeliveryPartner
 |
 +---- UserSession
 |
 +---- ApplicationRequest
```

A user account can therefore participate in different parts of the system depending on its assigned role.

---

# 6. Role Data

`Role.java` represents the role assigned to a user.

LocalMart currently has four application roles:

```text
CUSTOMER
STORE_OWNER
DELIVERY_PARTNER
ADMIN
```

The role identifiers used by the application are:

```text
CUSTOMER          = 1
STORE_OWNER       = 2
DELIVERY_PARTNER  = 3
ADMIN             = 4
```

The role is associated with the user identity and is used by the application for authorization.

Conceptually:

```text
User
 |
 +---- Role
          |
          +---- CUSTOMER
          +---- STORE_OWNER
          +---- DELIVERY_PARTNER
          +---- ADMIN
```

---

# 7. Address Data

`Address.java` stores address information.

Addresses are used by different parts of LocalMart, including:

* Customer addresses
* Store addresses
* Location-based delivery operations

A customer can maintain multiple addresses.

Conceptually:

```text
User
 |
 +---- Address 1
 |
 +---- Address 2
 |
 +---- Address 3
```

An address can also contain geographic information such as:

```text
Latitude
Longitude
```

These coordinates are important for delivery calculations and location-based functionality.

---

# 8. Address and Location Data

The application stores both human-readable and geographic information.

A conceptual address record contains information such as:

```text
Address
├── Address information
├── City
├── State
├── Pincode
├── Latitude
└── Longitude
```

The latitude and longitude values allow the backend to associate a physical location with the address.

The backend validates coordinate ranges:

```text
Latitude:
-90 to +90

Longitude:
-180 to +180
```

This prevents invalid geographic coordinates from being stored through the normal address-management flow.

---

# 9. Store Data

`StoreDetails.java` represents store-specific information.

The store belongs to a store owner and is associated with an address.

Conceptually:

```text
User
 |
 | STORE_OWNER
 v
StoreDetails
 |
 v
Address
```

Store information is used by:

* Store browsing
* Product browsing
* Store-owner operations
* Orders
* Delivery calculations

---

# 10. Store Ownership

A key relationship in the database is the relationship between a store owner and a store.

Conceptually:

```text
User
  |
  | owner
  v
StoreDetails
```

This relationship is important for authorization.

When a store owner performs an operation involving a store, the backend can determine whether that store belongs to the authenticated owner.

This is different from simply checking:

```text
Is this user a STORE_OWNER?
```

The business rule may also require:

```text
Does this store belong to this STORE_OWNER?
```

Therefore database relationships support both data organization and authorization.

---

# 11. Product Data

`Product.java` represents products sold through stores.

A product is associated with a store.

Conceptually:

```text
StoreDetails
     |
     +---- Product
     |
     +---- Product
     |
     +---- Product
```

Product information is used by:

* Store product browsing
* Category/product browsing
* Cart
* Orders
* Store-owner product management

The product entity therefore participates in several important business relationships.

---

# 12. Store–Product Relationship

The store/product relationship can be represented as:

```text
Store
 |
 +---- Product A
 |
 +---- Product B
 |
 +---- Product C
```

The store provides the business context for a product.

This is important because LocalMart is a multi-store commerce application.

The same conceptual product category can exist across multiple stores while the actual product record belongs to a specific store.

---

# 13. Cart Data

LocalMart uses a backend-managed shopping cart.

The primary entities are:

```text
Cart.java
CartItem.java
```

The conceptual relationship is:

```text
Customer
   |
   v
 Cart
   |
   +---- CartItem
   |
   +---- CartItem
   |
   +---- CartItem
```

The cart is persisted in the backend/database rather than being treated as only browser state.

---

# 14. Cart Items

`CartItem.java` represents an individual product entry inside a cart.

Conceptually:

```text
Cart
 |
 +---- CartItem
          |
          +---- Product
          |
          +---- Quantity
```

The cart item therefore connects:

```text
Cart → Product
```

while storing the quantity associated with that product.

This allows the backend to calculate the cart contents and totals.

---

# 15. Why the Cart Is Database-Backed

A browser-only cart could look like:

```text
Browser
   |
   v
localStorage
   |
   v
Cart
```

LocalMart instead uses:

```text
Frontend
   |
   v
Cart API
   |
   v
CartService
   |
   v
CartRepository / CartItemRepository
   |
   v
PostgreSQL
```

This makes the backend/database the authoritative source for cart state.

It also allows cart information to survive frontend reloads and remain associated with the authenticated customer.

---

# 16. Order Data

`Order.java` represents a customer order.

An order connects several important parts of the application:

```text
Customer
   |
   v
Order
   |
   +---- Store
   |
   +---- Order Items
   |
   +---- Payment
   |
   +---- Delivery information
```

Orders represent a persistent business transaction rather than temporary shopping state.

---

# 17. Order Items

`OrderItem.java` represents the individual products purchased in an order.

Conceptually:

```text
Order
 |
 +---- OrderItem
 |       |
 |       +---- Product
 |       +---- Quantity
 |
 +---- OrderItem
         |
         +---- Product
         +---- Quantity
```

This separates the order itself from its individual line items.

A single order can therefore contain multiple products.

---

# 18. Why Order Items Are Separate

Consider an order containing:

```text
Rice       × 2
Milk       × 1
Bread      × 3
```

The database conceptually represents:

```text
Order
 |
 +---- OrderItem → Rice  → 2
 |
 +---- OrderItem → Milk  → 1
 |
 +---- OrderItem → Bread → 3
```

This relational structure is more flexible than storing all products directly inside one order record.

It also allows each purchased item to have its own quantity and product relationship.

---

# 19. Order Lifecycle

Orders move through business states during their lifecycle.

The delivery-related status flow is:

```text
READY_FOR_PICKUP
       ↓
ACCEPTED
       ↓
PICKED_UP
       ↓
OUT_FOR_DELIVERY
       ↓
DELIVERED
```

The database stores the order's persistent state so that different users can interact with the same order throughout its lifecycle.

For example:

```text
Customer
    |
    v
Order
    |
    +---- Store Owner
    |
    +---- Delivery Partner
```

---

# 20. Payment Data

`Payment.java` represents payment information associated with an order.

The backend also contains:

```text
PaymentRepository.java
RazorpayService.java
```

Conceptually:

```text
Order
 |
 v
Payment
 |
 v
Razorpay
```

The payment entity allows payment-related state to be associated with the LocalMart order.

The actual payment-processing operation is performed through the Razorpay integration rather than by implementing payment processing directly inside PostgreSQL.

---

# 21. Delivery Partner Data

Delivery partners have role-specific information.

The primary entity is:

```text
DeliveryPartner.java
```

It is associated with the common user account.

Conceptually:

```text
User
 |
 | DELIVERY_PARTNER
 v
DeliveryPartner
```

This separates common account information from delivery-specific information.

---

# 22. Vehicle Data

Delivery partners can have vehicle-related information represented by:

```text
VehicleDetails.java
```

The conceptual relationship is:

```text
DeliveryPartner
       |
       v
VehicleDetails
```

Vehicle information supports the delivery-partner domain without placing all vehicle-specific attributes directly into the common `User` entity.

---

# 23. Delivery Partner Location

LocalMart maintains delivery-partner location information through:

```text
DeliveryPartnerLocation.java
```

The associated repository is:

```text
DeliveryPartnerLocationRepository.java
```

The conceptual relationship is:

```text
DeliveryPartner
       |
       +---- Location
       +---- Location
       +---- Location
```

Depending on the implementation, these records can represent location updates over time.

Location information is used by the delivery subsystem.

---

# 24. Delivery Location Architecture

There are multiple location sources in LocalMart.

```text
Customer Address
       |
       v
Stored coordinates

Store Address
       |
       v
Stored coordinates

Delivery Partner
       |
       v
Browser Geolocation API
       |
       v
Backend location update
       |
       v
Database
```

The browser's:

```text
navigator.geolocation.getCurrentPosition()
```

is provided by the browser's Geolocation Web API.

It is not imported from a LocalMart JavaScript library.

---

# 25. Application Requests

`ApplicationRequest.java` represents role-approval requests.

This is particularly relevant to:

* Store-owner registration
* Delivery-partner registration

The application statuses currently used are:

```text
PENDING  = 1
APPROVED = 2
REJECTED = 3
```

Conceptually:

```text
User
 |
 v
ApplicationRequest
 |
 +---- PENDING
 |
 +---- APPROVED
 |
 +---- REJECTED
```

This allows administrative approval to be represented as persistent database state.

---

# 26. Store Owner Application

A store-owner registration can result in:

```text
User
 |
 +---- Role
 |
 +---- Address
 |
 +---- StoreDetails
 |
 +---- ApplicationRequest
```

The application request represents the administrative approval process.

The store-owner account can therefore exist in a state where registration information exists but activation depends on approval/business rules.

---

# 27. Delivery Partner Application

Similarly, a delivery-partner registration can create:

```text
User
 |
 +---- Role
 |
 +---- Address
 |
 +---- VehicleDetails
 |
 +---- DeliveryPartner
 |
 +---- ApplicationRequest
```

The application request is then processed by administrative functionality.

This provides persistent separation between:

```text
Registration
```

and:

```text
Administrative approval
```

---

# 28. User Sessions

LocalMart contains:

```text
UserSession.java
UserSessionRepository.java
UserSessionService.java
```

These represent server-side session information associated with authenticated users.

Conceptually:

```text
User
 |
 +---- Session 1
 |
 +---- Session 2
 |
 +---- Session 3
```

The session layer works together with JWT authentication.

The JWT can identify the associated session, while the backend maintains session state.

---

# 29. Session and JWT Relationship

The architecture can be visualized as:

```text
Login
  |
  v
UserSession
  |
  v
JWT
  |
  v
Frontend
```

Later:

```text
Frontend
  |
  | JWT
  v
JwtAuthenticationFilter
  |
  v
JWT validation
  |
  v
Session validation
  |
  v
Authenticated request
```

This gives LocalMart server-side control over authenticated sessions.

---

# 30. Password Reset Session

The backend also contains:

```text
PasswordResetSession.java
```

under:

```text
passwordreset/entity/
```

This represents temporary state associated with password-reset operations.

Conceptually:

```text
Password Reset Request
        |
        v
PasswordResetSession
        |
        v
Verification
        |
        v
Password Change
```

This is separated from the normal authenticated user session because password reset is a different security workflow.

---

# 31. Repository Architecture

LocalMart uses Spring Data repositories for persistence.

The repository package contains:

```text
repository/
├── AddressRepository.java
├── ApplicationRequestRepository.java
├── CartItemRepository.java
├── CartRepository.java
├── DeliveryPartnerLocationRepository.java
├── DeliveryPartnerRepository.java
├── OrderItemRepository.java
├── OrderRepository.java
├── PaymentRepository.java
├── ProductRepository.java
├── RoleRepository.java
├── StoreDetailsRepository.java
├── UserRepository.java
├── UserSessionRepository.java
└── VehicleDetailsRepository.java
```

Each repository provides the persistence boundary for its corresponding domain entity.

---

# 32. Repository Request Flow

A typical database operation follows:

```text
HTTP Request
     |
     v
Controller
     |
     v
Service
     |
     v
Repository
     |
     v
Hibernate
     |
     v
PostgreSQL
```

For example, retrieving products can conceptually follow:

```text
ProductController
       |
       v
ProductService
       |
       v
ProductRepository
       |
       v
Hibernate
       |
       v
PostgreSQL
```

The controller does not directly execute SQL.

---

# 33. JPA and Hibernate

The entity classes are mapped to relational database structures through JPA annotations and Hibernate.

Conceptually:

```text
Java Object
     |
     | JPA mapping
     v
Hibernate
     |
     | SQL
     v
PostgreSQL Table
```

For example:

```text
Product.java
      ↓
Hibernate mapping
      ↓
Product table
```

The exact table and column names are determined by the entity mappings and database schema.

---

# 34. Object-Relational Mapping

ORM means that the application works primarily with Java objects while Hibernate manages their relational representation.

Without ORM, application code would need to manually handle many SQL operations.

With JPA/Hibernate:

```text
Product
   |
   v
ProductRepository
   |
   v
Hibernate
   |
   v
SQL
   |
   v
PostgreSQL
```

This allows the domain model and persistence layer to work together.

---

# 35. Database Relationships

The main domain relationships can be represented conceptually as:

```text
User
 |
 +---- Role
 |
 +---- Address
 |
 +---- UserSession
 |
 +---- Cart
 |      |
 |      +---- CartItem ---- Product ---- Store
 |
 +---- StoreDetails
 |
 +---- DeliveryPartner
 |      |
 |      +---- VehicleDetails
 |      |
 |      +---- DeliveryPartnerLocation
 |
 +---- ApplicationRequest
```

Orders form another major relationship:

```text
Order
 |
 +---- OrderItem ---- Product
 |
 +---- Payment
 |
 +---- Store
 |
 +---- Customer
```

---

# 36. High-Level Entity Relationship Model

A simplified model of LocalMart is:

```text
                         +-------------+
                         |    Role     |
                         +-------------+
                                |
                                |
                         +-------------+
                         |    User     |
                         +-------------+
                           /    |    \
                          /     |     \
                         /      |      \
                        v       v       v
                   Address    Cart    Session
                               |
                               v
                          CartItem
                               |
                               v
                            Product
                               |
                               v
                            Store
                               |
                               v
                         Store Owner
```

The order subsystem connects the shopping and fulfillment domains:

```text
Customer
   |
   v
 Order
   |
   +---- OrderItem ---- Product
   |
   +---- Payment
   |
   +---- Delivery
```

---

# 37. Data Ownership

Database relationships also establish ownership boundaries.

For example:

```text
Customer
   |
   +---- Owns cart
   |
   +---- Owns addresses
   |
   +---- Owns orders
```

A store owner:

```text
Store Owner
   |
   +---- Owns store
             |
             +---- Owns products
```

A delivery partner:

```text
Delivery Partner
   |
   +---- Vehicle
   |
   +---- Location information
   |
   +---- Delivery assignments
```

These ownership relationships are important for backend authorization.

---

# 38. Data Flow: Product Browsing

A product browsing request can follow:

```text
Customer Frontend
       |
       | GET product request
       v
ProductController
       |
       v
ProductService
       |
       v
ProductRepository
       |
       v
Hibernate
       |
       v
PostgreSQL
       |
       v
Product records
       |
       v
ProductService
       |
       v
JSON Response
       |
       v
Frontend
```

The database therefore provides the actual product data.

---

# 39. Data Flow: Cart

A cart operation follows:

```text
Customer
   |
   v
Cart API
   |
   v
CartController
   |
   v
CartService
   |
   +---- CartRepository
   |
   +---- CartItemRepository
   |
   +---- ProductRepository
   |
   v
PostgreSQL
```

The backend can then return the updated cart representation.

---

# 40. Data Flow: Order Creation

Order creation connects several database entities.

Conceptually:

```text
Customer
   |
   v
Create Order Request
   |
   v
OrderController
   |
   v
OrderService
   |
   +---- Cart
   |
   +---- CartItems
   |
   +---- Products
   |
   +---- Address
   |
   +---- Store
   |
   v
Order
   |
   +---- OrderItems
   |
   v
PostgreSQL
```

Payment and delivery processing can then operate on the persistent order.

---

# 41. Data Flow: Payment

The payment subsystem connects the LocalMart database with Razorpay.

```text
Customer
   |
   v
Checkout
   |
   v
Order / Payment logic
   |
   v
RazorpayService
   |
   v
Razorpay
   |
   v
Payment result
   |
   v
LocalMart backend
   |
   v
Payment / Order state
```

The database stores LocalMart's payment-related state while the external payment provider handles payment processing.

---

# 42. Data Flow: Delivery

Once an order enters the delivery process:

```text
Order
 |
 v
Delivery Assignment
 |
 v
Delivery Partner
 |
 +---- Current Location
 |
 v
Delivery Status
 |
 v
PostgreSQL
```

The delivery subsystem can use:

* Store coordinates
* Customer coordinates
* Delivery-partner coordinates
* Road distance
* Delivery status

to support the delivery lifecycle.

---

# 43. Database as Source of Truth

For persistent business data, LocalMart treats the backend/database as the authoritative source.

Examples include:

```text
Stores
Products
Cart
Orders
Addresses
Payments
Users
Delivery data
```

The frontend should not be treated as the authoritative database.

The architecture is:

```text
Frontend
   |
   | Request
   v
Backend
   |
   v
Database
   |
   | Authoritative state
   v
Backend
   |
   v
Frontend
```

This is particularly important for financial and transactional operations.

---

# 44. Data Consistency

Because multiple users interact with the same data, consistency matters.

For example:

```text
Customer
   |
   +---- Cart

Store Owner
   |
   +---- Product

Customer
   |
   +---- Order

Delivery Partner
   |
   +---- Delivery
```

All of these users interact with shared backend state.

Therefore business operations should be performed through service-layer logic and persisted transactionally where required.

---

# 45. Database and Security

Database architecture also supports security.

Examples:

### User identity

```text
User → Role
```

supports authorization.

### Session management

```text
User → UserSession
```

supports authenticated-session control.

### Store ownership

```text
Store Owner → Store
```

supports ownership checks.

### Customer ownership

```text
Customer → Cart / Address / Order
```

supports customer-specific access.

### Delivery ownership

```text
Delivery Partner → Delivery / Location
```

supports delivery-specific operations.

The database is therefore not just storage; its relationships support business security rules.

---

# 46. Database and Location Services

Location data is integrated into the database model.

```text
Address
 |
 +---- Latitude
 +---- Longitude
```

and:

```text
DeliveryPartnerLocation
 |
 +---- Latitude
 +---- Longitude
```

These coordinates can then be used by backend services.

For example:

```text
Store Coordinates
       +
Customer Coordinates
       |
       v
RoadDistanceService
       |
       v
OSRM
       |
       v
Road Distance / Duration
       |
       v
Delivery Calculation
```

The database stores the application's persistent location information, while external services can provide geographic calculations.

---

# 47. Database and Multi-Store Commerce

LocalMart's database is designed around a multi-store model.

The fundamental relationship is:

```text
Store
 |
 +---- Product
 |
 +---- Product
 |
 +---- Product
```

Orders then connect customers with store-specific products.

This makes the database model suitable for local-commerce functionality where customers browse products belonging to different stores.

---

# 48. Database Lifecycle

A simplified lifecycle for a customer is:

```text
Registration
    |
    v
User created
    |
    v
Role assigned
    |
    v
Address added
    |
    v
Cart created/used
    |
    v
Products selected
    |
    v
Order created
    |
    v
Payment recorded
    |
    v
Delivery
    |
    v
Order completed
```

A store owner's lifecycle can involve:

```text
Registration
    |
    v
ApplicationRequest
    |
    v
Admin approval
    |
    v
StoreDetails
    |
    v
Products
    |
    v
Store orders
```

A delivery partner's lifecycle can involve:

```text
Registration
    |
    v
ApplicationRequest
    |
    v
Admin approval
    |
    v
DeliveryPartner
    |
    v
VehicleDetails
    |
    v
Location updates
    |
    v
Delivery operations
```

---

# 49. Persistence Package Structure

The persistence layer is organized as:

```text
src/main/java/com/localmart/localmartbackend/
│
├── entity/
│   ├── Address.java
│   ├── ApplicationRequest.java
│   ├── Cart.java
│   ├── CartItem.java
│   ├── DeliveryPartner.java
│   ├── DeliveryPartnerLocation.java
│   ├── Order.java
│   ├── OrderItem.java
│   ├── Payment.java
│   ├── Product.java
│   ├── Role.java
│   ├── StoreDetails.java
│   ├── User.java
│   ├── UserSession.java
│   └── VehicleDetails.java
│
├── repository/
│   ├── AddressRepository.java
│   ├── ApplicationRequestRepository.java
│   ├── CartItemRepository.java
│   ├── CartRepository.java
│   ├── DeliveryPartnerLocationRepository.java
│   ├── DeliveryPartnerRepository.java
│   ├── OrderItemRepository.java
│   ├── OrderRepository.java
│   ├── PaymentRepository.java
│   ├── ProductRepository.java
│   ├── RoleRepository.java
│   ├── StoreDetailsRepository.java
│   ├── UserRepository.java
│   ├── UserSessionRepository.java
│   └── VehicleDetailsRepository.java
│
└── passwordreset/
    └── entity/
        └── PasswordResetSession.java
```

---

# 50. Database Design Principles

The LocalMart persistence architecture follows several important principles.

## 50.1 Separation of Concerns

Common user information is kept in the user domain while role-specific information is represented separately.

```text
User
 |
 +---- StoreDetails
 |
 +---- DeliveryPartner
 |
 +---- VehicleDetails
```

---

## 50.2 Relational Modeling

Related information is represented through relationships rather than putting every attribute into a single large record.

For example:

```text
Order
   |
   +---- OrderItem
```

instead of storing an arbitrary number of products directly inside the order.

---

## 50.3 Persistent Business State

Important business information is stored in PostgreSQL rather than only in frontend state.

---

## 50.4 Repository Abstraction

Services interact with repositories instead of embedding database-access logic throughout controllers.

---

## 50.5 ORM-Based Persistence

JPA/Hibernate handles the mapping between Java entities and relational database records.

---

## 50.6 Security Through Ownership

Database relationships allow services to determine which user owns or controls a resource.

---

# 51. Database Technology Stack

The persistence stack can be summarized as:

```text
                 LocalMart Backend
                        |
                        v
                  Spring Data JPA
                        |
                        v
                    Hibernate
                        |
                        v
                   JDBC Driver
                        |
                        v
                   PostgreSQL
```

The PostgreSQL JDBC driver provides the database connectivity layer between the Java application and PostgreSQL.

---

# 52. Database Architecture Summary

LocalMart's database is the persistent foundation of the application.

The major domains are:

```text
                    PostgreSQL
                        |
        +---------------+---------------+
        |               |               |
     Identity         Commerce       Fulfillment
        |               |               |
        v               v               v
      User            Cart            Delivery
      Role            Product         Partner
      Session         Order           Vehicle
      Address         Payment         Location
      Application
```

The backend accesses these domains through Spring Data JPA repositories and Hibernate.

The overall persistence flow is:

```text
React
  |
  v
REST API
  |
  v
Controller
  |
  v
Service
  |
  v
Repository
  |
  v
Hibernate / JPA
  |
  v
PostgreSQL
```

The central architectural principle is:

> **PostgreSQL stores the authoritative persistent state of LocalMart, while JPA/Hibernate provides the mapping between the relational database and the Java domain model.**

The database is therefore responsible not only for storing information, but also for supporting the relationships and ownership boundaries required by authentication, commerce, payments, orders, stores, and delivery.
