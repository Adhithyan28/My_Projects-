
        package com.localmart.localmartbackend.repository;

import com.localmart.localmartbackend.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {

    List<Product> findByStoreId(Long storeId);

    List<Product> findByCategoryIgnoreCase(String category);

    List<Product> findByIsAvailableTrue();

    List<Product> findByStoreIdAndIsAvailableTrue(Long storeId);
}
