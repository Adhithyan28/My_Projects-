package com.localmart.localmartbackend.dto;

import jakarta.validation.constraints.NotNull;

public class DeliveryFeeRequest {

    @NotNull(message = "Store ID is required")
    private Long storeId;

    @NotNull(message = "Address ID is required")
    private Long addressId;

    public DeliveryFeeRequest() {
    }

    public Long getStoreId() {
        return storeId;
    }

    public void setStoreId(Long storeId) {
        this.storeId = storeId;
    }

    public Long getAddressId() {
        return addressId;
    }

    public void setAddressId(Long addressId) {
        this.addressId = addressId;
    }
}