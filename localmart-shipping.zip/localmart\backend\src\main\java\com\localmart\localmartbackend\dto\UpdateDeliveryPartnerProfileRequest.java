package com.localmart.localmartbackend.dto;

public class UpdateDeliveryPartnerProfileRequest {

    private String firstName;
    private String lastName;
    private String emergencyContactPhone;

    public UpdateDeliveryPartnerProfileRequest() {
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmergencyContactPhone() {
        return emergencyContactPhone;
    }

    public void setEmergencyContactPhone(String emergencyContactPhone) {
        this.emergencyContactPhone = emergencyContactPhone;
    }
}