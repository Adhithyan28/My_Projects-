# LocalMart setup handoff

This is a source package for the LocalMart React/Vite frontend and Spring Boot backend, with PostgreSQL setup included. It is intended for local development on a fresh device.

## Requirements
- Docker Desktop with Compose
- Java 21 (for the backend)
- Node.js and npm (for the frontend)

## First-time setup
1. Copy `.env.example` to `.env` in the project root. These are local-development defaults only; replace the JWT and admin values before any shared deployment.
2. Start PostgreSQL from the project root: `docker compose up -d db`. Wait until `docker compose ps` reports the database as healthy.
3. Open a terminal in `backend` and run `./mvnw spring-boot:run` (macOS/Linux) or `.\mvnw.cmd spring-boot:run` (Windows). The first backend start creates/updates the tables in the empty database using the JPA entities (`ddl-auto=update`). The initializer creates the development admin account if it does not exist.
4. Open another terminal in `frontend`; run `npm ci` then `npm run dev`. The UI is served at `http://localhost:5174` and proxies `/api` to the backend on port 8080.

Development admin credentials are the `ADMIN_EMAIL` and `ADMIN_PASSWORD` values in `.env` (defaults: `admin@localmart.local` / `LocalMartDevOnly123!`). These are local-only defaults. Authentication flows that send OTPs, Google sign-in, X sign-in, maps/geocoding, email, and payments need their corresponding provider credentials added to `.env`; without those providers, those integration features will not work.

## Database data and persistence
The ZIP contains no copy of another machine's database records. It starts with an empty PostgreSQL database; the backend creates the schema and the development admin account. The named Docker volume `localmart-postgres-data` keeps local records across restarts. `docker compose down` stops the database without deleting that volume. To intentionally erase the local database, use `docker compose down -v` (this permanently deletes its data).

## Build
- Backend: `backend\mvnw.cmd -DskipTests package` (Windows) or `backend/mvnw -DskipTests package` (macOS/Linux).
- Frontend: from `frontend`, run `npm ci` and `npm run build`.

`ddl-auto=update` is a convenience for local setup, not a production migration strategy. For production, configure managed PostgreSQL, unique secrets and provider credentials, and adopt reviewed schema migrations/backups before deployment.
