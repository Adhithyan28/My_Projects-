import { useState } from "react"
import { useAuth } from "../context/AuthContext"
import GoogleSignInButton from "../components/GoogleSignInButton"

interface LoginProps {
    onRegister: () => void
    onForgotPassword: () => void
}

function Login({
                   onRegister,
                   onForgotPassword
               }: LoginProps) {

    const { login } = useAuth()

    const [step, setStep] = useState(1)

    const [identifier, setIdentifier] = useState("")
    const [password, setPassword] = useState("")
    const [showPassword, setShowPassword] = useState(false)

    const [otp, setOtp] = useState("")

    const [otpDestination, setOtpDestination] =
        useState("")

    const [otpType, setOtpType] =
        useState<"EMAIL" | "MOBILE">("EMAIL")

    const [message, setMessage] = useState("")
    const [messageType, setMessageType] =
        useState<"success" | "error">("success")

    const [loading, setLoading] = useState(false)


    // ============================================================
    // X OAUTH BACKEND ORIGIN
    // ============================================================

    const X_OAUTH_ORIGIN =
        "http://localhost:8080"


    // ============================================================
    // EXTRACT BACKEND MESSAGE
    // ============================================================

    const getResponseMessage = async (
        response: Response
    ): Promise<string> => {

        const text = await response.text()

        if (!text) {
            return "Something went wrong. Please try again."
        }

        try {

            const data = JSON.parse(text)

            if (typeof data === "string") {
                return data
            }

            if (data?.message) {
                return data.message
            }

            if (data?.error) {
                return data.error
            }

            return text

        } catch {

            return text
        }
    }


    // ============================================================
    // EXTRACT MESSAGE FROM PARSED DATA
    // ============================================================

    const getResponseMessageFromData = (
        data: unknown,
        fallback: string
    ): string => {

        if (typeof data === "string") {
            return data || fallback
        }

        if (
            typeof data === "object" &&
            data !== null
        ) {

            const responseData =
                data as {
                    message?: string
                    error?: string
                }

            if (responseData.message) {
                return responseData.message
            }

            if (responseData.error) {
                return responseData.error
            }
        }

        return fallback
    }


    // ============================================================
    // VALIDATION
    // ============================================================

    const detectIdentifierType = (
        value: string
    ): "EMAIL" | "MOBILE" | "" => {

        const trimmed =
            value.trim()

        const emailRegex =
            /^[^\s@]+@[^\s@]+\.[^\s@]+$/

        const phoneRegex =
            /^[6-9]\d{9}$/

        if (emailRegex.test(trimmed)) {
            return "EMAIL"
        }

        if (phoneRegex.test(trimmed)) {
            return "MOBILE"
        }

        return ""
    }


    // ============================================================
    // MASK EMAIL
    // ============================================================

    const maskEmail = (
        email: string
    ): string => {

        const parts =
            email.split("@")

        if (parts.length !== 2) {
            return email
        }

        const username =
            parts[0]

        const domain =
            parts[1]

        if (!username) {
            return email
        }

        if (username.length <= 2) {

            return (
                username[0] +
                "***@" +
                domain
            )
        }

        return (
            username.substring(0, 2) +
            "***@" +
            domain
        )
    }


    // ============================================================
    // GET OTP DESTINATION
    // ============================================================

    const getOtpDestination = (): string => {

        if (otpType === "EMAIL") {
            return otpDestination
        }

        return (
            "mobile number ending in " +
            identifier.trim().slice(-4)
        )
    }


    // ============================================================
    // LOGIN CONTINUE
    // ============================================================

    const handleContinue = async () => {

        setMessage("")
        setMessageType("success")

        const trimmedIdentifier =
            identifier.trim()

        if (!trimmedIdentifier) {

            setMessageType("error")

            setMessage(
                "Please enter your email or mobile number"
            )

            return
        }

        const detectedType =
            detectIdentifierType(
                trimmedIdentifier
            )

        if (!detectedType) {

            setMessageType("error")

            setMessage(
                "Please enter a valid email or 10-digit mobile number"
            )

            return
        }

        if (!password) {

            setMessageType("error")

            setMessage(
                "Please enter your password"
            )

            return
        }

        setLoading(true)

        try {

            const response =
                await fetch(
                    "/api/users/login/send-otp",
                    {
                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/json"
                        },

                        body: JSON.stringify({
                            login:
                            trimmedIdentifier,

                            password:
                            password
                        })
                    }
                )

            const result =
                await getResponseMessage(
                    response
                )

            if (!response.ok) {

                setMessageType("error")

                setMessage(result)

                return
            }

            setOtpType(
                detectedType
            )

            if (
                detectedType ===
                "EMAIL"
            ) {

                setOtpDestination(
                    maskEmail(
                        trimmedIdentifier
                    )
                )

            } else {

                setOtpDestination(
                    `mobile number ending in ${trimmedIdentifier.slice(-4)}`
                )
            }

            setOtp("")

            setStep(2)

            setMessageType("success")

            if (
                detectedType ===
                "EMAIL"
            ) {

                setMessage(
                    "OTP sent successfully to your registered email"
                )

            } else {

                setMessage(
                    "OTP sent successfully to your registered mobile number"
                )
            }

        } catch (error) {

            console.error(
                "Login OTP error:",
                error
            )

            setMessageType("error")

            if (
                error instanceof Error
            ) {

                setMessage(
                    error.message
                )

            } else {

                setMessage(
                    "Login failed. Please try again."
                )
            }

        } finally {

            setLoading(false)
        }
    }


    // ============================================================
    // VERIFY OTP
    // ============================================================

    const handleVerifyOtp = async () => {

        setMessage("")
        setMessageType("success")

        if (!otp.trim()) {

            setMessageType("error")

            setMessage(
                "Please enter the OTP"
            )

            return
        }

        if (otp.trim().length !== 6) {

            setMessageType("error")

            setMessage(
                "Please enter a valid 6-digit OTP"
            )

            return
        }

        setLoading(true)

        try {

            const response =
                await fetch(
                    "/api/users/login/verify",
                    {
                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/json"
                        },

                        body: JSON.stringify({
                            login:
                                identifier.trim(),

                            otp:
                                otp.trim()
                        })
                    }
                )

            const result =
                await getResponseMessage(
                    response
                )

            if (!response.ok) {

                setMessageType("error")

                setMessage(result)

                return
            }

            let loginResponse: any

            try {

                loginResponse =
                    JSON.parse(result)

            } catch {

                setMessageType("error")

                setMessage(
                    "Invalid login response from server"
                )

                return
            }

            if (
                !loginResponse ||
                !loginResponse.token
            ) {

                setMessageType("error")

                setMessage(
                    "Invalid login response from server"
                )

                return
            }

            login(
                loginResponse
            )

            setMessageType("success")

            setMessage(
                "Login successful"
            )

        } catch (error) {

            console.error(
                "OTP verification error:",
                error
            )

            setMessageType("error")

            if (
                error instanceof Error
            ) {

                setMessage(
                    error.message
                )

            } else {

                setMessage(
                    "Invalid OTP. Please try again."
                )
            }

        } finally {

            setLoading(false)
        }
    }


    // ============================================================
    // GOOGLE LOGIN
    // ============================================================

    const handleGoogleLogin = async (
        credential: string
    ) => {

        if (!credential) {

            setMessageType("error")

            setMessage(
                "Google authentication did not return a valid credential."
            )

            return
        }

        setMessage("")
        setMessageType("success")
        setLoading(true)

        try {

            const response =
                await fetch(
                    "/api/users/google/login",
                    {
                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/json"
                        },

                        body: JSON.stringify({
                            credential:
                            credential
                        })
                    }
                )

                const contentType =
                    response.headers.get(
                        "content-type"
                    )

                let data: any

                if (
                    contentType &&
                    contentType.includes(
                        "application/json"
                    )
                ) {

                    data =
                        await response.json()

                } else {

                    data =
                        await response.text()
                }

                if (!response.ok) {

                    throw new Error(
                        getResponseMessageFromData(
                            data,
                            "Google login failed."
                        )
                    )
                }

                if (
                    !data ||
                    !data.token
                ) {

                    throw new Error(
                        "Invalid login response from server."
                    )
                }

                login(
                    data
                )

                setMessageType("success")

                setMessage(
                    "Google login successful"
                )

            } catch (error) {

                console.error(
                    "Google login error:",
                    error
                )

                setMessageType("error")

                if (
                    error instanceof Error
                ) {

                    setMessage(
                        error.message
                    )

                } else {

                    setMessage(
                        "Google login failed. Please try again."
                    )
                }

            } finally {

                setLoading(false)
            }
        }


    // ============================================================
    // X LOGIN
    // ============================================================

    const handleXLogin = () => {

        setMessage("")
        setMessageType("success")
        setLoading(true)

        let messageHandled = false

        let popupCheckInterval:
            number | undefined


        // --------------------------------------------------------
        // CLEANUP
        // --------------------------------------------------------

        const cleanup = () => {

            window.removeEventListener(
                "message",
                handleXMessage
            )

            if (
                popupCheckInterval !==
                undefined
            ) {

                window.clearInterval(
                    popupCheckInterval
                )

                popupCheckInterval =
                    undefined
            }
        }


        // --------------------------------------------------------
        // RECEIVE MESSAGE FROM X CALLBACK POPUP
        // --------------------------------------------------------

        const handleXMessage = (
            event: MessageEvent
        ) => {


            console.log(
                "========== X MESSAGE RECEIVED =========="
            )

            console.log(
                "X MESSAGE ORIGIN:",
                event.origin
            )

            console.log(
                "X MESSAGE TYPE:",
                event.data?.type
            )


            // ----------------------------------------------------
            // SECURITY CHECK
            // ----------------------------------------------------

            if (
                event.origin !==
                X_OAUTH_ORIGIN
            ) {

                console.log(
                    "X MESSAGE IGNORED: unexpected origin"
                )

                return
            }


            const data =
                event.data


            // ----------------------------------------------------
            // SUCCESS
            // ----------------------------------------------------

            if (
                data?.type ===
                "X_LOGIN_SUCCESS"
            ) {

                console.log(
                    "X LOGIN SUCCESS MESSAGE RECEIVED"
                )

                messageHandled = true

                cleanup()

                const userData =
                    data.data


                if (
                    !userData ||
                    !userData.token
                ) {

                    setLoading(false)

                    setMessageType(
                        "error"
                    )

                    setMessage(
                        "Invalid login response from X."
                    )

                    return
                }


                // ------------------------------------------------
                // SAME AUTH CONTEXT LOGIN USED BY:
                //
                // 1. OTP login
                // 2. Google login
                // 3. X login
                // ------------------------------------------------

                login(
                    userData
                )

                setLoading(false)

                setMessageType(
                    "success"
                )

                setMessage(
                    "X login successful"
                )

                return
            }


            // ----------------------------------------------------
            // ERROR
            // ----------------------------------------------------

            if (
                data?.type ===
                "X_AUTH_ERROR"
            ) {

                console.log(
                    "X AUTH ERROR MESSAGE RECEIVED"
                )

                messageHandled = true

                cleanup()

                setLoading(false)

                setMessageType(
                    "error"
                )

                setMessage(
                    data.message ||
                    "X login failed. Please try again."
                )

                return
            }


            console.log(
                "X MESSAGE IGNORED: unknown message type"
            )
        }


        // --------------------------------------------------------
        // REGISTER MESSAGE LISTENER
        // --------------------------------------------------------

        window.addEventListener(
            "message",
            handleXMessage
        )


        // --------------------------------------------------------
        // OPEN X LOGIN POPUP
        // --------------------------------------------------------

        const popup =
            window.open(
                "/api/users/x/login",
                "localmart-x-login",
                "width=500,height=700,resizable=yes,scrollbars=yes"
            )


        // --------------------------------------------------------
        // POPUP BLOCKED
        // --------------------------------------------------------

        if (!popup) {

            cleanup()

            setLoading(false)

            setMessageType(
                "error"
            )

            setMessage(
                "Please allow popups in your browser to continue with X."
            )

            return
        }


        // --------------------------------------------------------
        // CHECK WHETHER POPUP WAS CLOSED
        // --------------------------------------------------------

        popupCheckInterval =
            window.setInterval(() => {

                if (
                    popup.closed
                ) {

                    window.clearInterval(
                        popupCheckInterval
                    )

                    popupCheckInterval =
                        undefined

                    cleanup()


                    // ------------------------------------------------
                    // IMPORTANT:
                    //
                    // If the backend already sent a message,
                    // messageHandled will be true.
                    //
                    // Therefore we won't incorrectly display
                    // "X login was cancelled".
                    // ------------------------------------------------

                    if (
                        !messageHandled
                    ) {

                        console.log(
                            "X POPUP CLOSED WITHOUT AUTH MESSAGE"
                        )

                        setLoading(false)

                        setMessageType(
                            "error"
                        )

                        setMessage(
                            "X login was cancelled or the authentication window closed before LocalMart received the result."
                        )
                    }

                }

            }, 500)
    }


    // ============================================================
    // PREVIOUS
    // =================================== otp=========================

    const handlePrevious = () => {

        setMessage("")
        setMessageType("success")

        setOtp("")

        setStep(1)
    }


    // ============================================================
    // RESEND OTP
    // ============================================================

    const handleResendOtp = async () => {

        setMessage("")
        setMessageType("success")

        setLoading(true)

        try {

            const response =
                await fetch(
                    "/api/users/login/send-otp",
                    {
                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/json"
                        },

                        body: JSON.stringify({
                            login:
                                identifier.trim(),

                            password:
                            password
                        })
                    }
                )

            const result =
                await getResponseMessage(
                    response
                )

            if (!response.ok) {

                setMessageType("error")

                setMessage(result)

                return
            }

            setOtp("")

            setMessageType("success")

            if (
                otpType ===
                "EMAIL"
            ) {

                setMessage(
                    "OTP resent successfully to your registered email"
                )

            } else {

                setMessage(
                    "OTP resent successfully to your registered mobile number"
                )
            }

        } catch (error) {

            console.error(
                "Resend OTP error:",
                error
            )

            setMessageType("error")

            if (
                error instanceof Error
            ) {

                setMessage(
                    error.message
                )

            } else {

                setMessage(
                    "Unable to resend OTP"
                )
            }

        } finally {

            setLoading(false)
        }
    }


    // ============================================================
    // GO TO REGISTER
    // ============================================================

    const handleGoToRegister = () => {

        onRegister()
    }


    // ============================================================
    // UI
    // ============================================================

    return (

        <div className="login-form">

            <h2>
                {step === 1
                    ? "Welcome back"
                    : "Verify your login"}
            </h2>

            {step === 1 && (

                <p className="form-subtitle">
                    Login to your LocalMart account
                </p>
            )}

            {step === 2 && (

                <p className="form-subtitle">
                    Enter the OTP sent to{" "}
                    {getOtpDestination()}
                </p>
            )}


            {/* =====================================================
                    STEP 1 - LOGIN DETAILS
                ===================================================== */}

            {step === 1 && (

                <div className="form-section">

                    <label>
                        Email or mobile number
                    </label>

                    <input
                        className="input"
                        type="text"
                        placeholder="Enter your email or mobile number"
                        value={identifier}
                        onChange={(e) =>
                            setIdentifier(
                                e.target.value
                            )
                        }
                        autoComplete="username"
                    />

                    <label>
                        Password
                    </label>

                    <div
                        style={{
                            position:
                                "relative",
                            width:
                                "100%"
                        }}
                    >

                        <input
                            className="input"
                            type={
                                showPassword
                                    ? "text"
                                    : "password"
                            }
                            placeholder="Enter your password"
                            value={password}
                            onChange={(e) =>
                                setPassword(
                                    e.target.value
                                )
                            }
                            autoComplete="current-password"
                            style={{
                                paddingRight:
                                    "48px"
                            }}
                        />

                        <button
                            type="button"
                            onClick={() =>
                                setShowPassword(
                                    !showPassword
                                )
                            }
                            aria-label={
                                showPassword
                                    ? "Hide password"
                                    : "Show password"
                            }
                            style={{
                                position:
                                    "absolute",
                                right:
                                    "12px",
                                top:
                                    "50%",
                                transform:
                                    "translateY(-50%)",
                                border:
                                    "none",
                                background:
                                    "transparent",
                                cursor:
                                    "pointer",
                                padding:
                                    "4px",
                                fontSize:
                                    "18px",
                                lineHeight:
                                    "1"
                            }}
                        >

                            {showPassword
                                ? "🙈"
                                : "👁️"}

                        </button>

                    </div>


                    {/* =================================================
                            FORGOT PASSWORD
                        ================================================= */}

                    <div
                        style={{
                            display:
                                "flex",
                            justifyContent:
                                "flex-end",
                            marginTop:
                                "8px"
                        }}
                    >

                        <button
                            type="button"
                            onClick={
                                onForgotPassword
                            }
                            style={{
                                border:
                                    "none",
                                background:
                                    "transparent",
                                cursor:
                                    "pointer",
                                padding:
                                    "4px 0",
                                fontSize:
                                    "14px"
                            }}
                        >
                            Forgot password?
                        </button>

                    </div>


                    {/* =================================================
                            CONTINUE
                        ================================================= */}

                    <div
                        className="login-navigation"
                        style={{
                            display:
                                "flex",
                            justifyContent:
                                "flex-end",
                            alignItems:
                                "center",
                            marginTop:
                                "24px",
                            width:
                                "100%"
                        }}
                    >

                        <button
                            type="button"
                            className="button"
                            onClick={
                                handleContinue
                            }
                            disabled={
                                loading
                            }
                            style={{
                                minWidth:
                                    "130px",
                                height:
                                    "44px"
                            }}
                        >

                            {loading
                                ? "Sending..."
                                : "Continue"}

                        </button>

                    </div>


                    {/* =================================================
                            SOCIAL LOGIN
                        ================================================= */}

                    <div
                        style={{
                            marginTop:
                                "24px",
                            borderTop:
                                "1px solid #ddd",
                            paddingTop:
                                "20px"
                        }}
                    >

                        <p
                            style={{
                                textAlign:
                                    "center",
                                fontSize:
                                    "14px",
                                marginBottom:
                                    "8px"
                            }}
                        >
                            Or continue with
                        </p>


                        {/* =================================================
                                GOOGLE LOGIN
                            ================================================= */}

                        <GoogleSignInButton
                            onCredential={
                                handleGoogleLogin
                            }
                            disabled={
                                loading
                            }
                        />


                        {/* =================================================
                                X LOGIN
                            ================================================= */}

                        <div
                            style={{
                                width:
                                    "240px",
                                height:
                                    "40px",
                                margin:
                                    "12px auto 0",
                                padding:
                                    0,
                                display:
                                    "flex",
                                justifyContent:
                                    "center",
                                alignItems:
                                    "center",
                                boxSizing:
                                    "border-box"
                            }}
                        >

                            <button
                                type="button"
                                onClick={
                                    handleXLogin
                                }
                                disabled={
                                    loading
                                }
                                style={{
                                    width:
                                        "240px",
                                    height:
                                        "40px",
                                    margin:
                                        0,
                                    padding:
                                        0,
                                    border:
                                        "1px solid #dadce0",
                                    borderRadius:
                                        "4px",
                                    background:
                                        "#ffffff",
                                    color:
                                        "#3c4043",
                                    cursor:
                                        loading
                                            ? "not-allowed"
                                            : "pointer",
                                    fontSize:
                                        "14px",
                                    fontWeight:
                                        500,
                                    display:
                                        "flex",
                                    alignItems:
                                        "center",
                                    justifyContent:
                                        "center",
                                    gap:
                                        "8px",
                                    boxSizing:
                                        "border-box",
                                    fontFamily:
                                        "Arial, sans-serif"
                                }}
                            >

                                <span
                                    style={{
                                        fontSize:
                                            "18px",
                                        fontWeight:
                                            700,
                                        lineHeight:
                                            1,
                                        display:
                                            "flex",
                                        alignItems:
                                            "center",
                                        justifyContent:
                                            "center"
                                    }}
                                >
                                    𝕏
                                </span>

                                <span

                                >
                                    {loading
                                        ? "Connecting..."
                                        : "Continue with X "}
                                </span>

                            </button>

                        </div>

                    </div>

                </div>
            )}


            {/* =====================================================
                    STEP 2 - OTP VERIFICATION
                ===================================================== */}

            {step === 2 && (

                <div className="form-section">

                    <h3>
                        {otpType === "EMAIL"
                            ? "Email Verification"
                            : "Mobile Verification"}
                    </h3>

                    <p>
                        For security, we sent a
                        one-time password to{" "}
                        {getOtpDestination()}.
                    </p>

                    <label>
                        Enter OTP
                    </label>

                    <input
                        className="input"
                        type="text"
                        inputMode="numeric"
                        maxLength={6}
                        placeholder="Enter 6-digit OTP"
                        value={otp}
                        onChange={(e) =>
                            setOtp(
                                e.target.value.replace(
                                    /\D/g,
                                    ""
                                )
                            )
                        }
                        autoComplete="one-time-code"
                    />


                    {/* =================================================
                            NAVIGATION
                        ================================================= */}

                    <div
                        className="login-navigation"
                        style={{
                            display:
                                "flex",
                            justifyContent:
                                "space-between",
                            alignItems:
                                "center",
                            gap:
                                "16px",
                            marginTop:
                                "24px",
                            width:
                                "100%"
                        }}
                    >

                        <button
                            type="button"
                            className="button secondary-button"
                            onClick={
                                handlePrevious
                            }
                            disabled={
                                loading
                            }
                            style={{
                                minWidth:
                                    "110px",
                                height:
                                    "44px"
                            }}
                        >
                            Previous
                        </button>

                        <button
                            type="button"
                            className="button"
                            onClick={
                                handleVerifyOtp
                            }
                            disabled={
                                loading
                            }
                            style={{
                                minWidth:
                                    "130px",
                                height:
                                    "44px"
                            }}
                        >

                            {loading
                                ? "Verifying..."
                                : "Verify & Login"}

                        </button>

                    </div>


                    {/* =================================================
                            RESEND OTP
                        ================================================= */}

                    <div
                        style={{
                            textAlign:
                                "center",
                            marginTop:
                                "20px"
                        }}
                    >

                        <button
                            type="button"
                            onClick={
                                handleResendOtp
                            }
                            disabled={
                                loading
                            }
                            style={{
                                border:
                                    "none",
                                background:
                                    "transparent",
                                cursor:
                                    loading
                                        ? "not-allowed"
                                        : "pointer",
                                fontSize:
                                    "14px"
                            }}
                        >
                            Resend OTP
                        </button>

                    </div>

                </div>
            )}


            {/* =====================================================
                    MESSAGE
                ===================================================== */}

            {message && (

                <p
                    className="message"
                    style={{
                        color:
                            messageType ===
                            "error"
                                ? "red"
                                : undefined
                    }}
                >
                    {message}
                </p>
            )}


            {/* =====================================================
                    REGISTER LINK
                ===================================================== */}

            {step === 1 && (

                <div
                    style={{
                        textAlign:
                            "center",
                        marginTop:
                            "24px",
                        fontSize:
                            "14px"
                    }}
                >

                    Don't have an account?{" "}

                    <button
                        type="button"
                        onClick={
                            handleGoToRegister
                        }
                        style={{
                            border:
                                "none",
                            background:
                                "transparent",
                            cursor:
                                "pointer",
                            fontWeight:
                                600
                        }}
                    >
                        Create account
                    </button>

                </div>
            )}

        </div>
    )
}

export default Login