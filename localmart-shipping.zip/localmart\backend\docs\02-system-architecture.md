# LocalMart — System Architecture

**Version:** 1.0
**Project:** LocalMart
**Document Type:** System Architecture Documentation
**Application Type:** Full-Stack Local-Commerce / Quick-Commerce Platform

---

## 1. Purpose

This document describes the technical architecture of the LocalMart application.

The purpose of this document is to explain:

* How the frontend, backend, database, and external services interact.
* How an HTTP request travels through the LocalMart backend.
* How Spring Boot components are organized.
* How authentication and authorization are integrated into the request lifecycle.
* How business logic is separated from HTTP handling and database access.
* How external services are integrated into the application.
* How data moves between the different architectural layers.
* The responsibilities of the major packages and components.

This document focuses on the **technical structure and communication between components** rather than individual business flows.

Detailed feature-specific flows are documented separately under the `docs/flows/` directory.

---

# 2. High-Level Architecture

LocalMart follows a **client-server architecture**.

The major components are:

```text
                    ┌──────────────────────────┐
                    │      LocalMart User      │
                    │       Web Browser        │
                    └────────────┬─────────────┘
                                 │
                                 │ HTTP / JSON
                                 ▼
                    ┌──────────────────────────┐
                    │   React + TypeScript     │
                    │        Frontend          │
                    │       Vite Server        │
                    └────────────┬─────────────┘
                                 │
                                 │ REST API
                                 ▼
              ┌────────────────────────────────────┐
              │       Spring Boot Backend          │
              │                                    │
              │  ┌──────────────────────────────┐  │
              │  │       Security Layer         │  │
              │  │ JWT / Authentication /       │  │
              │  │ Authorization / Rate Limit   │  │
              │  └──────────────┬───────────────┘  │
              │                 │                  │
              │  ┌──────────────▼───────────────┐  │
              │  │         Controllers          │  │
              │  └──────────────┬───────────────┘  │
              │                 │                  │
              │  ┌──────────────▼───────────────┐  │
              │  │           Services            │  │
              │  └──────────────┬───────────────┘  │
              │                 │                  │
              │  ┌──────────────▼───────────────┐  │
              │  │         Repositories          │  │
              │  └──────────────┬───────────────┘  │
              │                 │                  │
              │  ┌──────────────▼───────────────┐  │
              │  │      JPA / Hibernate          │  │
              │  └──────────────┬───────────────┘  │
              └─────────────────┼──────────────────┘
                                │
                                │ JDBC
                                ▼
                    ┌──────────────────────────┐
                    │       PostgreSQL         │
                    │        Database          │
                    └──────────────────────────┘


       ┌─────────────────────────────────────────────┐
       │             External Services               │
       │                                             │
       │ Google │ Message Central │ Gmail SMTP       │
       │ Razorpay │ OSRM │ Geocoding                │
       └─────────────────────────────────────────────┘
```

---

# 3. Architectural Style

LocalMart primarily uses a **layered backend architecture**.

The backend separates responsibilities into different layers:

```text
HTTP Request
     │
     ▼
Security
     │
     ▼
Controller
     │
     ▼
DTO
     │
     ▼
Service
     │
     ▼
Repository
     │
     ▼
JPA / Hibernate
     │
     ▼
JDBC
     │
     ▼
PostgreSQL
```

Each layer has a specific responsibility.

The purpose of this separation is to prevent HTTP handling, business rules, authentication logic, and database operations from being mixed together.

---

# 4. Frontend Architecture

The LocalMart frontend is implemented using:

* React
* TypeScript
* Vite
* Browser Fetch API
* Browser Geolocation API
* Browser Local Storage

The frontend is responsible for:

* Rendering the user interface.
* Collecting user input.
* Sending HTTP requests to the backend.
* Receiving JSON responses.
* Managing frontend state.
* Managing the authenticated user session on the client side.
* Accessing browser-provided location information.
* Displaying backend validation and business responses.

The frontend should not be responsible for core business rules that must be trusted by the server.

For example:

```text
Frontend
   │
   │ "Add product to cart"
   ▼
Backend
   │
   ├── Authenticate user
   ├── Validate product
   ├── Validate store
   ├── Validate quantity
   └── Update database
```

The backend remains responsible for enforcing business rules.

---

# 5. Backend Architecture

The backend is implemented using:

* Java 21
* Spring Boot
* Spring MVC / Spring Web
* Spring Data JPA
* Hibernate
* Spring Security
* JJWT
* PostgreSQL

The main application package is:

```text
com.localmart.localmartbackend
```

The main application entry point is:

```text
LocalmartBackendApplication.java
```

The backend is divided into the following major packages:

```text
com.localmart.localmartbackend
│
├── config
├── controller
├── dto
├── entity
├── exception
├── passwordreset
├── repository
├── security
├── service
└── smsotp
```

---

# 6. Package Responsibilities

## 6.1 `config`

Location:

```text
src/main/java/com/localmart/localmartbackend/config
```

Contains application configuration components.

Current components include:

```text
AdminInitializer.java
CorsConfig.java
GoogleAuthProperties.java
XAuthProperties.java
```

### Responsibilities

The configuration layer is responsible for application-wide configuration and initialization.

Examples:

* Initial administrator initialization.
* CORS configuration.
* Google authentication properties.
* X authentication properties.

---

# 7. Controller Layer

Location:

```text
src/main/java/com/localmart/localmartbackend/controller
```

Controllers are responsible for handling HTTP requests.

Current controllers include:

```text
AdminController.java
AdminDataController.java
AdminRequestController.java
CartController.java
CustomerAddressController.java
CustomerController.java
DeliveryPartnerLocationController.java
DeliveryPartnerProfileController.java
LocationController.java
OrderController.java
ProductController.java
StoreController.java
StoreOwnerController.java
StoreOwnerOrderController.java
UserController.java
XOAuthController.java
```

A controller typically performs the following tasks:

```text
HTTP Request
     │
     ▼
Controller
     │
     ├── Read path/query/body parameters
     │
     ├── Convert JSON into DTO
     │
     ├── Call Service
     │
     └── Return HTTP Response
```

Controllers should generally avoid containing complex business logic.

For example:

```java
@PostMapping("/google/login")
public ResponseEntity<UserResponse> googleLogin(
        @RequestBody GoogleAuthRequest request) {

    UserResponse response =
            userService.googleLogin(request);

    return ResponseEntity.ok(response);
}
```

The controller receives the HTTP request and delegates the actual authentication work to the service layer.

---

# 8. DTO Layer

Location:

```text
src/main/java/com/localmart/localmartbackend/dto
```

DTO stands for:

**Data Transfer Object**

DTOs define the data exchanged between the client and backend.

Examples:

```text
LoginRequest.java
LoginOtpRequest.java
VerifyOtpRequest.java
UserRegistrationRequest.java
GoogleAuthRequest.java
AddCartItemRequest.java
CreateOrderRequest.java
DeliveryFeeRequest.java
CustomerAddressRequest.java
```

DTOs prevent the application from directly exposing internal database entities as API contracts.

The general flow is:

```text
JSON Request
     │
     ▼
Request DTO
     │
     ▼
Service
     │
     ▼
Entity
```

For responses:

```text
Entity
     │
     ▼
Service
     │
     ▼
Response DTO
     │
     ▼
JSON Response
```

---

# 9. Entity Layer

Location:

```text
src/main/java/com/localmart/localmartbackend/entity
```

The entity layer represents persistent database data.

Current entities include:

```text
Address.java
ApplicationRequest.java
Cart.java
CartItem.java
DeliveryPartner.java
DeliveryPartnerLocation.java
Order.java
OrderItem.java
Payment.java
Product.java
Role.java
StoreDetails.java
User.java
UserSession.java
VehicleDetails.java
```

These classes are mapped to database tables using JPA annotations.

Conceptually:

```text
Java Entity
     │
     │ JPA mapping
     ▼
Database Table
```

For example:

```text
User.java
    │
    ▼
users table
```

and:

```text
Product.java
    │
    ▼
products table
```

The exact table and column mappings are defined by the annotations and configuration in the actual entity classes.

---

# 10. Repository Layer

Location:

```text
src/main/java/com/localmart/localmartbackend/repository
```

Repositories provide database access through Spring Data JPA.

Current repositories include:

```text
AddressRepository.java
ApplicationRequestRepository.java
CartItemRepository.java
CartRepository.java
DeliveryPartnerLocationRepository.java
DeliveryPartnerRepository.java
OrderItemRepository.java
OrderRepository.java
PaymentRepository.java
ProductRepository.java
RoleRepository.java
StoreDetailsRepository.java
UserRepository.java
UserSessionRepository.java
VehicleDetailsRepository.java
```

The repository layer abstracts database operations from business logic.

Conceptually:

```text
Service
   │
   ▼
Repository
   │
   ▼
JPA / Hibernate
   │
   ▼
PostgreSQL
```

This means the service does not need to manually construct SQL for every standard CRUD operation.

---

# 11. Service Layer

Location:

```text
src/main/java/com/localmart/localmartbackend/service
```

The service layer contains application and business logic.

Current services include:

```text
AdminDataService.java
AdminRequestService.java
AdminService.java
CartService.java
CustomerAddressService.java
CustomerService.java
DeliveryPartnerLocationService.java
DeliveryPartnerProfileService.java
EmailService.java
GeocodingService.java
GoogleTokenVerificationService.java
MessageCentralOtpService.java
MockOtpDeliveryService.java
OrderService.java
OtpDeliveryService.java
OtpService.java
ProductService.java
RazorpayService.java
RegistrationVerificationService.java
RoadDistanceService.java
StoreOwnerService.java
StoreService.java
TotpService.java
UserService.java
UserSessionService.java
XOAuthService.java
```

The service layer is where the application decides **what should happen**.

For example:

```text
Customer requests an address update
              │
              ▼
CustomerAddressController
              │
              ▼
CustomerAddressService
              │
              ├── Validate customer
              ├── Validate address
              ├── Validate coordinates
              ├── Apply business rules
              └── Save address
                     │
                     ▼
              AddressRepository
```

This separation allows business rules to remain independent from HTTP-specific code.

---

# 12. Security Architecture

Security is handled through Spring Security and LocalMart security components.

Location:

```text
src/main/java/com/localmart/localmartbackend/security
```

Current security components include:

```text
SecurityConfig.java
JwtAuthenticationFilter.java
JwtService.java
RateLimitFilter.java
```

The security architecture contains several responsibilities:

* Authentication.
* JWT validation.
* Authorization.
* Security context creation.
* Request filtering.
* Rate limiting.

---

# 13. HTTP Request Security Flow

For an authenticated API request, the conceptual flow is:

```text
Browser
   │
   │ Authorization: Bearer <JWT>
   ▼
Spring Security
   │
   ▼
JwtAuthenticationFilter
   │
   ├── Read Authorization header
   │
   ├── Extract JWT
   │
   ├── Validate JWT
   │
   ├── Extract user information
   │
   └── Create Authentication
   │
   ▼
SecurityContext
   │
   ▼
Controller
```

If authentication fails, the request does not proceed normally to the protected controller.

---

# 14. JWT Architecture

LocalMart uses JSON Web Tokens for authenticated API communication.

The conceptual flow is:

```text
User Login
    │
    ▼
UserService
    │
    ▼
Authentication Successful
    │
    ▼
JwtService
    │
    ▼
JWT Created
    │
    ▼
Frontend
```

For subsequent requests:

```text
Frontend
    │
    │ Authorization: Bearer JWT
    ▼
JwtAuthenticationFilter
    │
    ▼
JwtService
    │
    ▼
Validate JWT
    │
    ▼
SecurityContext
    │
    ▼
Controller
```

The JWT allows the backend to identify the authenticated user on subsequent requests.

---

# 15. Session Architecture

LocalMart also contains:

```text
UserSession.java
UserSessionRepository.java
UserSessionService.java
```

The session mechanism works alongside JWT-based authentication.

The purpose is to allow the backend to maintain server-side session information associated with authenticated users.

The exact session rules are implemented in:

```text
UserSessionService.java
```

and should be referenced when documenting individual authentication flows.

---

# 16. Rate Limiting

LocalMart contains:

```text
RateLimitFilter.java
```

The rate-limiting layer is intended to restrict excessive requests to the backend.

Conceptually:

```text
HTTP Request
     │
     ▼
Rate Limit Check
     │
     ├── Allowed ───────► Continue
     │
     └── Limit exceeded ► Reject
```

Rate limiting is particularly relevant for endpoints such as:

* Login.
* OTP generation.
* OTP verification.
* Authentication-related endpoints.

The exact limits and implementation rules are defined by the current `RateLimitFilter` implementation.

---

# 17. External Service Architecture

LocalMart integrates with external systems for functionality that is not implemented entirely inside the application.

The current architecture includes integrations for:

```text
Google
Message Central
Gmail SMTP
Razorpay
OSRM
Geocoding Service
```

Conceptually:

```text
                         ┌───────────────┐
                         │   LocalMart   │
                         │    Backend    │
                         └───────┬───────┘
                                 │
             ┌───────────────────┼───────────────────┐
             │                   │                   │
             ▼                   ▼                   ▼
          Google          Message Central        Gmail SMTP
       Authentication       SMS / OTP             Email
             │
             │
             ├─────────────────────────────────────┐
             │                                     │
             ▼                                     ▼
          Razorpay                                OSRM
          Payments                         Road Distance
             │
             │
             ▼
        Geocoding Service
```

The backend service classes responsible for these integrations include:

```text
GoogleTokenVerificationService.java
MessageCentralOtpService.java
EmailService.java
RazorpayService.java
RoadDistanceService.java
GeocodingService.java
```

---

# 18. Location Architecture

Location processing involves multiple layers.

The browser can provide the user's current device coordinates through the Browser Geolocation API.

Conceptually:

```text
Browser
   │
   │ navigator.geolocation
   ▼
Latitude / Longitude
   │
   ▼
LocalMart Frontend
   │
   ▼
LocalMart Backend
```

The backend contains:

```text
LocationController.java
GeocodingService.java
RoadDistanceService.java
```

These components can be used for location-related operations such as:

* Location search.
* Address/coordinate processing.
* Road distance calculation.
* Delivery distance calculation.

The browser's Geolocation API and external geocoding/routing services are separate responsibilities.

---

# 19. Delivery Architecture

Delivery functionality is distributed across:

```text
DeliveryPartner.java
DeliveryPartnerLocation.java
DeliveryPartnerLocationController.java
DeliveryPartnerProfileController.java
DeliveryPartnerLocationService.java
DeliveryPartnerProfileService.java
RoadDistanceService.java
```

A simplified architecture is:

```text
Delivery Partner Browser
          │
          │ Device Location
          ▼
Frontend
          │
          │ Latitude / Longitude
          ▼
DeliveryPartnerLocationController
          │
          ▼
DeliveryPartnerLocationService
          │
          ▼
DeliveryPartnerLocationRepository
          │
          ▼
PostgreSQL
```

Road distance calculation is handled separately:

```text
Store / Pickup Location
          │
          │
          ▼
      OSRM Service
          │
          ▼
Road Distance / Duration
```

---

# 20. Cart Architecture

Cart functionality is implemented through:

```text
CartController.java
CartService.java
Cart.java
CartItem.java
CartRepository.java
CartItemRepository.java
```

The conceptual flow is:

```text
Frontend
    │
    │ Cart Request
    ▼
CartController
    │
    ▼
CartService
    │
    ├── Validate user
    ├── Validate product
    ├── Validate store
    ├── Apply cart rules
    │
    ▼
CartRepository / CartItemRepository
    │
    ▼
PostgreSQL
```

The cart is persisted on the backend rather than relying on browser local storage as the source of truth.

---

# 21. Order Architecture

Order functionality is implemented through:

```text
OrderController.java
OrderService.java
StoreOwnerOrderController.java
Order.java
OrderItem.java
OrderRepository.java
OrderItemRepository.java
CreateOrderRequest.java
OrderItemRequest.java
DeliveryFeeRequest.java
```

The high-level flow is:

```text
Customer
   │
   │ Checkout
   ▼
OrderController
   │
   ▼
OrderService
   │
   ├── Validate cart
   ├── Validate address
   ├── Calculate order information
   ├── Create order
   ├── Create order items
   └── Persist order
          │
          ▼
      PostgreSQL
```

Payment and delivery processing are connected to the order lifecycle through their respective services and entities.

---

# 22. Payment Architecture

Payment functionality is represented by:

```text
Payment.java
PaymentRepository.java
RazorpayService.java
```

The payment architecture separates payment-provider communication from the rest of the order business logic.

Conceptually:

```text
Customer
   │
   ▼
Frontend
   │
   ▼
Order / Payment API
   │
   ▼
RazorpayService
   │
   ▼
Razorpay
```

The exact payment lifecycle should be documented in:

```text
docs/flows/payment-flow.md
```

after tracing the current `RazorpayService`, `OrderService`, `Payment` entity, and relevant controllers.

---

# 23. Authentication Services

Authentication functionality is distributed across several services.

Important components include:

```text
UserService.java
OtpService.java
OtpDeliveryService.java
RegistrationVerificationService.java
TotpService.java
GoogleTokenVerificationService.java
XOAuthService.java
UserSessionService.java
```

Different authentication mechanisms can therefore use different service components while still eventually producing an authenticated LocalMart user session/JWT.

Conceptually:

```text
                 Authentication
                       │
        ┌──────────────┼──────────────┐
        │              │              │
        ▼              ▼              ▼
    Password/OTP     Google          X OAuth
        │              │              │
        └──────────────┼──────────────┘
                       ▼
                  UserService
                       │
                       ▼
                 User Session
                       │
                       ▼
                     JWT
```

The exact flow of each authentication mechanism is documented separately.

---

# 24. SMS OTP Subsystem

The project contains a dedicated package:

```text
smsotp
```

Structure:

```text
smsotp
├── controller
│   └── SmsOtpController.java
├── dto
│   ├── SmsOtpSendRequest.java
│   └── SmsOtpVerifyRequest.java
├── model
│   └── SmsOtpSession.java
└── service
    └── SmsOtpFlowService.java
```

This subsystem isolates SMS OTP-specific functionality.

The flow is conceptually:

```text
Frontend
   │
   │ Send OTP
   ▼
SmsOtpController
   │
   ▼
SmsOtpFlowService
   │
   ▼
MessageCentralOtpService
   │
   ▼
Message Central
   │
   ▼
User Mobile
```

Verification returns through the backend after the OTP is supplied by the user.

---

# 25. Exception Handling

Location:

```text
src/main/java/com/localmart/localmartbackend/exception
```

Current component:

```text
GlobalExceptionHandler.java
```

The global exception handler provides centralized handling of application exceptions.

Conceptually:

```text
Controller / Service
        │
        │ Exception
        ▼
GlobalExceptionHandler
        │
        ▼
HTTP Error Response
```

This prevents every controller from having to independently implement the same error-response logic.

---

# 26. Password Reset Architecture

Password reset functionality contains:

```text
passwordreset
└── entity
    └── PasswordResetSession.java
```

The password reset subsystem uses a dedicated session entity to represent password-reset-related state.

The complete password-reset flow should be documented separately after tracing the corresponding controller/service implementation.

---

# 27. Database Communication

LocalMart uses PostgreSQL as its persistent data store.

The database communication path is:

```text
Service
   │
   ▼
Spring Data Repository
   │
   ▼
JPA
   │
   ▼
Hibernate
   │
   ▼
JDBC
   │
   ▼
PostgreSQL
```

### Responsibility of each component

**Repository**

Provides the application-level database access abstraction.

**JPA**

Defines the Java persistence API used by the application.

**Hibernate**

Provides the JPA implementation and maps Java entities to relational database operations.

**JDBC**

Provides the lower-level Java database connectivity mechanism.

**PostgreSQL JDBC Driver**

Allows Java/Hibernate to communicate with PostgreSQL.

**PostgreSQL**

Stores the persistent application data.

---

# 28. Entity Relationship Concept

The LocalMart database contains multiple related business entities.

A simplified conceptual model is:

```text
User
 │
 ├── Address
 │
 ├── Cart
 │     └── CartItem
 │             └── Product
 │
 ├── Order
 │     └── OrderItem
 │             └── Product
 │
 ├── UserSession
 │
 └── DeliveryPartner
        │
        ├── VehicleDetails
        │
        └── DeliveryPartnerLocation

StoreDetails
 │
 └── Product

Order
 │
 ├── Payment
 │
 └── Delivery Partner
```

This is a conceptual relationship diagram.

The authoritative relationship definitions are the actual JPA mappings in the entity classes and the PostgreSQL schema.

---

# 29. Request/Response Architecture

LocalMart APIs use HTTP and JSON.

A typical request looks conceptually like:

```text
HTTP Request
     │
     ├── Method
     ├── URL
     ├── Headers
     └── JSON Body
             │
             ▼
         Controller
```

The backend processes the request and produces:

```text
Service Result
     │
     ▼
Response DTO
     │
     ▼
Jackson
     │
     ▼
JSON
     │
     ▼
HTTP Response
     │
     ▼
Frontend
```

Jackson is responsible for converting Java objects to JSON responses and JSON request bodies into Java objects where applicable.

---

# 30. Complete Backend Request Lifecycle

A protected API request can be represented as:

```text
┌──────────────────────┐
│      Browser         │
└──────────┬───────────┘
           │
           │ HTTP Request
           ▼
┌──────────────────────┐
│   Spring Security    │
└──────────┬───────────┘
           │
           ▼
┌──────────────────────┐
│ RateLimitFilter      │
└──────────┬───────────┘
           │
           ▼
┌──────────────────────┐
│ JwtAuthentication    │
│ Filter               │
└──────────┬───────────┘
           │
           ▼
┌──────────────────────┐
│ SecurityContext      │
└──────────┬───────────┘
           │
           ▼
┌──────────────────────┐
│ Controller           │
└──────────┬───────────┘
           │
           ▼
┌──────────────────────┐
│ Service              │
└──────────┬───────────┘
           │
           ▼
┌──────────────────────┐
│ Repository           │
└──────────┬───────────┘
           │
           ▼
┌──────────────────────┐
│ JPA / Hibernate      │
└──────────┬───────────┘
           │
           ▼
┌──────────────────────┐
│ PostgreSQL           │
└──────────────────────┘
```

The response travels in the opposite logical direction:

```text
PostgreSQL
    │
    ▼
Hibernate / JPA
    │
    ▼
Repository
    │
    ▼
Service
    │
    ▼
Controller
    │
    ▼
Jackson
    │
    ▼
JSON HTTP Response
    │
    ▼
Frontend
```

---

# 31. Dependency Direction

The intended dependency direction is:

```text
Controller
    │
    ▼
Service
    │
    ▼
Repository
    │
    ▼
Persistence
```

External integrations are generally accessed through service components:

```text
Service
   │
   ├── Google
   ├── Message Central
   ├── Gmail SMTP
   ├── Razorpay
   ├── OSRM
   └── Geocoding Provider
```

This keeps third-party communication away from controllers.

---

# 32. Why Layered Architecture Is Used

The layered architecture provides separation of concerns.

Without separation, a controller could become responsible for:

```text
HTTP handling
+ validation
+ authentication
+ business rules
+ database operations
+ external API calls
+ error handling
```

That would make the application difficult to maintain.

Instead, LocalMart separates responsibilities:

```text
Controller
   = HTTP communication

Service
   = Business logic

Repository
   = Database access

Entity
   = Persistent data model

DTO
   = API data contract

Security
   = Authentication / authorization / request protection

Configuration
   = Application configuration
```

---

# 33. Current Project Architecture Map

The current backend structure can therefore be mapped as:

```text
localmartbackend
│
├── config
│   └── Application configuration
│
├── controller
│   └── HTTP API layer
│
├── dto
│   └── API request/response models
│
├── entity
│   └── Persistent domain models
│
├── exception
│   └── Centralized error handling
│
├── passwordreset
│   └── Password reset models
│
├── repository
│   └── Database access
│
├── security
│   └── JWT / Spring Security / rate limiting
│
├── service
│   └── Business logic and integrations
│
└── smsotp
    └── SMS OTP subsystem
```

---

# 34. Architecture Principles

The LocalMart backend follows these architectural principles:

### Separation of concerns

Different responsibilities are handled by different components.

### Layered processing

Requests pass through defined application layers rather than directly accessing the database.

### DTO-based API communication

API contracts are separated from persistence entities.

### Centralized security

Authentication and authorization are handled through the Spring Security infrastructure.

### Service-based business logic

Business operations are implemented in service classes rather than controllers.

### Repository abstraction

Database operations are isolated through Spring Data repositories.

### External service isolation

Third-party integrations are handled by dedicated service components.

### Persistent server-side business data

Important application data such as carts, orders, payments, users, products, and delivery information is stored and managed by the backend/database rather than being treated as frontend-only data.

---

# 35. Architecture Documentation Strategy

The architecture described here is the high-level structure.

Individual feature flows should not be duplicated completely in this document.

Instead, detailed flows should be stored under:

```text
docs/flows/
```

For example:

```text
docs/flows/login-flow.md
docs/flows/registration-flow.md
docs/flows/google-login-flow.md
docs/flows/otp-flow.md
docs/flows/password-reset-flow.md
docs/flows/address-geocoding-flow.md
docs/flows/delivery-distance-flow.md
docs/flows/cart-flow.md
docs/flows/checkout-flow.md
docs/flows/payment-flow.md
docs/flows/order-flow.md
docs/flows/delivery-partner-flow.md
```

Each flow document should trace the **actual LocalMart source code**, including:

```text
Frontend component
       ↓
HTTP request
       ↓
Security filter
       ↓
Controller
       ↓
DTO
       ↓
Service
       ↓
Repository
       ↓
Entity
       ↓
Database
       ↓
External service (if applicable)
       ↓
Response
       ↓
Frontend
```

---

# 36. Source-of-Truth Principle

This architecture document describes the current intended architecture.

For implementation-level documentation, the source code is authoritative.

Therefore:

* A feature should be marked implemented only when the corresponding code exists and works.
* Planned integrations should not be documented as completed integrations.
* External providers should be named only when the implementation actually uses them.
* Exact endpoint paths should be taken from the current controller mappings.
* Exact database relationships should be taken from the current entity mappings.
* Exact authentication behavior should be taken from the current security and service implementations.

This prevents the documentation from becoming different from the actual application.

---

# 37. Relationship With Other Documentation

The documentation hierarchy is:

```text
01-system-overview.md
        │
        ▼
02-system-architecture.md
        │
        ├── Authentication
        ├── Customer
        ├── Store
        ├── Product
        ├── Cart
        ├── Order
        ├── Payment
        ├── Delivery
        ├── Location
        ├── Security
        ├── Database
        └── External Integrations
                │
                ▼
             flows/
```

`01-system-overview.md` answers:

> What is LocalMart?

`02-system-architecture.md` answers:

> How is LocalMart technically structured?

The later documents will answer:

> How does each individual feature actually work?

---

# 38. Conclusion

LocalMart uses a layered full-stack architecture in which the React frontend communicates with a Spring Boot REST backend.

The backend separates:

```text
HTTP handling
      ↓
Security
      ↓
Controllers
      ↓
DTOs
      ↓
Services
      ↓
Repositories
      ↓
JPA / Hibernate
      ↓
PostgreSQL
```

External capabilities such as authentication providers, OTP delivery, email delivery, payments, geocoding, and road-distance calculation are isolated behind dedicated backend services.

This architecture provides a structured foundation for implementing and documenting the complete LocalMart application while keeping HTTP communication, business logic, persistence, security, and third-party integrations separated.

The next documentation layer should move from architecture into **actual implementation-level feature flows**, using the LocalMart source code as the source of truth.
