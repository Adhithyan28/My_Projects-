package com.localmart.localmartbackend.controller;

import com.localmart.localmartbackend.dto.AddCartItemRequest;
import com.localmart.localmartbackend.dto.CartResponse;
import com.localmart.localmartbackend.service.CartService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/cart")
@CrossOrigin(origins = {
        "http://localhost:5173",
        "http://localhost:5174",
        "http://localhost:5175"
})
public class CartController {

    private final CartService cartService;

    public CartController(CartService cartService) {
        this.cartService = cartService;
    }

    @GetMapping
    public ResponseEntity<CartResponse> getCart(
            Authentication authentication) {

        Long customerId =
                getAuthenticatedUserId(authentication);

        return ResponseEntity.ok(
                cartService.getCart(customerId)
        );
    }

    @PostMapping("/items")
    public ResponseEntity<CartResponse> addItem(
            Authentication authentication,
            @RequestBody AddCartItemRequest request) {

        Long customerId =
                getAuthenticatedUserId(authentication);

        return ResponseEntity.ok(
                cartService.addItem(
                        customerId,
                        request
                )
        );
    }

    @PutMapping("/items/{cartItemId}")
    public ResponseEntity<CartResponse> updateItem(
            Authentication authentication,
            @PathVariable Long cartItemId,
            @RequestParam Integer quantity) {

        Long customerId =
                getAuthenticatedUserId(authentication);

        return ResponseEntity.ok(
                cartService.updateItem(
                        customerId,
                        cartItemId,
                        quantity
                )
        );
    }

    @DeleteMapping("/items/{cartItemId}")
    public ResponseEntity<Void> deleteItem(
            Authentication authentication,
            @PathVariable Long cartItemId) {

        Long customerId =
                getAuthenticatedUserId(authentication);

        cartService.deleteItem(
                customerId,
                cartItemId
        );

        return ResponseEntity.noContent().build();
    }

    @DeleteMapping
    public ResponseEntity<Void> clearCart(
            Authentication authentication) {

        Long customerId =
                getAuthenticatedUserId(authentication);

        cartService.clearCart(customerId);

        return ResponseEntity.noContent().build();
    }

    private Long getAuthenticatedUserId(
            Authentication authentication) {

        if (authentication == null ||
                authentication.getPrincipal() == null) {

            throw new RuntimeException(
                    "User is not authenticated"
            );
        }

        Object principal =
                authentication.getPrincipal();

        if (principal instanceof Long userId) {
            return userId;
        }

        if (principal instanceof String userId) {

            try {
                return Long.valueOf(userId);

            } catch (NumberFormatException exception) {

                throw new RuntimeException(
                        "Invalid authenticated user ID"
                );
            }
        }

        throw new RuntimeException(
                "Invalid authenticated user"
        );
    }
}