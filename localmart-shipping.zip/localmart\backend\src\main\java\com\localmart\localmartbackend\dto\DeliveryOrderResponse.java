package com.localmart.localmartbackend.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public class DeliveryOrderResponse {

    private Long orderId;
    private String orderNumber;

    private Long customerId;
    private Long storeId;
    private Long deliveryPartnerId;

    private BigDecimal subtotal;
    private BigDecimal deliveryFee;
    private BigDecimal total;

    private BigDecimal estimatedEarnings;

    private BigDecimal pickupDistanceKm;
    private BigDecimal deliveryDistanceKm;
    private BigDecimal totalDistanceKm;

    private String paymentMethod;
    private String paymentStatus;
    private String orderStatus;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    private PickupLocation pickupLocation;
    private DeliveryLocation deliveryLocation;

    private List<Item> items;

    public DeliveryOrderResponse() {
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public Long getStoreId() {
        return storeId;
    }

    public void setStoreId(Long storeId) {
        this.storeId = storeId;
    }

    public Long getDeliveryPartnerId() {
        return deliveryPartnerId;
    }

    public void setDeliveryPartnerId(Long deliveryPartnerId) {
        this.deliveryPartnerId = deliveryPartnerId;
    }

    public BigDecimal getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(BigDecimal subtotal) {
        this.subtotal = subtotal;
    }

    public BigDecimal getDeliveryFee() {
        return deliveryFee;
    }

    public void setDeliveryFee(BigDecimal deliveryFee) {
        this.deliveryFee = deliveryFee;
    }

    public BigDecimal getTotal() {
        return total;
    }

    public void setTotal(BigDecimal total) {
        this.total = total;
    }

    public BigDecimal getEstimatedEarnings() {
        return estimatedEarnings;
    }

    public void setEstimatedEarnings(
            BigDecimal estimatedEarnings
    ) {
        this.estimatedEarnings = estimatedEarnings;
    }

    public BigDecimal getPickupDistanceKm() {
        return pickupDistanceKm;
    }

    public void setPickupDistanceKm(
            BigDecimal pickupDistanceKm
    ) {
        this.pickupDistanceKm = pickupDistanceKm;
    }

    public BigDecimal getDeliveryDistanceKm() {
        return deliveryDistanceKm;
    }

    public void setDeliveryDistanceKm(
            BigDecimal deliveryDistanceKm
    ) {
        this.deliveryDistanceKm = deliveryDistanceKm;
    }

    public BigDecimal getTotalDistanceKm() {
        return totalDistanceKm;
    }

    public void setTotalDistanceKm(
            BigDecimal totalDistanceKm
    ) {
        this.totalDistanceKm = totalDistanceKm;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(
            String paymentMethod
    ) {
        this.paymentMethod = paymentMethod;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(
            String paymentStatus
    ) {
        this.paymentStatus = paymentStatus;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(
            String orderStatus
    ) {
        this.orderStatus = orderStatus;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(
            LocalDateTime createdAt
    ) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(
            LocalDateTime updatedAt
    ) {
        this.updatedAt = updatedAt;
    }

    public PickupLocation getPickupLocation() {
        return pickupLocation;
    }

    public void setPickupLocation(
            PickupLocation pickupLocation
    ) {
        this.pickupLocation = pickupLocation;
    }

    public DeliveryLocation getDeliveryLocation() {
        return deliveryLocation;
    }

    public void setDeliveryLocation(
            DeliveryLocation deliveryLocation
    ) {
        this.deliveryLocation = deliveryLocation;
    }

    public List<Item> getItems() {
        return items;
    }

    public void setItems(
            List<Item> items
    ) {
        this.items = items;
    }

    public static class PickupLocation {

        private String storeName;
        private String storePhone;

        private String address;
        private String city;
        private String state;
        private String pincode;

        private BigDecimal latitude;
        private BigDecimal longitude;

        public PickupLocation() {
        }

        public String getStoreName() {
            return storeName;
        }

        public void setStoreName(
                String storeName
        ) {
            this.storeName = storeName;
        }

        public String getStorePhone() {
            return storePhone;
        }

        public void setStorePhone(
                String storePhone
        ) {
            this.storePhone = storePhone;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(
                String address
        ) {
            this.address = address;
        }

        public String getCity() {
            return city;
        }

        public void setCity(
                String city
        ) {
            this.city = city;
        }

        public String getState() {
            return state;
        }

        public void setState(
                String state
        ) {
            this.state = state;
        }

        public String getPincode() {
            return pincode;
        }

        public void setPincode(
                String pincode
        ) {
            this.pincode = pincode;
        }

        public BigDecimal getLatitude() {
            return latitude;
        }

        public void setLatitude(
                BigDecimal latitude
        ) {
            this.latitude = latitude;
        }

        public BigDecimal getLongitude() {
            return longitude;
        }

        public void setLongitude(
                BigDecimal longitude
        ) {
            this.longitude = longitude;
        }
    }

    public static class DeliveryLocation {

        private String customerName;
        private String phone;

        private String address;
        private String city;
        private String state;
        private String pincode;

        public DeliveryLocation() {
        }

        public String getCustomerName() {
            return customerName;
        }

        public void setCustomerName(
                String customerName
        ) {
            this.customerName = customerName;
        }

        public String getPhone() {
            return phone;
        }

        public void setPhone(
                String phone
        ) {
            this.phone = phone;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(
                String address
        ) {
            this.address = address;
        }

        public String getCity() {
            return city;
        }

        public void setCity(
                String city
        ) {
            this.city = city;
        }

        public String getState() {
            return state;
        }

        public void setState(
                String state
        ) {
            this.state = state;
        }

        public String getPincode() {
            return pincode;
        }

        public void setPincode(
                String pincode
        ) {
            this.pincode = pincode;
        }
    }

    public static class Item {

        private Long productId;
        private String productName;
        private String unit;
        private Integer quantity;

        private BigDecimal unitPrice;
        private BigDecimal totalPrice;

        public Item() {
        }

        public Long getProductId() {
            return productId;
        }

        public void setProductId(
                Long productId
        ) {
            this.productId = productId;
        }

        public String getProductName() {
            return productName;
        }

        public void setProductName(
                String productName
        ) {
            this.productName = productName;
        }

        public String getUnit() {
            return unit;
        }

        public void setUnit(
                String unit
        ) {
            this.unit = unit;
        }

        public Integer getQuantity() {
            return quantity;
        }

        public void setQuantity(
                Integer quantity
        ) {
            this.quantity = quantity;
        }

        public BigDecimal getUnitPrice() {
            return unitPrice;
        }

        public void setUnitPrice(
                BigDecimal unitPrice
        ) {
            this.unitPrice = unitPrice;
        }

        public BigDecimal getTotalPrice() {
            return totalPrice;
        }

        public void setTotalPrice(
                BigDecimal totalPrice
        ) {
            this.totalPrice = totalPrice;
        }
    }
}