package com.localmart.localmartbackend.dto;

public class AdminVerifyOtpRequest {

    private String identifier;
    private String otp;
    private String channel;

    public AdminVerifyOtpRequest() {
    }

    public String getIdentifier() {
        return identifier;
    }

    public void setIdentifier(String identifier) {
        this.identifier = identifier;
    }

    public String getOtp() {
        return otp;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }
}