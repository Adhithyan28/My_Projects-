
        package com.localmart.localmartbackend.service;

import com.localmart.localmartbackend.config.XAuthProperties;
import com.localmart.localmartbackend.dto.XUserInfo;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class XOAuthService {

    private final XAuthProperties xAuthProperties;

    /*
     * state -> OAuth authorization request
     *
     * We store:
     *
     * 1. codeVerifier
     * 2. flow
     *
     * because the same X callback is used for:
     *
     * LOGIN
     * REGISTER
     */
    private final Map<String, AuthorizationRequest> authorizationRequests =
            new ConcurrentHashMap<>();

    public XOAuthService(XAuthProperties xAuthProperties) {
        this.xAuthProperties = xAuthProperties;
    }

    // ============================================================
    // X LOGIN
    // ============================================================

    public String createLoginAuthorizationUrl() {

        return createAuthorizationUrl(
                OAuthFlow.LOGIN
        );
    }

    // ============================================================
    // X REGISTRATION
    // ============================================================

    public String createRegistrationAuthorizationUrl() {

        return createAuthorizationUrl(
                OAuthFlow.REGISTER
        );
    }

    // ============================================================
    // CREATE X AUTHORIZATION URL
    // ============================================================

    private String createAuthorizationUrl(
            OAuthFlow flow) {

        /*
         * --------------------------------------------------------
         * STATE
         * --------------------------------------------------------
         */

        String state =
                UUID.randomUUID().toString();

        // TEMPORARY TEST LOGS
        System.out.println();
        System.out.println("========== X OAUTH START ==========");
        System.out.println("X OAuth flow: " + flow);
        System.out.println("X OAuth state created");
        System.out.println("==================================");

        /*
         * --------------------------------------------------------
         * PKCE CODE VERIFIER
         * --------------------------------------------------------
         */

        String codeVerifier =
                generateCodeVerifier();

        /*
         * --------------------------------------------------------
         * PKCE CODE CHALLENGE
         * --------------------------------------------------------
         */

        String codeChallenge =
                generateCodeChallenge(
                        codeVerifier
                );



        authorizationRequests.put(
                state,
                new AuthorizationRequest(
                        codeVerifier,
                        flow
                )
        );

        System.out.println(
                "X OAuth authorization request stored"
        );

        /*
         * --------------------------------------------------------
         * BUILD X AUTHORIZATION URL
         * --------------------------------------------------------
         */

        return "https://x.com/i/oauth2/authorize"
                + "?response_type=code"
                + "&client_id="
                + urlEncode(
                xAuthProperties.getClientId()
        )
                + "&redirect_uri="
                + urlEncode(
                xAuthProperties.getRedirectUri()
        )
                + "&scope="
                + urlEncode(
                "users.read users.email tweet.read"
        )
                + "&state="
                + urlEncode(state)
                + "&code_challenge="
                + urlEncode(codeChallenge)
                + "&code_challenge_method=S256";
    }

    // ============================================================
    // GENERATE PKCE CODE VERIFIER
    // ============================================================

    private String generateCodeVerifier() {

        byte[] randomBytes =
                new byte[32];

        new SecureRandom()
                .nextBytes(randomBytes);

        return Base64.getUrlEncoder()
                .withoutPadding()
                .encodeToString(
                        randomBytes
                );
    }

    // ============================================================
    // GENERATE PKCE CODE CHALLENGE
    // ============================================================

    private String generateCodeChallenge(
            String codeVerifier) {

        try {

            MessageDigest digest =
                    MessageDigest.getInstance(
                            "SHA-256"
                    );

            byte[] hash =
                    digest.digest(
                            codeVerifier.getBytes(
                                    StandardCharsets.UTF_8
                            )
                    );

            return Base64.getUrlEncoder()
                    .withoutPadding()
                    .encodeToString(hash);

        } catch (NoSuchAlgorithmException e) {

            throw new RuntimeException(
                    "SHA-256 algorithm is not available",
                    e
            );
        }
    }

    // ============================================================
    // URL ENCODE
    // ============================================================

    private String urlEncode(
            String value) {

        return URLEncoder
                .encode(
                        value,
                        StandardCharsets.UTF_8
                )
                .replace(
                        "+",
                        "%20"
                );
    }

    // ============================================================
    // GET CODE VERIFIER
    // ============================================================

    public String getCodeVerifier(
            String state) {

        AuthorizationRequest request =
                authorizationRequests.get(state);

        if (request == null) {
            return null;
        }

        return request.codeVerifier();
    }

    // ============================================================
    // GET OAUTH FLOW
    // ============================================================

    public OAuthFlow getFlow(
            String state) {

        AuthorizationRequest request =
                authorizationRequests.get(state);

        if (request == null) {

            throw new RuntimeException(
                    "Invalid or expired X OAuth request"
            );
        }

        System.out.println(
                "X OAuth flow recovered from state: "
                        + request.flow()
        );

        return request.flow();
    }

    // ============================================================
    // REMOVE AUTHORIZATION REQUEST
    // ============================================================

    public void removeAuthorizationRequest(
            String state) {

        authorizationRequests.remove(
                state
        );
    }

    // ============================================================
    // EXCHANGE CODE FOR ACCESS TOKEN
    // ============================================================

    public String exchangeCodeForAccessToken(
            String code,
            String state) {

        if (code == null
                || code.isBlank()) {

            throw new RuntimeException(
                    "Authorization code is required"
            );
        }

        if (state == null
                || state.isBlank()) {

            throw new RuntimeException(
                    "OAuth state is required"
            );
        }

        AuthorizationRequest authorizationRequest =
                authorizationRequests.get(state);

        if (authorizationRequest == null) {

            throw new RuntimeException(
                    "Invalid or expired X OAuth request"
            );
        }

        String codeVerifier =
                authorizationRequest.codeVerifier();

        try {

            /*
             * ----------------------------------------------------
             * CLIENT AUTHENTICATION
             * ----------------------------------------------------
             */

            String credentials =
                    xAuthProperties.getClientId()
                            + ":"
                            + xAuthProperties.getClientSecret();

            String basicAuth =
                    Base64.getEncoder()
                            .encodeToString(
                                    credentials.getBytes(
                                            StandardCharsets.UTF_8
                                    )
                            );

            /*
             * ----------------------------------------------------
             * TOKEN REQUEST BODY
             * ----------------------------------------------------
             */

            String requestBody =
                    "code=" + urlEncode(code)
                            + "&grant_type=authorization_code"
                            + "&redirect_uri="
                            + urlEncode(
                            xAuthProperties.getRedirectUri()
                    )
                            + "&code_verifier="
                            + urlEncode(codeVerifier);

            /*
             * ----------------------------------------------------
             * HTTP REQUEST TO X
             * ----------------------------------------------------
             */

            HttpRequest request =
                    HttpRequest.newBuilder()
                            .uri(
                                    URI.create(
                                            "https://api.x.com/2/oauth2/token"
                                    )
                            )
                            .header(
                                    "Content-Type",
                                    "application/x-www-form-urlencoded"
                            )
                            .header(
                                    "Authorization",
                                    "Basic " + basicAuth
                            )
                            .POST(
                                    HttpRequest.BodyPublishers
                                            .ofString(
                                                    requestBody
                                            )
                            )
                            .build();

            HttpClient client =
                    HttpClient.newHttpClient();

            // TEMPORARY TEST LOG
            System.out.println();
            System.out.println(
                    "========== X TOKEN EXCHANGE =========="
            );
            System.out.println(
                    "Sending authorization code to X"
            );

            HttpResponse<String> response =
                    client.send(
                            request,
                            HttpResponse.BodyHandlers.ofString()
                    );



            System.out.println(
                    "X token response status: "
                            + response.statusCode()
            );

            /*
             * ----------------------------------------------------
             * CHECK X RESPONSE
             * ----------------------------------------------------
             */

            if (response.statusCode() < 200
                    || response.statusCode() >= 300) {

                throw new RuntimeException(
                        "X token exchange failed: "
                                + response.body()
                );
            }

            System.out.println(
                    "X access token received successfully"
            );

            /*
             * ----------------------------------------------------
             * REMOVE USED OAUTH REQUEST
             * ----------------------------------------------------
             */

            authorizationRequests.remove(
                    state
            );

            System.out.println(
                    "X OAuth state removed after token exchange"
            );

            /*
             * ----------------------------------------------------
             * EXTRACT ACCESS TOKEN
             * ----------------------------------------------------
             */

            return extractAccessToken(
                    response.body()
            );

        } catch (IOException e) {

            throw new RuntimeException(
                    "Failed to communicate with X",
                    e
            );

        } catch (InterruptedException e) {

            Thread.currentThread().interrupt();

            throw new RuntimeException(
                    "X OAuth request was interrupted",
                    e
            );
        }
    }

    // ============================================================
    // EXTRACT ACCESS TOKEN
    // ============================================================

    private String extractAccessToken(
            String responseBody) {

        int accessTokenIndex =
                responseBody.indexOf(
                        "\"access_token\""
                );

        if (accessTokenIndex == -1) {

            throw new RuntimeException(
                    "X response did not contain an access token"
            );
        }

        int colonIndex =
                responseBody.indexOf(
                        ":",
                        accessTokenIndex
                );

        int firstQuote =
                responseBody.indexOf(
                        "\"",
                        colonIndex + 1
                );

        int secondQuote =
                responseBody.indexOf(
                        "\"",
                        firstQuote + 1
                );

        if (firstQuote == -1
                || secondQuote == -1) {

            throw new RuntimeException(
                    "Invalid access token response from X"
            );
        }

        return responseBody.substring(
                firstQuote + 1,
                secondQuote
        );
    }

    // ============================================================
    // GET CURRENT X USER
    // ============================================================

    public XUserInfo getCurrentUser(
            String accessToken) {

        if (accessToken == null
                || accessToken.isBlank()) {

            throw new RuntimeException(
                    "X access token is required"
            );
        }

        try {

            /*
             * ----------------------------------------------------
             * REQUEST X USER INFORMATION
             * ----------------------------------------------------
             */

            HttpRequest request =
                    HttpRequest.newBuilder()
                            .uri(
                                    URI.create(
                                            "https://api.x.com/2/users/me"
                                                    + "?user.fields=id,name,username,confirmed_email,description,profile_image_url"
                                    )
                            )
                            .header(
                                    "Authorization",
                                    "Bearer " + accessToken
                            )
                            .GET()
                            .build();

            HttpClient client =
                    HttpClient.newHttpClient();

            // TEMPORARY TEST LOG
            System.out.println();
            System.out.println(
                    "========== X USER REQUEST =========="
            );
            System.out.println(
                    "Requesting authenticated X user"
            );

            HttpResponse<String> response =
                    client.send(
                            request,
                            HttpResponse.BodyHandlers.ofString()
                    );

            // IMPORTANT:
            // Do NOT print response.body().
            // It may contain personal user information.

            System.out.println(
                    "X user response status: "
                            + response.statusCode()
            );

            if (response.statusCode() < 200
                    || response.statusCode() >= 300) {

                throw new RuntimeException(
                        "Failed to retrieve X user information: "
                                + response.body()
                );
            }

            System.out.println(
                    "X user information received successfully"
            );

            return parseXUser(
                    response.body()
            );

        } catch (IOException e) {

            throw new RuntimeException(
                    "Failed to communicate with X",
                    e
            );

        } catch (InterruptedException e) {

            Thread.currentThread().interrupt();

            throw new RuntimeException(
                    "X user request was interrupted",
                    e
            );
        }
    }

    // ============================================================
    // PARSE X USER
    // ============================================================

    private XUserInfo parseXUser(
            String responseBody) {

        String xId =
                extractJsonValue(
                        responseBody,
                        "id"
                );

        String email =
                extractJsonValue(
                        responseBody,
                        "confirmed_email"
                );

        String name =
                extractJsonValue(
                        responseBody,
                        "name"
                );

        String username =
                extractJsonValue(
                        responseBody,
                        "username"
                );

        if (xId == null
                || xId.isBlank()) {

            throw new RuntimeException(
                    "X response did not contain a user ID"
            );
        }

        // TEMPORARY TEST LOGS
        System.out.println();
        System.out.println(
                "========== X USER PARSED =========="
        );
        System.out.println(
                "X user ID received: " + xId
        );
        System.out.println(
                "X username received: " + username
        );
        System.out.println(
                "X email received: "
                        + (email != null && !email.isBlank())
        );

        /*
         * We intentionally do NOT print:
         *
         * email value
         * access token
         * JWT
         */

        return new XUserInfo(
                xId,
                email,
                name,
                null,
                null,
                username
        );
    }

    // ============================================================
    // EXTRACT JSON VALUE
    // ============================================================

    private String extractJsonValue(
            String json,
            String fieldName) {

        String search =
                "\"" + fieldName + "\"";

        int fieldIndex =
                json.indexOf(search);

        if (fieldIndex == -1) {

            return null;
        }

        int colonIndex =
                json.indexOf(
                        ":",
                        fieldIndex + search.length()
                );

        if (colonIndex == -1) {

            return null;
        }

        int firstQuote =
                json.indexOf(
                        "\"",
                        colonIndex + 1
                );

        if (firstQuote == -1) {

            return null;
        }

        int secondQuote =
                json.indexOf(
                        "\"",
                        firstQuote + 1
                );

        if (secondQuote == -1) {

            return null;
        }

        return json.substring(
                firstQuote + 1,
                secondQuote
        );
    }

    // ============================================================
    // OAUTH FLOW
    // ============================================================

    public enum OAuthFlow {

        LOGIN,

        REGISTER
    }

    // ============================================================
    // AUTHORIZATION REQUEST
    // ============================================================

    private record AuthorizationRequest(
            String codeVerifier,
            OAuthFlow flow
    ) {
    }
}
