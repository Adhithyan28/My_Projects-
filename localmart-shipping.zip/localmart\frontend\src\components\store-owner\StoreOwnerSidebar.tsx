
interface StoreOwnerSidebarProps {
    activePage: "dashboard" | "store" | "products" | "orders"
    onNavigate: (
        page: "dashboard" | "store" | "products" | "orders"
    ) => void
    onLogout: () => void
}

function StoreOwnerSidebar({
    activePage,
    onNavigate,
    onLogout,
}: StoreOwnerSidebarProps) {

    return (

        <aside className="owner-sidebar">

            <div className="owner-sidebar-logo">

                <button
                    type="button"
                    onClick={() => onNavigate("dashboard")}
                >
                    Local<span>Mart</span>
                </button>

                <p>Store Owner</p>

            </div>

            <nav className="owner-sidebar-navigation">

                <button
                    type="button"
                    className={
                        activePage === "dashboard"
                            ? "owner-nav-item active"
                            : "owner-nav-item"
                    }
                    onClick={() => onNavigate("dashboard")}
                >
                    <span className="owner-nav-icon">
                        🏠
                    </span>

                    <span>
                        Dashboard
                    </span>
                </button>

                <button
                    type="button"
                    className={
                        activePage === "store"
                            ? "owner-nav-item active"
                            : "owner-nav-item"
                    }
                    onClick={() => onNavigate("store")}
                >
                    <span className="owner-nav-icon">
                        🏪
                    </span>

                    <span>
                        My Store
                    </span>
                </button>

                <button
                    type="button"
                    className={
                        activePage === "products"
                            ? "owner-nav-item active"
                            : "owner-nav-item"
                    }
                    onClick={() => onNavigate("products")}
                >
                    <span className="owner-nav-icon">
                        📦
                    </span>

                    <span>
                        Products
                    </span>
                </button>

                <button
                    type="button"
                    className={
                        activePage === "orders"
                            ? "owner-nav-item active"
                            : "owner-nav-item"
                    }
                    onClick={() => onNavigate("orders")}
                >
                    <span className="owner-nav-icon">
                        🛒
                    </span>

                    <span>
                        Orders
                    </span>
                </button>

            </nav>

            <div className="owner-sidebar-bottom">

                <div className="owner-sidebar-divider"></div>

                <button
                    type="button"
                    className="owner-logout-button"
                    onClick={onLogout}
                >
                    <span>
                        🚪
                    </span>

                    <span>
                        Logout
                    </span>
                </button>

            </div>

        </aside>
    )
}

export default StoreOwnerSidebar
