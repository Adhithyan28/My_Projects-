function PrivacyPolicy() {

    return (
        <div
            style={{
                minHeight: "100vh",
                padding: "40px",
                maxWidth: "900px",
                margin: "0 auto",
                fontFamily: "Arial, sans-serif",
                lineHeight: "1.7"
            }}
        >

            <h1>LocalMart Privacy Policy</h1>

            <p>
                This Privacy Policy explains how LocalMart
                collects, uses, and protects information provided
                by users while using the LocalMart application.
            </p>

            <h2>1. Information We Collect</h2>

            <p>
                Depending on the features used, LocalMart may
                collect information such as name, email address,
                mobile number, delivery address, account
                information, and order-related information.
            </p>

            <h2>2. Google and Third-Party Authentication</h2>

            <p>
                LocalMart may allow users to sign in using
                third-party authentication providers such as
                Google or X. When a user chooses a third-party
                sign-in option, LocalMart may receive information
                provided by that authentication provider that is
                necessary to identify and authenticate the user.
            </p>

            <h2>3. How We Use Information</h2>

            <p>
                Information may be used to create and manage
                accounts, authenticate users, process orders,
                provide delivery services, communicate with
                users, and improve the LocalMart platform.
            </p>

            <h2>4. Information Security</h2>

            <p>
                LocalMart uses appropriate technical and
                organizational measures to protect user
                information from unauthorized access,
                alteration, disclosure, or destruction.
            </p>

            <h2>5. Third-Party Services</h2>

            <p>
                LocalMart may integrate with third-party services
                for authentication and other application
                functionality. Information shared with those
                services is handled according to their respective
                privacy policies.
            </p>

            <h2>6. Data Retention</h2>

            <p>
                User information may be retained for as long as
                necessary to provide LocalMart services, comply
                with applicable requirements, resolve disputes,
                and maintain appropriate business records.
            </p>

            <h2>7. Changes to This Privacy Policy</h2>

            <p>
                This Privacy Policy may be updated from time to
                time. Updated versions will be published through
                the LocalMart application.
            </p>

            <h2>8. Contact</h2>

            <p>
                For questions regarding this Privacy Policy,
                please contact the LocalMart administration team.
            </p>

            <p>
                Last updated: September 2026
            </p>

        </div>
    )
}

export default PrivacyPolicy