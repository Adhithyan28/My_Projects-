# LocalMart — Project Structure

## 1. Overview

LocalMart is organized as a layered full-stack application.

The backend follows a separation of responsibilities between:

* Controllers
* DTOs
* Services
* Repositories
* Entities
* Security
* Configuration
* Exception handling
* Specialized authentication modules

The frontend is implemented separately using React, TypeScript, and Vite.

The overall project can therefore be viewed as:

```text id="2n8j8h"
LocalMart
│
├── Frontend
│   └── React + TypeScript + Vite
│
└── Backend
    └── Java + Spring Boot
        ├── Controller
        ├── DTO
        ├── Entity
        ├── Repository
        ├── Service
        ├── Security
        ├── Config
        ├── Exception
        └── Specialized Modules
```

---

# 2. Repository Structure

The current backend project has the following high-level structure:

```text id="1d3m8y"
localmart-backend/
│
├── .gitattributes
├── .gitignore
├── backend-tree.txt
├── HELP.md
├── mvnw
├── mvnw.cmd
├── package-lock.json
├── pom.xml
├── project-tree.txt
│
├── .idea/
│
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/
│   │   │       └── localmart/
│   │   │           └── localmartbackend/
│   │   │
│   │   └── resources/
│   │
│   └── test/
│       └── java/
│
└── target/
```

The most important application code is located under:

```text id="3cnm3c"
src/main/java/com/localmart/localmartbackend/
```

---

# 3. Main Java Package

The root Java package is:

```text id="8o3l9k"
com.localmart.localmartbackend
```

The main Spring Boot application class is:

```text id="w2i2rj"
LocalmartBackendApplication.java
```

This class is the entry point of the backend application.

Conceptually:

```text id="m5h7h4"
LocalmartBackendApplication
            ↓
     Spring Boot starts
            ↓
    Application Context
            ↓
      Beans initialized
            ↓
     LocalMart backend
```

Spring Boot scans the application's packages beneath the main package and discovers the relevant components.

---

# 4. Complete Backend Package Structure

The current backend contains:

```text id="s7qj0r"
com.localmart.localmartbackend
│
├── config
├── controller
├── dto
├── entity
├── exception
├── passwordreset
├── repository
├── security
├── service
└── smsotp
```

Each package has a different responsibility.

---

# 5. `config` Package

Location:

```text id="0fy2yv"
com.localmart.localmartbackend.config
```

Current files:

```text id="1lqj6c"
AdminInitializer.java
CorsConfig.java
GoogleAuthProperties.java
XAuthProperties.java
```

The `config` package contains application configuration and initialization components.

---

## 5.1 `AdminInitializer`

```text id="2xv0pt"
AdminInitializer.java
```

This component is responsible for initialization related to the predefined administrator account.

It allows the application to establish the required admin state when the application starts.

Conceptually:

```text id="2p3y1d"
Application startup
       ↓
AdminInitializer
       ↓
Admin configuration / initialization
       ↓
Admin available
```

---

## 5.2 `CorsConfig`

```text id="r8e6q4"
CorsConfig.java
```

This class configures Cross-Origin Resource Sharing.

This is required because the frontend and backend run on different origins during development.

```text id="j5h3w2"
React
localhost:5174
       |
       | HTTP request
       v
Spring Boot
localhost:8080
       |
       ↓
CORS configuration
```

---

## 5.3 `GoogleAuthProperties`

```text id="a4v8z6"
GoogleAuthProperties.java
```

This class represents configuration associated with Google authentication.

It provides a structured way for Google-related configuration to be consumed by backend components.

---

## 5.4 `XAuthProperties`

```text id="p3s7k1"
XAuthProperties.java
```

This class represents configuration associated with X authentication.

It keeps X-specific configuration separate from the application's authentication business logic.

---

# 6. `controller` Package

Location:

```text id="1n9w4k"
com.localmart.localmartbackend.controller
```

Current files:

```text id="6g8s2m"
AdminController.java
AdminDataController.java
AdminRequestController.java
CartController.java
CustomerAddressController.java
CustomerController.java
DeliveryPartnerLocationController.java
DeliveryPartnerProfileController.java
LocationController.java
OrderController.java
ProductController.java
StoreController.java
StoreOwnerController.java
StoreOwnerOrderController.java
UserController.java
XOAuthController.java
test.http
```

Controllers represent the HTTP/API boundary of the backend.

Their primary responsibility is to:

1. Receive HTTP requests.
2. Read request data.
3. Call the appropriate service.
4. Return an HTTP response.

The controller should not contain the application's main business logic.

---

# 7. Controller-to-Service Flow

The general request flow is:

```text id="3p8z4n"
HTTP Request
     ↓
Controller
     ↓
Service
     ↓
Repository
     ↓
Database
```

For an external integration:

```text id="2j7w5x"
HTTP Request
     ↓
Controller
     ↓
Service
     ↓
Integration Service
     ↓
External API
```

This separation makes the backend easier to maintain.

---

# 8. User and Authentication Controllers

### `UserController`

```text id="z5t3q8"
UserController.java
```

Handles user-related HTTP operations such as:

* Registration
* Registration OTP
* Login
* Login OTP
* Google login
* Google registration
* Logout

Its base path is:

```text
/api/users
```

For example:

```text id="4g9r1k"
/api/users/register
/api/users/login
/api/users/login/send-otp
/api/users/login/verify
/api/users/google/login
/api/users/google/register
/api/users/logout
```

The controller delegates authentication logic to services rather than implementing the authentication algorithms itself.

---

### `XOAuthController`

```text id="8j2m6q"
XOAuthController.java
```

Handles HTTP requests associated with X OAuth authentication.

The OAuth business logic is delegated to:

```text
XOAuthService
```

---

# 9. Customer Controllers

### `CustomerController`

Handles customer-related operations.

### `CustomerAddressController`

Handles customer address operations such as:

* Retrieving addresses
* Adding addresses
* Updating addresses
* Deleting addresses
* Setting the default address

The structure separates general customer functionality from address-specific functionality.

---

# 10. Store Controllers

### `StoreController`

Handles store-related operations.

This is used by the customer-facing store browsing functionality and store-related APIs.

### `StoreOwnerController`

Handles store-owner functionality.

### `StoreOwnerOrderController`

Handles order-related operations specific to store owners.

This separation prevents all store-owner functionality from being placed into a single large controller.

---

# 11. Product Controller

### `ProductController`

Handles product-related HTTP operations.

Conceptually:

```text id="z1q5v7"
Frontend
   ↓
ProductController
   ↓
ProductService
   ↓
ProductRepository
   ↓
PostgreSQL
```

The controller does not directly query the database.

---

# 12. Cart Controller

### `CartController`

Handles shopping-cart API requests.

The cart architecture is:

```text id="0f6zq2"
Customer
   ↓
CartController
   ↓
CartService
   ↓
CartRepository / CartItemRepository
   ↓
PostgreSQL
```

The cart is persisted in the database rather than being treated as frontend-only state.

---

# 13. Order Controller

### `OrderController`

Handles order-related operations.

The order layer connects multiple parts of the system:

```text id="3s8h6a"
Customer
   ↓
OrderController
   ↓
OrderService
   ↓
Cart / Product / Address / Payment
   ↓
Order
```

The order system is therefore one of the central modules of LocalMart.

---

# 14. Delivery Controllers

### `DeliveryPartnerLocationController`

Handles delivery-partner location operations.

### `DeliveryPartnerProfileController`

Handles delivery-partner profile-related operations.

Delivery functionality is separated into multiple controllers rather than placing all delivery functionality in one class.

---

# 15. Location Controller

### `LocationController`

Handles location-related API operations.

Location functionality may involve:

```text id="r6n4j2"
Address
    ↓
Geocoding
    ↓
Coordinates
```

and delivery-distance functionality:

```text id="h2w7p9"
Store coordinates
       +
Customer coordinates
       ↓
RoadDistanceService
       ↓
OSRM
```

---

# 16. Admin Controllers

The project contains three administrator-related controllers:

```text id="u3y5p7"
AdminController.java
AdminDataController.java
AdminRequestController.java
```

The separation reflects different administrative responsibilities.

These include administration of:

* Admin operations
* Administrative data
* Approval/application requests

The admin layer is especially important for workflows such as store-owner and delivery-partner approval.

---

# 17. `dto` Package

Location:

```text id="q4h8m2"
com.localmart.localmartbackend.dto
```

DTO means **Data Transfer Object**.

The DTO package contains objects used to transfer structured data between the HTTP/API layer and application services.

Current DTOs include:

```text id="w8k3r5"
AddCartItemRequest.java
AdminLoginOtpRequest.java
AdminVerifyOtpRequest.java
CartItemResponse.java
CartResponse.java
CreateOrderRequest.java
CustomerAddressRequest.java
CustomerProfileRequest.java
CustomerProfileResponse.java
DeliveryFeeRequest.java
DeliveryOrderResponse.java
DeliveryPartnerAvailabilityRequest.java
DeliveryPartnerLocationRequest.java
DeliveryPartnerProfileResponse.java
GoogleAuthRequest.java
LocationSearchRequest.java
LocationSearchResponse.java
LoginOtpRequest.java
OrderItemRequest.java
RegistrationOtpRequest.java
StoreOwnerDetailsRequest.java
StoreOwnerDetailsResponse.java
UserRegistrationRequest.java
VerifyOtpRequest.java
XRegistrationData.java
XUserInfo.java
```

---

# 18. Request DTOs

Request DTOs represent data coming into the backend.

For example:

```text id="4y6m2r"
UserRegistrationRequest
```

represents registration data.

Other examples include:

```text id="8k1p4z"
LoginOtpRequest
CustomerAddressRequest
AddCartItemRequest
CreateOrderRequest
DeliveryFeeRequest
GoogleAuthRequest
```

The flow is:

```text id="7x3n9c"
JSON
 ↓
Jackson
 ↓
Request DTO
 ↓
Controller
 ↓
Service
```

This prevents controllers from having to manually parse raw JSON.

---

# 19. Response DTOs

Response DTOs represent information returned by the backend.

Examples include:

```text id="r4m7s2"
CartResponse
CartItemResponse
CustomerProfileResponse
DeliveryOrderResponse
DeliveryPartnerProfileResponse
LocationSearchResponse
StoreOwnerDetailsResponse
```

The flow is:

```text id="9k5t1w"
Database Entity
       ↓
Service
       ↓
Response DTO
       ↓
Jackson
       ↓
JSON
       ↓
Frontend
```

This prevents internal persistence entities from automatically becoming the public API contract.

---

# 20. `entity` Package

Location:

```text id="n7c3v8"
com.localmart.localmartbackend.entity
```

Current entities:

```text id="x6k2p9"
Address.java
ApplicationRequest.java
Cart.java
CartItem.java
DeliveryPartner.java
DeliveryPartnerLocation.java
Order.java
OrderItem.java
Payment.java
Product.java
Role.java
StoreDetails.java
User.java
UserSession.java
VehicleDetails.java
```

These classes represent persistent domain objects mapped to database tables through JPA/Hibernate.

---

# 21. User Entity

```text id="d2m8q4"
User.java
```

Represents the core user record.

It is central to authentication and authorization.

Conceptually:

```text id="w5r9k1"
User
 ├── Identity information
 ├── Authentication information
 ├── Account status
 └── Role relationship
```

Other domain objects can reference the user.

---

# 22. Role Entity

```text id="f7p3m8"
Role.java
```

Represents the user's application role.

LocalMart supports:

```text
CUSTOMER
STORE_OWNER
DELIVERY_PARTNER
ADMIN
```

The role is used in authorization decisions.

---

# 23. Address Entity

```text id="a9q4t6"
Address.java
```

Represents persisted address information.

Addresses can contain geographic coordinates used by location and delivery functionality.

---

# 24. Store Entities

### `StoreDetails`

Represents store information.

It connects the store with its owner and address-related information.

### `Product`

Represents products offered by stores.

Conceptually:

```text id="r3v8n2"
Store
  ↓
Products
  ↓
Cart
  ↓
Order
```

---

# 25. Cart Entities

### `Cart`

Represents a customer's cart.

### `CartItem`

Represents an individual product entry inside the cart.

Relationship:

```text id="q2w6e9"
Customer
   ↓
Cart
   ↓
CartItem
   ↓
Product
```

The database therefore maintains persistent cart state.

---

# 26. Order Entities

### `Order`

Represents the overall customer order.

### `OrderItem`

Represents an individual item belonging to an order.

Relationship:

```text id="m4x8s1"
Order
  ↓
OrderItem
  ↓
Product
```

An order can contain multiple order items.

---

# 27. Payment Entity

```text id="v6k2r9"
Payment.java
```

Represents payment-related persisted information associated with the ordering/payment lifecycle.

Razorpay integration is handled separately through:

```text
RazorpayService
```

This is an important separation:

```text id="t7p3m4"
Payment Entity
→ Persistence

RazorpayService
→ External payment communication
```

---

# 28. Delivery Entities

The delivery subsystem contains:

```text id="q8m5n3"
DeliveryPartner.java
DeliveryPartnerLocation.java
VehicleDetails.java
```

These represent:

* Delivery partner information
* Delivery partner location
* Vehicle information

The relationship can be conceptualized as:

```text id="f4r7w2"
User
  ↓
DeliveryPartner
  ├── VehicleDetails
  └── DeliveryPartnerLocation
```

---

# 29. Application Request Entity

```text id="c6p2x8"
ApplicationRequest.java
```

Represents role-approval applications.

This is important for workflows where certain roles require administrator approval.

For example:

```text id="e9k4m7"
Registration
     ↓
ApplicationRequest
     ↓
ADMIN
     ↓
APPROVED / REJECTED
```

---

# 30. User Session Entity

```text id="j3w8q5"
UserSession.java
```

Represents authenticated user sessions.

It works with:

```text
UserSessionService
JwtService
JwtAuthenticationFilter
```

The architecture combines session tracking with JWT authentication.

Conceptually:

```text id="v5n1z7"
Login
 ↓
UserSession
 ↓
JWT
 ↓
Frontend
 ↓
Bearer token
 ↓
JwtAuthenticationFilter
 ↓
Session validation
```

---

# 31. `repository` Package

Location:

```text id="x7m3q9"
com.localmart.localmartbackend.repository
```

Current repositories:

```text id="p4r8k2"
AddressRepository.java
ApplicationRequestRepository.java
CartItemRepository.java
CartRepository.java
DeliveryPartnerLocationRepository.java
DeliveryPartnerRepository.java
OrderItemRepository.java
OrderRepository.java
PaymentRepository.java
ProductRepository.java
RoleRepository.java
StoreDetailsRepository.java
UserRepository.java
UserSessionRepository.java
VehicleDetailsRepository.java
```

Repositories provide the persistence abstraction between services and the database.

---

# 32. Repository Flow

The standard flow is:

```text id="s5h9w3"
Controller
    ↓
Service
    ↓
Repository
    ↓
JPA / Hibernate
    ↓
PostgreSQL
```

A service should generally not need to write raw JDBC operations for normal JPA persistence.

Spring Data JPA provides repository functionality.

---

# 33. Repository Responsibilities

Examples:

```text id="m8q2v6"
UserRepository
→ User persistence

ProductRepository
→ Product persistence

CartRepository
→ Cart persistence

CartItemRepository
→ Cart-item persistence

OrderRepository
→ Order persistence

PaymentRepository
→ Payment persistence

DeliveryPartnerRepository
→ Delivery-partner persistence
```

This keeps persistence responsibilities separate from business logic.

---

# 34. `service` Package

Location:

```text id="k6p9r3"
com.localmart.localmartbackend.service
```

Current services:

```text id="z2w5m8"
AdminDataService.java
AdminRequestService.java
AdminService.java
CartService.java
CustomerAddressService.java
CustomerService.java
DeliveryPartnerLocationService.java
DeliveryPartnerProfileService.java
EmailService.java
GeocodingService.java
GoogleTokenVerificationService.java
MessageCentralOtpService.java
MockOtpDeliveryService.java
OrderService.java
OtpDeliveryService.java
OtpService.java
RazorpayService.java
RegistrationVerificationService.java
RoadDistanceService.java
StoreOwnerService.java
StoreService.java
TotpService.java
UserService.java
UserSessionService.java
XOAuthService.java
```

The service layer contains the application's main business logic.

---

# 35. Why the Service Layer Exists

Consider a login request.

The controller receives the request:

```text id="c3x7p5"
POST /api/users/login
```

Instead of performing every operation itself, the controller calls:

```text id="v9m2q6"
UserService
```

The service can then:

```text id="f8k4w1"
Validate input
    ↓
Find user
    ↓
Check account status
    ↓
Verify password
    ↓
Create session
    ↓
Generate JWT
    ↓
Return UserResponse
```

This keeps the controller thin.

---

# 36. Authentication Services

### `UserService`

Central service for user registration, login, Google authentication, X authentication, account-status checks, and user-related business rules.

### `RegistrationVerificationService`

Handles registration OTP verification and registration-token logic.

### `OtpService`

Provides OTP-related functionality.

### `OtpDeliveryService`

Defines the OTP-delivery abstraction.

### `MessageCentralOtpService`

Provides Message Central-based OTP delivery.

### `MockOtpDeliveryService`

Provides a mock OTP-delivery implementation for development/testing scenarios.

### `TotpService`

Handles TOTP functionality.

---

# 37. Session and JWT Services

### `UserSessionService`

Manages authenticated user sessions.

### `JwtService`

Creates and validates JWTs.

Together:

```text id="h5q8w3"
UserService
    ↓
UserSessionService
    ↓
JwtService
    ↓
JWT
```

For subsequent requests:

```text id="p7m2v9"
HTTP Request
    ↓
JwtAuthenticationFilter
    ↓
JwtService
    ↓
UserSessionService
    ↓
SecurityContext
```

---

# 38. External Authentication Services

### `GoogleTokenVerificationService`

Verifies Google identity credentials received from the frontend.

### `XOAuthService`

Handles X OAuth-related backend functionality.

The separation ensures that external identity-provider communication is not mixed with general user-management logic.

---

# 39. Email Service

### `EmailService`

Responsible for email communication.

The OTP flow can be represented as:

```text id="w6p4n8"
User
 ↓
Authentication operation
 ↓
OTP generation
 ↓
EmailService
 ↓
SMTP
 ↓
User email
```

---

# 40. Location Services

### `GeocodingService`

Handles address/location conversion through a geocoding provider.

### `RoadDistanceService`

Handles road-distance and route-related calculations using OSRM.

Conceptually:

```text id="q9k3v5"
GeocodingService
→ Address ↔ Coordinates

RoadDistanceService
→ Coordinates → Road distance/duration
```

These services should remain separate because geocoding and routing solve different problems.

---

# 41. Payment Service

### `RazorpayService`

Handles communication with Razorpay.

The architecture separates payment persistence from payment-provider communication:

```text id="r8m4x2"
Order / Payment
      ↓
RazorpayService
      ↓
Razorpay
```

---

# 42. Customer Services

### `CustomerService`

Handles customer-related business logic.

### `CustomerAddressService`

Handles customer address management.

For example:

```text id="n6p3w7"
CustomerAddressController
        ↓
CustomerAddressService
        ↓
AddressRepository
        ↓
PostgreSQL
```

The address service also performs validation such as coordinate and Indian PIN-code validation.

---

# 43. Store and Product Services

### `StoreService`

Handles store-related business logic.

### `StoreOwnerService`

Handles store-owner functionality.

### `ProductService`

Handles product-related business logic.

The relationship is:

```text id="c4r8m6"
StoreController
     ↓
StoreService

ProductController
     ↓
ProductService
     ↓
ProductRepository
```

---

# 44. Cart and Order Services

### `CartService`

Handles cart business rules.

### `OrderService`

Handles order-related business rules.

The relationship is:

```text id="y7m2q5"
Cart
 ↓
CartService
 ↓
Checkout
 ↓
OrderService
 ↓
Order
```

Order processing can also interact with payment, address, product, and delivery functionality.

---

# 45. Delivery Services

### `DeliveryPartnerLocationService`

Handles delivery-partner location functionality.

### `DeliveryPartnerProfileService`

Handles delivery-partner profile functionality.

Delivery functionality therefore has both:

```text
Profile
+
Location
```

components.

---

# 46. Admin Services

The administrative services are:

```text id="x3k7n5"
AdminService
AdminDataService
AdminRequestService
```

They provide separate responsibilities for administrative operations, data, and approval requests.

The approval architecture is:

```text id="p8m4v2"
Store Owner /
Delivery Partner
       ↓
ApplicationRequest
       ↓
Admin
       ↓
Approval decision
```

---

# 47. `security` Package

Location:

```text id="d7q2m8"
com.localmart.localmartbackend.security
```

Current files:

```text id="w4n9p3"
JwtAuthenticationFilter.java
JwtService.java
RateLimitFilter.java
SecurityConfig.java
```

This package contains the application's security infrastructure.

---

# 48. `SecurityConfig`

```text id="m6r2x8"
SecurityConfig.java
```

Configures Spring Security.

It is responsible for defining the security behavior of HTTP requests and integrating authentication-related components into the Spring Security pipeline.

---

# 49. `JwtAuthenticationFilter`

```text id="k8p3v5"
JwtAuthenticationFilter.java
```

This filter processes incoming authenticated requests.

Conceptually:

```text id="f2m7q9"
HTTP Request
      ↓
Authorization header
      ↓
JwtAuthenticationFilter
      ↓
Extract JWT
      ↓
Validate JWT
      ↓
Validate session
      ↓
Create Authentication
      ↓
SecurityContext
      ↓
Controller
```

This occurs before the request reaches the protected controller endpoint.

---

# 50. `RateLimitFilter`

```text id="r5n8w2"
RateLimitFilter.java
```

Provides application-level rate-limiting functionality.

Its purpose is to restrict excessive request activity.

Conceptually:

```text id="z6q3m9"
Request
  ↓
RateLimitFilter
  ↓
Within limit?
 /       \
YES       NO
 ↓         ↓
Continue  Reject
```

This is particularly relevant to authentication endpoints and abuse prevention.

---

# 51. `exception` Package

Location:

```text id="q4m8x1"
com.localmart.localmartbackend.exception
```

Current file:

```text id="s7n3p5"
GlobalExceptionHandler.java
```

The global exception handler provides centralized handling for application errors.

Conceptually:

```text id="v2k6r9"
Controller
   ↓
Service
   ↓
Exception
   ↓
GlobalExceptionHandler
   ↓
HTTP error response
   ↓
Frontend
```

This avoids repeating error-response logic throughout every controller.

---

# 52. `passwordreset` Package

Current structure:

```text id="j5q8m2"
passwordreset/
└── entity/
    └── PasswordResetSession.java
```

The module contains persistence support for password-reset sessions.

The concept is:

```text id="b8r3v6"
Password reset request
       ↓
Password reset session
       ↓
Verification
       ↓
Password change
```

The session entity allows the password-reset process to be represented independently from the normal authenticated user session.

---

# 53. `smsotp` Package

The SMS OTP functionality has its own module:

```text id="n4x7p2"
smsotp/
├── controller/
├── dto/
├── model/
└── service/
```

Current structure:

```text id="w3m8q5"
smsotp/
├── controller/
│   └── SmsOtpController.java
│
├── dto/
│   ├── SmsOtpSendRequest.java
│   └── SmsOtpVerifyRequest.java
│
├── model/
│   └── SmsOtpSession.java
│
└── service/
    └── SmsOtpFlowService.java
```

This is a specialized module rather than putting every SMS-related class into the general packages.

---

# 54. SMS OTP Architecture

The flow is:

```text id="p9k4w6"
Frontend
   ↓
SmsOtpController
   ↓
SmsOtpFlowService
   ↓
MessageCentralOtpService
   ↓
Message Central
   ↓
SMS
   ↓
User
```

Verification follows the reverse application flow:

```text id="g5m2r8"
Frontend
   ↓
SmsOtpController
   ↓
SmsOtpFlowService
   ↓
OTP session / verification
   ↓
Success / failure
```

This module isolates the SMS-specific flow from the general user-service implementation.

---

# 55. Resources Package

The backend contains:

```text id="c8m3q6"
src/main/resources/
```

with:

```text
application.properties
static/
templates/
```

### `application.properties`

Contains Spring Boot application configuration.

### `static/`

Provides the standard Spring Boot location for static resources.

### `templates/`

Provides the standard Spring Boot location for server-side templates.

The current LocalMart architecture primarily uses REST APIs and a separate React frontend.

---

# 56. Test Structure

The project contains a test source tree under:

```text id="q7n4m2"
src/test/java/com/localmart/localmartbackend/
```

Current tests include:

```text id="x5p8r3"
LocalmartBackendApplicationTests.java
service/
└── TotpServiceTest.java
```

The tests provide the foundation for verifying application startup and TOTP functionality.

Additional testing categories can be expanded as the project grows.

---

# 57. Maven Build Configuration

The backend contains:

```text id="m8q3v7"
pom.xml
```

This is the Maven project configuration.

It defines the project's dependencies and build configuration.

The dependency layer includes technologies such as:

```text
Spring Boot
Spring Web
Spring Security
Spring Data JPA
Hibernate
PostgreSQL Driver
JWT library
Google API Client
TOTP library
Razorpay SDK
Mail support
Validation
```

Maven resolves these dependencies and makes them available to the application.

---

# 58. Maven Wrapper

The project contains:

```text id="p4n7x2"
mvnw
mvnw.cmd
```

These are Maven Wrapper files.

On Windows, the project can use:

```text id="w6k3m9"
mvnw.cmd
```

The wrapper allows the project to invoke Maven using the configured wrapper version without requiring the developer to manage the Maven installation manually.

---

# 59. `target` Directory

The project also contains:

```text id="v3m8q1"
target/
```

This is Maven's build-output directory.

It can contain:

* Compiled classes
* Generated build artifacts
* Test results
* Packaged application files

It is generated during the build process rather than being the primary source-code directory.

---

# 60. `.idea` Directory

The project contains:

```text id="n5q2r8"
.idea/
```

This directory contains IntelliJ IDEA project metadata.

Examples include:

```text
compiler.xml
encodings.xml
misc.xml
workspace.xml
```

These files are development-environment metadata rather than LocalMart business logic.

---

# 61. Backend Layered Architecture

The main backend architecture can be represented as:

```text id="e7m3q9"
                 HTTP REQUEST
                      |
                      v
              ┌──────────────┐
              │  Controller  │
              └──────┬───────┘
                     |
                     v
              ┌──────────────┐
              │    DTO       │
              └──────┬───────┘
                     |
                     v
              ┌──────────────┐
              │   Service    │
              └──────┬───────┘
                     |
                     v
              ┌──────────────┐
              │ Repository   │
              └──────┬───────┘
                     |
                     v
              ┌──────────────┐
              │   Entity     │
              └──────┬───────┘
                     |
                     v
                PostgreSQL
```

Security operates around the HTTP request pipeline:

```text id="j4n8p6"
HTTP Request
      ↓
Security Filters
      ↓
Controller
      ↓
Service
      ↓
Repository
      ↓
Database
```

---

# 62. External Integration Architecture

External services are accessed through dedicated service classes.

```text id="r2m7x5"
                 LocalMart Service Layer
                         |
        ┌────────────────┼────────────────┐
        ↓                ↓                ↓
 GoogleToken       MessageCentral    RazorpayService
 Verification           ↓                ↓
        ↓           SMS/WhatsApp      Razorpay
     Google
```

Location services are separated similarly:

```text id="p6k3w8"
GeocodingService
      ↓
Geocoding Provider

RoadDistanceService
      ↓
OSRM
```

Email communication is handled through:

```text id="m9q4r2"
EmailService
     ↓
SMTP
```

---

# 63. Dependency Direction

The intended dependency direction is:

```text id="x8m3q5"
Controller
    ↓
Service
    ↓
Repository
    ↓
Entity / Database
```

External integrations are accessed through service abstractions:

```text id="q5r7n2"
Service
   ↓
Integration Service
   ↓
External Provider
```

The purpose is to prevent lower-level infrastructure details from leaking into controllers.

---

# 64. Example: Customer Address Request

Suppose the frontend sends an address request.

The flow is:

```text id="f7m2x9"
React
  |
  | JSON
  v
CustomerAddressController
  |
  v
CustomerAddressRequest
  |
  v
CustomerAddressService
  |
  v
AddressRepository
  |
  v
Hibernate
  |
  v
PostgreSQL
```

The response follows the reverse direction:

```text id="r3q8w5"
PostgreSQL
   ↓
Entity
   ↓
Service
   ↓
Response DTO
   ↓
Jackson
   ↓
JSON
   ↓
React
```

---

# 65. Example: Login Request

The login architecture is:

```text id="m5n9p3"
React
   |
   | POST /api/users/login
   v
UserController
   |
   v
UserService
   |
   ├── UserRepository
   |
   ├── BCrypt password verification
   |
   ├── Account status check
   |
   ├── UserSessionService
   |
   └── JwtService
           |
           v
          JWT
           |
           v
        Response
```

For subsequent requests:

```text id="q8r2x6"
React
   |
   | Authorization: Bearer JWT
   v
JwtAuthenticationFilter
   |
   v
JwtService
   |
   v
UserSessionService
   |
   v
SecurityContext
   |
   v
Controller
```

---

# 66. Example: Order Architecture

An order request can conceptually follow:

```text id="w4m7q9"
Customer
   ↓
OrderController
   ↓
OrderService
   ├── Cart
   ├── Product
   ├── Address
   ├── Payment
   └── Order
   ↓
Repository layer
   ↓
PostgreSQL
```

The order module therefore interacts with several domain components while keeping HTTP handling separate from business logic.

---

# 67. Example: Delivery Architecture

The delivery architecture connects multiple modules:

```text id="p2n6x8"
Order
   ↓
Delivery workflow
   ↓
DeliveryPartner
   ↓
DeliveryPartnerLocation
   ↓
Browser Geolocation
   ↓
RoadDistanceService
   ↓
OSRM
```

The delivery status lifecycle is:

```text id="k7m3q5"
READY_FOR_PICKUP
        ↓
    ACCEPTED
        ↓
    PICKED_UP
        ↓
 OUT_FOR_DELIVERY
        ↓
    DELIVERED
```

---

# 68. Why the Project Is Split Into Packages

The package structure follows separation of concerns.

Without separation, a single class could end up containing:

```text id="r5w8m2"
HTTP handling
+
SQL operations
+
Authentication
+
Payment
+
Business rules
+
External API calls
```

That would make the system difficult to understand and maintain.

Instead, LocalMart separates these concerns:

```text id="v3q7n9"
Controller
→ HTTP

DTO
→ Data transfer

Service
→ Business logic

Repository
→ Persistence

Entity
→ Database/domain mapping

Security
→ Authentication infrastructure

Config
→ Configuration

Exception
→ Error handling

Integration services
→ External systems
```

---

# 69. Complete Backend Responsibility Map

| Package         | Primary responsibility                       |
| --------------- | -------------------------------------------- |
| `config`        | Application configuration and initialization |
| `controller`    | HTTP/API endpoints                           |
| `dto`           | Request and response data structures         |
| `entity`        | Persistent domain/database mappings          |
| `repository`    | Database persistence abstraction             |
| `service`       | Business logic and integrations              |
| `security`      | JWT, Spring Security, rate limiting          |
| `exception`     | Centralized exception handling               |
| `passwordreset` | Password-reset session persistence           |
| `smsotp`        | Dedicated SMS OTP workflow                   |
| `resources`     | Application configuration and resources      |

---

# 70. Complete Request Lifecycle

The complete LocalMart backend request lifecycle can be summarized as:

```text id="n8m4q2"
                    Browser
                       |
                       | HTTP
                       v
                Security Filters
                       |
              ┌────────┴────────┐
              |                 |
          JWT Filter       Rate Limit
              |                 |
              └────────┬────────┘
                       ↓
                  Controller
                       ↓
                     DTO
                       ↓
                    Service
                       |
              ┌────────┼─────────┐
              ↓        ↓         ↓
         Repository  External   Security
              |      Service
              ↓        ↓
         PostgreSQL  External API
              |
              ↓
            Entity
              ↓
        Response DTO
              ↓
           Jackson
              ↓
             JSON
              ↓
           Browser
```

This is the central architectural pattern behind the LocalMart backend.

---

# 71. Project Structure and Maintainability

The current structure makes it possible to modify one part of the application without unnecessarily affecting unrelated parts.

For example:

```text id="c9r4m7"
Change payment integration
        ↓
RazorpayService
        ↓
Payment-related logic
```

instead of modifying every controller.

Similarly:

```text id="x5m8q2"
Change database persistence
        ↓
Repository / Entity layer
```

while keeping the HTTP layer mostly unchanged.

This separation becomes increasingly valuable as LocalMart grows.

---

# 72. Key Takeaways

The LocalMart backend is organized around a layered architecture.

The most important responsibilities are:

1. **Controllers expose HTTP APIs.**
2. **DTOs define request and response structures.**
3. **Services contain business logic.**
4. **Repositories handle persistence through Spring Data JPA.**
5. **Entities represent persistent domain objects.**
6. **Security contains JWT and request-security infrastructure.**
7. **Configuration contains application initialization and provider configuration.**
8. **Exception handling centralizes error responses.**
9. **Specialized modules isolate password-reset and SMS OTP functionality.**
10. **Dedicated integration services isolate external providers.**

The resulting architecture is:

```text id="z6q3w9"
                    LocalMart
                       |
          ┌────────────┴────────────┐
          |                         |
       Frontend                  Backend
          |                         |
     React/Vite              Spring Boot
                                    |
       ┌────────────────────────────┼──────────────────────────┐
       ↓                            ↓                          ↓
   Controller                    Security                  Config
       ↓
      DTO
       ↓
    Service
       |
       ├───────────────┐
       ↓               ↓
 Repository       External Services
       ↓               ↓
   Entities       External APIs
       |
       ↓
 PostgreSQL
```

This package structure provides the separation of concerns required for LocalMart to function as a maintainable full-stack application rather than a collection of tightly coupled CRUD endpoints.
