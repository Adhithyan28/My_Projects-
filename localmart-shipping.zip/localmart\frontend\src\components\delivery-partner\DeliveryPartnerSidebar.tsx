interface DeliveryPartnerSidebarProps {
    activePage: "dashboard" | "deliveries" | "location" | "profile"
    onNavigate: (
        page: "dashboard" | "deliveries" | "location" | "profile"
    ) => void
    onLogout: () => void
}

function DeliveryPartnerSidebar({
                                    activePage,
                                    onNavigate,
                                    onLogout,
                                }: DeliveryPartnerSidebarProps) {

    return (

        <aside className="delivery-sidebar">

            <div className="delivery-sidebar-logo">

                <button
                    type="button"
                    onClick={() => onNavigate("dashboard")}
                >
                    Local<span>Mart</span>
                </button>

                <p>Delivery Partner</p>

            </div>

            <nav className="delivery-sidebar-navigation">

                <button
                    type="button"
                    className={
                        activePage === "dashboard"
                            ? "delivery-nav-item active"
                            : "delivery-nav-item"
                    }
                    onClick={() => onNavigate("dashboard")}
                >
                    <span className="delivery-nav-icon">
                        🏠
                    </span>

                    <span>
                        Dashboard
                    </span>
                </button>

                <button
                    type="button"
                    className={
                        activePage === "deliveries"
                            ? "delivery-nav-item active"
                            : "delivery-nav-item"
                    }
                    onClick={() => onNavigate("deliveries")}
                >
                    <span className="delivery-nav-icon">
                        🚚
                    </span>

                    <span>
                        My Deliveries
                    </span>
                </button>

                <button
                    type="button"
                    className={
                        activePage === "location"
                            ? "delivery-nav-item active"
                            : "delivery-nav-item"
                    }
                    onClick={() => onNavigate("location")}
                >
                    <span className="delivery-nav-icon">
                        ────
                    </span>

                    <span>
                            ──────────────
                    </span>
                </button>

                <button
                    type="button"
                    className={
                        activePage === "profile"
                            ? "delivery-nav-item active"
                            : "delivery-nav-item"
                    }
                    onClick={() => onNavigate("profile")}
                >
                    <span className="delivery-nav-icon">
                        👤
                    </span>

                    <span>
                        Profile
                    </span>
                </button>

            </nav>

            <div className="delivery-sidebar-bottom">

                <div className="delivery-sidebar-divider"></div>

                <button
                    type="button"
                    className="delivery-logout-button"
                    onClick={onLogout}
                >
                    <span>
                        🚪
                    </span>

                    <span>
                        Logout
                    </span>
                </button>

            </div>

        </aside>
    )
}

export default DeliveryPartnerSidebar