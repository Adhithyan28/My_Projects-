package com.localmart.localmartbackend.service;

public class MockOtpDeliveryService
        implements OtpDeliveryService {

    @Override
    public String sendSmsOtp(
            String phone) {

        System.out.println(
                "MOCK SMS OTP requested for: "
                        + phone
        );

        return "MOCK_VERIFICATION_ID";
    }

    @Override
    public String sendWhatsAppOtp(
            String phone) {

        System.out.println(
                "MOCK WHATSAPP OTP requested for: "
                        + phone
        );

        return "MOCK_VERIFICATION_ID";
    }

    @Override
    public boolean verifyOtp(
            String verificationId,
            String otp) {

        return false;
    }
}