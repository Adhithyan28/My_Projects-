package com.localmart.localmartbackend.service;

import com.localmart.localmartbackend.dto.ChangePasswordRequest;
import com.localmart.localmartbackend.dto.GoogleAuthRequest;
import com.localmart.localmartbackend.dto.LoginOtpRequest;
import com.localmart.localmartbackend.dto.LoginRequest;
import com.localmart.localmartbackend.dto.UserRegistrationRequest;
import com.localmart.localmartbackend.dto.UserResponse;
import com.localmart.localmartbackend.dto.VerifyOtpRequest;
import com.localmart.localmartbackend.dto.XRegistrationData;
import com.localmart.localmartbackend.dto.XUserInfo;
import com.localmart.localmartbackend.entity.Address;
import com.localmart.localmartbackend.entity.ApplicationRequest;
import com.localmart.localmartbackend.entity.DeliveryPartner;
import com.localmart.localmartbackend.entity.Role;
import com.localmart.localmartbackend.entity.StoreDetails;
import com.localmart.localmartbackend.entity.User;
import com.localmart.localmartbackend.entity.UserPasswordHistory;
import com.localmart.localmartbackend.entity.UserSession;
import com.localmart.localmartbackend.entity.VehicleDetails;
import com.localmart.localmartbackend.repository.AddressRepository;
import com.localmart.localmartbackend.repository.ApplicationRequestRepository;
import com.localmart.localmartbackend.repository.DeliveryPartnerRepository;
import com.localmart.localmartbackend.repository.RoleRepository;
import com.localmart.localmartbackend.repository.StoreDetailsRepository;
import com.localmart.localmartbackend.repository.UserPasswordHistoryRepository;
import com.localmart.localmartbackend.repository.UserRepository;
import com.localmart.localmartbackend.repository.VehicleDetailsRepository;
import com.localmart.localmartbackend.security.JwtService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

@Service
public class UserService {

    // ============================================================
    // ROLE CODES
    // ============================================================

    private static final int ROLE_CUSTOMER = 1;
    private static final int ROLE_STORE_OWNER = 2;
    private static final int ROLE_DELIVERY_PARTNER = 3;
    private static final int ROLE_ADMIN = 4;

    // ============================================================
    // ACCOUNT STATUS CODES
    // ============================================================

    private static final int ACCOUNT_ACTIVE = 1;
    private static final int ACCOUNT_INACTIVE = 2;
    private static final int ACCOUNT_BLOCKED = 3;

    // ============================================================
    // APPLICATION TYPES
    // ============================================================

    private static final int APPLICATION_STORE_OWNER = 1;
    private static final int APPLICATION_DELIVERY_PARTNER = 2;

    // ============================================================
    // APPLICATION STATUS
    // ============================================================

    private static final int APPLICATION_PENDING = 1;
    private static final int APPLICATION_APPROVED = 2;
    private static final int APPLICATION_REJECTED = 3;

    // ============================================================
    // OTP CONFIGURATION
    // ============================================================

    private static final int OTP_EXPIRY_MINUTES = 5;

    // ============================================================
    // GOOGLE REGISTRATION CONFIGURATION
    // ============================================================

    private static final int GOOGLE_REGISTRATION_EXPIRY_MINUTES = 10;

    private static final String GOOGLE_REGISTRATION_TOKEN_PREFIX =
            "GOOGLE_REG_";

    private final Map<String, GoogleRegistrationData>
            googleRegistrationStore =
            new ConcurrentHashMap<>();

    // ============================================================
    // X REGISTRATION CONFIGURATION
    // ============================================================

    private static final int X_REGISTRATION_EXPIRY_MINUTES = 10;

    private static final String X_REGISTRATION_TOKEN_PREFIX =
            "X_REG_";

    private final Map<String, XRegistrationData>
            xRegistrationStore =
            new ConcurrentHashMap<>();

    // ============================================================
    // LOGIN OTP STORAGE
    // ============================================================

    private final Map<String, OtpData> otpStore =
            new ConcurrentHashMap<>();

    // ============================================================
    // REPOSITORIES / SERVICES
    // ============================================================

    private final UserRepository userRepository;

    private final RoleRepository roleRepository;

    private final AddressRepository addressRepository;

    private final ApplicationRequestRepository
            applicationRequestRepository;

    private final StoreDetailsRepository
            storeDetailsRepository;

    private final DeliveryPartnerRepository
            deliveryPartnerRepository;

    private final VehicleDetailsRepository
            vehicleDetailsRepository;

    private final UserPasswordHistoryRepository
            userPasswordHistoryRepository;

    private final EmailService emailService;

    private final JwtService jwtService;

    private final UserSessionService userSessionService;

    private final OtpDeliveryService otpDeliveryService;

    private final RegistrationVerificationService
            registrationVerificationService;

    private final GoogleTokenVerificationService
            googleTokenVerificationService;

    private final TotpService totpService;

    // ============================================================
    // PASSWORD ROTATION
    // ============================================================

    private final PasswordRotationService passwordRotationService;

    // ============================================================
    // VALIDATION
    // ============================================================

    private static final Pattern EMAIL_PATTERN =
            Pattern.compile(
                    "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"
            );

    private static final Pattern PHONE_PATTERN =
            Pattern.compile(
                    "^[6-9][0-9]{9}$"
            );

    // ============================================================
    // CONSTRUCTOR
    // ============================================================

    public UserService(
            UserRepository userRepository,
            RoleRepository roleRepository,
            AddressRepository addressRepository,
            ApplicationRequestRepository applicationRequestRepository,
            StoreDetailsRepository storeDetailsRepository,
            DeliveryPartnerRepository deliveryPartnerRepository,
            VehicleDetailsRepository vehicleDetailsRepository,
            UserPasswordHistoryRepository userPasswordHistoryRepository,
            EmailService emailService,
            JwtService jwtService,
            UserSessionService userSessionService,
            OtpDeliveryService otpDeliveryService,
            RegistrationVerificationService
                    registrationVerificationService,
            GoogleTokenVerificationService
                    googleTokenVerificationService,
            TotpService totpService,
            PasswordRotationService passwordRotationService) {

        this.userRepository =
                userRepository;

        this.roleRepository =
                roleRepository;

        this.addressRepository =
                addressRepository;

        this.applicationRequestRepository =
                applicationRequestRepository;

        this.storeDetailsRepository =
                storeDetailsRepository;

        this.deliveryPartnerRepository =
                deliveryPartnerRepository;

        this.vehicleDetailsRepository =
                vehicleDetailsRepository;

        this.userPasswordHistoryRepository =
                userPasswordHistoryRepository;

        this.emailService =
                emailService;

        this.jwtService =
                jwtService;

        this.userSessionService =
                userSessionService;

        this.otpDeliveryService =
                otpDeliveryService;

        this.registrationVerificationService =
                registrationVerificationService;

        this.googleTokenVerificationService =
                googleTokenVerificationService;

        this.totpService =
                totpService;

        this.passwordRotationService =
                passwordRotationService;
    }

    // ============================================================
    // REGISTRATION
    // ============================================================

    @Transactional
    public UserResponse registerUser(
            UserRegistrationRequest request) {

        if (request == null) {
            throw new RuntimeException(
                    "Registration request is required"
            );
        }

        // ========================================================
        // REGISTRATION TYPE
        // ========================================================

        GoogleRegistrationData googleRegistrationData =
                null;

        XRegistrationData xRegistrationData =
                null;

        String registrationToken =
                request.getRegistrationToken();

        // ========================================================
        // GOOGLE REGISTRATION
        // ========================================================

        if (isGoogleRegistrationToken(
                registrationToken
        )) {

            googleRegistrationData =
                    validateGoogleRegistrationToken(
                            registrationToken
                    );
        }

        // ========================================================
        // X REGISTRATION
        // ========================================================

        else if (isXRegistrationToken(
                registrationToken
        )) {

            xRegistrationData =
                    validateXRegistrationToken(
                            registrationToken
                    );
        }

        // ========================================================
        // NORMAL EMAIL / MOBILE REGISTRATION
        // ========================================================

        else {

            RegistrationVerificationService
                    .RegistrationSession registrationSession =
                    registrationVerificationService.validateToken(
                            registrationToken
                    );

            registrationVerificationService
                    .validateVerifiedIdentifier(
                            registrationSession,
                            request.getEmail(),
                            request.getPhone()
                    );
        }

        // ========================================================
        // EMAIL
        // ========================================================

        String email =
                normalizeEmail(
                        request.getEmail()
                );

        if (email == null) {
            throw new RuntimeException(
                    "Email is required"
            );
        }

        if (!EMAIL_PATTERN.matcher(email).matches()) {
            throw new RuntimeException(
                    "Please enter a valid email address"
            );
        }

        // ========================================================
        // GOOGLE EMAIL MATCH
        // ========================================================

        if (googleRegistrationData != null) {

            String googleEmail =
                    normalizeEmail(
                            googleRegistrationData.email()
                    );

            if (!email.equals(
                    googleEmail
            )) {

                throw new RuntimeException(
                        "The email address must match the verified Google account"
                );
            }
        }

        // ========================================================
        // X EMAIL MATCH
        // ========================================================

        if (xRegistrationData != null) {

            String xEmail =
                    normalizeEmail(
                            xRegistrationData.email()
                    );

            if (!email.equals(
                    xEmail
            )) {

                throw new RuntimeException(
                        "The email address must match the verified X account"
                );
            }
        }

        // ========================================================
        // PHONE
        // ========================================================

        String phone =
                normalizePhone(
                        request.getPhone()
                );

        if (phone == null) {
            throw new RuntimeException(
                    "Mobile number is required"
            );
        }

        if (!PHONE_PATTERN.matcher(phone).matches()) {
            throw new RuntimeException(
                    "Please enter a valid 10-digit Indian mobile number"
            );
        }

        // ========================================================
        // PASSWORD
        // ========================================================

        if (isBlank(request.getPassword())) {
            throw new RuntimeException(
                    "Password is required"
            );
        }

        // ========================================================
        // ROLE
        // ========================================================

        int roleCode =
                getRoleCode(
                        request.getRole()
                );

        // ========================================================
        // DUPLICATE EMAIL
        // ========================================================

        if (userRepository.existsByEmail(email)) {
            throw new RuntimeException(
                    "Email already registered"
            );
        }

        // ========================================================
        // DUPLICATE PHONE
        // ========================================================

        if (userRepository.existsByPhone(phone)) {
            throw new RuntimeException(
                    "Mobile number already registered"
            );
        }

        // ========================================================
        // GOOGLE ID DUPLICATE CHECK
        // ========================================================

        if (googleRegistrationData != null &&
                userRepository.existsByGoogleId(
                        googleRegistrationData.googleId()
                )) {

            throw new RuntimeException(
                    "This Google account is already registered with LocalMart"
            );
        }

        // ========================================================
        // X ID DUPLICATE CHECK
        // ========================================================

        if (xRegistrationData != null &&
                userRepository
                        .findByxId(
                                xRegistrationData.xId()
                        )
                        .isPresent()) {

            throw new RuntimeException(
                    "This X account is already registered with LocalMart"
            );
        }

        // ========================================================
        // NAME
        // ========================================================

        String firstName =
                request.getFirstName();

        String lastName =
                request.getLastName();

        if (isBlank(firstName)) {

            String nameSource =
                    request.getFullName();

            if (isBlank(nameSource)) {
                nameSource =
                        request.getOwnerName();
            }

            // ----------------------------------------------------
            // GOOGLE NAME
            // ----------------------------------------------------

            if (isBlank(nameSource) &&
                    googleRegistrationData != null) {

                nameSource =
                        googleRegistrationData.name();
            }

            // ----------------------------------------------------
            // X NAME
            // ----------------------------------------------------

            if (isBlank(nameSource) &&
                    xRegistrationData != null) {

                nameSource =
                        xRegistrationData.name();
            }

            String[] names =
                    splitName(
                            nameSource
                    );

            firstName =
                    names[0];

            lastName =
                    names[1];
        }

        if (isBlank(firstName)) {
            throw new RuntimeException(
                    "First name is required"
            );
        }

        if (isBlank(lastName)) {
            throw new RuntimeException(
                    "Last name is required"
            );
        }

        // ========================================================
        // CREATE USER
        // ========================================================

        User user =
                new User();

        user.setFirstName(
                firstName.trim()
        );

        user.setLastName(
                lastName.trim()
        );

        user.setEmail(
                email
        );

        user.setPhone(
                phone
        );

        // ========================================================
        // PASSWORD HASHING
        // ========================================================

        /*
         * PostgreSQL generates the BCrypt password hash
         * using pgcrypto crypt() + gen_salt().
         *
         * The plain password is sent as a parameter to PostgreSQL.
         * PostgreSQL returns the generated BCrypt hash.
         */

        user.setPassword(
                userRepository.hashPassword(
                        request.getPassword()
                )
        );

        // ========================================================
        // GOOGLE ID
        // ========================================================

        if (googleRegistrationData != null) {

            user.setGoogleId(
                    googleRegistrationData.googleId()
            );
        }

        // ========================================================
        // X ID
        // ========================================================

        if (xRegistrationData != null) {

            user.setXId(
                    xRegistrationData.xId()
            );
        }

        // ========================================================
        // ACCOUNT STATUS
        // ========================================================

        if (roleCode == ROLE_CUSTOMER) {

            user.setAccountStatus(
                    ACCOUNT_ACTIVE
            );

        } else {

            user.setAccountStatus(
                    ACCOUNT_INACTIVE
            );
        }

        // ========================================================
        // SAVE USER
        // ========================================================

        User savedUser =
                userRepository.save(
                        user
                );

        // ========================================================
        // SAVE INITIAL PASSWORD HISTORY
        // ========================================================

        /*
         * The password stored in users.password is already
         * BCrypt-hashed by PostgreSQL.
         *
         * We store that SAME hash in the password-history table.
         *
         * We do NOT hash the hash again.
         */

        UserPasswordHistory passwordHistory =
                new UserPasswordHistory();

        passwordHistory.setUserId(
                savedUser.getUserId()
        );

        passwordHistory.setPasswordHash(
                savedUser.getPassword()
        );

        passwordHistory.setChangedAt(
                LocalDateTime.now()
        );

        userPasswordHistoryRepository.save(
                passwordHistory
        );

        // ========================================================
        // SAVE ROLE
        // ========================================================

        Role role =
                new Role();

        role.setUserId(
                savedUser.getUserId()
        );

        role.setRole(
                roleCode
        );

        roleRepository.save(
                role
        );

        // ========================================================
        // SAVE ADDRESS
        // ========================================================

        saveAddress(
                savedUser,
                request
        );

        // ========================================================
        // STORE OWNER
        // ========================================================

        if (roleCode == ROLE_STORE_OWNER) {

            createStoreOwnerData(
                    savedUser,
                    request
            );

            createApplicationRequest(
                    savedUser,
                    APPLICATION_STORE_OWNER
            );
        }

        // ========================================================
        // DELIVERY PARTNER
        // ========================================================

        else if (roleCode == ROLE_DELIVERY_PARTNER) {

            createDeliveryPartnerData(
                    savedUser,
                    request
            );

            createApplicationRequest(
                    savedUser,
                    APPLICATION_DELIVERY_PARTNER
            );
        }

        // ========================================================
        // CONSUME REGISTRATION TOKEN
        // ========================================================

        if (googleRegistrationData != null) {

            googleRegistrationStore.remove(
                    registrationToken
            );

        } else if (xRegistrationData != null) {

            xRegistrationStore.remove(
                    registrationToken
            );

        } else {

            registrationVerificationService
                    .consumeToken(
                            registrationToken
                    );
        }

        return convertToResponse(
                savedUser,
                false
        );
    }

    // ============================================================
    // GOOGLE LOGIN
    // ============================================================

    public UserResponse googleLogin(
            GoogleAuthRequest request) {

        if (request == null ||
                isBlank(request.getCredential())) {

            throw new RuntimeException(
                    "Google credential is required"
            );
        }

        GoogleTokenVerificationService.GoogleUserInfo
                googleUser =
                googleTokenVerificationService.verify(
                        request.getCredential()
                );

        String googleId =
                googleUser.getGoogleId();

        String email =
                normalizeEmail(
                        googleUser.getEmail()
                );

        User user =
                userRepository
                        .findByGoogleId(
                                googleId
                        )
                        .orElse(null);

        if (user == null) {

            if (userRepository.existsByEmail(
                    email
            )) {

                throw new RuntimeException(
                        "A LocalMart account already exists with this email. Please use your existing LocalMart login."
                );
            }

            throw new RuntimeException(
                    "No LocalMart account is linked to this Google account. Please register first."
            );
        }

        if (!email.equals(
                normalizeEmail(
                        user.getEmail()
                )
        )) {

            throw new RuntimeException(
                    "Google account information does not match the LocalMart account"
            );
        }

        checkAccountStatus(
                user
        );

        return convertToResponse(
                user,
                true
        );
    }

    // ============================================================
    // X LOGIN
    // ============================================================

    public UserResponse xLogin(
            XUserInfo xUserInfo) {

        if (xUserInfo == null) {
            throw new RuntimeException(
                    "X user information is required"
            );
        }

        String xId =
                xUserInfo.getXId();

        if (isBlank(xId)) {
            throw new RuntimeException(
                    "X account ID is required"
            );
        }

        String email =
                normalizeEmail(
                        xUserInfo.getEmail()
                );

        if (email == null) {
            throw new RuntimeException(
                    "Email address could not be retrieved from the X account"
            );
        }

        User user =
                userRepository
                        .findByxId(
                                xId
                        )
                        .orElse(null);

        if (user != null) {

            checkAccountStatus(
                    user
            );

            return convertToResponse(
                    user,
                    true
            );
        }

        if (userRepository.existsByEmail(
                email
        )) {

            throw new RuntimeException(
                    "A LocalMart account already exists with this email. Please use your existing LocalMart login."
            );
        }

        throw new RuntimeException(
                "No LocalMart account is linked to this X account. Please register first."
        );
    }

    // ============================================================
    // X REGISTRATION
    // ============================================================

    public Map<String, Object> xRegister(
            XUserInfo xUserInfo) {

        if (xUserInfo == null) {
            throw new RuntimeException(
                    "X user information is required"
            );
        }

        String xId =
                xUserInfo.getXId();

        if (isBlank(xId)) {
            throw new RuntimeException(
                    "X account ID is required"
            );
        }

        String email =
                normalizeEmail(
                        xUserInfo.getEmail()
                );

        if (email == null) {
            throw new RuntimeException(
                    "Email address could not be retrieved from the X account"
            );
        }

        if (!EMAIL_PATTERN.matcher(email).matches()) {
            throw new RuntimeException(
                    "The email address received from X is invalid"
            );
        }

        if (userRepository
                .findByxId(
                        xId
                )
                .isPresent()) {

            throw new RuntimeException(
                    "This X account is already registered with LocalMart. Please use X login."
            );
        }

        if (userRepository.existsByEmail(
                email
        )) {

            throw new RuntimeException(
                    "A LocalMart account already exists with this email. Please use your existing LocalMart login."
            );
        }

        String registrationToken =
                X_REGISTRATION_TOKEN_PREFIX +
                        UUID.randomUUID();

        LocalDateTime expiresAt =
                LocalDateTime.now()
                        .plusMinutes(
                                X_REGISTRATION_EXPIRY_MINUTES
                        );

        xRegistrationStore.put(
                registrationToken,
                new XRegistrationData(
                        xId,
                        email,
                        xUserInfo.getName(),
                        xUserInfo.getUsername(),
                        expiresAt
                )
        );

        return Map.of(
                "success",
                true,

                "message",
                "X account verified successfully. Please complete your registration.",

                "registrationToken",
                registrationToken,

                "identifier",
                email,

                "identifierType",
                "X",

                "email",
                email,

                "firstName",
                "",

                "lastName",
                "",

                "name",
                xUserInfo.getName() == null
                        ? ""
                        : xUserInfo.getName(),

                "username",
                xUserInfo.getUsername() == null
                        ? ""
                        : xUserInfo.getUsername()
        );
    }

    // ============================================================
    // GOOGLE REGISTRATION
    // ============================================================

    public Map<String, Object> googleRegister(
            GoogleAuthRequest request) {

        if (request == null ||
                isBlank(request.getCredential())) {

            throw new RuntimeException(
                    "Google credential is required"
            );
        }

        GoogleTokenVerificationService.GoogleUserInfo
                googleUser =
                googleTokenVerificationService.verify(
                        request.getCredential()
                );

        String googleId =
                googleUser.getGoogleId();

        String email =
                normalizeEmail(
                        googleUser.getEmail()
                );

        if (userRepository.existsByGoogleId(
                googleId
        )) {

            throw new RuntimeException(
                    "This Google account is already registered with LocalMart. Please use Google login."
            );
        }

        if (userRepository.existsByEmail(
                email
        )) {

            throw new RuntimeException(
                    "A LocalMart account already exists with this email. Please use your existing LocalMart login."
            );
        }

        String registrationToken =
                GOOGLE_REGISTRATION_TOKEN_PREFIX +
                        UUID.randomUUID();

        LocalDateTime expiresAt =
                LocalDateTime.now()
                        .plusMinutes(
                                GOOGLE_REGISTRATION_EXPIRY_MINUTES
                        );

        googleRegistrationStore.put(
                registrationToken,
                new GoogleRegistrationData(
                        googleId,
                        email,
                        googleUser.getName(),
                        googleUser.getGivenName(),
                        googleUser.getFamilyName(),
                        googleUser.getPicture(),
                        expiresAt
                )
        );

        return Map.of(
                "success",
                true,

                "message",
                "Google account verified successfully. Please complete your registration.",

                "registrationToken",
                registrationToken,

                "identifier",
                email,

                "identifierType",
                "GOOGLE",

                "email",
                email,

                "firstName",
                googleUser.getGivenName() == null
                        ? ""
                        : googleUser.getGivenName(),

                "lastName",
                googleUser.getFamilyName() == null
                        ? ""
                        : googleUser.getFamilyName(),

                "name",
                googleUser.getName() == null
                        ? ""
                        : googleUser.getName()
        );
    }

    // ============================================================
    // VALIDATE GOOGLE REGISTRATION TOKEN
    // ============================================================

    private GoogleRegistrationData
    validateGoogleRegistrationToken(
            String registrationToken) {

        if (isBlank(registrationToken)) {

            throw new RuntimeException(
                    "Registration verification is required"
            );
        }

        GoogleRegistrationData data =
                googleRegistrationStore.get(
                        registrationToken
                );

        if (data == null) {

            throw new RuntimeException(
                    "Google registration verification is invalid or has expired"
            );
        }

        if (data.expiresAt() == null ||
                !data.expiresAt()
                        .isAfter(
                                LocalDateTime.now()
                        )) {

            googleRegistrationStore.remove(
                    registrationToken
            );

            throw new RuntimeException(
                    "Google registration verification has expired. Please sign in with Google again."
            );
        }

        return data;
    }

    // ============================================================
    // VALIDATE X REGISTRATION TOKEN
    // ============================================================

    private XRegistrationData
    validateXRegistrationToken(
            String registrationToken) {

        if (isBlank(registrationToken)) {

            throw new RuntimeException(
                    "Registration verification is required"
            );
        }

        XRegistrationData data =
                xRegistrationStore.get(
                        registrationToken
                );

        if (data == null) {

            throw new RuntimeException(
                    "X registration verification is invalid or has expired"
            );
        }

        if (data.expiresAt() == null ||
                !data.expiresAt()
                        .isAfter(
                                LocalDateTime.now()
                        )) {

            xRegistrationStore.remove(
                    registrationToken
            );

            throw new RuntimeException(
                    "X registration verification has expired. Please sign in with Google again."
            );
        }

        return data;
    }

    // ============================================================
    // CHECK GOOGLE REGISTRATION TOKEN
    // ============================================================

    private boolean isGoogleRegistrationToken(
            String token) {

        return token != null &&
                token.startsWith(
                        GOOGLE_REGISTRATION_TOKEN_PREFIX
                );
    }

    // ============================================================
    // CHECK X REGISTRATION TOKEN
    // ============================================================

    private boolean isXRegistrationToken(
            String token) {

        return token != null &&
                token.startsWith(
                        X_REGISTRATION_TOKEN_PREFIX
                );
    }

    // ============================================================
    // STORE OWNER DATA
    // ============================================================

    private void createStoreOwnerData(
            User user,
            UserRegistrationRequest request) {

        if (isBlank(request.getBusinessName())) {

            throw new RuntimeException(
                    "Business name is required for store owner"
            );
        }

        if (isBlank(request.getBusinessType())) {

            throw new RuntimeException(
                    "Business type is required for store owner"
            );
        }

        if (!isBlank(request.getGstNumber()) &&
                storeDetailsRepository.existsByGstNumber(
                        request.getGstNumber().trim()
                )) {

            throw new RuntimeException(
                    "GST number already registered"
            );
        }

        StoreDetails storeDetails =
                new StoreDetails();

        storeDetails.setUserId(
                user.getUserId()
        );

        storeDetails.setStoreName(
                request.getBusinessName().trim()
        );

        storeDetails.setBusinessType(
                request.getBusinessType().trim()
        );

        if (!isBlank(request.getGstNumber())) {

            storeDetails.setGstNumber(
                    request.getGstNumber().trim()
            );
        }

        storeDetailsRepository.save(
                storeDetails
        );
    }

    // ============================================================
    // DELIVERY PARTNER DATA
    // ============================================================

    private void createDeliveryPartnerData(
            User user,
            UserRegistrationRequest request) {

        if (isBlank(request.getVehicleType())) {

            throw new RuntimeException(
                    "Vehicle type is required"
            );
        }

        if (isBlank(request.getVehicleNumber())) {

            throw new RuntimeException(
                    "Vehicle number is required"
            );
        }

        String vehicleNumber =
                request.getVehicleNumber()
                        .trim()
                        .toUpperCase();

        if (vehicleDetailsRepository
                .existsByVehicleNumber(
                        vehicleNumber
                )) {

            throw new RuntimeException(
                    "Vehicle number already registered"
            );
        }

        if (isBlank(
                request.getDrivingLicenceNumber()
        )) {

            throw new RuntimeException(
                    "Driving licence number is required"
            );
        }

        String licenceNumber =
                request.getDrivingLicenceNumber()
                        .trim()
                        .toUpperCase();

        if (deliveryPartnerRepository
                .existsByDrivingLicenceNumber(
                        licenceNumber
                )) {

            throw new RuntimeException(
                    "Driving licence number already registered"
            );
        }

        VehicleDetails vehicle =
                new VehicleDetails();

        vehicle.setVehicleType(
                request.getVehicleType().trim()
        );

        vehicle.setVehicleNumber(
                vehicleNumber
        );

        VehicleDetails savedVehicle =
                vehicleDetailsRepository.save(
                        vehicle
                );

        DeliveryPartner deliveryPartner =
                new DeliveryPartner();

        deliveryPartner.setUserId(
                user.getUserId()
        );

        deliveryPartner.setVehicleId(
                savedVehicle.getVehicleId()
        );

        deliveryPartner.setDrivingLicenceNumber(
                licenceNumber
        );

        deliveryPartnerRepository.save(
                deliveryPartner
        );
    }

    // ============================================================
    // SAVE ADDRESS
    // ============================================================

    private void saveAddress(
            User user,
            UserRegistrationRequest request) {

        if (isBlank(request.getAddressLine()) &&
                isBlank(request.getCity()) &&
                isBlank(request.getState()) &&
                isBlank(request.getPincode())) {

            return;
        }

        if (isBlank(request.getAddressLine())) {

            throw new RuntimeException(
                    "Address line is required"
            );
        }

        if (isBlank(request.getCity())) {

            throw new RuntimeException(
                    "City is required"
            );
        }

        if (isBlank(request.getState())) {

            throw new RuntimeException(
                    "State is required"
            );
        }

        if (isBlank(request.getPincode())) {

            throw new RuntimeException(
                    "Pincode is required"
            );
        }

        if (request.getLatitude() == null ||
                request.getLongitude() == null) {

            throw new RuntimeException(
                    "Latitude and longitude are required for an address"
            );
        }

        Address address =
                new Address();

        address.setUserId(
                user.getUserId()
        );

        address.setAddressLine(
                request.getAddressLine().trim()
        );

        address.setCity(
                request.getCity().trim()
        );

        address.setState(
                request.getState().trim()
        );

        address.setPincode(
                request.getPincode().trim()
        );

        address.setLatitude(
                request.getLatitude()
        );

        address.setLongitude(
                request.getLongitude()
        );

        address.setIsDefault(
                true
        );

        addressRepository.save(
                address
        );
    }

    // ============================================================
    // CREATE APPLICATION
    // ============================================================

    private void createApplicationRequest(
            User user,
            int applicationType) {

        ApplicationRequest application =
                new ApplicationRequest();

        application.setUserId(
                user.getUserId()
        );

        application.setApplicationType(
                applicationType
        );

        application.setApplicationStatus(
                APPLICATION_PENDING
        );

        application.setSubmittedAt(
                LocalDateTime.now()
        );

        applicationRequestRepository.save(
                application
        );
    }

    // ============================================================
    // PASSWORD LOGIN
    // ============================================================

    public UserResponse loginUser(
            LoginRequest request) {

        if (request == null ||
                isBlank(request.getEmail())) {

            throw new RuntimeException(
                    "Email is required"
            );
        }

        if (isBlank(request.getPassword())) {

            throw new RuntimeException(
                    "Password is required"
            );
        }

        String email =
                request.getEmail()
                        .trim()
                        .toLowerCase();

        User user =
                userRepository
                        .findByEmail(email)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "User is not registered"
                                )
                        );

        if (!userRepository.verifyPassword(
                user.getUserId(),
                request.getPassword()
        )) {

            throw new RuntimeException(
                    "Invalid email or password"
            );
        }

        checkAccountStatus(
                user
        );

        return convertToResponse(
                user,
                true
        );
    }

    // ============================================================
    // SEND LOGIN OTP
    // ============================================================

    public String sendLoginOtp(
            LoginOtpRequest request) {

        if (request == null ||
                isBlank(request.getLogin())) {

            throw new RuntimeException(
                    "Email or mobile number is required"
            );
        }

        if (isBlank(request.getPassword())) {

            throw new RuntimeException(
                    "Password is required"
            );
        }

        String login =
                request.getLogin()
                        .trim();

        User user =
                findUserByLogin(
                        login
                );

        if (!userRepository.verifyPassword(
                user.getUserId(),
                request.getPassword()
        )) {

            throw new RuntimeException(
                    "Invalid email/mobile number or password"
            );
        }

        checkAccountStatus(
                user
        );

        if (EMAIL_PATTERN.matcher(
                login
        ).matches()) {

            return sendEmailLoginOtp(
                    user
            );
        }

        if (PHONE_PATTERN.matcher(
                normalizePhoneNumber(login)
        ).matches()) {

            return sendMobileLoginOtp(
                    user
            );
        }

        throw new RuntimeException(
                "Please enter a valid email address or mobile number"
        );
    }

    // ============================================================
    // SEND MOBILE LOGIN OTP
    // ============================================================

    private String sendMobileLoginOtp(
            User user) {

        if (isBlank(user.getPhone())) {

            throw new RuntimeException(
                    "No registered mobile number is available for this account"
            );
        }

        try {

            String verificationId =
                    otpDeliveryService.sendSmsOtp(
                            user.getPhone()
                    );

            String key =
                    createOtpKey(
                            user.getUserId(),
                            "SMS"
                    );

            LocalDateTime expiresAt =
                    LocalDateTime.now()
                            .plusMinutes(
                                    OTP_EXPIRY_MINUTES
                            );

            otpStore.put(
                    key,
                    new OtpData(
                            null,
                            verificationId,
                            expiresAt
                    )
            );

            return "OTP sent successfully to your registered mobile number by SMS";

        } catch (Exception exception) {

            throw new RuntimeException(
                    "Unable to send SMS OTP"
            );
        }
    }

    // ============================================================
    // SEND EMAIL LOGIN OTP
    // ============================================================

    private String sendEmailLoginOtp(
            User user) {

        String secret =
                totpService.generateSecret();

        String otp =
                totpService.generateOtp(
                        secret
                );

        LocalDateTime expiresAt =
                LocalDateTime.now()
                        .plusMinutes(
                                OTP_EXPIRY_MINUTES
                        );

        String key =
                createOtpKey(
                        user.getUserId(),
                        "EMAIL"
                );

        otpStore.put(
                key,
                new OtpData(
                        secret,
                        null,
                        expiresAt
                )
        );

        try {

            emailService.sendOtpEmail(
                    user.getEmail(),
                    otp
            );

        } catch (Exception exception) {

            otpStore.remove(
                    key
            );

            throw new RuntimeException(
                    "Unable to send OTP email"
            );
        }

        return "OTP sent successfully to your registered email";
    }

    // ============================================================
    // VERIFY LOGIN OTP
    // ============================================================

    public UserResponse verifyLoginOtp(
            VerifyOtpRequest request) {

        if (request == null ||
                isBlank(request.getLogin())) {

            throw new RuntimeException(
                    "Email or mobile number is required"
            );
        }

        if (isBlank(request.getOtp())) {

            throw new RuntimeException(
                    "OTP is required"
            );
        }

        String login =
                request.getLogin()
                        .trim();

        User user =
                findUserByLogin(
                        login
                );

        checkAccountStatus(
                user
        );

        String channel;

        if (EMAIL_PATTERN.matcher(
                login
        ).matches()) {

            channel = "EMAIL";

        } else if (PHONE_PATTERN.matcher(
                normalizePhoneNumber(login)
        ).matches()) {

            channel = "SMS";

        } else {

            throw new RuntimeException(
                    "Please enter a valid email address or mobile number"
            );
        }

        String key =
                createOtpKey(
                        user.getUserId(),
                        channel
                );

        OtpData otpData =
                otpStore.get(
                        key
                );

        if (otpData == null) {

            throw new RuntimeException(
                    "OTP not found. Please request a new OTP"
            );
        }

        if (otpData.expiresAt() == null ||
                !otpData.expiresAt()
                        .isAfter(
                                LocalDateTime.now()
                        )) {

            otpStore.remove(
                    key
            );

            throw new RuntimeException(
                    "OTP has expired. Please request a new OTP"
            );
        }

        boolean verified;

        if (channel.equals("EMAIL")) {

            if (otpData.totpSecret() == null ||
                    otpData.totpSecret().isBlank()) {

                throw new RuntimeException(
                        "Invalid email OTP session"
                );
            }

            verified =
                    totpService.verifyOtp(
                            otpData.totpSecret(),
                            request.getOtp().trim()
                    );

        } else {

            if (otpData.verificationId() == null ||
                    otpData.verificationId().isBlank()) {

                throw new RuntimeException(
                        "Invalid mobile OTP session"
                );
            }

            verified =
                    otpDeliveryService.verifyOtp(
                            otpData.verificationId(),
                            request.getOtp().trim()
                    );
        }

        if (!verified) {

            throw new RuntimeException(
                    "Invalid OTP"
            );
        }

        otpStore.remove(
                key
        );

        return convertToResponse(
                user,
                true
        );
    }

    // ============================================================
    // CHANGE PASSWORD
    // ============================================================

    @Transactional
    public void changePassword(
            String token,
            ChangePasswordRequest request) {

        // ========================================================
        // REQUEST VALIDATION
        // ========================================================

        if (request == null) {

            throw new RuntimeException(
                    "Password change request is required"
            );
        }

        if (isBlank(
                request.getCurrentPassword()
        )) {

            throw new RuntimeException(
                    "Current password is required"
            );
        }

        if (isBlank(
                request.getNewPassword()
        )) {

            throw new RuntimeException(
                    "New password is required"
            );
        }

        // ========================================================
        // TOKEN VALIDATION
        // ========================================================

        if (isBlank(token)) {

            throw new RuntimeException(
                    "Authentication token is required"
            );
        }

        if (!jwtService.isTokenValid(token)) {

            throw new RuntimeException(
                    "Invalid or expired authentication token"
            );
        }

        // ========================================================
        // EXTRACT USER ID FROM JWT
        // ========================================================

        Long userId =
                jwtService.extractUserId(
                        token
                );

        // ========================================================
        // FIND USER
        // ========================================================

        User user =
                userRepository
                        .findById(
                                userId
                        )
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "User account not found"
                                )
                        );

        // ========================================================
        // CHECK ACCOUNT STATUS
        // ========================================================

        checkAccountStatus(
                user
        );

        // ========================================================
        // VERIFY CURRENT PASSWORD
        // ========================================================

        if (!userRepository.verifyPassword(
                user.getUserId(),
                request.getCurrentPassword()
        )) {

            throw new RuntimeException(
                    "Current password is incorrect"
            );
        }

        // ========================================================
        // PREVENT SAME PASSWORD
        // ========================================================

        if (userRepository.verifyPassword(
                user.getUserId(),
                request.getNewPassword()
        )) {

            throw new RuntimeException(
                    "New password must be different from the current password"
            );
        }

        // ========================================================
        // HASH NEW PASSWORD
        // ========================================================

        String newPasswordHash =
                userRepository.hashPassword(
                        request.getNewPassword()
                );

        // ========================================================
        // UPDATE USERS PASSWORD
        // ========================================================

        user.setPassword(
                newPasswordHash
        );

        userRepository.save(
                user
        );

        // ========================================================
        // SAVE PASSWORD HISTORY
        // ========================================================

        UserPasswordHistory passwordHistory =
                new UserPasswordHistory();

        passwordHistory.setUserId(
                user.getUserId()
        );

        passwordHistory.setPasswordHash(
                newPasswordHash
        );

        passwordHistory.setChangedAt(
                LocalDateTime.now()
        );

        userPasswordHistoryRepository.save(
                passwordHistory
        );
    }

    // ============================================================
    // FIND USER BY EMAIL OR PHONE
    // ============================================================

    private User findUserByLogin(
            String login) {

        if (login == null ||
                login.trim().isEmpty()) {

            throw new RuntimeException(
                    "Email or mobile number is required"
            );
        }

        String normalized =
                login.trim();

        if (EMAIL_PATTERN.matcher(
                normalized
        ).matches()) {

            return userRepository
                    .findByEmail(
                            normalized.toLowerCase()
                    )
                    .orElseThrow(() ->
                            new RuntimeException(
                                    "User is not registered"
                            )
                    );
        }

        String normalizedPhone =
                normalizePhoneNumber(
                        normalized
                );

        if (PHONE_PATTERN.matcher(
                normalizedPhone
        ).matches()) {

            return userRepository
                    .findByPhone(
                            normalizedPhone
                    )
                    .orElseThrow(() ->
                            new RuntimeException(
                                    "User is not registered"
                            )
                    );
        }

        throw new RuntimeException(
                "Please enter a valid email address or mobile number"
        );
    }

    // ============================================================
    // ACCOUNT STATUS CHECK
    // ============================================================

    private void checkAccountStatus(
            User user) {

        Integer status =
                user.getAccountStatus();

        if (status == null) {

            throw new RuntimeException(
                    "Account status is not configured"
            );
        }

        if (status == ACCOUNT_ACTIVE) {
            return;
        }

        if (status == ACCOUNT_BLOCKED) {

            throw new RuntimeException(
                    "Your account has been blocked"
            );
        }

        if (status == ACCOUNT_INACTIVE) {

            ApplicationRequest application =
                    getLatestApplication(
                            user.getUserId()
                    );

            if (application == null) {

                throw new RuntimeException(
                        "Your account is inactive. Please contact admin"
                );
            }

            Integer applicationStatus =
                    application.getApplicationStatus();

            if (applicationStatus ==
                    APPLICATION_PENDING) {

                throw new RuntimeException(
                        "Your application is waiting for admin approval. You will be able to log in after your application is approved."
                );
            }

            if (applicationStatus ==
                    APPLICATION_REJECTED) {

                throw new RuntimeException(
                        "Your application has been rejected by admin"
                );
            }

            if (applicationStatus ==
                    APPLICATION_APPROVED) {

                throw new RuntimeException(
                        "Your application has been approved, but your account is not active yet. Please contact admin."
                );
            }

            throw new RuntimeException(
                    "Your account is inactive"
            );
        }

        throw new RuntimeException(
                "Your account status is invalid"
        );
    }

    // ============================================================
    // GET LATEST APPLICATION
    // ============================================================

    private ApplicationRequest getLatestApplication(
            Long userId) {

        return applicationRequestRepository
                .findByUserId(
                        userId
                )
                .stream()
                .sorted(
                        (a, b) -> {

                            LocalDateTime aTime =
                                    a.getSubmittedAt();

                            LocalDateTime bTime =
                                    b.getSubmittedAt();

                            if (aTime == null &&
                                    bTime == null) {

                                return 0;
                            }

                            if (aTime == null) {
                                return 1;
                            }

                            if (bTime == null) {
                                return -1;
                            }

                            return bTime.compareTo(
                                    aTime
                            );
                        }
                )
                .findFirst()
                .orElse(null);
    }

    // ============================================================
    // ROLE CODE
    // ============================================================

    private int getRoleCode(
            String role) {

        if (isBlank(role)) {

            throw new RuntimeException(
                    "Role is required"
            );
        }

        String roleName =
                role.trim()
                        .toUpperCase();

        return switch (roleName) {

            case "CUSTOMER" ->
                    ROLE_CUSTOMER;

            case "STORE_OWNER" ->
                    ROLE_STORE_OWNER;

            case "DELIVERY_PARTNER" ->
                    ROLE_DELIVERY_PARTNER;

            default ->
                    throw new RuntimeException(
                            "Invalid role"
                    );
        };
    }

    // ============================================================
    // EXTRACT SESSION ID FROM JWT
    // ============================================================

    public String extractSessionIdFromToken(
            String token) {

        return jwtService.extractSessionId(
                token
        );
    }

    // ============================================================
    // CONVERT USER TO RESPONSE
    // ============================================================

    private UserResponse convertToResponse(
            User user,
            boolean includeToken) {

        Role role =
                roleRepository
                        .findByUserId(
                                user.getUserId()
                        )
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "User role not found"
                                )
                        );

        String roleName =
                getRoleName(
                        role.getRole()
                );

        UserResponse response =
                new UserResponse();

        response.setUserId(
                user.getUserId()
        );

        response.setEmail(
                user.getEmail()
        );

        response.setRole(
                roleName
        );

        response.setAccountStatus(
                getAccountStatusName(
                        user.getAccountStatus()
                )
        );

        response.setCreatedAt(
                user.getCreatedAt()
        );

        response.setUpdatedAt(
                user.getUpdatedAt()
        );

        // ========================================================
        // PASSWORD ROTATION
        // ========================================================

        response.setPasswordChangeRequired(
                passwordRotationService.isPasswordExpired(
                        user.getUserId()
                )
        );

        if (includeToken) {

            UserSession session =
                    userSessionService.createSession(
                            user.getUserId()
                    );

            String token =
                    jwtService.generateToken(
                            user.getUserId(),
                            user.getEmail(),
                            roleName,
                            session.getSessionId()
                    );

            response.setToken(
                    token
            );
        }

        return response;
    }

    // ============================================================
    // ROLE NAME
    // ============================================================

    private String getRoleName(
            Integer role) {

        if (role == null) {
            return "UNKNOWN";
        }

        return switch (role) {

            case ROLE_CUSTOMER ->
                    "CUSTOMER";

            case ROLE_STORE_OWNER ->
                    "STORE_OWNER";

            case ROLE_DELIVERY_PARTNER ->
                    "DELIVERY_PARTNER";

            case ROLE_ADMIN ->
                    "ADMIN";

            default ->
                    "UNKNOWN";
        };
    }

    // ============================================================
    // ACCOUNT STATUS NAME
    // ============================================================

    private String getAccountStatusName(
            Integer status) {

        if (status == null) {
            return "UNKNOWN";
        }

        return switch (status) {

            case ACCOUNT_ACTIVE ->
                    "ACTIVE";

            case ACCOUNT_INACTIVE ->
                    "INACTIVE";

            case ACCOUNT_BLOCKED ->
                    "BLOCKED";

            default ->
                    "UNKNOWN";
        };
    }

    // ============================================================
    // NAME SPLITTER
    // ============================================================

    private String[] splitName(
            String fullName) {

        if (isBlank(fullName)) {

            return new String[]{
                    "",
                    ""
            };
        }

        String cleaned =
                fullName.trim()
                        .replaceAll(
                                "\\s+",
                                " "
                        );

        int firstSpace =
                cleaned.indexOf(
                        " "
                );

        if (firstSpace == -1) {

            return new String[]{
                    cleaned,
                    ""
            };
        }

        String firstName =
                cleaned.substring(
                        0,
                        firstSpace
                );

        String lastName =
                cleaned.substring(
                        firstSpace + 1
                );

        return new String[]{
                firstName,
                lastName
        };
    }

    // ============================================================
    // NORMALIZE EMAIL
    // ============================================================

    private String normalizeEmail(
            String email) {

        if (isBlank(email)) {
            return null;
        }

        return email.trim()
                .toLowerCase();
    }

    // ============================================================
    // NORMALIZE PHONE
    // ============================================================

    private String normalizePhone(
            String phone) {

        if (isBlank(phone)) {
            return null;
        }

        return normalizePhoneNumber(
                phone
        );
    }

    // ============================================================
    // NORMALIZE PHONE NUMBER
    // ============================================================

    private String normalizePhoneNumber(
            String phone) {

        if (phone == null ||
                phone.trim().isEmpty()) {

            return "";
        }

        String cleaned =
                phone.trim()
                        .replaceAll(
                                "[^0-9]",
                                ""
                        );

        if (cleaned.startsWith("91") &&
                cleaned.length() == 12) {

            cleaned =
                    cleaned.substring(
                            2
                    );
        }

        return cleaned;
    }

    // ============================================================
    // BLANK CHECK
    // ============================================================

    private boolean isBlank(
            String value) {

        return value == null ||
                value.trim().isEmpty();
    }

    // ============================================================
    // OTP KEY
    // ============================================================

    private String createOtpKey(
            Long userId,
            String channel) {

        return userId +
                ":" +
                channel;
    }

    // ============================================================
    // TEMPORARY OTP DATA
    // ============================================================

    private record OtpData(
            String totpSecret,
            String verificationId,
            LocalDateTime expiresAt
    ) {
    }

    // ============================================================
    // TEMPORARY GOOGLE REGISTRATION DATA
    // ============================================================

    private record GoogleRegistrationData(
            String googleId,
            String email,
            String name,
            String givenName,
            String familyName,
            String picture,
            LocalDateTime expiresAt
    ) {
    }
}