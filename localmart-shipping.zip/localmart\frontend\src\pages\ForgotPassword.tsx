import React from "react";
import "./ForgotPassword.css";

interface ForgotPasswordProps {
    onBackToLogin: () => void;
}

const ForgotPassword: React.FC<ForgotPasswordProps> = ({
                                                           onBackToLogin
                                                       }) => {
    return (
        <div className="forgot-password">

            <h1>Forgot Password</h1>

            <p className="forgot-password-description">
                Enter your email or mobile number to reset your password.
            </p>

            <div className="forgot-password-form">

                <label className="forgot-password-label">
                    Email or mobile number
                </label>

                <input
                    type="text"
                    className="forgot-password-input"
                    placeholder="Email or mobile number"
                />

                <button
                    type="button"
                    className="forgot-password-button"
                >
                    Send OTP
                </button>

                <button
                    type="button"
                    onClick={onBackToLogin}
                    className="forgot-password-button"
                >
                    Login page
                </button>

            </div>

        </div>
    );
};

export default ForgotPassword;