    package com.localmart.localmartbackend.entity;

    import jakarta.persistence.*;

    @Entity
    @Table(
            name = "cart_items",
            uniqueConstraints = {
                    @UniqueConstraint(
                            name = "uq_cart_product",
                            columnNames = {"cart_id", "product_id"}
                    )
            }
    )
    public class CartItem {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Column(name = "cart_item_id")
        private Long cartItemId;

        @Column(name = "cart_id", nullable = false)
        private Long cartId;

        @Column(name = "product_id", nullable = false)
        private Long productId;

        @Column(name = "quantity", nullable = false)
        private Integer quantity;

        public CartItem() {
        }

        public Long getCartItemId() {
            return cartItemId;
        }

        public void setCartItemId(Long cartItemId) {
            this.cartItemId = cartItemId;
        }

        public Long getCartId() {
            return cartId;
        }

        public void setCartId(Long cartId) {
            this.cartId = cartId;
        }

        public Long getProductId() {
            return productId;
        }

        public void setProductId(Long productId) {
            this.productId = productId;
        }

        public Integer getQuantity() {
            return quantity;
        }

        public void setQuantity(Integer quantity) {
            this.quantity = quantity;
        }
    }