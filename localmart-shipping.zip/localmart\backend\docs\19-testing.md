# LocalMart — Testing

## 1. Overview

Testing is used to verify that LocalMart behaves correctly under valid, invalid, expected, and failure conditions.

LocalMart contains several independent layers:

```text
Frontend
    |
    v
REST API
    |
    v
Controller
    |
    v
Service
    |
    v
Repository
    |
    v
PostgreSQL
```

It also communicates with external systems:

```text
Google
X
Message Central
SMTP
Razorpay
OSRM
Geocoding Provider
```

Testing therefore needs to cover more than individual Java methods.

The testing strategy can be viewed as:

```text
Unit Tests
    ↓
Integration Tests
    ↓
API / Controller Tests
    ↓
Security Tests
    ↓
Database Tests
    ↓
External Integration Tests
    ↓
End-to-End Tests
```

---

# 2. Testing Goals

The main goals of LocalMart testing are:

* Verify business logic
* Verify validation rules
* Verify authentication
* Verify authorization
* Verify database operations
* Verify API responses
* Verify order and payment behavior
* Verify delivery workflows
* Verify external integrations
* Detect regressions when features change
* Ensure invalid requests cannot corrupt application state

---

# 3. Current Test Structure

The backend currently contains:

```text
src/
└── test/
    └── java/
        └── com/
            └── localmart/
                └── localmartbackend/
                    ├── LocalmartBackendApplicationTests.java
                    │
                    └── service/
                        └── TotpServiceTest.java
```

This establishes the project's automated-test structure.

The project therefore already contains:

```text
Application-level test
Service-level test
```

Additional tests can be added as individual modules mature.

---

# 4. Testing Pyramid

A useful model for LocalMart is the testing pyramid:

```text
                /\
               /  \
              / E2E\
             /------\
            / API /  \
           /Integration\
          /--------------\
         /  Unit Tests    \
        /------------------\
```

The lower layers generally contain more tests and execute faster.

The upper layers test larger portions of the system but are usually slower and more dependent on infrastructure.

---

# 5. Unit Testing

A unit test verifies a small piece of application logic independently.

For example:

```text
TotpService
```

can be tested without running the complete LocalMart application.

Conceptually:

```text
Input
  |
  v
One Service / Method
  |
  v
Expected Result
```

A unit test should focus on the behavior of the component being tested.

---

# 6. TOTP Service Test

LocalMart currently contains:

```text
TotpServiceTest.java
```

This test is associated with:

```text
TotpService.java
```

The purpose is to verify TOTP-related behavior independently.

The relationship is:

```text
TotpServiceTest
       |
       v
TotpService
       |
       v
TOTP Library
```

This is an example of service-level unit testing.

---

# 7. What a Unit Test Should Verify

For a service such as `TotpService`, useful cases include:

```text
Valid TOTP
Invalid TOTP
Expired time window
Incorrect secret
Generated secret
Verification behavior
```

The exact cases should correspond to the implementation.

The important principle is that both successful and failure scenarios should be tested.

---

# 8. Positive and Negative Tests

A complete test suite should not only test successful operations.

### Positive test

```text
Valid input
     ↓
Expected success
```

### Negative test

```text
Invalid input
     ↓
Expected failure
```

For example:

```text
Valid OTP
    → verification succeeds

Invalid OTP
    → verification fails
```

Both are important.

---

# 9. Boundary Testing

Boundary testing checks values at or near allowed limits.

For LocalMart coordinates:

```text
Latitude:
-90
+90
```

are valid boundaries.

Values such as:

```text
-90.1
90.1
```

should be rejected.

Similarly:

```text
Longitude:
-180
+180
```

represent the valid boundaries.

Testing these boundaries helps detect off-by-one and range-validation errors.

---

# 10. Validation Testing

Validation rules should be tested explicitly.

Examples include:

```text
Invalid email
Invalid phone
Invalid PIN
Missing required field
Invalid coordinates
Invalid quantity
Invalid identifier
```

Conceptually:

```text
Test Input
    |
    v
Validation
    |
 +--+--+
 |     |
Valid Invalid
 |       |
Pass    Reject
```

---

# 11. Service Testing

Each major business service can have its own test cases.

Relevant LocalMart services include:

```text
UserService
CartService
OrderService
ProductService
StoreService
CustomerService
CustomerAddressService
DeliveryPartnerLocationService
StoreOwnerService
TotpService
```

A service test should verify the business rules implemented by that service.

---

# 12. UserService Testing

Important scenarios include:

```text
Successful registration
Duplicate email
Duplicate phone
Invalid registration token
Invalid role
Password hashing
Successful login
Invalid password
Blocked account
Inactive account
OTP verification
Google authentication
X authentication
Session creation
```

A simplified test matrix:

| Scenario           | Expected result       |
| ------------------ | --------------------- |
| Valid registration | User created          |
| Duplicate email    | Registration rejected |
| Duplicate phone    | Registration rejected |
| Invalid role       | Registration rejected |
| Valid password     | Login succeeds        |
| Invalid password   | Login rejected        |
| Blocked account    | Login rejected        |
| Invalid OTP        | Verification rejected |

---

# 13. Registration Testing

Registration contains multiple business rules.

The test flow can be:

```text
Registration Request
       |
       v
Input Validation
       |
       v
Verification Token
       |
       v
Duplicate Check
       |
       v
Role Validation
       |
       v
Password Hashing
       |
       v
User Creation
```

Each important branch should have corresponding tests.

---

# 14. OTP Testing

OTP functionality should test:

```text
Correct OTP
Incorrect OTP
Expired OTP
Missing OTP
Wrong identifier
Repeated verification
Invalid verification context
```

Conceptually:

```text
                 OTP
                  |
        +---------+---------+
        |         |         |
      Valid    Invalid    Expired
        |         |         |
      Pass      Reject    Reject
```

---

# 15. Authentication Testing

Authentication testing should cover all supported authentication mechanisms.

LocalMart includes:

```text
Password authentication
Email OTP
SMS OTP
Google authentication
X authentication
TOTP
JWT sessions
```

A high-level matrix is:

| Authentication method | Valid case           | Invalid case           |
| --------------------- | -------------------- | ---------------------- |
| Password              | Correct password     | Incorrect password     |
| Email OTP             | Correct OTP          | Invalid/expired OTP    |
| SMS OTP               | Correct OTP          | Invalid OTP            |
| Google                | Valid credential     | Invalid credential     |
| X                     | Valid authentication | Invalid authentication |
| TOTP                  | Correct code         | Incorrect code         |
| JWT                   | Valid session/token  | Invalid/expired token  |

---

# 16. Authorization Testing

Authentication and authorization must be tested separately.

Authentication:

```text
"Who are you?"
```

Authorization:

```text
"Are you allowed to do this?"
```

For LocalMart:

```text
CUSTOMER
STORE_OWNER
DELIVERY_PARTNER
ADMIN
```

each has different responsibilities.

Example:

```text
CUSTOMER
   |
   X
Admin operation
```

The test should verify that the request is rejected.

---

# 17. Role-Based Testing

A role-access matrix can be used:

| Operation           | Customer |         Store Owner |    Delivery Partner | Admin |
| ------------------- | -------: | ------------------: | ------------------: | ----: |
| Browse products     |        ✓ | Depends on endpoint | Depends on endpoint |     ✓ |
| Manage own cart     |        ✓ |                   — |                   — |     — |
| Manage store        |        — |                   ✓ |                   — |     ✓ |
| Delivery operations |        — |                   — |                   ✓ |     ✓ |
| Admin approval      |        — |                   — |                   — |     ✓ |

The exact endpoint authorization is determined by the current `SecurityConfig` and controller/service implementation.

Tests should verify the actual authorization rules.

---

# 18. JWT Testing

JWT-related testing should cover:

```text
Valid JWT
Expired JWT
Malformed JWT
Invalid signature
Missing JWT
Invalid session
```

The flow is:

```text
HTTP Request
     |
     v
JwtAuthenticationFilter
     |
     v
JWT validation
     |
 +---+---+
 |       |
Valid   Invalid
 |       |
 v       v
Continue Reject
```

---

# 19. Session Testing

LocalMart maintains user sessions.

Important scenarios include:

```text
Session creation
Session validation
Session logout
Invalid session
Expired session
Token/session mismatch
```

Logout should invalidate the appropriate session according to the implementation.

---

# 20. Customer Address Testing

`CustomerAddressService` contains important validation and business rules.

Tests should cover:

```text
Get addresses
Add address
Update address
Delete address
Set default address
Invalid PIN
Invalid latitude
Invalid longitude
Non-customer access
Address ownership
Default-address behavior
```

For example:

```text
Latitude = 91
     ↓
Validation
     ↓
Reject
```

---

# 21. Address Ownership Testing

A particularly important security test is:

```text
Customer A
    |
    X
Attempt to modify Customer B's address
```

Expected behavior:

```text
Request rejected
```

This verifies that resource IDs alone do not grant access.

---

# 22. Store Testing

Store functionality should be tested for:

```text
Store creation
Store retrieval
Store update
Store ownership
Invalid store ID
Unauthorized store modification
Store status
Store/customer relationship
```

The important business rule is that a store owner should only manage stores they are authorized to manage.

---

# 23. Product Testing

Product tests should cover:

```text
Create product
Retrieve product
Update product
Delete product
Invalid product ID
Invalid price
Invalid quantity
Store association
Store-owner authorization
```

A product should not be associated with a nonexistent or unauthorized store.

---

# 24. Cart Testing

Cart testing should verify:

```text
Create/get cart
Add item
Update quantity
Remove item
Empty cart
Invalid product
Invalid quantity
Customer ownership
```

Example:

```text
Customer A
    |
    v
Cart A

Customer B
    |
    X
Access Cart A
```

The second request should be rejected.

---

# 25. Order Testing

Orders are one of the most important areas to test.

Important cases include:

```text
Valid order
Invalid customer
Invalid address
Invalid store
Invalid cart
Invalid product
Invalid quantity
Incorrect store/product relationship
Order creation failure
Payment failure
Order status transitions
```

The objective is to ensure that invalid checkout requests cannot create inconsistent orders.

---

# 26. Order State Testing

Order state changes should be tested as transitions.

Conceptually:

```text
Current State
      +
Requested Action
      |
      v
Transition Rule
      |
 +----+----+
 |         |
Allowed   Invalid
 |           |
Update     Reject
```

Testing state transitions is especially important because an invalid transition can create inconsistent business state.

---

# 27. Payment Testing

Payment testing should cover:

```text
Order amount
Payment creation
Payment success
Payment failure
Payment status
Invalid order association
External payment failure
Repeated payment attempts
```

The backend should calculate trusted amounts rather than accepting arbitrary payment amounts from the client.

---

# 28. Idempotency Testing

Payment and order-related operations can potentially receive duplicate requests.

For example:

```text
Request 1
    ↓
Create Order

Request 2
    ↓
Same operation repeated
```

Testing should verify that retrying an operation does not unintentionally create duplicate business records where the operation is intended to be idempotent.

This is especially important for payment and checkout flows.

---

# 29. Delivery Testing

LocalMart's delivery lifecycle is:

```text
READY_FOR_PICKUP
        ↓
ACCEPTED
        ↓
PICKED_UP
        ↓
OUT_FOR_DELIVERY
        ↓
DELIVERED
```

Tests should verify valid transitions.

Example:

```text
READY_FOR_PICKUP
       ↓
ACCEPTED
```

should be accepted.

An invalid transition should be rejected according to the implemented business rules.

---

# 30. Delivery Partner Testing

Delivery-partner tests should cover:

```text
Partner authentication
Partner availability
Available deliveries
Accept delivery
Current deliveries
Completed deliveries
Status update
Location update
Profile operations
Vehicle information
```

Role authorization should also be tested.

---

# 31. Concurrent Delivery Acceptance

A particularly important scenario is simultaneous acceptance.

Imagine:

```text
Partner A ──┐
             ├──> Delivery 101
Partner B ──┘
```

Both requests arrive at nearly the same time.

The system should ensure that the delivery is not incorrectly assigned to both partners.

A concurrency test should verify that only the permitted request succeeds.

This is a business-integrity test rather than ordinary input validation.

---

# 32. Location Testing

Location functionality involves multiple components:

```text
Browser Geolocation API
Geocoding service
OSRM
LocalMart database
```

Tests should cover:

```text
Valid coordinates
Invalid coordinates
Missing location
Geocoding failure
Routing failure
Unavailable external service
Delivery-distance calculation
```

For example:

```text
Latitude = 100
     ↓
Coordinate validation
     ↓
Reject
```

---

# 33. External Integration Testing

External services should not necessarily be called during every unit test.

Examples:

```text
Google
X
Message Central
Razorpay
OSRM
Geocoding provider
SMTP
```

Instead, integration-specific tests can verify communication separately.

Conceptually:

```text
Application
     |
     v
Integration Service
     |
     v
External Provider
```

This separates business-logic testing from provider availability.

---

# 34. Mocking External Services

When appropriate, external services can be replaced with test doubles.

For example:

```text
Production:

LocalMart
    ↓
Razorpay


Test:

LocalMart
    ↓
Mock Razorpay
```

This makes tests:

* Faster
* More deterministic
* Less dependent on internet connectivity
* Less dependent on external credentials
* Less expensive

---

# 35. Integration Testing

Integration testing verifies that multiple application components work together.

For example:

```text
Controller
    ↓
Service
    ↓
Repository
    ↓
Database
```

Unlike a unit test, the test covers a larger portion of the application.

Example:

```text
POST /api/...
      ↓
Controller
      ↓
Service
      ↓
Repository
      ↓
Database
```

The test verifies the complete interaction.

---

# 36. Repository Testing

Repositories should be tested to verify persistence behavior.

Examples:

```text
Save entity
Find entity
Find by user
Find by store
Update entity
Delete entity
```

Important cases include:

```text
Existing record
Missing record
Duplicate constraint
Relationship behavior
```

Repository testing is particularly useful for custom query methods.

---

# 37. Database Integration Testing

Database tests verify that the application's JPA/Hibernate mappings correctly communicate with PostgreSQL.

The architecture is:

```text
Test
 |
 v
JPA Entity
 |
 v
Hibernate
 |
 v
PostgreSQL
```

This can reveal problems that pure unit tests cannot detect.

For example:

```text
Incorrect column mapping
Incorrect relationship
Invalid query
Constraint violation
Schema mismatch
```

---

# 38. Entity Relationship Testing

LocalMart contains relationships between entities such as:

```text
User
  |
  +---- Role
  |
  +---- Address
  |
  +---- Store
  |
  +---- Cart
  |
  +---- Order
  |
  +---- Session
```

Tests should verify that these relationships behave as intended.

---

# 39. API Testing

REST endpoints can be tested independently of the browser.

A typical API test is:

```text
HTTP Request
      |
      v
Controller
      |
      v
Application
      |
      v
HTTP Response
```

The test can verify:

```text
Status code
Response body
Validation
Authentication
Authorization
Error response
```

---

# 40. API Negative Testing

Every important endpoint should have negative tests.

For example:

```text
Valid request
Invalid request
Missing field
Invalid ID
Unauthorized request
Forbidden request
Nonexistent resource
Invalid state
```

This is important because API security cannot be verified by testing successful requests alone.

---

# 41. Error Response Testing

LocalMart contains:

```text
GlobalExceptionHandler.java
```

Error tests should verify that exceptions are converted into appropriate HTTP responses.

Conceptually:

```text
Service
   |
   X
Exception
   |
   v
GlobalExceptionHandler
   |
   v
HTTP Error Response
```

Tests should verify both:

```text
HTTP status
Response body
```

where the implementation defines a structured error response.

---

# 42. Security Testing

Security testing should verify that users cannot bypass application security simply by manually constructing HTTP requests.

Examples:

```text
No JWT
Invalid JWT
Expired JWT
Wrong role
Wrong resource owner
Blocked account
Unauthorized admin operation
```

The important principle is:

> **Security tests should test the backend directly, not only the frontend behavior.**

---

# 43. Manual API Testing

LocalMart can also be tested manually using HTTP clients.

The project contains:

```text
controller/test.http
```

and IntelliJ HTTP request files under:

```text
.idea/httpRequests/
```

These can be useful for manually testing REST endpoints.

Typical flow:

```text
Send HTTP Request
       |
       v
Observe Status
       |
       v
Observe JSON Response
       |
       v
Inspect Database / Logs
```

Manual API testing is useful during development even when automated tests are not yet available for a feature.

---

# 44. End-to-End Testing

End-to-end testing verifies a complete user workflow.

For example, a customer purchase:

```text
Login
  ↓
Browse stores
  ↓
Browse products
  ↓
Add product to cart
  ↓
Select address
  ↓
Calculate delivery fee
  ↓
Checkout
  ↓
Payment
  ↓
Order created
  ↓
Delivery
```

An E2E test verifies the system from the user's perspective.

---

# 45. Customer E2E Flow

A representative customer test can be:

```text
Customer
   |
   v
Login
   |
   v
Stores
   |
   v
Products
   |
   v
Cart
   |
   v
Address
   |
   v
Checkout
   |
   v
Payment
   |
   v
Order
```

Each stage should produce the expected result before continuing.

---

# 46. Delivery E2E Flow

A delivery workflow can be tested as:

```text
Customer places order
        |
        v
Order ready
        |
        v
Delivery partner sees delivery
        |
        v
Accept
        |
        v
Pick up
        |
        v
Out for delivery
        |
        v
Delivered
```

This tests interactions between multiple roles and modules.

---

# 47. Testing Authentication End-to-End

A complete authentication workflow can be tested as:

```text
Registration
     ↓
OTP request
     ↓
OTP verification
     ↓
Registration completion
     ↓
Login
     ↓
JWT
     ↓
Protected API
     ↓
Logout
     ↓
Protected API rejected
```

This verifies that authentication is not merely working at one endpoint but across the entire session lifecycle.

---

# 48. Regression Testing

Whenever an existing feature is changed, previously working functionality should be tested again.

For example:

```text
Add rate limiting
      ↓
Test authentication
      ↓
Test cart
      ↓
Test orders
      ↓
Test delivery
```

This is especially important in LocalMart because security filters, authentication, orders, and payment processing are interconnected.

---

# 49. Regression Risk Example

Suppose a change is made to:

```text
SecurityConfig
```

It can potentially affect:

```text
Login
OTP
Google login
X login
Cart
Orders
Delivery
Admin endpoints
```

Therefore testing only the feature that was changed may not be sufficient.

The affected request paths should also be tested.

---

# 50. Test Data

Testing should use dedicated test data rather than accidentally modifying important development or production data.

A test environment can contain:

```text
Test Users
Test Stores
Test Products
Test Orders
Test Addresses
Test Delivery Partners
```

This keeps testing isolated from real application data.

---

# 51. Test Isolation

Tests should ideally avoid depending on the execution order of other tests.

Bad pattern:

```text
Test A creates user
       ↓
Test B assumes user exists
```

Better:

```text
Test A
  ↓
Own setup

Test B
  ↓
Own setup
```

This makes tests more predictable.

---

# 52. Deterministic Tests

A good automated test should produce the same result when run repeatedly under the same conditions.

Avoid unnecessary dependence on:

```text
Current time
Random values
External network
External provider availability
Existing database state
Execution order
```

When such dependencies are necessary, they should be controlled or isolated.

---

# 53. Testing Time-Based Features

LocalMart contains time-dependent functionality:

```text
OTP expiry
TOTP
Sessions
JWT expiration
```

These features can be difficult to test if the test depends directly on real wall-clock time.

A good testing strategy isolates time-dependent behavior where possible.

For example:

```text
Generate code
      |
      v
Controlled test time
      |
      v
Verify behavior
```

This makes expiration tests predictable.

---

# 54. Testing External Failure

External integrations should be tested not only when they succeed.

For example:

```text
OSRM
  |
  X
Timeout
```

or:

```text
Message Central
  |
  X
Unavailable
```

or:

```text
Razorpay
  |
  X
Payment failure
```

The application should respond according to its intended failure-handling behavior.

---

# 55. Testing Security Boundaries

Security testing should specifically attempt to cross boundaries.

Examples:

```text
Customer → Admin endpoint
Customer A → Customer B address
Customer → Store-owner operation
Store Owner A → Store Owner B store
Delivery Partner A → Delivery Partner B delivery
Unauthenticated user → Protected endpoint
```

These tests verify that authorization is enforced by the backend.

---

# 56. Testing Business State

LocalMart contains stateful processes.

Examples:

```text
Application:
PENDING → APPROVED / REJECTED

Delivery:
READY_FOR_PICKUP
→ ACCEPTED
→ PICKED_UP
→ OUT_FOR_DELIVERY
→ DELIVERED
```

Tests should verify:

```text
Valid transitions
Invalid transitions
Repeated transitions
Unauthorized transitions
Concurrent transitions
```

---

# 57. Testing the Database as the Source of Truth

LocalMart intentionally uses the database as the source of truth for shopping data.

Therefore tests should verify that:

```text
Store data
Product data
Cart data
Order data
Address data
```

are correctly persisted and retrieved.

The frontend should not be able to manufacture authoritative product or price information.

---

# 58. Testing Frontend–Backend Communication

The frontend and backend communicate through HTTP.

For example:

```text
React
  |
  | POST /api/orders/...
  v
Spring Boot
  |
  | JSON
  v
React
```

Tests should verify:

```text
Correct URL
Correct HTTP method
Correct request body
Correct authentication header
Correct response parsing
Correct error handling
```

---

# 59. Testing JSON Contracts

DTOs define the structure of many API requests and responses.

For example:

```text
JSON
  ↓
DTO
  ↓
Service
```

Tests should verify that expected JSON fields map correctly to DTO properties.

This helps detect accidental API contract changes.

---

# 60. Testing Configuration

External-service configuration should also be tested in deployment environments.

Important configuration areas include:

```text
Database
JWT
Google
X
SMTP
Message Central
Razorpay
Geocoding
OSRM
```

A configuration error can cause an otherwise correct application to fail at startup or during a request.

---

# 61. Test Levels Summary

| Test type            | Main purpose                                 |
| -------------------- | -------------------------------------------- |
| Unit                 | Test individual methods/classes              |
| Service              | Verify business logic                        |
| Repository           | Verify persistence/query behavior            |
| Integration          | Verify multiple backend components together  |
| API                  | Verify HTTP contracts                        |
| Security             | Verify authentication/authorization          |
| External integration | Verify third-party communication             |
| Database             | Verify persistence and mappings              |
| End-to-end           | Verify complete user workflows               |
| Manual               | Rapid development/debugging                  |
| Regression           | Ensure existing functionality remains intact |

---

# 62. Recommended Testing Flow for a New Feature

When adding a new LocalMart feature:

```text
1. Write/identify business rules
        ↓
2. Test validation
        ↓
3. Test service logic
        ↓
4. Test repository behavior
        ↓
5. Test controller/API
        ↓
6. Test authorization
        ↓
7. Test external integration if applicable
        ↓
8. Test complete workflow
        ↓
9. Run regression tests
```

This gives the feature multiple levels of verification.

---

# 63. Testing a New API Endpoint

For a new endpoint, verify:

```text
[ ] Correct HTTP method
[ ] Correct URL
[ ] Valid request succeeds
[ ] Invalid request fails
[ ] Missing fields fail
[ ] Authentication is enforced
[ ] Authorization is enforced
[ ] Resource ownership is enforced
[ ] Business rules are enforced
[ ] Correct status code is returned
[ ] Correct response body is returned
[ ] Exceptions are handled
```

---

# 64. Testing Checklist for LocalMart

### Authentication

```text
[ ] Registration
[ ] Email OTP
[ ] SMS OTP
[ ] TOTP
[ ] Google
[ ] X
[ ] Password login
[ ] JWT
[ ] Session
[ ] Logout
```

### Customer

```text
[ ] Profile
[ ] Address
[ ] Default address
[ ] Cart
[ ] Checkout
[ ] Orders
```

### Store

```text
[ ] Store registration
[ ] Admin approval
[ ] Store management
[ ] Product management
[ ] Store-owner authorization
```

### Delivery

```text
[ ] Delivery availability
[ ] Accept delivery
[ ] Status transitions
[ ] Location updates
[ ] Partner authorization
```

### Payment

```text
[ ] Amount calculation
[ ] Payment creation
[ ] Payment success
[ ] Payment failure
[ ] Duplicate/retry behavior
```

### Location

```text
[ ] Coordinate validation
[ ] Geocoding
[ ] Road distance
[ ] Delivery fee
[ ] External service failure
```

---

# 65. Testing and Error Handling

Testing and error handling are closely related.

For every important exception path:

```text
Operation
   |
   X
Exception
   |
   v
GlobalExceptionHandler
   |
   v
HTTP Response
```

the test should verify that the client receives the expected result.

For example:

```text
Invalid address
     ↓
Exception
     ↓
GlobalExceptionHandler
     ↓
400 response
```

The exact status and response structure should match the actual implementation.

---

# 66. Testing and Security

Security testing should never rely only on frontend behavior.

For example, hiding an Admin button in React is not authorization.

A test should directly attempt:

```text
POST /admin/...
Authorization: Bearer <customer-token>
```

and verify that the backend rejects the request.

The backend is the authoritative security boundary.

---

# 67. Testing Philosophy

The purpose of testing LocalMart is not simply to prove that the application works in the ideal scenario.

A stronger objective is:

```text
Valid input
     → Works

Invalid input
     → Rejected

Unauthorized operation
     → Rejected

Invalid business state
     → Rejected

External failure
     → Handled

Unexpected failure
     → Safely reported
```

This gives confidence that the system behaves correctly under both normal and abnormal conditions.

---

# 68. Overall Testing Architecture

The complete LocalMart testing architecture can be visualized as:

```text
                         LocalMart
                            |
              +-------------+-------------+
              |             |             |
              v             v             v
           Frontend       Backend      External APIs
              |             |             |
              |        +----+----+        |
              |        |         |        |
              |        v         v        |
              |    Controllers Services   |
              |                  |         |
              |                  v         |
              |             Repositories   |
              |                  |         |
              |                  v         |
              |              PostgreSQL    |
              |                            |
              +-------------+--------------+
                            |
                            v
                         Testing
                            |
        +-------------------+-------------------+
        |          |         |        |         |
        v          v         v        v         v
      Unit      API       Security  Database   E2E
```

---

# 69. Final Testing Principle

LocalMart testing follows a layered approach:

```text
Unit
 ↓
Service
 ↓
Repository
 ↓
Integration
 ↓
API
 ↓
Security
 ↓
External Integrations
 ↓
End-to-End
```

The most important principle is:

> **A feature is not considered reliable merely because its happy path works; its validation, authorization, business-state transitions, persistence, error handling, and failure scenarios must also be verified.**

LocalMart already has an automated test structure and a `TotpServiceTest`. As additional modules become stable, tests can be expanded around the highest-risk areas: authentication, authorization, cart/order integrity, payment, delivery-state transitions, and external integrations.
