package com.localmart.localmartbackend.dto;

public class AdminLoginOtpRequest {

    private String identifier;
    private String password;
    private String channel;

    public AdminLoginOtpRequest() {
    }

    public String getIdentifier() {
        return identifier;
    }

    public void setIdentifier(String identifier) {
        this.identifier = identifier;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }
}